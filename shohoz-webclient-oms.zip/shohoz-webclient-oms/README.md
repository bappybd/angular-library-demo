# Outlet Management System

## Change Log

### Date: 12/07/2021

1. Added Sort order and Operating hours column in the shop list table.
2. Added Operating hour filter in shop list.
3. Search UI updated.   
4. Updated version info 1.0.5 
