import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {AssignFilterOption, AssignFilterQuery} from '../../models/coupon-assign-models';
import {MatDialog} from '@angular/material/dialog';
import {AdvancedFilterComponent} from '../advanced-filter/advanced-filter.component';
import {CouponEntityType} from '../../../shared/models/coupon-entity-models';

@Component({
  selector: 'app-assign-filter',
  templateUrl: './assign-filter.component.html',
  styleUrls: ['./assign-filter.component.scss']
})
export class AssignFilterComponent implements OnInit {
  @Output() filterQuery: EventEmitter<AssignFilterQuery> = new EventEmitter();

  @Input()
  options: Subject<AssignFilterOption>;

  filterForm: FormGroup;
  hasAdvancedFilter = false;
  filter = new AssignFilterQuery();
  searchOptions = new AssignFilterOption();

  constructor(
    public dialog: MatDialog,
    private formBuilder: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.getSearchFilterOptions();
    this.initFilterForm();
    this.onFilterChanges();
  }

  getSearchFilterOptions(): void {
    this.options.subscribe(data => {
      this.searchOptions = data;
      if (this.searchOptions.formReset) {
        this.filterForm.reset();
      }

      if (this.searchOptions) {
        if (!this.searchOptions.searchKey || this.searchOptions.searchKey === '') {
          this.filterForm.get('searchKey').setValue(this.searchOptions.searchKey);
        }
      }

    });
  }

  initFilterForm(): void {
    this.filterForm = this.formBuilder.group({
      searchKey: [''],
    });
  }

  onFilterChanges(): void {
    this.filterForm.get('searchKey').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        if (!this.hasAdvancedFilter) {
          this.filter.searchKey = value;
          this.filter.assignType = this.searchOptions.assignType;
          this.filter.searchForm = null;
          this.filterQuery.emit(this.filter);
        }
        this.hasAdvancedFilter = false;
      });
  }

  advancedFilter(): void {
    const dialogRef = this.dialog.open(AdvancedFilterComponent, {
      panelClass: 'advanced-filter-dialog',
      data: this.searchOptions
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result && result.formValue) {
        this.filter.searchKey = '';
        this.filter.assignType = result.assignType;
        this.filter.searchForm = result.formValue;
        this.filterQuery.emit(this.filter);

        this.hasAdvancedFilter = true;

        if (this.searchOptions) {
          if (this.searchOptions.assignType === CouponEntityType.Shop) {
            this.filterForm.get('searchKey').setValue(result.formValue.shopName);
          } else if (this.searchOptions.assignType === CouponEntityType.ProductCategory) {
            this.filterForm.get('searchKey').setValue(result.formValue.categoryName);
          } else if (this.searchOptions.assignType === CouponEntityType.Product) {
            this.filterForm.get('searchKey').setValue(result.formValue.productName);
          }
        } else {
          this.filterForm.get('searchKey').setValue(result.formValue.shopName);
        }

      }
    });
  }

}
