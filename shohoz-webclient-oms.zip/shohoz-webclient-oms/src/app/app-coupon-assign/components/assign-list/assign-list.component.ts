import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import {AssignFilterQuery, AssignInfoModel, AssignListOptions} from '../../models/coupon-assign-models';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {Subject} from 'rxjs';
import {Router} from '@angular/router';
import {MatDialog} from '@angular/material/dialog';
import {EevoQueryService} from '@eevo/eevo-core';
import {CouponAssignEntity} from '../../entities/coupon-assign-entity';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {CouponEntityType} from '../../../shared/models/coupon-entity-models';

@Component({
  selector: 'app-assign-list',
  templateUrl: './assign-list.component.html',
  styleUrls: ['./assign-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AssignListComponent implements OnInit {
  @Input()
  assignType: CouponEntityType;

  @Input()
  couponDetails: any;

  @Input()
  options: Subject<AssignListOptions>;

  @Output() selectedAssignInfo: EventEmitter<AssignInfoModel> = new EventEmitter();

  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('nameCell', {static: true}) nameCellTemplate: TemplateRef<any>;
  @ViewChild('zoneCell', {static: true}) zoneCellTemplate: TemplateRef<any>;
  @ViewChild('shopZoneCell', {static: true}) shopZoneCellTemplate: TemplateRef<any>;
  @ViewChild('categoriesCell', {static: true}) categoriesCellTemplate: TemplateRef<any>;
  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);

  isLoading = true;
  searchKey: string;
  tableOptions: any = {};
  searchOptions: AssignFilterQuery;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private eevoQueryService: EevoQueryService,
    private couponAssignEntity: CouponAssignEntity,
    @Inject('config') private config: any
  ) {
  }

  ngOnInit(): void {
    this.getSearchFilterData();

    this.prepareDataTable();
  }

  getSearchFilterData(): void {
    this.options.subscribe( (data: AssignFilterQuery) => {
      this.searchOptions = data;
      this.datatableModel.CurrentPageNumber = 0;
      this.loadData();
    });
  }

  getFileKey(shop: any): string {
    return this.couponAssignEntity.getFileKey(
      shop.Id, 'logo', 'png', 'shop'
    );
  }

  selectData(dataTableRow: any): void {

  }

  fetchDataRequired(): void {
    this.loadData();
    this.topFunction();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private loadData(): void {
    if (this.assignType === CouponEntityType.Shop) {
      this.getShops();
    } else if (this.assignType === CouponEntityType.Product) {
      this.getProduct();
    }  else if (this.assignType === CouponEntityType.ProductCategory) {
      this.getProductCategories();
    }
  }

  private getShops(): void {
    let filter = '{}';
    const entityName = this.couponAssignEntity.getShopEntityName();
    const fields = this.couponAssignEntity.getShopListFields();

    const so = this.searchOptions;
    if (so && so.searchForm && so.searchForm.shopName && so.searchForm.shopName.length > 0) {
      filter = `{ Name: /${so.searchForm.shopName}/i }`;
    } else if (so && so.searchKey && so.searchKey.length > 0) {
      filter = `{ Name: /${so.searchKey}/i }`;
    }

    this.getList(this.datatableModel, entityName, fields, filter);

    this.setSelectedAssignInfo({
      filter,
      assignType: CouponEntityType.Shop,
    } as AssignInfoModel);
  }

  private getProduct(): void {
    let filter = '{}';
    const entityName = this.couponAssignEntity.getProductEntityName();
    const fields = this.couponAssignEntity.getProductListFields();

    const so = this.searchOptions;
    if (so && so.searchForm) {
      const query = [];
      if (so.searchForm.shopName && so.searchForm.shopName.length > 0) {
        query.push(`{ ShopName: /${so.searchForm.shopName}/i }`);
      }
      if (so.searchForm.categoryName && so.searchForm.categoryName.length > 0) {
        query.push(`{ ProductCategories: { $elemMatch: { ProductCategoryName: /${so.searchForm.categoryName}/i } } }`);
      }
      if (so.searchForm.productName && so.searchForm.productName.length > 0) {
        query.push(`{ Name: /${so.searchForm.productName}/i }`);
      }
      filter = `{$and: [${query.join(',')}]}`;
    } else if (so && so.searchKey && so.searchKey.length > 0) {
      filter = `{ Name: /${so.searchKey}/i }`;
    }

    this.getList(this.datatableModel, entityName, fields, filter);

    this.setSelectedAssignInfo({
      filter,
      assignType: CouponEntityType.Product,
    } as AssignInfoModel);
  }

  private getProductCategories(): void {
    let filter = '{}';
    const entityName = this.couponAssignEntity.getProductCategoryEntityName();
    const fields = this.couponAssignEntity.getProductCategoryListFields();

    const so = this.searchOptions;
    if (so && so.searchForm) {
      const query = [];
      if (so.searchForm.shopName && so.searchForm.shopName.length > 0) {
        query.push(`{ ShopName: /${so.searchForm.shopName}/i }`);
      }
      if (so.searchForm.categoryName && so.searchForm.categoryName.length > 0) {
        query.push(`{ Name:  /${so.searchForm.categoryName}/i }`);
      }
      filter = `{$and: [${query.join(',')}]}`;
    } else if (so && so.searchKey && so.searchKey.length > 0) {
      filter = `{ Name: /${so.searchKey}/i }`;
    }

    this.getList(this.datatableModel, entityName, fields, filter);

    this.setSelectedAssignInfo({
      filter,
      assignType: CouponEntityType.ProductCategory,
    } as AssignInfoModel);
  }

  private topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  private prepareDataTable(): void {
    this.tableOptions = {
      columns: [] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
      assignType: CouponEntityType.None
    };

    if (this.assignType === CouponEntityType.Shop) {

      this.tableOptions.columns = [
        {
          prop: 'Name',
          name: 'Name',
          flexGrow: 1.5,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.nameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Address',
          name: 'Zone',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.zoneCellTemplate,
          draggable: true,
          sortable: true,
        }
      ] as TableColumn[];

    } else if (this.assignType === CouponEntityType.Product) {

      this.tableOptions.columns = [
        {
          prop: 'Name',
          name: 'Item Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.nameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ProductCategories',
          name: 'Categories Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.categoriesCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopName',
          name: 'Restaurant Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopZone',
          name: 'Restaurant Zone',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.shopZoneCellTemplate,
          draggable: true,
          sortable: true,
        }
      ] as TableColumn[];

    }  else if (this.assignType === CouponEntityType.ProductCategory) {

      this.tableOptions.columns = [
        {
          prop: 'Name',
          name: 'Name',
          flexGrow: 1.5,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.nameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopName',
          name: 'Restaurant Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopZone',
          name: 'Restaurant Zone',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.shopZoneCellTemplate,
          draggable: true,
          sortable: true,
        }
      ] as TableColumn[];

    }

    this.loadData();
    this.initDataTable();
  }

  private initDataTable(): void {
    this.datatableModel.SortBy = this.tableOptions.defaultSort;
    this.datatableModel.Descending = this.tableOptions.descending;
    this.datatableModel.PageSize = this.tableOptions.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.tableOptions.columns;
      this.datatable.messages = this.tableOptions.messages;
    }
  }

  private getList(tableModel: DatatableModel<any>, entityName: string, fields: string[], filter = '{}'): void {
    this.isLoading = true;

    const url = this.config.ShopService.toQueryURL();

    this.eevoQueryService.getListCount(url, entityName, filter).subscribe((total) => {
      if (total) {
        this.eevoQueryService.getList(
          url,
          entityName,
          fields,
          filter,
          tableModel.CurrentPageNumber,
          tableModel.PageSize,
          tableModel.SortBy,
          tableModel.Descending
        ).subscribe((response) => {
            this.setData(total, response);
          }, (error) => {
            this.setData(0);
          }
        );
      } else {
        this.setData(0);
      }
    });

  }

  private setData(totalCount, data: any[] = []): void {

    this.datatableModel = {
      Data: data,
      TotalElements: totalCount,
      ColumnMode: ColumnMode.flex,
      SortBy: this.datatableModel.SortBy,
      PageSize: this.datatableModel.PageSize,
      Descending: this.datatableModel.Descending,
      CurrentPageNumber: this.datatableModel.CurrentPageNumber,
    };

    this.isLoading = false;
  }

  private setSelectedAssignInfo(assignInfo: AssignInfoModel): void {
    this.selectedAssignInfo.emit(assignInfo);
  }
}
