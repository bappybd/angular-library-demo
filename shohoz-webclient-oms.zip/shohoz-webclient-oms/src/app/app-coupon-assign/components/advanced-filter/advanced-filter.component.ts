import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {FormBuilder, FormGroup} from '@angular/forms';
import {AssignFilterOption, AssignSearchForm} from '../../models/coupon-assign-models';

@Component({
  selector: 'app-advanced-filter',
  templateUrl: './advanced-filter.component.html',
  styleUrls: ['./advanced-filter.component.scss']
})
export class AdvancedFilterComponent implements OnInit {
  searchForm: FormGroup;
  formData: AssignFilterOption;

  constructor(
    public dialogRef: MatDialogRef<AdvancedFilterComponent>,
    @Inject(MAT_DIALOG_DATA) private data: AssignFilterOption,
    private formBuilder: FormBuilder
  ) {
    if (!this.data) {
      this.formData = new AssignFilterOption();
    } else {
      this.formData = data;
    }
  }

  ngOnInit(): void {
    this.searchForm = this.formBuilder.group({
      shopName: [this.formData && this.formData.shopName || ''],
      productName: [this.formData && this.formData.productName || ''],
      categoryName: [this.formData && this.formData.categoryName || ''],
    });
  }

  search(): void {
    const formData = {
      assignType: this.formData.assignType,
      formValue: this.searchForm.value as AssignSearchForm
    };

    this.dialogRef.close(formData);
  }
}
