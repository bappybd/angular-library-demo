import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {debounceTime, distinctUntilChanged, map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-data-filter',
  templateUrl: './data-filter.component.html',
  styleUrls: ['./data-filter.component.scss']
})
export class DataFilterComponent implements OnInit {
  @Output() getDataOnSubmit: EventEmitter<any> = new EventEmitter();

  filterForm: FormGroup;

  filter = {
    searchKey: '',
  };

  constructor(
    private formBuilder: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.initFilterForm();
    this.onFilterChanges();
  }

  initFilterForm(): void {
    this.filterForm = this.formBuilder.group({
      searchKey: [''],
    });
  }

  onFilterChanges(): void {
    this.filterForm.get('searchKey').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.filter.searchKey = value;
        this.getDataOnSubmit.emit(this.filter);
      });
  }

}
