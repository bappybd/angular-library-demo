import {
  Component,
  EventEmitter, Inject,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import {Router} from '@angular/router';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {MatDialog} from '@angular/material/dialog';
import {CouponAssignEntity} from '../../entities/coupon-assign-entity';
import {EevoQueryService} from '@eevo/eevo-core';
import {SelectionModel} from '@angular/cdk/collections';
import {Subject} from 'rxjs';
import {MatCheckboxChange} from '@angular/material/checkbox';
import {AssignInfoModel} from '../../models/coupon-assign-models';
import {CouponEntityType} from '../../../shared/models/coupon-entity-models';

@Component({
  selector: 'app-shop-list',
  templateUrl: './shop-list.component.html',
  styleUrls: ['./shop-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ShopListComponent implements OnInit {
  @Output() selectedAssignInfo: EventEmitter<AssignInfoModel> = new EventEmitter();

  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('selectionCell', {static: true}) selectionCellTemplate: TemplateRef<any>;
  @ViewChild('nameCell', {static: true}) nameCellTemplate: TemplateRef<any>;
  @ViewChild('zoneCell', {static: true}) zoneCellTemplate: TemplateRef<any>;
  @ViewChild('contactCell', {static: true}) contactCellTemplate: TemplateRef<any>;

  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;

  @Input()
  searchFilter: Subject<any>;

  selection = new SelectionModel<any>(true, []);

  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  searchKey: string;
  shopFilter;
  isLoading = true;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private eevoQueryService: EevoQueryService,
    private couponAssignEntity: CouponAssignEntity,
    @Inject('config') private config: any
  ) {
  }

  ngOnInit(): void {
    this.prepareDataTable();

    this.getSearchFilterData();
  }

  getSearchFilterData(): void {
    this.searchFilter.subscribe(data => {
      // this.datatableModel.CurrentPageNumber = 0;
      // this.getShopList(this.datatableModel, this.shopFilter);
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Item Selected (Section) methods
  // -----------------------------------------------------------------------------------------------------

  setSelectedShopList(): void {
    setTimeout(() => {
      const assignInfoModel = new AssignInfoModel();
      assignInfoModel.dataList = this.selection.selected;
      assignInfoModel.assignType = CouponEntityType.Shop;
      this.selectedAssignInfo.emit(assignInfoModel);
    }, 100);
  }

  clearSelectionList(): void {
    const dataRows = this.datatableModel.Data;
    this.selection.selected.forEach((data, index) => {
      const row = dataRows.find(f => {
        return f.Id === data;
      });
      if (row) {
        this.selection.toggle(data);
      }
    });
  }

  isAllSelected(): boolean {
    const currentPageSelected = [];
    const dataSelected = this.selection.selected;
    const dataRows = this.datatableModel.Data;

    dataRows.forEach(data => {
      const currentSelected = dataSelected.find(f => {
        return f === data.Id;
      });

      if (currentSelected) {
        currentPageSelected.push(currentSelected);
      }
    });

    const numRows = dataRows.length;
    const numSelected = currentPageSelected.length;

    return numSelected === numRows;
  }

  masterToggle(): void {
    this.isAllSelected() ?
      this.clearSelectionList() :
      this.datatableModel.Data.forEach(row => {
        this.selection.select(row.Id);
      });

    this.setSelectedShopList();
  }

  selectionChange($event: MatCheckboxChange, row: any): void {
    this.selection.toggle(row.Id);
    this.setSelectedShopList();
  }

  applicableForAll($event: MatCheckboxChange): void {
    const assignInfoModel = new AssignInfoModel();
    assignInfoModel.assignType = CouponEntityType.Shop;

    if ($event && $event.checked) {
      this.selection.clear();
      assignInfoModel.isApplicableForAll = true;
    }

    this.selectedAssignInfo.emit(assignInfoModel);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Data Table (Section) methods
  // -----------------------------------------------------------------------------------------------------

  getFileKey(shop: any): string {
    return this.couponAssignEntity.getFileKey(
      shop.Id, 'logo', 'png', 'shop'
    );
  }

  selectData(dataTableRow: any): void {
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getShopList(tableModel, this.shopFilter);
    this.topFunction();
  }

  private topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: '-',
          name: 'checkbox',
          maxWidth: '50px',
          headerTemplate: this.headerTemplate,
          cellTemplate: this.selectionCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Name',
          name: 'Name',
          flexGrow: 1.5,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.nameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'EmergencyContactDetails.Email',
          name: 'Contact',
          flexGrow: 1.2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.contactCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Affordability',
          name: 'Affordability',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Address',
          name: 'Zone',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.zoneCellTemplate,
          draggable: true,
          sortable: true,
        },
      ] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.getShopList(this.datatableModel, this.shopFilter);
    this.initDataTable();
  }

  private initDataTable(): void {
    // this.datatableModelInput.subscribe(response => {
    //   this.datatableModel.TotalElements = response ? response[1][0][0] : 0;
    //   this.datatableModel.Data = response ? response[0] : [];
    // }, err => console.log(err));

    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  private getShopList(tableModel: DatatableModel<any>, shopFilter?: any): void {
    this.isLoading = true;
    const entityName = this.couponAssignEntity.getShopEntityName();
    const fields = this.couponAssignEntity.getShopListFields();
    let filter = '{}';

    if (shopFilter && shopFilter.searchKey && shopFilter.searchKey.length > 0) {
      filter += `{ Name: /` + shopFilter.searchKey + `/i }`;
    }
    const url = this.config.ShopService.toQueryURL();

    this.eevoQueryService.getListCount(url, entityName, filter).subscribe((total) => {
      if (total) {
        this.eevoQueryService.getList(
          url, entityName, fields, filter, tableModel.CurrentPageNumber, tableModel.PageSize,
          tableModel.SortBy, tableModel.Descending).subscribe((response) => {
            this.setShopData(total, response);
          },
          (error) => {
            this.setShopData(0);
          });
      } else {
        this.setShopData(0);
      }
    });

  }

  private setShopData(totalCount, data: any[] = []): void {

    this.datatableModel = {
      PageSize: this.datatableModel.PageSize,
      TotalElements: totalCount,
      CurrentPageNumber: this.datatableModel.CurrentPageNumber,
      SortBy: this.datatableModel.SortBy,
      Descending: this.datatableModel.Descending,
      Data: data,
      ColumnMode: ColumnMode.flex
    };

    this.isLoading = false;
  }

}
