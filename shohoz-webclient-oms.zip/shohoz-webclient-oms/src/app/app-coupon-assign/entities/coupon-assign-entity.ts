import {Injectable} from '@angular/core';
import {EevoDefaultMessage, EevoEntityRoot} from '@eevo/eevo-core';

enum CouponEvents {
  CouponBusinessRuleViolatedEvent = 'CouponBusinessRuleViolationEvent',
  AttachCouponByFilterEvent = 'AttachCouponByFilterEvent',
  DetachCouponByFilterEvent = 'DetachCouponByFilterEvent',
  AssignCouponEvent = 'AssignCouponEvent',
  CouponAttachSucceededEvent = 'CouponAttachSucceededEvent',
}

@Injectable({
  providedIn: 'root'
})
export class CouponAssignEntity extends EevoEntityRoot {
  Events = CouponEvents;

  constructor() {
    super('CouponViewModels');
  }

  getDetailsFields(): string[] {
    return [
      'CouponName', 'Category', 'ValidFrom', 'ValidTill', 'MaximumDiscountAmount', 'CouponLogics',
      'Rank', 'SupportedCouponIds', 'Description_En', 'Description_Bn', 'HighlightText_Bn',
      'HighlightText_En', 'MaxRedeemCountPerUser', 'MaxRedeemCountPerUserPerDay',
      'MaxRedeemCount', 'ShohozPortionOfDiscount', 'CouponCode', 'AutoApplied', 'CouponState',
      'CityIds', 'PaymentMethodIds', 'DiscountPartnerIds', 'IsProductCoupon'
    ];
  }

  getListFields(): string[] {
    return [
      'CouponName', 'ValidFrom', 'ValidTill', 'CouponState', 'Rank', 'CouponCode'
    ];
  }


  // Assign Coupon
  getShopEntityName(): string {
    return 'ShopLists';
  }

  getShopListFields(): string[] {
    return [
      'Name', 'Address'
    ];
  }

  getProductCategoryEntityName(): string {
    return 'ProductCategoryLists';
  }

  getProductCategoryListFields(): string[] {
    return [
      'Name', 'ShopName', 'ShopZone'
    ];
  }

  getProductEntityName(): string {
    return 'ProductLists';
  }

  getProductListFields(): string[] {
    return [
      'Name', 'ShopName', 'ShopZone', 'ProductCategories'
    ];
  }


  // Coupon Attached
  getAttachedCouponEntityName(): string {
    return 'AttachedCouponViewModels';
  }

  getAttachedCouponListFields(): string[] {
    return [
      'CouponId', 'EntityIds', 'CouponEntityType'
    ];
  }

  getCouponAttachedToShopEntityName(): string {
    return 'CouponAttachedToShopViewModels';
  }

  getCouponAttachedToShopListFields(): string[] {
    return [
      'Name', 'Address', 'CouponInfos'
    ];
  }

  getCouponAttachedToProductCategoryEntityName(): string {
    return 'CouponAttachedToProductCategoryViewModels';
  }

  getCouponAttachedToProductCategoryListFields(): string[] {
    return [
      'Name', 'ShopName', 'ShopZone', 'CouponInfos'
    ];
  }

  getCouponAttachedToProductEntityName(): string {
    return 'CouponAttachedToProductViewModels';
  }

  getCouponAttachedToProductListFields(): string[] {
    return [
      'Name', 'ShopName', 'ShopZone', 'ProductCategories', 'CouponInfos'
    ];
  }
}
