import {EevoCommandBase} from '@eevo/eevo-core';
import {CouponEntityType} from '../../shared/models/coupon-entity-models';

// Assign by EntityIds
export class CouponAssignCommand extends EevoCommandBase {
  CouponIds: string[];
  EntityIds: string[];
  CouponEntityType: CouponEntityType;

  constructor() {
    super();
  }
}

export class CouponAttachCommand extends CouponAssignCommand {
  constructor() {
    super();
  }
}

export class CouponDetachCommand extends CouponAssignCommand {
  constructor() {
    super();
  }
}

// Assign by Filter
export class CouponAssignByFilterCommand extends EevoCommandBase {
  Filter: string;
  CouponIds: string[];
  CouponEntityType: CouponEntityType;

  constructor() {
    super();
  }
}

export class AttachCouponsByFilterCommand extends CouponAssignByFilterCommand {
  constructor() {
    super();
  }
}

export class DetachCouponsByFilterCommand extends CouponAssignByFilterCommand {
  constructor() {
    super();
  }
}
