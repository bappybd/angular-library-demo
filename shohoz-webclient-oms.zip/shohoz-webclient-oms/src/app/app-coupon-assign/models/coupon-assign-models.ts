import {CouponEntityType} from '../../shared/models/coupon-entity-models';

export interface Coupon {
  _id: string;
  Name: string;
  Category: string;
  ValidFrom: string;
  ValidTill: string;
  Active: string;
  Weight: string;
}

export interface CouponListResponse {
  data: Coupon[];
  totalCount: number;
}

export interface CouponFilter {
  searchKey: string;
  status: string;
  affordability: string;
  zone: any;
}

export interface AssignListOptions {
  searchKey: string;
  assignType: CouponEntityType;
}

export class AssignFilterQuery {
  searchKey: string;
  assignType: CouponEntityType;
  searchForm: AssignSearchForm;
}

export class AssignSearchForm {
  shopName: string;
  categoryName: string;
  productName: string;
}

export class AssignFilterOption {
  formReset: boolean;
  assignType: CouponEntityType;
  searchKey: string;
  shopName: string;
  categoryName: string;
  productName: string;

  constructor() {
    this.formReset = false;
    this.assignType = CouponEntityType.Shop;
    this.searchKey = null;
    this.shopName = null;
    this.categoryName = null;
    this.productName = null;
  }
}

export interface CouponAttachTabInfo {
  index: number;
  label: string;
  assignType: CouponEntityType;
  assignInfo: AssignInfoModel;
}

export class AssignInfoModel {

  filter: string;
  assignType: CouponEntityType;
  isApplicableForAll: boolean;
  dataList: Array<string>;
  userPhoneNumbers: Array<string>;

  constructor() {
    this.filter = '{}';
    this.assignType = CouponEntityType.None;
    this.isApplicableForAll = false;
    this.dataList = new Array<string>();
    this.userPhoneNumbers = new Array<string>();
  }
}
