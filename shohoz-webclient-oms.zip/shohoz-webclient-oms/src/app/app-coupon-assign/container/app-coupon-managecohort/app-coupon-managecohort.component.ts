import {Component, Inject, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {CouponEntityType, CouponModel} from '../../../shared/models/coupon-entity-models';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {CouponAssignEntity} from '../../entities/coupon-assign-entity';
import {fuseAnimations} from '@eevo/eevo-base';
import {CouponAssignCommandService} from '../../services/coupon-assign-command.service';
import {CouponAssignCommandBuilder} from '../../services/coupon-assign-command-builder';
import {CouponAssignNotificationService} from '../../services/coupon-assign-notification.service';
import {CouponAssignQueryService} from '../../services/coupon-assign-query.service';

@Component({
  selector: 'app-app-coupon-managecohort',
  templateUrl: './app-coupon-managecohort.component.html',
  styleUrls: ['./app-coupon-managecohort.component.scss'],
  animations: fuseAnimations
})
export class AppCouponManagecohortComponent implements OnInit {

  couponId: string;
  details: any;
  formSubmitted = false;
  loadingFromServer = true;
  cohortForm: FormGroup;
  couponDetails: CouponModel;
  breadcrumbList: BreadcrumbModel[] = [];

  constructor(
    private router: Router,
    private actRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private eevoNotifyService: EevoNotifyService,
    private eevoQueryService: EevoQueryService,
    private couponAssignEntity: CouponAssignEntity,
    private couponAssignQueryService: CouponAssignQueryService,
    private couponAssignCommandService: CouponAssignCommandService,
    private couponAssignCommandBuilder: CouponAssignCommandBuilder,
    private couponAssignNotificationService: CouponAssignNotificationService,
    @Inject('config') private config: any
  ) {
    this.couponId = this.actRoute.snapshot.params.id;
  }

  ngOnInit(): void {
    this.cohortForm = this.formBuilder.group({
      UserPhoneList: [''],
    });

    this.getAssignCouponsDetails();

    this.getCouponDetails();

  }

  goToCouponListPage(): void {
    this.router.navigate(['coupon']);
  }

  manageCohort(): void {
    const userPhoneNumberValue = this.cohortForm.get('UserPhoneList').value;


      const userPhoneNumbers = userPhoneNumberValue.trim().split(',');
      const userPhoneNumberList = [];
      userPhoneNumbers.forEach(phone => {
        const pn = phone.trim();
        if (pn) {
          userPhoneNumberList.push(pn);
        }
      });


        this.formSubmitted = true;
        const command = this.couponAssignCommandBuilder.getAssignCouponsCommand(this.couponId, userPhoneNumberList, CouponEntityType.User);

        this.couponAssignNotificationService.couponAttachSucceeded();
        this.eevoNotifyService.displayMessage('Assign coupon request submitted!', NotifyType.Info);

        this.couponAssignCommandService.assignCoupon(command).subscribe(data => {
          this.goToCouponListPage();
          this.formSubmitted = false;
        }, error => {
          this.formSubmitted = false;
          this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        });




  }

  private getCouponDetails(): void {
    this.loadingFromServer = true;
    const url = this.config.CouponService.toQueryURL();
    this.eevoQueryService.getDetailsById<CouponModel>(
      url,
      this.couponAssignEntity.getDetailsName(),
      this.couponId,
      this.couponAssignEntity.getDetailsFields()
    ).subscribe((data) => {
      this.loadingFromServer = false;
      if (data && data.Id) {
        data.CouponId = data.Id;
        this.couponDetails = data;
        this.setBreadcrumbData();
      }
    });
  }

  private getAssignCouponsDetails(): void {
    this.couponAssignQueryService.getAttachedCouponByIdAndType(
      this.couponId,
      CouponEntityType.User
    ).subscribe((data) => {
      if (data) {
        this.details = data;
        if (this.details && this.details.EntityIds) {
          this.cohortForm.get('UserPhoneList').setValue(this.details.EntityIds.join(','));
        }
      }
    });
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Coupons',
      Path: ['/coupon']
    });

    this.breadcrumbList.push({
      Text: 'Manage Cohort',
    });

    this.breadcrumbList.push({
      Text: this.couponDetails.CouponCode
    });
  }

}
