import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCouponManagecohortComponent } from './app-coupon-managecohort.component';

describe('AppCouponManagecohortComponent', () => {
  let component: AppCouponManagecohortComponent;
  let fixture: ComponentFixture<AppCouponManagecohortComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCouponManagecohortComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCouponManagecohortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
