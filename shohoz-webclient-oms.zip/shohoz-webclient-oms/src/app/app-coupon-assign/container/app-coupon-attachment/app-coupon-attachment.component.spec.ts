import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCouponAttachmentComponent } from './app-coupon-attachment.component';

describe('AppCouponAttachmentComponent', () => {
  let component: AppCouponAttachmentComponent;
  let fixture: ComponentFixture<AppCouponAttachmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCouponAttachmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCouponAttachmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
