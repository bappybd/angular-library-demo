import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Inject,
  Input, OnDestroy,
  OnInit,
  Output,
  ViewEncapsulation
} from '@angular/core';
import {Observable, Subject, Subscription} from 'rxjs';
import {CouponEntityType, CouponModel, CouponState} from '../../../shared/models/coupon-entity-models';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {ActivatedRoute, Router} from '@angular/router';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {CouponAssignEntity} from '../../entities/coupon-assign-entity';
import {CouponAssignCommandService} from '../../services/coupon-assign-command.service';
import {CouponAssignCommandBuilder} from '../../services/coupon-assign-command-builder';
import {fuseAnimations} from '@eevo/eevo-base';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {MatDialog} from '@angular/material/dialog';
import {CouponAssignNotificationService} from '../../services/coupon-assign-notification.service';
import {DatatableHelperService, EevoAdvanceDatatableOptions, FinalFilterQueryEvent} from "@eevo/eevo-platform-advance-datatable";
import {SubSink} from "subsink";

@Component({
  selector: 'app-app-coupon-attachment',
  templateUrl: './app-coupon-attachment.component.html',
  styleUrls: ['./app-coupon-attachment.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class AppCouponAttachmentComponent implements OnInit, OnDestroy, AfterViewInit {
  couponId: string;
  selectedIndex: number;
  formSubmitted = false;
  loadingFromServer = true;
  couponDetails: CouponModel;
  breadcrumbList: BreadcrumbModel[] = [];
  private subs = new SubSink();

  queryFilters: Subject<any> = new Subject<any>();
  searchFilterOptions: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  tableConfigOptions: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  datatableConfigOptions: EevoAdvanceDatatableOptions;
  selectedTabIndex: Subject<number> = new Subject<number>();
  searchQueryResult: string;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    public cd: ChangeDetectorRef,
    private actRoute: ActivatedRoute,
    private eevoNotifyService: EevoNotifyService,
    private eevoQueryService: EevoQueryService,
    private couponAssignEntity: CouponAssignEntity,
    private couponAssignCommandService: CouponAssignCommandService,
    private couponAssignCommandBuilder: CouponAssignCommandBuilder,
    private couponAssignNotificationService: CouponAssignNotificationService,
    private datatableHelperService: DatatableHelperService,
    @Inject('config') private config: any
  ) {
    this.selectedIndex = 0;
    this.couponId = this.actRoute.snapshot.params.id;
  }

  ngOnInit(): void {
    this.getCouponDetails();
  }

  ngOnDestroy(): void {
   this.subs.unsubscribe();
  }

  ngAfterViewInit(): void {
  }

  goToCouponListPage(): void {
    this.router.navigate(['coupon']);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  assignCoupon(): void {
    let assignType = CouponEntityType.Shop;
    if (this.selectedIndex === 1) {
      assignType = CouponEntityType.ProductCategory;
    } else if (this.selectedIndex === 2) {
      assignType = CouponEntityType.Product;
    }
    if (this.searchQueryResult) {
      let commandObserver: Observable<any>;
      const command = this.couponAssignCommandBuilder.getAttachCouponsByFilterCommand(
        this.couponId, this.searchQueryResult, assignType
      );
      commandObserver = this.couponAssignCommandService.attachCouponByFilter(command);

      this.couponAssignNotificationService.couponAttachSucceeded();
      this.eevoNotifyService.displayMessage('Attach coupon by filter request submitted!', NotifyType.Info);

      this.formSubmitted = true;

      this.subs.sink = commandObserver.subscribe(data => {
        this.formSubmitted = false;
        this.goToCouponListPage();
      }, error => {
        this.formSubmitted = false;
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
      });
    } else {
      this.eevoNotifyService.displayMessage('Invalid request', NotifyType.Error);
    }

  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private getCouponDetails(): void {
    this.loadingFromServer = true;

    const url = this.config.CouponService.toQueryURL();

    this.subs.sink = this.eevoQueryService.getDetailsById<CouponModel>(
      url,
      this.couponAssignEntity.getDetailsName(),
      this.couponId,
      this.couponAssignEntity.getDetailsFields()
    ).subscribe((data) => {
      this.loadingFromServer = false;
      if (data && data.Id) {
        data.CouponId = data.Id;
        this.couponDetails = data;
        this.setBreadcrumbData();
        this.loadAdvanceDatatable();
      }
    });
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Coupons',
      Path: ['/coupon']
    });

    this.breadcrumbList.push({
      Text: 'Assignment',
    });

    this.breadcrumbList.push({
      Text: this.couponDetails.CouponCode
    });
  }

  loadAdvanceDatatable(): void {
    const datatableConfigOptions = new EevoAdvanceDatatableOptions();
    datatableConfigOptions.NavId = '116bcde2-f5db-4202-be7d-f15a80bad7ce';
    datatableConfigOptions.TableConfigId = '';
    datatableConfigOptions.TabIndex = 0;
    datatableConfigOptions.InitialFilters = null;
    datatableConfigOptions.ApplySearchFilterToAllTab = false;

    this.datatableConfigOptions = datatableConfigOptions;
    this.tableConfigOptions.next(datatableConfigOptions);

    const searchFilterOptions = new EevoAdvanceDatatableOptions();
    searchFilterOptions.TableConfigId = 'da30a08c-9de8-4e73-9436-d9a878448d47';

    this.searchFilterOptions.next(searchFilterOptions);
  }

  searchFilterOnSubmit($event): void {
    this.queryFilters.next($event);
  }

  sideBarAction($event): void {

  }

  filterInitializeCompleted($event): void {
  }

  hasTabChangeAccess($event: any): void {
    if (this.searchQueryResult && this.searchQueryResult !== '{}' && this.searchQueryResult !== '') {
      // if form is dirty, show a warning modal and don't change tab.
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        data: {
          title: 'Confirmation',
          message: `Are you sure you want to change without save?`,
          buttonText: {
            ok: 'Yes',
            cancel: 'Cancel'
          }
        }
      });

      dialogRef.afterClosed().subscribe((confirmed: boolean) => {
        if (confirmed) {
          this.selectedTabIndex.next($event.selectedIndex);
        }
      });
    } else {
      // if form is not dirty, change the tab
      this.selectedTabIndex.next($event.selectedIndex);
    }
  }

  onTabChanged($event: any) {
    this.selectedIndex = $event?.currentIndex;
    const searchFilterOptions = new EevoAdvanceDatatableOptions();
    searchFilterOptions.TableConfigId = $event?.currentTabConfig?.DataTableConfigId;

    this.datatableConfigOptions.TabIndex = $event?.currentIndex;
    this.tableConfigOptions.next(this.datatableConfigOptions);
    this.searchFilterOptions.next(searchFilterOptions);
  }

  finalFilterQuery($event: FinalFilterQueryEvent): void {
    this.searchQueryResult = $event?.FinalQueryString;
  }
}
