import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCouponDetachmentComponent } from './app-coupon-detachment.component';

describe('AppCouponDetachmentComponent', () => {
  let component: AppCouponDetachmentComponent;
  let fixture: ComponentFixture<AppCouponDetachmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCouponDetachmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCouponDetachmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
