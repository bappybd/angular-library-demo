import {AfterViewInit, Component, Inject, OnInit, ViewEncapsulation} from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {
  AssignFilterOption,
  AssignFilterQuery,
  AssignInfoModel,
  CouponAttachTabInfo
} from '../../models/coupon-assign-models';
import {CouponEntityType, CouponModel} from '../../../shared/models/coupon-entity-models';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {ActivatedRoute, Router} from '@angular/router';
import {MatDialog} from '@angular/material/dialog';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {CouponAssignEntity} from '../../entities/coupon-assign-entity';
import {CouponAssignCommandService} from '../../services/coupon-assign-command.service';
import {CouponAssignCommandBuilder} from '../../services/coupon-assign-command-builder';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {fuseAnimations} from '@eevo/eevo-base';
import {CouponAssignNotificationService} from '../../services/coupon-assign-notification.service';
import {
  EevoAdvanceDatatableOptions,
  FilterFromEnum,
  FinalFilterQueryEvent,
  DatatableOtherFilters
} from "@eevo/eevo-platform-advance-datatable";

@Component({
  selector: 'app-app-coupon-detachment',
  templateUrl: './app-coupon-detachment.component.html',
  styleUrls: ['./app-coupon-detachment.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class AppCouponDetachmentComponent implements OnInit, AfterViewInit {
  couponId: string;
  filterQuery: string;
  selectedIndex: number;
  formSubmitted = false;
  loadingFromServer = true;
  couponDetails: CouponModel;
  breadcrumbList: BreadcrumbModel[] = [];

  queryFilters: Subject<any> = new Subject<any>();
  searchFilterOptions: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  tableConfigOptions: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  datatableConfigOptions: EevoAdvanceDatatableOptions;
  selectedTabIndex: Subject<number> = new Subject<number>();
  searchQueryResult: string;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private actRoute: ActivatedRoute,
    private eevoNotifyService: EevoNotifyService,
    private eevoQueryService: EevoQueryService,
    private couponAssignEntity: CouponAssignEntity,
    private couponAssignCommandService: CouponAssignCommandService,
    private couponAssignCommandBuilder: CouponAssignCommandBuilder,
    private couponAssignNotificationService: CouponAssignNotificationService,
    @Inject('config') private config: any
  ) {
    this.selectedIndex = 0;
    this.couponId = this.actRoute.snapshot.params.id;
    this.filterQuery = `{ 'CouponInfos._id':  GUID('${this.couponId}') }`;
  }

  ngOnInit(): void {
    this.getCouponDetails();
  }

  ngAfterViewInit(): void {
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  goToCouponListPage(): void {
    this.router.navigate(['coupon']);
  }

  unassignCoupon(): void {
    let assignType = CouponEntityType.Shop;
    if (this.selectedIndex === 1) {
      assignType = CouponEntityType.ProductCategory;
    } else if (this.selectedIndex === 2) {
      assignType = CouponEntityType.Product;
    }

    if (this.searchQueryResult) {
      let commandObserver: Observable<any>;
      const command = this.couponAssignCommandBuilder.getDetachCouponsByFilterCommand(
        this.couponId, this.searchQueryResult, assignType
      );
      commandObserver = this.couponAssignCommandService.detachCouponByFilter(command);

      this.couponAssignNotificationService.couponAttachSucceeded();
      this.eevoNotifyService.displayMessage('Detach coupon by filter request submitted!', NotifyType.Info);

      this.formSubmitted = true;

      commandObserver.subscribe(data => {
        this.goToCouponListPage();
        this.formSubmitted = false;
      }, error => {
        this.formSubmitted = false;
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
      });
    } else {
      this.eevoNotifyService.displayMessage('Invalid request', NotifyType.Error);
    }
  }

  loadAdvanceDatatable(): void {
    const datatableConfigOptions = new EevoAdvanceDatatableOptions();
    datatableConfigOptions.NavId = 'd83ca0e6-e07b-4da6-a28b-46a544acc81f';
    datatableConfigOptions.TableConfigId = '';
    datatableConfigOptions.TabIndex = 0;
    datatableConfigOptions.InitialFilters = null;
    datatableConfigOptions.ApplySearchFilterToAllTab = false;

    this.datatableConfigOptions = datatableConfigOptions;
    this.tableConfigOptions.next(datatableConfigOptions);

    const searchFilterOptions = new EevoAdvanceDatatableOptions();
    searchFilterOptions.TableConfigId = '18211130-61c5-4613-9a87-59e7043390d5';

    this.searchFilterOptions.next(searchFilterOptions);
  }

  searchFilterOnSubmit($event): void {
    this.queryFilters.next($event);
  }

  sideBarAction($event): void {
  }

  filterInitializeCompleted($event): void {
  }

  hasTabChangeAccess($event: any): void {
    if (this.searchQueryResult && this.searchQueryResult !== '{}' && this.searchQueryResult !== '') {
      // if form is dirty, show a warning modal and don't change tab.
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        data: {
          title: 'Confirmation',
          message: `Are you sure you want to change without save?`,
          buttonText: {
            ok: 'Yes',
            cancel: 'Cancel'
          }
        }
      });

      dialogRef.afterClosed().subscribe((confirmed: boolean) => {
        if (confirmed) {
          this.selectedTabIndex.next($event.selectedIndex);
        }
      });
    } else {
      // if form is not dirty, change the tab
      this.selectedTabIndex.next($event.selectedIndex);
    }
  }

  onTabChanged($event: any): void {
    this.selectedIndex = $event?.currentIndex;
    const searchFilterOptions = new EevoAdvanceDatatableOptions();
    searchFilterOptions.TableConfigId = $event?.currentTabConfig?.DataTableConfigId;

    this.datatableConfigOptions.TabIndex = $event?.currentIndex;
    this.tableConfigOptions.next(this.datatableConfigOptions);
    this.searchFilterOptions.next(searchFilterOptions);
  }

  finalFilterQuery($event: FinalFilterQueryEvent): void {
    this.searchQueryResult = this.getFilterQuery($event?.OtherFilters);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private getCouponDetails(): void {
    this.loadingFromServer = true;
    const url = this.config.CouponService.toQueryURL();
    this.eevoQueryService.getDetailsById<CouponModel>(
      url,
      this.couponAssignEntity.getDetailsName(),
      this.couponId,
      this.couponAssignEntity.getDetailsFields()
    ).subscribe((data) => {
      this.loadingFromServer = false;
      if (data && data.Id) {
        data.CouponId = data.Id;
        this.couponDetails = data;
        this.loadAdvanceDatatable();
        this.setBreadcrumbData();
      }
    });
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Coupons',
      Path: ['/coupon']
    });

    this.breadcrumbList.push({
      Text: 'Manage Assigned',
    });

    this.breadcrumbList.push({
      Text: this.couponDetails.CouponCode
    });
  }

  private getFilterQuery(otherFilters: DatatableOtherFilters[]): string {
    let searchFilter = '{}';
    const query = [];

    if (otherFilters && otherFilters.length > 0) {
      otherFilters.forEach(filter => {
        if (filter.FilterString && filter.FilterString != '' &&
          filter.FilterString != '{}' && filter.FilterFrom !== FilterFromEnum.CustomQuery) {
          query.push(filter.FilterString);
        }
      });
    }

    if (query.length) {
      if (query.length === 1) {
        searchFilter = `${query.join(',')}`;
      } else {
        searchFilter = `{$and: [${query.join(',')}]}`;
      }
    }

    return searchFilter;
  }
}
