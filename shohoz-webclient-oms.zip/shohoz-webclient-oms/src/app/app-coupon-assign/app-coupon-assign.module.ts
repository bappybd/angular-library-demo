import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppCouponAssignRoutingModule } from './app-coupon-assign-routing.module';
import {FlexModule} from '@angular/flex-layout';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {EevoPlatformAvatarModule} from '@eevo/eevo-platform-avatar';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {FuseDirectivesModule, FuseSidebarModule} from '@eevo/eevo-base';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatTabsModule} from '@angular/material/tabs';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import {DataFilterComponent} from './components/data-filter/data-filter.component';
import {ShopListComponent} from './components/shop-list/shop-list.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { AppCouponAttachmentComponent } from './container/app-coupon-attachment/app-coupon-attachment.component';
import { AssignListComponent } from './components/assign-list/assign-list.component';
import { AssignFilterComponent } from './components/assign-filter/assign-filter.component';
import { AdvancedFilterComponent } from './components/advanced-filter/advanced-filter.component';
import {MatDialogModule} from '@angular/material/dialog';
import {MatChipsModule} from '@angular/material/chips';
import { UnassignListComponent } from './components/unassign-list/unassign-list.component';
import { AppCouponManagecohortComponent } from './container/app-coupon-managecohort/app-coupon-managecohort.component';
import {CouponAssignNotificationService} from './services/coupon-assign-notification.service';
import {AppCouponDetachmentComponent} from './container/app-coupon-detachment/app-coupon-detachment.component';
import {EevoPlatformAdvanceDatatableModule} from "@eevo/eevo-platform-advance-datatable";


@NgModule({
  declarations: [
    DataFilterComponent,
    ShopListComponent,
    AppCouponAttachmentComponent,
    AssignListComponent,
    AssignFilterComponent,
    AdvancedFilterComponent,
    AppCouponDetachmentComponent,
    UnassignListComponent,
    AppCouponManagecohortComponent
  ],
  imports: [
    CommonModule,
    AppCouponAssignRoutingModule,
    FlexModule,
    MatButtonModule,
    MatCardModule,
    EevoPlatformDatatableModule,
    NgxDatatableModule,
    EevoPlatformAvatarModule,
    MatSlideToggleModule,
    MatIconModule,
    MatMenuModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSelectModule,
    FuseSidebarModule,
    MatToolbarModule,
    FuseDirectivesModule,
    MatProgressBarModule,
    MatExpansionModule,
    MatTabsModule,
    EevoPlatformBreadcrumbModule,
    MatCheckboxModule,
    MatDialogModule,
    MatChipsModule,
    EevoPlatformAdvanceDatatableModule
  ],
  providers: [
    CouponAssignNotificationService
  ]
})
export class AppCouponAssignModule { }
