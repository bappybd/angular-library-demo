import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AppCouponAttachmentComponent} from './container/app-coupon-attachment/app-coupon-attachment.component';
import {AppCouponManagecohortComponent} from './container/app-coupon-managecohort/app-coupon-managecohort.component';
import {AppCouponDetachmentComponent} from './container/app-coupon-detachment/app-coupon-detachment.component';
import {FeatureAccessPermission} from '@eevo/eevo-core';

const routes: Routes = [
  {
    path: 'assign',
    component: AppCouponAttachmentComponent,
    data: {isFullScreen: true, name: 'coupon.assign'},
    canActivate: [FeatureAccessPermission]
  },
  {
    path: 'manageAssigned',
    component: AppCouponDetachmentComponent,
    data: {isFullScreen: true, name: 'coupon.unassign'},
    canActivate: [FeatureAccessPermission]
  },
  {
    path: 'manageCohort',
    component: AppCouponManagecohortComponent,
    data: {isFullScreen: true, name: 'coupon.cohort'},
    canActivate: [FeatureAccessPermission]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppCouponAssignRoutingModule { }
