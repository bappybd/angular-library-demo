import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {
  AttachCouponsByFilterCommand,
  CouponAssignByFilterCommand,
  CouponAssignCommand,
  CouponAttachCommand,
  CouponDetachCommand,
  DetachCouponsByFilterCommand,
} from '../models/coupon-assign-command';

@Injectable({
  providedIn: 'root'
})

export class CouponAssignCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  assignCoupon(command: CouponAssignCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/AssignCoupons',
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  attachCoupon(command: CouponAttachCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/AttachCoupons',
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  detachCoupon(command: CouponDetachCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/DetachCoupons',
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  assignCouponByFilter(command: CouponAssignByFilterCommand): Observable<any> {
    return null;
  }

  attachCouponByFilter(command: AttachCouponsByFilterCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/AttachCouponsByFilter',
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  detachCouponByFilter(command: DetachCouponsByFilterCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/DetachCouponsByFilter',
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
