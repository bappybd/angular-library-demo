import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';
import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {CouponAssignEntity} from '../entities/coupon-assign-entity';

@Injectable({
  providedIn: 'root'
})
export class CouponAssignNotificationService extends EevoNotificationBase<CommandNotificationModel> {

  constructor(
    private couponAssignEntity: CouponAssignEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(
      this.couponAssignEntity.Events.CouponBusinessRuleViolatedEvent, (response) => {
        const data = this.notificationHandlerService.parseAndDisplayMessage(response, false);
        // this.deliver(data);
      });
  }

  attachCouponByFilter(): void {
    this.signalrNotificationService.listenByKey(this.couponAssignEntity.Events.CouponAttachSucceededEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, 'Attach coupon by filter successfully done.');
      // this.deliver(data);
    });
  }

  detachCouponByFilter(): void {
    this.signalrNotificationService.listenByKey(this.couponAssignEntity.Events.CouponAttachSucceededEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, 'Detach coupon by filter successfully done.');
      // this.deliver(data);
    });
  }

  couponAttachSucceeded(): void {
    this.signalrNotificationService.listenByKey(this.couponAssignEntity.Events.CouponAttachSucceededEvent, (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true, 'Coupon attach/detach successfully done.');

      const types = ['Unknown', 'Shop', 'Product Category', 'Product', 'User'];
      if (data && data.Details) {
        let message = '';
        if (data.Details.CouponCode) {
          message = `${data.Details.CouponCode} coupon `;
        }

        let type = types[0];
        if (data.Details.CouponEntityType > -1) {
          type = types[data.Details.CouponEntityType];
        }

        if (data.Details.ActionName && data.Details.ActionName === 'DetachCouponsByFilter') {
          message += `successfully detach from ${type}(s)`;
        } else if (data.Details.ActionName && data.Details.ActionName === 'AttachCouponsByFilter') {
          message += `successfully attach to ${type}(s)`;
        } else if (data.Details.ActionName && data.Details.ActionName === 'AssignCoupons') {
          message += `successfully assign to ${type}(s)`;
        }

        data.Message = message;
      }
      this.notificationHandlerService.displayMessage(data);
      // this.deliver(data);
    });
  }

  assignCoupon(): void {
    this.signalrNotificationService.listenByKey(this.couponAssignEntity.Events.AssignCouponEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, 'Assign coupon successfully done.');
      // this.deliver(data);
    });
  }
}
