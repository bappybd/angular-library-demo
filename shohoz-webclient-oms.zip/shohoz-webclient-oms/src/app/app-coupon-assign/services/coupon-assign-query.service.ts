import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {CouponAssignEntity} from '../entities/coupon-assign-entity';
import {CouponEntityType} from '../../shared/models/coupon-entity-models';
import {map} from 'rxjs/operators';
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})

export class CouponAssignQueryService {
  constructor(
    private http: HttpClient,
    private couponEntity: CouponAssignEntity,
    private utilityService: UtilityService,
    @Inject('config') private config: any
  ) {
  }

  getAttachedCouponByIdAndType(couponId: string, type: CouponEntityType): Observable<any> {
    const query = `{ 'CouponId' : GUID('${couponId}'), 'CouponEntityType' : '${type}'  }`;

    const requestBody = [
      {
        source: this.couponEntity.getAttachedCouponEntityName(),
        text: null,
        filter: query,
        fields: this.couponEntity.getAttachedCouponListFields(),
        orderBy: 'Language',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.CouponService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        if (response && response[0]) {
          return response[0][0];
        }
        return null;
      })
    );
  }
}
