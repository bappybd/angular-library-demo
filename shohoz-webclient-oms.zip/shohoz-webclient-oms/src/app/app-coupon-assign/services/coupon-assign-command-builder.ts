import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {AssignInfoModel} from '../models/coupon-assign-models';
import {
  AttachCouponsByFilterCommand,
  CouponAssignByFilterCommand,
  CouponAssignCommand,
  DetachCouponsByFilterCommand
} from '../models/coupon-assign-command';
import {CouponEntityType} from '../../shared/models/coupon-entity-models';
@Injectable({
  providedIn: 'root'
})

export class CouponAssignCommandBuilder {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  isAssignCouponByFilter(assignCoupon: AssignInfoModel): boolean {
    return assignCoupon.isApplicableForAll;
  }

  getAssignCouponCommand(couponId: string, assignCoupon: AssignInfoModel): CouponAssignCommand {
    const command = new CouponAssignCommand();
    command.CouponEntityType = assignCoupon.assignType;
    command.CouponIds = [couponId];
    command.EntityIds = assignCoupon.dataList;

    return command;
  }

  getAssignCouponByFilterCommand(couponId: string, assignCoupon: AssignInfoModel): CouponAssignByFilterCommand {
    const command = new CouponAssignByFilterCommand();
    command.CouponEntityType = assignCoupon.assignType;
    command.CouponIds = [couponId];
    command.Filter = assignCoupon.filter;

    return command;
  }

  getAssignCouponsCommand(couponId: string, dataList: string[], assignType: CouponEntityType): CouponAssignCommand {
    const command = new CouponAssignCommand();
    command.CouponEntityType = assignType;
    command.CouponIds = [couponId];
    command.EntityIds = dataList;

    return command;
  }

  getAttachCouponsByFilterCommand(couponId: string, filter: string, assignType: CouponEntityType): AttachCouponsByFilterCommand {
    // let couponEntityType = 1;
    //
    // if (assignType === CouponEntityType.ProductCategory) {
    //   couponEntityType = 2;
    // } else if (assignType === CouponEntityType.Product) {
    //   couponEntityType = 3;
    // }

    const command = new AttachCouponsByFilterCommand();
    command.CouponEntityType = assignType;
    command.CouponIds = [couponId];
    command.Filter = filter;

    return command;
  }

  getDetachCouponsByFilterCommand(couponId: string, filter: string, assignType: CouponEntityType): DetachCouponsByFilterCommand {
    // let couponEntityType = 1;
    //
    // if (assignType === CouponEntityType.ProductCategory) {
    //   couponEntityType = 2;
    // } else if (assignType === CouponEntityType.Product) {
    //   couponEntityType = 3;
    // }

    const command = new DetachCouponsByFilterCommand();
    command.CouponEntityType = assignType;
    command.CouponIds = [couponId];
    command.Filter = filter;

    return command;
  }
}
