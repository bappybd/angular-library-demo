import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppUamRoutingModule } from './app-uam-routing.module';
import { AppUserCreateComponent } from './container/app-user-create/app-user-create.component';
import { AppUserListComponent } from './container/app-user-list/app-user-list.component';
import {FlexLayoutModule} from '@angular/flex-layout';
import {ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {MatSelectModule} from '@angular/material/select';
import {MatCardModule} from '@angular/material/card';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { AppUserFilterComponent } from './components/app-user-filter/app-user-filter.component';
import {MatIconModule} from '@angular/material/icon';
import { UserFormComponent } from './components/user-form/user-form.component';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import { AppUserUpdateComponent } from './container/app-user-update/app-user-update.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {AssignShopOperatorComponent} from './container/assign-shop-operator/assign-shop-operator.component';
import {UamNotificationService} from './services/uam-notification.service';
import {SharedModule} from "../shared/shared.module";

// @ts-ignore
@NgModule({
  declarations: [
    AppUserCreateComponent,
    AppUserListComponent,
    AppUserFilterComponent,
    UserFormComponent,
    AppUserUpdateComponent,
    AssignShopOperatorComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AppUamRoutingModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCheckboxModule,
    EevoPlatformDatatableModule,
    MatSelectModule,
    MatCardModule,
    MatProgressBarModule,
    MatIconModule,
    EevoPlatformBreadcrumbModule,
    MatAutocompleteModule,
  ],
  providers: [
    UamNotificationService
  ]
})
export class AppUamModule { }
