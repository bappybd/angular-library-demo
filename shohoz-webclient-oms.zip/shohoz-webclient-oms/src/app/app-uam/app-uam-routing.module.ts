import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {FeatureAccessPermission} from '@eevo/eevo-core';
import {AppUserCreateComponent} from './container/app-user-create/app-user-create.component';
import {AppUserListComponent} from './container/app-user-list/app-user-list.component';
import {AppUserUpdateComponent} from './container/app-user-update/app-user-update.component';
import {AssignShopOperatorComponent} from './container/assign-shop-operator/assign-shop-operator.component';

const routes: Routes = [
  {
    path: '',
    component: AppUserListComponent,
    data: {isFullScreen: true}
  },
  {
    path: 'create',
    component: AppUserCreateComponent,
    data: {
      isFullScreen: true,
      name: 'uam.create',
    },
    canActivate: [FeatureAccessPermission],
  },
  {
    path: 'shop-operator',
    component: AssignShopOperatorComponent,
    data: {
      isFullScreen: true,
      name: 'shop.operator.assignment',
    },
    canActivate: [FeatureAccessPermission],
  },
  {
    path: 'update/:username',
    component: AppUserUpdateComponent,
    data: {
      isFullScreen: true,
      name: 'uam.update',
    },
    canActivate: [FeatureAccessPermission],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppUamRoutingModule { }
