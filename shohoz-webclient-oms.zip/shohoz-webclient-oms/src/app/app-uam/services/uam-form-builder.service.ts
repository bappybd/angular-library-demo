import {Injectable} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {UtilityService} from '@eevo/eevo-core';
import {EevoValidator} from "../../shared/validator/eevo.validator";

@Injectable({
  providedIn: 'root'
})
export class UAMFormBuilder {

  constructor(
    private formBuilder: FormBuilder,
    private utilityService: UtilityService
  ) {
  }

  getUserForm(user?: any): FormGroup {
    const hasData = !!(user && user.id);

    return this.formBuilder.group({
      DisplayName: [hasData ? user.displayName : ''],
      FirstName: [hasData ? user.firstName : ''],
      LastName: [hasData ? user.lastName : ''],
      Email: [hasData ? user.email : '', [Validators.required, Validators.email]],
      PhoneNumber: [hasData ? user.phoneNumber : '', Validators.required],
      Password: ['', hasData ? null : Validators.required],
      Username: [hasData ? user.userName : '', Validators.required],
      Roles: [hasData ? user.roles : '', Validators.required],
    });
  }

  getAssignUserForm(): FormGroup {
    return this.formBuilder.group({
      ShopInfo: ['', [Validators.required, EevoValidator.dataSelectedValidator()]],
      UserName: ['', Validators.required]
    });
  }
}
