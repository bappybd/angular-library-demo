import {Inject, Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {UtilityService} from "@eevo/eevo-core";
import {Observable} from "rxjs";
import {map} from "rxjs/operators";
import {UAMCommand, UserAssignCommand} from "../models/uam-commands";

@Injectable({
  providedIn: 'root'
})

export class UAMCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createUser(uamCommand: UAMCommand): Observable<any> {
    return this.http.post(this.config.UAMService + 'User/Register',
      uamCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateUser(uamCommand: UAMCommand): Observable<any> {
    return this.http.post(this.config.UAMService + 'User/Update',
      uamCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  addShopOperator(command: UserAssignCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('AddShopOperator'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  removeShopOperator(command: UserAssignCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('RemoveShopOperator'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
