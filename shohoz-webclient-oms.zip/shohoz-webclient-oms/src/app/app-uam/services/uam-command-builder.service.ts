import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {FormGroup} from '@angular/forms';
import {UAMCommand, UserAssignCommand} from "../models/uam-commands";
import {CouponCategory, CouponLogicModel, CouponModel, CouponState} from '../../shared/models/coupon-entity-models';

@Injectable({
  providedIn: 'root'
})

export class UAMCommandBuilderService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getUAMCommand(formPayload: FormGroup): UAMCommand {
    const form = Object.assign({}, formPayload);
    const formData = form.value;

    const uamCommand =  {
      CorrelationId: this.utilityService.getNewGuid(),
      DisplayName: formData.DisplayName,
      FirstName: formData.FirstName,
      LastName: formData.LastName,
      Email: formData.Email,
      PhoneNumber: formData.PhoneNumber,
      Password: formData.Password,
      Username: formData.Username,
      Roles: formData.Roles,
    } as UAMCommand;

    return uamCommand;
  }

  getUserAssignCommand(shopId: string, userId: string, userName: string): UserAssignCommand {
    const userAssignCommand =  new UserAssignCommand();
    userAssignCommand.CorrelationId = this.utilityService.getNewGuid();
    userAssignCommand.Shops = [{
      ShopId: shopId,
      ShopOperators: [{
        UserId: userId,
        UserName: userName
      }],
    }];

    return userAssignCommand;
  }
}
