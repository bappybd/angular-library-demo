import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {Observable} from 'rxjs';
import {map} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})

export class UAMQueryService {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getUserList(tableModel: any): Observable<any> {
    return this.http.get(this.config.UAMService +
      `User/GetAllUserWithPagination?PageNumber=${tableModel.CurrentPageNumber + 1}&PageSize=${tableModel.PageSize}`);
  }

  getUserByUsername(username: any): Observable<any> {
    return this.http.get(this.config.UAMService + `User/GetUserByUserName?UserName=${username}`);
  }

  getShopList(searchKey?: string): Observable<any> {
    let rawQuery = '';
    let combinedQuery = '';

    if (searchKey) {
      if (searchKey && searchKey.length > 0) {
        combinedQuery += `{ Name: /` + searchKey + `/i }`;
      }
    }

    if (combinedQuery.length > 0) {
      rawQuery += `{$and: [ ` + combinedQuery + ` ] }`;
    }

    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: 'ShopLists',
        text: null,
        filter: rawQuery.length ? rawQuery : '{}',
        fields: [
          'Name', 'LogoFileId', 'Contact', 'Affordability', 'DeliveryFee',
          'ShopStatus', 'Address', 'EmergencyContactDetails'
        ],
        orderBy: 'CreatedDate',
        descending: true,
        pageSize: 9,
        pageIndex: 0
      },
    ]).pipe(
      map((response: any) => {
        response[0].map(data => {
        });
        return response[0];
      })
    );
  }
}
