import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';

@Injectable({
  providedIn: 'root'
})
export class UamNotificationService extends EevoNotificationBase<CommandNotificationModel> {

  constructor(
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey('ShopBusinessRuleViolationEvent', (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, false);
      this.deliver(data);
    });
  }

  assignUserEvent(): void {
    this.signalrNotificationService.listenByKey('ShopAllowedWriteAccessEvent', (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, 'Successfully Assigned');
      this.deliver(data);
    });
  }

  removeUserEvent(): void {
    this.signalrNotificationService.listenByKey('ShopRemovedWriteAccessEvent', (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, 'Successfully Removed');
      this.deliver(data);
    });
  }

}
