import {EevoCommandBase} from '@eevo/eevo-core';
import {ShopsAssignModel} from './uam-models';

export class UAMCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  public Id: string;
  public DisplayName: string;
  public FirstName: string;
  public LastName: string;
  public Email: string;
  public PhoneNumber: string;
  public Password: string;
  public Username: number;
  public Roles: string[];
}

export class UserAssignCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  public Shops: ShopsAssignModel[];
}


