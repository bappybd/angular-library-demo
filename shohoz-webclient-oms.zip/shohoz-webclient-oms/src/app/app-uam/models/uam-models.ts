export class UserListConfigModel<T> {
  TotalElements: number;
  TotalPages: number;
  Data: Array<T>;

  constructor() {
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.Data = new Array<T>();
  }
}
export class ShopOperatorsAssignModel {
  UserId: string;
  UserName: string;
}
export class ShopsAssignModel {
  ShopId: string;
  ShopOperators: ShopOperatorsAssignModel[];
}
