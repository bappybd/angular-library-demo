import { Component, OnInit } from '@angular/core';
import {FormGroup} from '@angular/forms';
import {UAMFormBuilder} from '../../services/uam-form-builder.service';
import {Router} from '@angular/router';
import {UAMCommandBuilderService} from '../../services/uam-command-builder.service';
import {UAMCommandService} from '../../services/uam-command.service';
import {fuseAnimations} from '@eevo/eevo-base';

@Component({
  selector: 'app-app-user-create',
  templateUrl: './app-user-create.component.html',
  styleUrls: ['./app-user-create.component.scss'],
  animations: fuseAnimations
})
export class AppUserCreateComponent implements OnInit {

  uamForm: FormGroup;
  breadcrumbList = [{
    Text: 'Create New User'
  }];

  constructor(
    private router: Router,
    private uamFormBuilder: UAMFormBuilder,
    private uamCommandBuilderService: UAMCommandBuilderService,
    private uamCommandService: UAMCommandService,
  ) { }

  ngOnInit(): void {
    this.uamForm = this.uamFormBuilder.getUserForm();
  }

  createUser(): void {
    this.uamForm.markAllAsTouched();
    if (this.uamForm.valid) {
      const command = this.uamCommandBuilderService.getUAMCommand(this.uamForm);
      this.uamCommandService.createUser(command).subscribe(response => {
        this.goToUserListPage();
      });
    }
  }

  goToUserListPage(): void {
    this.router.navigate(['uam']);
  }

}
