import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignShopOperatorComponent } from './assign-shop-operator.component';

describe('AssignShopOperatorComponent', () => {
  let component: AssignShopOperatorComponent;
  let fixture: ComponentFixture<AssignShopOperatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignShopOperatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignShopOperatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
