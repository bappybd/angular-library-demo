import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {debounceTime, distinctUntilChanged, map, startWith} from 'rxjs/operators';
import {UAMQueryService} from '../../services/uam-query.service';
import {Router} from '@angular/router';
import {UAMFormBuilder} from '../../services/uam-form-builder.service';
import {fuseAnimations} from '@eevo/eevo-base';
import {UAMCommandService} from '../../services/uam-command.service';
import {UAMCommandBuilderService} from '../../services/uam-command-builder.service';
import {UamNotificationService} from '../../services/uam-notification.service';

@Component({
  selector: 'app-assign-shop-operator',
  templateUrl: './assign-shop-operator.component.html',
  styleUrls: ['./assign-shop-operator.component.scss'],
  animations: fuseAnimations
})
export class AssignShopOperatorComponent implements OnInit {

  key: any;
  shopList = [];
  assignForm: FormGroup;
  userInfoNotFound = true;
  userInfo = null;

  breadcrumbList = [{
    Text: 'Assign shop operator'
  }];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private uamFormBuilder: UAMFormBuilder,
    private uamQueryService: UAMQueryService,
    private uamCommandService: UAMCommandService,
    private uamCommandBuilderService: UAMCommandBuilderService,
    private uamNotificationService: UamNotificationService,
  ) {
  }

  ngOnInit(): void {
    this.initShopFilterForm();
  }

  initShopFilterForm(): void {
    this.assignForm = this.uamFormBuilder.getAssignUserForm();
    this.onShopFilterChanges();
    this.onUserFilterChanges();
  }

  goToUserListPage(): void {
    this.router.navigate(['uam']);
  }

  onUserFilterChanges(): void {
    this.assignForm.get('UserName').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.userInfo = null;
        this.userInfoNotFound = true;
        this.uamQueryService.getUserByUsername(value.trim()).subscribe(data => {
          if (data && data.result) {
            this.userInfo = data.result;
            this.userInfoNotFound = false;
          }
        }, error => {});
      });
  }

  onShopFilterChanges(): void {
    this.assignForm.get('ShopInfo').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        console.log(value);
        this.getShopList(value);
      });
  }

  getShopList(value: string): void {
    this.uamQueryService.getShopList(value).subscribe((response) => {
      this.shopList = response;
    }, (error) => {
    });
  }

  displayFn(data: any): string {
    return data && data.Name ? data.Name : '';
  }

  removeUser(): void {
    this.assignForm.markAllAsTouched();
    if (this.assignForm.valid) {
      this.uamNotificationService.removeUserEvent();
      const shopInfo = this.assignForm.get('ShopInfo').value;
      const command = this.uamCommandBuilderService.getUserAssignCommand(shopInfo.Id, this.userInfo.id, this.userInfo.userName);

      this.uamCommandService.removeShopOperator(command).subscribe(response => {
        this.goToUserListPage();
      });
    }
  }

  assignUser(): void {
    this.assignForm.markAllAsTouched();
    if (this.assignForm.valid) {
      this.uamNotificationService.assignUserEvent();
      const shopInfo = this.assignForm.get('ShopInfo').value;
      const command = this.uamCommandBuilderService.getUserAssignCommand(shopInfo.Id, this.userInfo.id, this.userInfo.userName);

      this.uamCommandService.addShopOperator(command).subscribe(response => {
        this.goToUserListPage();
      });
    }
  }
}
