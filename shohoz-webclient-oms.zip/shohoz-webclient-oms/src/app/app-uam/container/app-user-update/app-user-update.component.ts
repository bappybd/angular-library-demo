import { Component, OnInit } from '@angular/core';
import {FormGroup} from '@angular/forms';
import {UAMFormBuilder} from '../../services/uam-form-builder.service';
import {ActivatedRoute, Router} from '@angular/router';
import {UAMCommandBuilderService} from '../../services/uam-command-builder.service';
import {UAMCommandService} from '../../services/uam-command.service';
import {UAMQueryService} from '../../services/uam-query.service';
import {fuseAnimations} from "@eevo/eevo-base";

@Component({
  selector: 'app-app-user-update',
  templateUrl: './app-user-update.component.html',
  styleUrls: ['./app-user-update.component.scss'],
  animations: fuseAnimations
})
export class AppUserUpdateComponent implements OnInit {

  loadedFromServer = false;
  userId: string;
  username: string;
  uamForm: FormGroup;
  breadcrumbList = [{
    Text: 'Create Update User'
  }];

  constructor(
    private router: Router,
    private actRoute: ActivatedRoute,
    private uamFormBuilder: UAMFormBuilder,
    private uamQueryService: UAMQueryService,
    private uamCommandService: UAMCommandService,
    private uamCommandBuilderService: UAMCommandBuilderService,
  ) {
    this.username = this.actRoute.snapshot.params.username;
    this.breadcrumbList.push({Text: this.username});
  }

  ngOnInit(): void {
    this.uamQueryService.getUserByUsername(this.username).subscribe(data => {
      if (data && data.result){
        this.loadedFromServer = true;
        this.userId = data.result.id;
        this.uamForm = this.uamFormBuilder.getUserForm(data.result);
      }
    });
  }

  updateUser(): void {
    this.uamForm.markAllAsTouched();
    if (this.uamForm.valid) {
      const command = this.uamCommandBuilderService.getUAMCommand(this.uamForm);
      command.Id = this.userId;
      if (!(command?.Password)) {
        delete command.Password;
      }

      this.uamCommandService.updateUser(command).subscribe(response => {
        this.goToUserListPage();
      });
    }
  }

  goToUserListPage(): void {
    this.router.navigate(['uam']);
  }


}
