import {
  Component,
  ElementRef,
  OnInit,
  QueryList,
  TemplateRef,
  ViewChild,
  ViewChildren,
  ViewEncapsulation
} from '@angular/core';
import {ActivatedRoute, Route, Router} from '@angular/router';
import {UAMQueryService} from '../../services/uam-query.service';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {BehaviorSubject} from 'rxjs';
import {UserListConfigModel} from '../../models/uam-models';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {ZoneFilter} from "../../../app-zone/models/zone-models";

@Component({
  selector: 'app-app-user-list',
  templateUrl: './app-user-list.component.html',
  styleUrls: ['./app-user-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppUserListComponent implements OnInit {

  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('userNameCell', {static: true}) userNameCellTemplate: TemplateRef<any>;
  @ViewChild('firstNameCell', {static: true}) firstNameCellTemplate: TemplateRef<any>;
  @ViewChild('roleCell', {static: true}) roleCellTemplate: TemplateRef<any>;
  @ViewChild('phoneNoCell', {static: true}) phoneNoCellTemplate: TemplateRef<any>;
  @ViewChild('emailCell', {static: true}) emailCellTemplate: TemplateRef<any>;
  @ViewChild('lastNameCell', {static: true}) lastNameCellTemplate: TemplateRef<any>;

  @ViewChildren('toggleElement') toggleElementRef: QueryList<ElementRef>;

  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  private datatableModelInput = new BehaviorSubject<UserListConfigModel<any>>(undefined);
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);

  filter;
  userList: any[];
  configOption: any = {};
  isDataLoaded: boolean;
  tableModelOpt;

  constructor(
    private router: Router,
    private uamQueryService: UAMQueryService,
  ) { }

  ngOnInit(): void {
    this.prepareDataTable();
  }

  getSearchFilterData($event: ZoneFilter): void {
    this.filter = $event;
    console.log(this.filter?.searchByUsername);
    if (this.filter && this.filter?.searchByUsername) {
      this.uamQueryService.getUserByUsername(this.filter.searchByUsername).subscribe(data => {
        if (data && data.result) {
          this.datatableModel = {
            PageSize: 10,
            TotalElements: 1,
            CurrentPageNumber: 0,
            SortBy: this.datatableModel.SortBy,
            Descending: this.datatableModel.Descending,
            Data: [data.result],
            ColumnMode: ColumnMode.flex
          };
        } else {
          {
            this.datatableModel = {
              PageSize: 10,
              TotalElements: 0,
              CurrentPageNumber: 0,
              SortBy: this.datatableModel.SortBy,
              Descending: this.datatableModel.Descending,
              Data: [],
              ColumnMode: ColumnMode.flex
            };
          }
        }
      }, error => {
        this.datatableModel = {
          PageSize: 10,
          TotalElements: 0,
          CurrentPageNumber: 0,
          SortBy: this.datatableModel.SortBy,
          Descending: this.datatableModel.Descending,
          Data: [],
          ColumnMode: ColumnMode.flex
        };
      });
    } else {
      this.getUserList(this.tableModelOpt);
    }
  }

  getUserList(dataTable: DatatableModel<any>): void {
    this.uamQueryService.getUserList(dataTable).subscribe(response => {
      this.userList = response.result;
      this.datatableModel = {
        PageSize: this.datatableModel.PageSize,
        TotalElements: 2000000,
        CurrentPageNumber: this.datatableModel.CurrentPageNumber,
        SortBy: this.datatableModel.SortBy,
        Descending: this.datatableModel.Descending,
        Data: this.userList,
        ColumnMode: ColumnMode.flex
      };
      this.isDataLoaded = true;
    });
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'userName',
          name: 'User Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.userNameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'phoneNumber',
          name: 'Phone Number',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.phoneNoCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'roles',
          name: 'Roles',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.roleCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'email',
          name: 'Email',
          flexGrow: 1.2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.emailCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'firstName',
          name: 'First Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.firstNameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'lastName',
          name: 'Last Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.lastNameCellTemplate,
          draggable: true,
          sortable: true,
        }
      ] as TableColumn[],
      defaultSort: 'createdDate',
      descending: false,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    // this.getUserList();
    this.initDataTable();
  }

  initDataTable(): void {
    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.tableModelOpt = tableModel;
    this.getUserList(tableModel);
    this.topFunction();
  }

  topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }
  selectData(dataTableRow: any): void {
    // this.router.navigate(['shop', 'detail', dataTableRow.Id, 'overview']);
  }

  createNewUser = () => {
    this.router.navigate(['uam', 'create']);
  }

  goToShopOperatorPage(): void {
    this.router.navigate(['uam', 'shop-operator']);
  }
}
