import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {debounceTime, distinctUntilChanged} from "rxjs/operators";

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit {
  @Input()
  parent: FormGroup;

  @Input()
  isEdit: boolean;

  roleList: string[] = [
    'admin',
    'user',
    'anonymous',
    'customer',
    'cc_admin',
    'cc_manager',
    'cc_executive',
    'accounts_admin',
    'accounts_manager',
    'accounts_executive',
    'ops_live_admin',
    'ops_live_manager',
    'ops_live_executive',
    'ops_dispatch_admin',
    'ops_dispatch_manager',
    'ops_dispatch_executive',
    'content_admin',
    'content_manager',
    'strategy_executive',
    'restaurant_admin',
    'restaurant_manager',
    'delivery_by_shop'
  ];

  constructor() { }

  ngOnInit(): void {
    this.makeDisplayName();
  }

  makeDisplayName(): void {
    this.parent.get('FirstName').valueChanges
      .subscribe(value => {
        this.displayName();
      });

    this.parent.get('LastName').valueChanges
      .subscribe(value => {
        this.displayName();
      });
  }

  displayName(): void {
    const firstName = this.parent.get('FirstName').value;
    const lastName = this.parent.get('LastName').value;

    this.parent.get('DisplayName').setValue(`${firstName} ${lastName}`);
  }
}
