import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';

@Component({
  selector: 'app-user-filter',
  templateUrl: './app-user-filter.component.html',
  styleUrls: ['./app-user-filter.component.scss']
})
export class AppUserFilterComponent implements OnInit {
  @Output() getDataOnSubmit: EventEmitter<any> = new EventEmitter();
  filterForm: FormGroup;

  filter = {
    searchByUsername: ''
  };

  constructor(
    private formBuilder: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.initShopFilterForm();
    this.onUserFilterChanges();
  }

  initShopFilterForm(): void {
    this.filterForm = this.formBuilder.group({
      searchByUsername: ['']
    });
  }

  onUserFilterChanges(): void {
    this.filterForm.get('searchByUsername').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.filter.searchByUsername = value;
        this.getDataOnSubmit.emit(this.filter);
      });
  }

}
