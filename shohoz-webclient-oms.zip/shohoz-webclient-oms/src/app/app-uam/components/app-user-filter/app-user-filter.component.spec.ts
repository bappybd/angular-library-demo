import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppUserFilterComponent } from './app-user-filter.component';

describe('AppUserFilterComponent', () => {
  let component: AppUserFilterComponent;
  let fixture: ComponentFixture<AppUserFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppUserFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppUserFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
