import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ZoneCommand} from '../models/zone-commands';

@Injectable({
  providedIn: 'root'
})

export class ZoneCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createZone(command: ZoneCommand): Observable<any> {
    return this.http.post(this.config.ZoneSettingsService.toCommandURL('Create'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateZone(command: ZoneCommand): Observable<any> {
    return this.http.post(this.config.ZoneSettingsService.toCommandURL('Update'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
