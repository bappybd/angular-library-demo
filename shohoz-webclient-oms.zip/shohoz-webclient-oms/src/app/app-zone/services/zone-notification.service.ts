import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';
import {ZoneEntity} from '../entities/zone-entity';

@Injectable({
  providedIn: 'root'
})
export class ZoneNotificationService extends EevoNotificationBase<CommandNotificationModel> {

  constructor(
    private zoneEntity: ZoneEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(
      this.zoneEntity.Events.ZoneBusinessRuleViolationEvent, (response) => {
        const data = this.notificationHandlerService.parseAndDisplayMessage(response, false);
        // this.deliver(data);
      });
  }

  zoneCreated(): void {
    this.signalrNotificationService.listenByKey(this.zoneEntity.Events.ZoneCreatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(
        response, true, this.zoneEntity.getMessages().CREATED
      );
      this.deliver(data);
    });
  }

  zoneUpdated(): void {
    this.signalrNotificationService.listenByKey(this.zoneEntity.Events.ZoneUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(
        response, true, this.zoneEntity.getMessages().UPDATED
      );
      this.deliver(data);
    });
  }

}
