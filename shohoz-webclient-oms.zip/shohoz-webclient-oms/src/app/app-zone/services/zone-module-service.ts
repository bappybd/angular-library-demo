import {Inject, Injectable} from '@angular/core';
import {Observable, of, Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ZoneModuleService {
  private subject = new Subject();

  constructor() {
  }

  setSubject(data: any): void {
    this.subject.next(data);
  }
  getSubject(): Observable<any> {
    return this.subject.asObservable();
  }
}
