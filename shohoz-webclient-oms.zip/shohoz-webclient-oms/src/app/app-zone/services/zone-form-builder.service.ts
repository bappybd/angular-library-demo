import {Injectable} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {UtilityService} from '@eevo/eevo-core';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class ZoneFormBuilderService {
  constructor(
    private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private scheduleHourService: ScheduleHourService
  ) {
  }

  setZoneFormData(formGroup: FormGroup, formData: any): void {
    const isSameForAllDaysServiceHours = formData.ServiceHourIsSameForAllDays;

    this.setApplicableFormGroup(formGroup.get('UserDetails') as FormGroup, formData.UserSettings);
    this.setApplicableFormGroup(formGroup.get('ShopDetails') as FormGroup, formData.ShopSettings);

    let excludedZones;
    if (formData && formData.ExcludedZones) {
      excludedZones = formData.ExcludedZones.map(data => {
        if (data) {
          data['Id'] = data._id ? data._id : data.Id;
          if (data._id) {
            delete data._id;
          }
        }

        return data;
      });
    }

    formGroup.get('SelectedZone').setValue(formData.SelectedZone);
    formGroup.get('ExcludedZones').setValue(excludedZones);
    formGroup.get('LookupRadius').setValue(formData.LookupRadius);
    formGroup.get('LookupRadiusForShopDispatch')
      .setValue(formData.LookupRadiusForShopDispatch);

    this.scheduleHourService.setScheduledHoursValues(
      formGroup.get('ScheduledHours') as FormGroup,
      isSameForAllDaysServiceHours,
      formData.ServiceHours
    );
  }

  getZoneForm(): FormGroup {
    return this.formBuilder.group({
      SelectedZone: [''],
      UserDetails: _.cloneDeep(this.getApplicableFormGroup()),
      ShopDetails: _.cloneDeep(this.getApplicableFormGroup()),
      ExcludedZones: [''],
      LookupRadius: ['', [Validators.required, Validators.min(.000001)]],
      ScheduledHours: this.scheduleHourService.getScheduleHoursFormGroup(),
      LookupRadiusForShopDispatch: [''],
    });
  }

  private setApplicableFormGroup(formGroup: FormGroup, formData: any): void {

    formGroup.get('Status').setValue(formData.IsBlocked);

    if (formData.ApplicableFrom.indexOf('0001-01-01') === -1) {
      formGroup.get('ApplicableFromDate').setValue(formData.ApplicableFrom);
      formGroup.get('ApplicableFromTime').setValue(this.getTimeSlot(formData.ApplicableFrom));
    }

    if (formData.ApplicableTo.indexOf('0001-01-01') === -1 && !formData.IsApplicableUntilFurtherNotice) {
      formGroup.get('ApplicableToDate').setValue(formData.ApplicableTo);
      formGroup.get('ApplicableToTime').setValue(this.getTimeSlot(formData.ApplicableTo));
    }

    formGroup.get('ReasonForUnavailability').setValue(formData?.UnavailabilityReason);
    formGroup.get('IsApplicableUntilFurtherNotice').setValue(formData.IsApplicableUntilFurtherNotice);

  }

  private getApplicableFormGroup(): FormGroup {
    return this.formBuilder.group({
      Status: [false],
      ApplicableFromDate: [''],
      ApplicableFromTime: [''],
      ApplicableToDate: [''],
      ApplicableToTime: [''],
      ReasonForUnavailability: [''],
      IsApplicableUntilFurtherNotice: [false],
    });
  }

  private getTimeSlot(date: string): string {
    const dt = new Date(date);
    return _.padStart(dt.getHours() + '', 2, '0') + ':' + _.padStart(dt.getMinutes() + '', 2, '0');
  }
}
