import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {FormGroup} from '@angular/forms';
import {ZoneCommand} from '../models/zone-commands';
import {ZoneDetailsModel} from '../models/zone-models';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';

@Injectable({
  providedIn: 'root'
})
export class ZoneCommandBuilderService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    private scheduleHourService: ScheduleHourService,
    @Inject('config') private config: any) {
  }

  public getZoneCommand(formPayload: FormGroup, zoneId?: string): ZoneCommand {
    const form = Object.assign({}, formPayload);
    const formData = form.value;
    const command = new ZoneCommand();

    const nextCenturyDate = new Date();
    nextCenturyDate.setFullYear(nextCenturyDate.getFullYear() + 100);
    nextCenturyDate.setMinutes(59);
    nextCenturyDate.setSeconds(59);

    const zone: ZoneDetailsModel = {
      ZoneId: zoneId ? zoneId : this.utilityService.getNewGuid(),
      ServiceHourIsSameForAllDays: formData.ScheduledHours.IsSameForAllDaysServiceHours,
      ServiceHours : this.scheduleHourService.getScheduledHoursPayload(formData.ScheduledHours),
      // ServiceHourIsSameForAllDays: isSameForAllDaysServiceHours ? isSameForAllDaysServiceHours : false,
      // ServiceHours : this.scheduleHourService.getScheduledHoursPayload(formPayload.get('ScheduledHours').value),
      ShopSettings: {
        ApplicableFrom: this.getISODateWithTimeString(
          formData.ShopDetails.ApplicableFromDate, formData.ShopDetails.ApplicableFromTime, true
        ),
        ApplicableTo:  formData.ShopDetails.IsApplicableUntilFurtherNotice ?
          nextCenturyDate.toISOString() : this.getISODateWithTimeString(
          formData.ShopDetails.ApplicableToDate, formData.ShopDetails.ApplicableToTime, false
        ),
        IsBlocked: formData.ShopDetails.Status,
        IsApplicableUntilFurtherNotice: formData.ShopDetails.IsApplicableUntilFurtherNotice,
        UnavailabilityReason: formData.ShopDetails.ReasonForUnavailability,
      },
      UserSettings: {
        ApplicableFrom: this.getISODateWithTimeString(
          formData.UserDetails.ApplicableFromDate, formData.UserDetails.ApplicableFromTime, true
        ),
        ApplicableTo: formData.UserDetails.IsApplicableUntilFurtherNotice ?
          nextCenturyDate.toISOString() : this.getISODateWithTimeString(
          formData.UserDetails.ApplicableToDate, formData.UserDetails.ApplicableToTime, false
        ),
        IsBlocked: formData.UserDetails.Status,
        IsApplicableUntilFurtherNotice: formData.UserDetails.IsApplicableUntilFurtherNotice,
        UnavailabilityReason: formData.UserDetails.ReasonForUnavailability,
      },
      LookupRadius: formData.LookupRadius,
      ExcludedZones: formData.ExcludedZones,
      SelectedZone: {
        Id: formData.SelectedZone._id ? formData.SelectedZone._id : formData.SelectedZone.id,
        Name: formData.SelectedZone.Name ? formData.SelectedZone.Name : formData.SelectedZone.name,
      },
      // LookupRadiusForShopDispatch: formData.LookupRadiusForShopDispatch,
    };

    command.Zones = [zone];
    return command;
  }

  private getISODateWithTimeString(date: Date, time: string, startTime: boolean = true): string {
    if (date) {
      return this.combineDateWithTime(date, time, startTime).toISOString();
    }

    return new Date('0001-01-01').toISOString();
  }

  private combineDateWithTime(date: Date, time: string, startTime: boolean = true): Date {
    date = new Date(date);
    let hour = 0;
    let minute = 0;

    if (time !== '') {
      const hourAndMinute = time.split(':');
      hour = Number(hourAndMinute[0]);
      minute = Number(hourAndMinute[1]);
    }

    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      hour,
      minute,
      startTime ? 0 : 59
    );
  }
}
