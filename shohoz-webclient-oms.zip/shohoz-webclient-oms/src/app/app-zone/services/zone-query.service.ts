import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {EevoQueryService, UtilityService} from '@eevo/eevo-core';
import {DatatableModel} from '@eevo/eevo-platform-datatable';
import {Observable, of, Subject} from 'rxjs';
import {map} from 'rxjs/operators';
import {ZoneFilter, ZoneListResponse} from '../models/zone-models';
import {ZoneEntity} from '../entities/zone-entity';
import {AbstractControl, AsyncValidatorFn, ValidationErrors} from '@angular/forms';

@Injectable({
  providedIn: 'root'
})

export class ZoneQueryService {
  constructor(
    private http: HttpClient,
    private zoneEntity: ZoneEntity,
    private utilityService: UtilityService,
    private eevoQueryService: EevoQueryService,
    @Inject('config') private config: any) {
  }

  getZoneList(tableModel: DatatableModel<any>, filter?: ZoneFilter): Observable<ZoneListResponse> {
    let searchFilter = '{}';
    const query = [];

    if (filter) {
      if (filter.searchKey && filter.searchKey.length > 0) {
        let sKey = this.utilityService.matchAnyCharacterRegx(filter.searchKey);
        // filter.searchKey = this.utilityService.matchAnyCharacterRegx(filter.searchKey);
        query.push(`{ 'SelectedZone.Name': { $regex: '${sKey}', $options: 'i'}}`);
      }

      if (query.length > 0) {
        searchFilter = `{$or: [ ${query.join(', ')} ] }`;
      }
    }

    return this.http.post(this.config.ZoneSettingsService.toQueryURL(), [
      {
        source: this.zoneEntity.getListName(),
        text: null,
        filter: searchFilter,
        fields: this.zoneEntity.getListFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.zoneEntity.getListName(),
        text: null,
        filter: searchFilter,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return {
          data: response[0],
          totalCount: response[1][0][0]
        };
      })
    );
  }

  getZoneDetails(zoneId: string): Observable<any> {
    const url = this.config.ZoneSettingsService.toQueryURL();
    return this.eevoQueryService.getDetailsById<any>(
      url, this.zoneEntity.getDetailsName(), zoneId, this.zoneEntity.getDetailsFields()
    );
  }

  zoneExistsValidator(): AsyncValidatorFn {

    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      if (control && control.value !== '' && typeof control.value === 'object') {

        const zoneData = control.value;
        return this.isZoneExists(zoneData.id).pipe(
          map((response: any) => {

            let zoneDetails = null;
            if (response && response[0]) {
              zoneDetails = response[0][0];
            }

            // if res is true, username exists, return true
            return zoneDetails ? { zoneExists: true } : null;
            // NB: Return null if there is no error
          })
        );

      } else {
        return of(null);
      }

    };

  }

  private isZoneExists(zoneId: string): any {
    const query = `{ 'SelectedZone._id' : '${zoneId}'  }`;
    const requestBody = [
      {
        source: this.zoneEntity.getListName(),
        text: null,
        filter: query,
        fields: this.zoneEntity.getListFields(),
        orderBy: 'Language',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.ZoneSettingsService.toQueryURL(), requestBody);
  }
}
