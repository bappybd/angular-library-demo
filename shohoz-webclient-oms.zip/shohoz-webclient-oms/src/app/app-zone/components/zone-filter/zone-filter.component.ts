import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {ShopFilter} from '../../../app-shop/models/shop-models';
import {ZoneService} from '@eevo/eevo-core';
import {debounceTime, distinctUntilChanged, map, startWith} from 'rxjs/operators';
import {MatSelectChange} from '@angular/material/select';

@Component({
  selector: 'app-zone-filter',
  templateUrl: './zone-filter.component.html',
  styleUrls: ['./zone-filter.component.scss']
})
export class ZoneFilterComponent implements OnInit {
  @Output() getDataOnSubmit: EventEmitter<any> = new EventEmitter();
  zoneFilterForm: FormGroup;

  zoneFilter: ShopFilter = {
    affordability: '',
    searchKey: '',
    status: '',
    zone: null
  };

  constructor(
    private zoneService: ZoneService,
    private formBuilder: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.initShopFilterForm();
    // this.loadZoneList();
    this.onShopFilterChanges();
  }

  initShopFilterForm(): void {
    this.zoneFilterForm = this.formBuilder.group({
      searchKey: [''],
      status: [''],
      city: ['']
    });
  }

  onShopFilterChanges(): void {
    this.zoneFilterForm.get('searchKey').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.zoneFilter.searchKey = value;
        this.getDataOnSubmit.emit(this.zoneFilter);
      });
  }

  statusChanged($event: MatSelectChange): void {
    this.zoneFilter.status = this.zoneFilterForm.get('status').value;
    this.getDataOnSubmit.emit(this.zoneFilter);
  }

  cityChanged($event: MatSelectChange): void {
  }
}
