import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, Validators} from '@angular/forms';
import {EevoValidator} from '../../../shared/validator/eevo.validator';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent implements OnInit {
  @Input()
  parent: FormGroup;

  constructor() {
  }

  ngOnInit(): void {
    this.setValidator();
  }

  private setValidator(): void {
    this.setDateTimeValidation();
  }

  setDateTimeValidation(): void {
    const form = this.parent as FormGroup;
    form.setValidators(EevoValidator.isValidDateAndTimeSlot);
    form.updateValueAndValidity();
    this.setRequiredValidator({checked: form.get('Status').value});
  }

  setRequiredValidator(toggleChange): void {
    const form = this.parent as FormGroup;
    if (toggleChange.checked) {
      form.get('ApplicableFromDate').setValidators(Validators.required);
      form.get('ApplicableFromTime').setValidators(Validators.required);
      form.get('ReasonForUnavailability').setValidators(Validators.required);
      form.updateValueAndValidity();

      if (!form.get('IsApplicableUntilFurtherNotice').value) {
        this.requireApplicableToDateAndTime(form);
      }
    } else {
      form.get('ApplicableFromDate').clearValidators();
      form.get('ApplicableFromDate').setErrors(null);
      form.get('ApplicableFromTime').clearValidators();
      form.get('ApplicableFromTime').setErrors(null);
      form.get('ApplicableToDate').clearValidators();
      form.get('ApplicableToDate').setErrors(null);
      form.get('ApplicableToTime').clearValidators();
      form.get('ApplicableToTime').setErrors(null);
      form.get('ReasonForUnavailability').clearValidators();
      form.get('ReasonForUnavailability').setErrors(null);
      form.updateValueAndValidity();
    }
  }

  clearApplicableToValidator($event): void {
    const form = this.parent as FormGroup;
    if ($event.checked) {
      form.get('ApplicableToDate').clearValidators();
      form.get('ApplicableToDate').setErrors(null);
      form.get('ApplicableToTime').clearValidators();
      form.get('ApplicableToTime').setErrors(null);
      form.get('ApplicableToDate').setValue(null);
      form.get('ApplicableToTime').setValue(null);
      form.updateValueAndValidity();
    } else {
      this.requireApplicableToDateAndTime(form);
      form.updateValueAndValidity();
    }
  }

  private requireApplicableToDateAndTime(form: FormGroup): void {
    form.get('ApplicableToDate').setValidators(Validators.required);
    form.get('ApplicableToTime').setValidators(Validators.required);
  }
}
