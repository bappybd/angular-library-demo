import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneBasicInfoComponent } from './zone-basic-info.component';

describe('ZoneBasicInfoComponent', () => {
  let component: ZoneBasicInfoComponent;
  let fixture: ComponentFixture<ZoneBasicInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZoneBasicInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneBasicInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
