import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, Validators} from '@angular/forms';
import {ZoneService} from '@eevo/eevo-core';
import {map, startWith} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {EevoValidator} from '../../../shared/validator/eevo.validator';
import {ZoneQueryService} from '../../services/zone-query.service';
import {ZoneModuleService} from "../../services/zone-module-service";

@Component({
  selector: 'app-zone-basic-info',
  templateUrl: './zone-basic-info.component.html',
  styleUrls: ['./zone-basic-info.component.scss']
})
export class ZoneBasicInfoComponent implements OnInit {
  @Input()
  parent: FormGroup;

  zoneList: any[] = [];
  filteredZoneList: Observable<any[]>;
  selectedZones = {};

  constructor(
    private zoneService: ZoneService,
    private zoneQueryService: ZoneQueryService,
    private zoneModuleService: ZoneModuleService,
  ) { }

  ngOnInit(): void {
    this.loadZoneList();
    this.zoneModuleService.getSubject().subscribe(data => {
      this.selectedZones = data;
    });
  }

  loadZoneList(): void {
    this.zoneService.getFoodZones().subscribe((response) => {
      this.zoneList = response.data;
      this.setFilteredZones();
      this.setZoneValidation();
    });
  }

  zoneOptionSelected($event): void {
    const zone = $event.option.value;
  }

  zoneDisplayFn(data: any): string {
    return data && data.name ? data.name : '';
  }

  private zoneFilter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.zoneList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  private setFilteredZones(): void {
    this.filteredZoneList = this.parent.get('SelectedZone').valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this.zoneFilter(name) : this.zoneList.slice())
      );
  }

  private setZoneValidation(): void {
    const control = this.parent.get('SelectedZone');

    if (this.zoneList && this.zoneList.length) {
      //   Set Validators
      control.setValidators([Validators.required, EevoValidator.dataSelectedValidator()]);
      control.setAsyncValidators([this.zoneQueryService.zoneExistsValidator()]);
      // control.updateOn();
      control.updateValueAndValidity();
    } else {
      //  Clear Validators
      control.clearValidators();

      //   Clear Errors
      control.setErrors(null);
    }
  }

}
