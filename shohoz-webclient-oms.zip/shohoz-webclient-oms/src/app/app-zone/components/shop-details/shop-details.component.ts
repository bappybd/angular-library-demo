import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, Validators} from "@angular/forms";
import {ScheduleHourValidator} from "../../../shared/components/schedule-hour/schedule-hour.validator";
import {EevoValidator} from "../../../shared/validator/eevo.validator";

@Component({
  selector: 'app-shop-details',
  templateUrl: './shop-details.component.html',
  styleUrls: ['./shop-details.component.scss']
})
export class ShopDetailsComponent implements OnInit {
  @Input()
  parent: FormGroup;

  constructor() { }

  ngOnInit(): void {
    this.setDateTimeValidation();
  }

  setDateTimeValidation(): void {
    const form = this.parent as FormGroup;
    form.setValidators(EevoValidator.isValidDateAndTimeSlot);
    form.updateValueAndValidity();
    this.setValidator({checked: form.get('Status').value});
  }

  setValidator(toggleChange): void {
    const form = this.parent as FormGroup;
    if (toggleChange.checked) {
      form.get('ApplicableFromDate').setValidators(Validators.required);
      form.get('ApplicableFromTime').setValidators(Validators.required);
      form.updateValueAndValidity();
      if (!form.get('IsApplicableUntilFurtherNotice').value) {
        this.requireApplicableToDateAndTime(form);
      }
    } else {
      form.get('ApplicableFromDate').clearValidators();
      form.get('ApplicableFromDate').setErrors(null);
      form.get('ApplicableFromTime').clearValidators();
      form.get('ApplicableFromTime').setErrors(null);
      form.get('ApplicableToDate').clearValidators();
      form.get('ApplicableToDate').setErrors(null);
      form.get('ApplicableToTime').clearValidators();
      form.get('ApplicableToTime').setErrors(null);
    }
  }

  clearApplicableToValidator($event): void {
    const form = this.parent as FormGroup;
    if ($event.checked) {
      form.get('ApplicableToDate').clearValidators();
      form.get('ApplicableToDate').setErrors(null);
      form.get('ApplicableToTime').clearValidators();
      form.get('ApplicableToTime').setErrors(null);
      form.get('ApplicableToDate').setValue(null);
      form.get('ApplicableToTime').setValue(null);
      form.updateValueAndValidity();
    } else {
      this.requireApplicableToDateAndTime(form);
      form.updateValueAndValidity();
    }
  }

  private requireApplicableToDateAndTime(form: FormGroup): void {
    form.get('ApplicableToDate').setValidators(Validators.required);
    form.get('ApplicableToTime').setValidators(Validators.required);
  }
}
