import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from "@angular/forms";
import {EevoBasicChipOptions} from "../../../shared/components/eevo-basic-chip-list/eevo-basic-chip-list.component";
import {ScheduleHourOptions} from "../../../shared/components/schedule-hour/schedule-hour.options";
import {ZoneAutocompleteChipOptions} from "../../../shared/components/zone-autocomplete-chip-list/zone-autocomplete-chip-list.component";
import {ActivatedRoute} from "@angular/router";


@Component({
  selector: 'app-zone-details',
  templateUrl: './zone-details.component.html',
  styleUrls: ['./zone-details.component.scss']
})
export class ZoneDetailsComponent implements OnInit {
  @Input()
  parent: FormGroup;

  excludeZoneOptions = {
    labelTxt : 'Exclude Zones',
    suggestionEnable: true,
    suggestionList: [
      'Dhanmondi R.A', 'Khilgaon', 'Azimpur', 'Sayedabad', 'Uttara', 'Mirpur', 'Gulshan', 'Banani', 'Karwan Bazar',
      'Sayedabad', 'Uttara', 'Khilgaon'
    ],
    formControlName: 'ExcludedZones',
    // queryProp: 'SupportedCouponIds',

  } as ZoneAutocompleteChipOptions;

  scheduleHourOptions = {
    startTimeLabel: 'Available from',
    endTimeLabel: 'Available to',
    hourOverlapValidationRequired: true,
    sameForAllDaysRequired: true,
    atLeastOneDayRequired: true
  } as ScheduleHourOptions;

  constructor(private actRoute: ActivatedRoute) {
    this.excludeZoneOptions.ignoreKeyDatas = [this.actRoute.snapshot.params.id];
  }

  ngOnInit(): void {
  }

}
