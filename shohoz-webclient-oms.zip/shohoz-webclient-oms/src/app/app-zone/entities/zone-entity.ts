import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ZoneEvents {
  ZoneBusinessRuleViolationEvent = 'ZoneBusinessRuleViolationEvent',
  ZoneUpdatedEvent = 'ZoneUpdatedEvent',
  ZoneCreatedEvent = 'ZoneCreatedEvent'
}

@Injectable({
  providedIn: 'root'
})

export class ZoneEntity extends EevoEntityRoot {
  Events = ZoneEvents;

  constructor() {
    super('ZoneLists');
  }

  getDetailsFields(): string[] {
    return [
      'UserSettings', 'ShopSettings', 'ServiceHourIsSameForAllDays',
      'ServiceHours', 'LookupRadius', 'SelectedZone', 'ExcludedZones',
      'LookupRadiusForShopDispatch'
    ];
  }

  getListFields(): string[] {
    return [
      'SelectedZone', 'ShopSettings', 'LookupRadius', 'UserSettings' // , 'ServiceHours'
    ];
  }
}
