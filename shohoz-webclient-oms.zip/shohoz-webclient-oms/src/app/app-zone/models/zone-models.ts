import {ScheduledHourModel} from '../../shared/models/scheduled-hour-model';

export interface Zone {
  _id: string;
  Id: string;
  CouponName: string;
  CouponCode: string;
  Rank: number;
  Category: string;
  ValidFrom: string;
  ValidTill: string;
  Active: string;
  Weight: string;
  Status: boolean;
}

export interface ZoneListResponse {
  data: Zone[];
  totalCount: number;
}

export interface ZoneFilter {
  searchKey: string;
  status: string;
  affordability: string;
  zone: any;
}

export class ZoneListConfigModel<T> {
  TotalElements: number;
  TotalPages: number;
  Data: Array<T>;

  constructor() {
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.Data = new Array<T>();
  }
}

export interface ZoneItem {
  Id: string;
  Name: string;
}

export interface ZoneSettingsModel {
  UnavailabilityReason: string;
  ApplicableFrom: string;
  ApplicableTo: string;
  IsBlocked: boolean;
  IsApplicableUntilFurtherNotice: string;
}

export interface ZoneDetailsModel {
  ZoneId: string;
  SelectedZone: ZoneItem;
  UserSettings: ZoneSettingsModel;
  ShopSettings: ZoneSettingsModel;
  ServiceHours: ScheduledHourModel[];
  LookupRadius: number;
  ExcludedZones: ZoneItem;
  ServiceHourIsSameForAllDays: boolean;
  LookupRadiusForShopDispatch?: number;
}
