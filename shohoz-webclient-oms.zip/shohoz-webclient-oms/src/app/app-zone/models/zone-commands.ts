import {EevoCommandBase} from '@eevo/eevo-core';
import {ZoneDetailsModel} from './zone-models';

export class ZoneCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  Zones: ZoneDetailsModel[];
}

// export class CreateZoneCommand extends ZoneCommand {
//   constructor() {
//     super();
//   }
// }
//
// export class UpdateZoneCommand extends ZoneCommand {
//   constructor() {
//     super();
//   }
// }
