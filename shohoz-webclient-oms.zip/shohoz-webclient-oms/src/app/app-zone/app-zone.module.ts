import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppZoneRoutingModule } from './app-zone-routing.module';
import { AppZoneListComponent } from './container/app-zone-list/app-zone-list.component';
import {FlexLayoutModule, FlexModule} from '@angular/flex-layout';
import {MatCardModule} from '@angular/material/card';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import { ZoneFilterComponent } from './components/zone-filter/zone-filter.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AppZoneUpdateComponent } from './container/app-zone-update/app-zone-update.component';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import {MatInputModule} from '@angular/material/input';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {SharedModule} from '../shared/shared.module';
import { ZoneBasicInfoComponent } from './components/zone-basic-info/zone-basic-info.component';
import { AppZoneCreateComponent } from './container/app-zone-create/app-zone-create.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { UserDetailsComponent } from './components/user-details/user-details.component';
import { ShopDetailsComponent } from './components/shop-details/shop-details.component';
import { ZoneDetailsComponent } from './components/zone-details/zone-details.component';
import {ProductNotificationService} from '../app-product/services/product-notification.service';
import {ZoneNotificationService} from './services/zone-notification.service';
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';


@NgModule({
  declarations: [AppZoneListComponent, ZoneFilterComponent, AppZoneUpdateComponent,
    ZoneBasicInfoComponent, AppZoneCreateComponent, UserDetailsComponent, ShopDetailsComponent, ZoneDetailsComponent],
    imports: [
        CommonModule,
        AppZoneRoutingModule,
        FlexModule,
        MatCardModule,
        MatProgressBarModule,
        EevoPlatformDatatableModule,
        NgxDatatableModule,
        MatMenuModule,
        MatButtonModule,
        MatIconModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatSelectModule,
        MatSlideToggleModule,
        EevoPlatformBreadcrumbModule,
        MatInputModule,
        MatDatepickerModule,
        MatCheckboxModule,
        SharedModule,
        MatAutocompleteModule,
        EevoPlatformFeatureGuardModule,
        FlexLayoutModule
    ],
  providers: [
    ZoneNotificationService
  ]
})
export class AppZoneModule { }
