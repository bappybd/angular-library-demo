import {
  Component,
  ElementRef,
  Input,
  OnInit,
  QueryList,
  TemplateRef,
  ViewChild,
  ViewChildren,
  ViewEncapsulation
} from '@angular/core';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {BehaviorSubject} from 'rxjs';
import {Router} from '@angular/router';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {ZoneQueryService} from '../../services/zone-query.service';
import {Zone, ZoneFilter, ZoneListConfigModel} from '../../models/zone-models';
import {ZoneNotificationService} from '../../services/zone-notification.service';
import {ZoneEntity} from '../../entities/zone-entity';


@Component({
  selector: 'app-app-zone-list',
  templateUrl: './app-zone-list.component.html',
  styleUrls: ['./app-zone-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppZoneListComponent implements OnInit {

  constructor(
    private router: Router,
    private zoneEntity: ZoneEntity,
    private zoneQueryService: ZoneQueryService,
    private zoneNotificationService: ZoneNotificationService,
  ) {
  }
  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('zoneCell', {static: true}) zoneCellTemplate: TemplateRef<any>;
  @ViewChild('userStatusCell', {static: true}) userStatusCellTemplate: TemplateRef<any>;
  @ViewChild('shopStatusCell', {static: true}) shopStatusCellTemplate: TemplateRef<any>;
  @ViewChild('shopApplicableFromCell', {static: true}) shopApplicableFromCellTemplate: TemplateRef<any>;
  @ViewChild('shopApplicableToCell', {static: true}) shopApplicableToCellTemplate: TemplateRef<any>;
  @ViewChild('userApplicableFromCell', {static: true}) userApplicableFromCellTemplate: TemplateRef<any>;
  @ViewChild('userApplicableToCell', {static: true}) userApplicableToCellTemplate: TemplateRef<any>;

  @ViewChildren('toggleElement') toggleElementRef: QueryList<ElementRef>;

  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  private datatableModelInput = new BehaviorSubject<ZoneListConfigModel<Zone>>(undefined);
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  searchKey: string;
  zoneFilter: ZoneFilter;
  isLoading = true;
  @Input() searchFilter: string;
  dialogRef: any;
  slideToggleChecked: boolean;

  ngOnInit(): void {
    this.prepareDataTable();

    this.zoneNotificationService.onReceived().subscribe(data => {
      if (data.ActionName !== this.zoneEntity.Events.ZoneBusinessRuleViolationEvent) {
        this.getZoneList(this.datatableModel, this.zoneFilter);
      }
    });
  }

  getSearchFilterData($event: ZoneFilter): void {
    this.zoneFilter = $event;
    this.datatableModel.CurrentPageNumber = 0;
    this.getZoneList(this.datatableModel, this.zoneFilter);
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'SelectedZone',
          name: 'Zone',
          flexGrow: 2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.zoneCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'LookupRadius',
          name: 'Radius',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'UserSettings',
          name: 'User Status',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.userStatusCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopSettings.IsActive',
          name: 'Shop Status',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.shopStatusCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopSettings.ApplicableFrom',
          name: 'Shop Applicable From',
          flexGrow: 2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.shopApplicableFromCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ShopSettings.ApplicableTo',
          name: 'Shop Applicable To',
          flexGrow: 2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.shopApplicableToCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'UserSettings.ApplicableFrom',
          name: 'User Applicable From',
          flexGrow: 2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.userApplicableFromCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'UserSettings.ApplicableTo',
          name: 'User Applicable To',
          flexGrow: 2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.userApplicableToCellTemplate,
          draggable: true,
          sortable: true,
        }
      ] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.getZoneList(this.datatableModel, this.zoneFilter);
    this.initDataTable();
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getZoneList(tableModel, this.zoneFilter);
    this.topFunction();
  }

  selectData(dataTableRow: any): void {
    // this.router.navigate(['shop', 'detail', dataTableRow.Id, 'overview']);
  }

  topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  initDataTable(): void {
    this.datatableModelInput.subscribe(response => {
      this.datatableModel.TotalElements = response ? response[1][0][0] : 0;
      this.datatableModel.Data = response ? response[0] : [];
    }, err => console.log(err));

    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  getZoneList(tableModel: DatatableModel<any>, zoneFilter?: ZoneFilter): void {
    this.isLoading = true;
    this.zoneQueryService.getZoneList(tableModel, zoneFilter).subscribe((response) => {
        this.datatableModel = {
          PageSize: this.datatableModel.PageSize,
          TotalElements: response.totalCount,
          CurrentPageNumber: this.datatableModel.CurrentPageNumber,
          SortBy: this.datatableModel.SortBy,
          Descending: this.datatableModel.Descending,
          Data: response.data,
          ColumnMode: ColumnMode.flex
        };
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = true;
        console.log('Error', error);
      });
  }

  // zoneStatusUpdate(event: MatSlideToggleChange, zone: any): void {
  //   const toggleRef: any = this.toggleElementRef.find((ref: any) => {
  //     return ref.id === zone.Id;
  //   });
  //   const findIndex = this.datatableModel.Data.findIndex(data => data.Id === zone.Id);
  //   this.datatableModel.Data[findIndex].Status = event.checked;
  //   toggleRef.checked = event.checked;
  // }

  addNewZone(): void {
    this.router.navigate(['/zones/create']);
  }
}
