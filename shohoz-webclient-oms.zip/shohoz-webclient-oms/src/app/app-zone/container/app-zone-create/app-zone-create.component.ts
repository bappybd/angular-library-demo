import {Component, OnInit} from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {FormGroup} from '@angular/forms';
import {Router} from '@angular/router';
import {ZoneFormBuilderService} from '../../services/zone-form-builder.service';
import {fuseAnimations} from '@eevo/eevo-base';
import {ZoneCommandBuilderService} from '../../services/zone-command-builder.service';
import {EevoNotifyService, NotifyType} from '@eevo/eevo-core';
import {ZoneEntity} from '../../entities/zone-entity';
import {ZoneNotificationService} from '../../services/zone-notification.service';
import {ZoneCommandService} from '../../services/zone-command.service';

@Component({
  selector: 'app-app-zone-create',
  templateUrl: './app-zone-create.component.html',
  styleUrls: ['./app-zone-create.component.scss'],
  animations: fuseAnimations
})
export class AppZoneCreateComponent implements OnInit {
  zoneForm: FormGroup;
  formSubmitted = false;
  breadcrumbList: BreadcrumbModel[] = [];

  constructor(
    private router: Router,
    private zoneEntity: ZoneEntity,
    private eevoNotifyService: EevoNotifyService,
    private zoneCommandService: ZoneCommandService,
    private zoneFormBuilderService: ZoneFormBuilderService,
    private zoneNotificationService: ZoneNotificationService,
    private zoneCommandBuilderService: ZoneCommandBuilderService,
  ) {
  }

  ngOnInit(): void {
    this.setBreadcrumbData();
    this.zoneForm = this.zoneFormBuilderService.getZoneForm();
  }

  goToZoneListPage(): void {
    this.router.navigate(['/zones']);
  }

  createZone(): void {
    this.zoneForm.markAllAsTouched();
    if (this.zoneForm.valid) {
      this.formSubmitted = true;
      this.zoneNotificationService.zoneCreated();
      this.eevoNotifyService.displayMessage(this.zoneEntity.getMessages().CREATE_REQUEST, NotifyType.Info);

      const command = this.zoneCommandBuilderService.getZoneCommand(this.zoneForm);
      this.zoneCommandService.createZone(command).subscribe(data => {
        this.goToZoneListPage();
        this.formSubmitted = false;
      }, error => {
        this.formSubmitted = false;
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
      });
    }
  }

  get getUserDetailsForm(): FormGroup {
    return this.zoneForm.get('UserDetails') as FormGroup;
  }

  get getShopDetailsForm(): FormGroup {
    return this.zoneForm.get('ShopDetails') as FormGroup;
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Zones',
      Path: ['/zones']
    });

    this.breadcrumbList.push({
      Text: 'Create Zone'
    });
  }
}
