import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppZoneCreateComponent } from './app-zone-create.component';

describe('AppZoneCreateComponent', () => {
  let component: AppZoneCreateComponent;
  let fixture: ComponentFixture<AppZoneCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppZoneCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppZoneCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
