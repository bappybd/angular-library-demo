import { Component, OnInit } from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {FormGroup} from '@angular/forms';
import {ZoneFormBuilderService} from '../../services/zone-form-builder.service';
import {ActivatedRoute, Router} from '@angular/router';
import {fuseAnimations} from '@eevo/eevo-base';
import {ZoneEntity} from '../../entities/zone-entity';
import {EevoNotifyService, NotifyType} from '@eevo/eevo-core';
import {ZoneCommandService} from '../../services/zone-command.service';
import {ZoneNotificationService} from '../../services/zone-notification.service';
import {ZoneCommandBuilderService} from '../../services/zone-command-builder.service';
import {ZoneQueryService} from "../../services/zone-query.service";

@Component({
  selector: 'app-app-zone-update',
  templateUrl: './app-zone-update.component.html',
  styleUrls: ['./app-zone-update.component.scss'],
  animations: fuseAnimations
})
export class AppZoneUpdateComponent implements OnInit {
  zoneId: string;
  zoneDetails: any;
  zoneForm: FormGroup;
  formSubmitted = false;
  loadingFromServer = true;
  breadcrumbList: BreadcrumbModel[] = [];

  constructor(
    private router: Router,
    private zoneEntity: ZoneEntity,
    private actRoute: ActivatedRoute,
    private eevoNotifyService: EevoNotifyService,
    private zoneQueryService: ZoneQueryService,
    private zoneCommandService: ZoneCommandService,
    private zoneFormBuilderService: ZoneFormBuilderService,
    private zoneNotificationService: ZoneNotificationService,
    private zoneCommandBuilderService: ZoneCommandBuilderService,
  ) {
    this.zoneId = this.actRoute.snapshot.params.id;
  }

  ngOnInit(): void {
    this.zoneForm = this.zoneFormBuilderService.getZoneForm();

    this.zoneQueryService.getZoneDetails(this.zoneId).subscribe((data) => {
      this.loadingFromServer = false;
      if (data) {
        this.zoneDetails = data;
        this.setBreadcrumbData();
        this.zoneFormBuilderService.setZoneFormData(this.zoneForm, this.zoneDetails);
      }
    });
  }

  goToZoneListPage(): void {
    this.router.navigate(['/zones']);
  }

  updateZone(): void {
    this.zoneForm.markAllAsTouched();
    if (this.zoneForm.valid) {
      this.formSubmitted = true;
      this.zoneNotificationService.zoneUpdated();
      this.eevoNotifyService.displayMessage(this.zoneEntity.getMessages().UPDATE_REQUEST, NotifyType.Info);

      const command = this.zoneCommandBuilderService.getZoneCommand(this.zoneForm, this.zoneId);

      this.zoneCommandService.updateZone(command).subscribe(data => {
        this.formSubmitted = false;
        this.goToZoneListPage();
      }, error => {
        this.formSubmitted = false;
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
      });
    }
  }

  get getUserDetailsForm(): FormGroup {
    return this.zoneForm.get('UserDetails') as FormGroup;
  }

  get getShopDetailsForm(): FormGroup {
    return this.zoneForm.get('ShopDetails') as FormGroup;
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Zones',
      Path: ['/zones']
    });

    this.breadcrumbList.push({
      Text: this.zoneDetails.SelectedZone.Name
    });
  }

}
