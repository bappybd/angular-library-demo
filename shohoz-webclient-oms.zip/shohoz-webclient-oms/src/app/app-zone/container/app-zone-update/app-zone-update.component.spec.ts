import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppZoneUpdateComponent } from './app-zone-update.component';

describe('AppZoneUpdateComponent', () => {
  let component: AppZoneUpdateComponent;
  let fixture: ComponentFixture<AppZoneUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppZoneUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppZoneUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
