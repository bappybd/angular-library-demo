import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AppZoneListComponent} from './container/app-zone-list/app-zone-list.component';
import {AppZoneUpdateComponent} from './container/app-zone-update/app-zone-update.component';
import {AppZoneCreateComponent} from './container/app-zone-create/app-zone-create.component';
import {FeatureAccessPermission} from '@eevo/eevo-core';

const routes: Routes = [
  {
    path: '',
    component: AppZoneListComponent,
    data: {isFullScreen: true}
  },
  {
    path: 'create',
    component: AppZoneCreateComponent,
    data: {isFullScreen: true, name: 'zone.config.create'},
    canActivate: [FeatureAccessPermission]
  },
  {
    path: 'update/:id',
    component: AppZoneUpdateComponent,
    data: {isFullScreen: true, name: 'zone.config.details'},
    canActivate: [FeatureAccessPermission]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppZoneRoutingModule { }
