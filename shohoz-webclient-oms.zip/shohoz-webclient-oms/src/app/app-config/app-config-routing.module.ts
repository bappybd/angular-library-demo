import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {UserHomePageComponent} from './container/user-home-page-section/user-home-page.component';
import {UserHomePageSectionDetailsComponent} from './container/user-home-page-section-details/user-home-page-section-details.component';

const routes: Routes = [
  {
    path: '',
    component: UserHomePageComponent,
    data: {isFullScreen: true}
  },
  {
    path: 'user-home-page-section-config',
    component: UserHomePageComponent,
    data: {isFullScreen: true}
  },
  {
    path: 'user-home-page-section-config/:id/details',
    component: UserHomePageSectionDetailsComponent,
    data: {isFullScreen: true}
  },
  {
    path: 'user-home-page-section-config/:id/details/:detailId',
    component: UserHomePageSectionDetailsComponent,
    data: {isFullScreen: true}
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppConfigRoutingModule { }
