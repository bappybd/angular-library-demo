import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ConfigEvents {
  AppConfigBusinessRuleViolatedEvent = 'AppConfigBusinessRuleViolatedEvent'
}

@Injectable({
  providedIn: 'root'
})
export class ConfigEntity extends EevoEntityRoot {
  Events = ConfigEvents;

  constructor() {
    super('FoodHomeSectionItemDatas', 'Coupon');
  }

  getDetailsFields(): string[] {
    return [
      'CouponName', 'Category', 'ValidFrom', 'ValidTill', 'MaximumDiscountAmount', 'CouponLogics',
      'Rank', 'SupportedCouponIds', 'Description_En', 'Description_Bn', 'HighlightText_Bn',
      'HighlightText_En', 'MaxRedeemCountPerUser', 'MaxRedeemCountPerUserPerDay',
      'MaxRedeemCount', 'ShohozPortionOfDiscount', 'CouponCode', 'AutoApplied', 'CouponState',
      'CityIds', 'PaymentMethodIds', 'DiscountPartnerIds', 'IsProductCoupon'
    ];
  }

  getListFields(): string[] {
    return [
      'CouponName', 'ValidFrom', 'ValidTill', 'CouponState', 'Rank', 'CouponCode'
    ];
  }

}
