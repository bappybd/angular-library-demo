import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ConfigImageType {
  Image = 'image',
}
enum ConfigImageFolder {
  PredefinedFilter = 'predefined-filter',
}
class ConfigEvents {
}

@Injectable({
  providedIn: 'root'
})
export class UserAppHomeConfigEntity extends EevoEntityRoot {
  Events = ConfigEvents;

  ImageType = ConfigImageType;
  ImageFolder = ConfigImageFolder;

  constructor() {
    super('FoodHomeMobileUIConfigs', 'App config');
  }

  getDetailsFields(): string[] {
    return [
      'SectionName', 'SectionOrder', 'Whole'
    ];
  }

  getListFields(): string[] {
    return [
      'SectionName', 'SectionOrder', 'Whole'
    ];
  }

}
