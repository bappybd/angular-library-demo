import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserHomePageComponent } from './container/user-home-page-section/user-home-page.component';
import { PredefinedFilterFormComponent } from './components/predefined-filter-form/predefined-filter-form.component';
import {AppConfigRoutingModule} from './app-config-routing.module';
import {MatCardModule} from '@angular/material/card';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {SharedModule} from '../shared/shared.module';
import {ConfigNotificationService} from './services/config-notification.service';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import { DataFilterFormComponent } from './components/data-filter-form/data-filter-form.component';
import {MatIconModule} from '@angular/material/icon';
import {FlexLayoutModule, FlexModule} from '@angular/flex-layout';
import {MatButtonModule} from '@angular/material/button';
import {MatMenuModule} from '@angular/material/menu';
import { UserHomePageSectionDetailsComponent } from './container/user-home-page-section-details/user-home-page-section-details.component';
import {FuseSidebarModule} from '@eevo/eevo-base';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatFormFieldModule} from '@angular/material/form-field';
import { PredefinedFilterCreateComponent } from './components/predefined-filter-create/predefined-filter-create.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatInputModule} from '@angular/material/input';
import {EevoImageUploaderModule} from "@eevo/eevo-image-uploader";
import { PredefinedFilterUpdateComponent } from './components/predefined-filter-update/predefined-filter-update.component';
import {MatSlideToggleModule} from "@angular/material/slide-toggle";
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';
import {NgxDatatableModule} from "@swimlane/ngx-datatable";
import {PredefinedFilterCreateWithZoneAndTimeComponent} from './components/predefined-filter-create-with-zone-and-time/predefined-filter-create-with-zone-and-time.component';
import {PredefinedFilterFormWithZoneAndTimeComponent} from './components/predefined-filter-form-with-zone-and-time/predefined-filter-form-with-zone-and-time.component';
import { PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent } from './components/predefined-filter-form-with-zone-and-time-time-selector/predefined-filter-form-with-zone-and-time-time-selector.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { PredefinedFilterUpdateWithTimeAndZoneComponent } from './components/predefined-filter-update-with-time-and-zone/predefined-filter-update-with-time-and-zone.component';
import {MatRadioModule} from '@angular/material/radio';

@NgModule({
  declarations: [
    UserHomePageComponent,
    PredefinedFilterFormComponent,
    DataFilterFormComponent,
    UserHomePageSectionDetailsComponent,
    PredefinedFilterCreateComponent,
    PredefinedFilterUpdateComponent,
    PredefinedFilterCreateWithZoneAndTimeComponent,
    PredefinedFilterFormWithZoneAndTimeComponent,
    PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent,
    PredefinedFilterUpdateWithTimeAndZoneComponent,
  ],
    imports: [
        CommonModule,
        SharedModule,
        FlexModule,
        FlexLayoutModule,
        AppConfigRoutingModule,
        MatCardModule,
        EevoPlatformDatatableModule,
        MatProgressBarModule,
        EevoPlatformBreadcrumbModule,
        MatIconModule,
        MatButtonModule,
        MatMenuModule,
        FuseSidebarModule,
        MatToolbarModule,
        MatFormFieldModule,
        ReactiveFormsModule,
        MatCheckboxModule,
        MatInputModule,
        EevoImageUploaderModule,
        MatSlideToggleModule,
        EevoPlatformFeatureGuardModule,
        NgxDatatableModule,
        MatDatepickerModule,
        MatRadioModule,
    ],
  providers: [
    ConfigNotificationService
  ]
})
export class AppConfigModule { }
