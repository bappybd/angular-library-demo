import {Injectable} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {AppConfigTimeAndZoneModel, PredefinedFilterModel} from '../models/config-models';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class ConfigFormBuilder {

  constructor(
    private formBuilder: FormBuilder,
    private scheduleHourService: ScheduleHourService
  ) {
  }

  getForm(data?: PredefinedFilterModel, includeTimeZone = false): FormGroup {
    const hasItemData = data && data.SectionItemDataId ? true : false;

    const configForm = this.formBuilder.group({
      Name: [hasItemData ? data.Name : '', Validators.required],
      Query: [hasItemData ? data.Query : ''],
      EntityName: [hasItemData ? data.EntityName : ''],
      Fields: [hasItemData ? data.Fields : ''],
      IsExternalLink: [hasItemData ? data.IsExternalLink : false],
      IsInternalLink: [hasItemData ? data.IsInternalLink ? data.IsInternalLink : false : false],
      IsActive: [hasItemData ? data.IsActive : false],
      Link: [hasItemData ? data.Link : ''],
      Order: [hasItemData ? data.Order : 99],
      EntityOrderBy: [data && data.EntityOrderBy || -1],
      EntitySortBy: [data && data.EntitySortBy || 'CreatedDate'],
      HasCurationName: [hasItemData ? data.HasCurationName : false],
      CurationName: [hasItemData ? data.CurationName : ''],
    });

    if (includeTimeZone) {
      configForm.addControl('appConfigTimeAndZone', this.getTimeZoneForm(data?.AppConfigTimeAndZone));
    }
    return configForm;
  }

  private getTimeZoneForm(data?: AppConfigTimeAndZoneModel): FormGroup {
    return this.formBuilder.group({
      IsAllZones: [data ? data?.IsAllZones : false],
      ApplicableZones: [this.getApplicableZone(data), data?.IsAllZones ? [] : [Validators.required]],
      IsWeekly: [data ? data?.IsWeekly : false],
      IsDateRange: [data ? data?.IsDateRange : false],
      IsAlwaysAvailable: [data ? data.hasOwnProperty('IsAlwaysAvailable') ? !!data.IsAlwaysAvailable : true : true],
      AvailabilityType: [this.getAvailabilityType(data), [Validators.required]]
    });
  }

  private getApplicableZone(data?: AppConfigTimeAndZoneModel): any[] {
    return data ? data?.ApplicableZones.map(AZ => ({Id: AZ?._id || AZ?.Id, Name: AZ?.Name})) : [];
  }

  private getAvailabilityType(data?: AppConfigTimeAndZoneModel): number {
    if (data?.IsAlwaysAvailable) {
      return 0;
    }
    if (data?.IsWeekly) {
      return 1;
    }
    if (data?.IsDateRange) {
      return 2;
    }
    return 0;
  }

  addDateRangeFormFields(parentForm: FormGroup, appConfigTimeAndZone: AppConfigTimeAndZoneModel): void {
    const {IsApplicableUntilFurtherNotice = false} = appConfigTimeAndZone || {};

    parentForm.addControl('ApplicableFromDate', new FormControl(appConfigTimeAndZone?.ApplicableFrom || null, Validators.required));
    parentForm.addControl('ApplicableFromTime', new FormControl(this.getTimeSlot(appConfigTimeAndZone?.ApplicableFrom), Validators.required));
    parentForm.addControl('IsApplicableUntilFurtherNotice', new FormControl(IsApplicableUntilFurtherNotice));
    parentForm.addControl('ApplicableToDate', new FormControl(IsApplicableUntilFurtherNotice ? null : appConfigTimeAndZone?.ApplicableTo || null, IsApplicableUntilFurtherNotice ? [] : [Validators.required]));
    parentForm.addControl('ApplicableToTime', new FormControl(IsApplicableUntilFurtherNotice ? null : this.getTimeSlot(appConfigTimeAndZone?.ApplicableTo), IsApplicableUntilFurtherNotice ? [] : [Validators.required]));
  }

  removeDateRangeFormFields(parentForm: FormGroup): void {
    parentForm.removeControl('ApplicableFromDate');
    parentForm.removeControl('ApplicableFromTime');
    parentForm.removeControl('IsApplicableUntilFurtherNotice');
    parentForm.removeControl('ApplicableToDate');
    parentForm.removeControl('ApplicableToTime');
  }

  private getTimeSlot(date: string): string {
    if (!date) {
      return null;
    }
    const dt = new Date(date);
    return _.padStart(dt.getHours() + '', 2, '0') + ':' + _.padStart(dt.getMinutes() + '', 2, '0');
  }
}
