import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {PredefinedFilterCommand} from '../models/config-commands';
import {map} from "rxjs/operators";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})

export class ConfigCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createPredefinedFilterConfig(command: PredefinedFilterCommand): Observable<any> {
    return this.http.post(this.config.AppConfigService.toCommandURL('CreateSectionItemData'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updatePredefinedFilterConfig(command: PredefinedFilterCommand): Observable<any> {
    return this.http.post(this.config.AppConfigService.toCommandURL('UpdateSectionItemData'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
