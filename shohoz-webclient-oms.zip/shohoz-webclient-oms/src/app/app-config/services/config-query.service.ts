import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {DatatableModel} from '@eevo/eevo-platform-datatable';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ConfigEntity} from '../entities/config-entity';
import {UserAppHomeConfigEntity} from '../entities/user-app-home-config-entity';
import {UserAppHomeConfigListResponse} from '../models/config-models';

@Injectable({
  providedIn: 'root'
})

export class ConfigQueryService {
  constructor(
    private http: HttpClient,
    private configEntity: ConfigEntity,
    private userAppHomeConfigEntity: UserAppHomeConfigEntity,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getUserAppHomeConfigDetails(id: string): Observable<any> {
    const query = `{ $or: [{'_id' : '${id}'}, {'_id' : GUID('${id}')}]  }`;
    const requestBody = [
      {
        source: this.userAppHomeConfigEntity.getListName(),
        text: null,
        filter: query,
        fields: this.userAppHomeConfigEntity.getDetailsFields(),
        orderBy: 'SectionOrder',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.AppConfigService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        response[0].map(data => {
          data.CouponId = data.Id;
          return data;
        });

        if (response && response[0]) {
          return response[0][0];
        }
        return null;
      })
    );
  }

  getUserAppHomeConfigList(tableModel: DatatableModel<any>, filter?: any): Observable<UserAppHomeConfigListResponse> {
    const searchFilter = '{}';
    const query = [];

    if (filter) {
    }

    return this.http.post(this.config.AppConfigService.toQueryURL(), [
      {
        source: this.userAppHomeConfigEntity.getListName(),
        text: null,
        filter: searchFilter,
        fields: this.userAppHomeConfigEntity.getListFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.userAppHomeConfigEntity.getListName(),
        text: null,
        filter: searchFilter,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return {
          data: response[0],
          totalCount: response[1][0][0]
        };
      })
    );
  }

}
