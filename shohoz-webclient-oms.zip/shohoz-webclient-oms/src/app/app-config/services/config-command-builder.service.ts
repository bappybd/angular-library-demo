import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {FormGroup} from '@angular/forms';
import {PredefinedFilterCommand} from '../models/config-commands';
import {AppConfigTimeAndZoneModel, PredefinedFilterModel} from '../models/config-models';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';

@Injectable({
  providedIn: 'root'
})

export class ConfigCommandBuilderService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    private scheduleHourService: ScheduleHourService,
    @Inject('config') private config: any) {
  }

  getPredefinedFilterConfigCommand(sectionId: string, sectionDataId: string, formPayload: FormGroup): PredefinedFilterCommand {
    const form = Object.assign({}, formPayload);
    const formData = form.value;

    const sectionItemData = new PredefinedFilterModel();
    sectionItemData.SectionItemDataId = sectionDataId;
    sectionItemData.Name = formData.Name;
    sectionItemData.Query = formData.Query;
    sectionItemData.EntityName = formData.EntityName;
    sectionItemData.Fields = formData.Fields;
    sectionItemData.IsExternalLink = formData.IsExternalLink;
    sectionItemData.IsInternalLink = formData.IsInternalLink;
    sectionItemData.Link = formData.Link;
    sectionItemData.IsActive = formData.IsActive;
    sectionItemData.Order = formData.Order;
    sectionItemData.EntityOrderBy = formData.EntityOrderBy;
    sectionItemData.EntitySortBy = formData.EntitySortBy;
    sectionItemData.HasCurationName = Boolean(formData.HasCurationName);
    sectionItemData.CurationName = (formData.HasCurationName) ? formData.CurationName : null;

    const command = new PredefinedFilterCommand();
    command.SectionItemId = sectionId;
    command.SectionItemData = sectionItemData;

    if (formData.hasOwnProperty('appConfigTimeAndZone')) {
      command.SectionItemData.AppConfigTimeAndZone = this.createAppConfigTimeAndZoneCommand(formData);
    }
    return command;
  }

  private createAppConfigTimeAndZoneCommand(formData: any): AppConfigTimeAndZoneModel {
    let command = {
      IsAllZones: formData?.appConfigTimeAndZone?.IsAllZones || false,
      ApplicableZones: !formData?.appConfigTimeAndZone?.IsAllZones && formData?.appConfigTimeAndZone?.ApplicableZones || [],
      IsWeekly: formData?.appConfigTimeAndZone?.IsWeekly || false,
      IsDateRange: formData?.appConfigTimeAndZone?.IsDateRange || false,
      IsAlwaysAvailable: formData?.appConfigTimeAndZone?.IsAlwaysAvailable || false,
    } as AppConfigTimeAndZoneModel;
    if (formData?.appConfigTimeAndZone?.IsWeekly) {
      command = {
        ...command,
        ServiceHourIsSameForAllDays: formData.appConfigTimeAndZone?.ScheduledHours.IsSameForAllDaysServiceHours,
        ScheduledHours: this.scheduleHourService.getScheduledHoursPayload(formData?.appConfigTimeAndZone?.ScheduledHours)
      };
    }

    if (formData?.appConfigTimeAndZone?.IsDateRange) {
      const nextCenturyDate = new Date();
      nextCenturyDate.setFullYear(nextCenturyDate.getFullYear() + 100);
      nextCenturyDate.setMinutes(59);
      nextCenturyDate.setSeconds(59);

      command = {
        ...command,
        ApplicableFrom: this.getISODateWithTimeString(
          formData?.appConfigTimeAndZone?.ApplicableFromDate, formData?.appConfigTimeAndZone?.ApplicableFromTime, true
        ),
        IsApplicableUntilFurtherNotice: formData?.appConfigTimeAndZone?.IsApplicableUntilFurtherNotice,
        ApplicableTo: formData?.appConfigTimeAndZone?.IsApplicableUntilFurtherNotice ?
          nextCenturyDate.toISOString() : this.getISODateWithTimeString(
            formData?.appConfigTimeAndZone?.ApplicableToDate, formData?.appConfigTimeAndZone?.ApplicableToTime, false
          )
      };
    }
    return command;
  }

  private getISODateWithTimeString(date: Date, time: string, startTime: boolean = true): string {
    if (date) {
      return this.combineDateWithTime(date, time, startTime).toISOString();
    }

    return new Date('0001-01-01').toISOString();
  }

  private combineDateWithTime(date: Date, time: string, startTime: boolean = true): Date {
    date = new Date(date);
    let hour = 0;
    let minute = 0;

    if (time !== '') {
      const hourAndMinute = time.split(':');
      hour = Number(hourAndMinute[0]);
      minute = Number(hourAndMinute[1]);
    }

    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      hour,
      minute,
      startTime ? 0 : 59
    );
  }
}
