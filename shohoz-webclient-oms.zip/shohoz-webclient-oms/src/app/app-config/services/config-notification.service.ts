import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';
import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {ConfigEntity} from '../entities/config-entity';

@Injectable({
  providedIn: 'root'
})

export class ConfigNotificationService extends EevoNotificationBase<CommandNotificationModel> {
  constructor(
    private configEntity: ConfigEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(
      this.configEntity.Events.AppConfigBusinessRuleViolatedEvent, (response) => {
        const data = this.notificationHandlerService.parseAndDisplayMessage(response, false);
        // this.deliver(data);
      });
  }

}
