import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-filter-form',
  templateUrl: './data-filter-form.component.html',
  styleUrls: ['./data-filter-form.component.scss']
})
export class DataFilterFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
