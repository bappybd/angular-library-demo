import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedFilterCreateComponent } from './predefined-filter-create.component';

describe('PredefinedFilterCreateComponent', () => {
  let component: PredefinedFilterCreateComponent;
  let fixture: ComponentFixture<PredefinedFilterCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedFilterCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedFilterCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
