import {ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {FuseSidebarService} from '@eevo/eevo-base';
import {ConfigFormBuilder} from '../../services/config-form-builder';
import {EevoFileUploadService, EevoNotifyService, FilesModel, NotifyType, UtilityService} from '@eevo/eevo-core';
import {forkJoin, Subscription} from 'rxjs';
import {ConfigCommandService} from '../../services/config-command.service';
import {ConfigCommandBuilderService} from '../../services/config-command-builder.service';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {UserAppHomeConfigEntity} from '../../entities/user-app-home-config-entity';
import {SubSink} from "subsink";

@Component({
  selector: 'app-predefined-filter-create',
  templateUrl: './predefined-filter-create.component.html',
  styleUrls: ['./predefined-filter-create.component.scss']
})
export class PredefinedFilterCreateComponent implements OnInit, OnDestroy {

  loadingFromServer = true;
  configForm: FormGroup;
  formSubmitted = false;
  file: FilesModel;
  private subs = new SubSink();

  @Input()
  sectionId: string;

  @Output() finished: EventEmitter<any> = new EventEmitter();

  constructor(
    private utilityService: UtilityService,
    private fuseSidebarService: FuseSidebarService,
    private eevoNotifyService: EevoNotifyService,
    private configFormBuilder: ConfigFormBuilder,
    private configCommandService: ConfigCommandService,
    private configCommandBuilderService: ConfigCommandBuilderService,
    private eevoFileUploadService: EevoFileUploadService,
    private signalrNotificationService: SignalrNotificationService,
    private userAppHomeConfigEntity: UserAppHomeConfigEntity,
    private cdr: ChangeDetectorRef
  ) {
  }

  ngOnInit(): void {
    this.loadingFromServer = false;
    this.initFormGroup();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  initFormGroup(): void {
    this.file = new FilesModel();
    this.configForm = this.configFormBuilder.getForm();
  }

  toggleSidebarOpen(key: string): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  create(): void {
    this.configForm.markAllAsTouched();
    if (this.configForm.valid) {
      this.formSubmitted = true;
      this.eevoNotifyService.displayMessage('Predefined filter config create requested', NotifyType.Info);

      const subscription = forkJoin(this.getCrateCalls()).subscribe(data => {
        this.formSubmitted = false;
        this.toggleSidebarOpen('predefinedFilterCrate');
        this.finished.emit({success: true});
        this.eevoNotifyService.displayMessage('Successfully created');
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
        this.toggleSidebarOpen('predefinedFilterCrate');
      });
      this.subs.sink = subscription;
    }
  }

  private getCrateCalls(): any[] {
    const calls = [];

    const detailsId = this.utilityService.getNewGuid();

    const predefinedCommand = this.configCommandBuilderService.getPredefinedFilterConfigCommand(this.sectionId, detailsId, this.configForm);

    calls.push(
      this.configCommandService.createPredefinedFilterConfig(
        predefinedCommand
      )
    );

    if (this.file.Files.length > 0) {
      calls.push(
        this.eevoFileUploadService.uploadPublicImages(
          this.signalrNotificationService,
          this.userAppHomeConfigEntity.ImageFolder.PredefinedFilter,
          detailsId,
          this.file
        )
      );
    }

    return calls;
  }

}
