import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedFilterFormComponent } from './predefined-filter-form.component';

describe('PredefinedFilterFormComponent', () => {
  let component: PredefinedFilterFormComponent;
  let fixture: ComponentFixture<PredefinedFilterFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedFilterFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedFilterFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
