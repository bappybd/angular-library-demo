import {ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {FormGroup, Validators} from '@angular/forms';
import {EevoStorageService, FilesModel, UtilityService} from '@eevo/eevo-core';
import {EevoBasicChipOptions} from '../../../shared/components/eevo-basic-chip-list/eevo-basic-chip-list.component';
import {UserAppHomeConfigEntity} from '../../entities/user-app-home-config-entity';
import {MatCheckboxChange} from '@angular/material/checkbox';
import {ZoneAutocompleteChipOptions} from '../../../shared/components/zone-autocomplete-chip-list/zone-autocomplete-chip-list.component';
import {MatSlideToggleChange} from '@angular/material/slide-toggle';
import {PredefinedFilterModel} from '../../models/config-models';

@Component({
  selector: 'app-predefined-filter-form-with-zone-and-time',
  templateUrl: './predefined-filter-form-with-zone-and-time.component.html',
  styleUrls: ['./predefined-filter-form-with-zone-and-time.component.scss']
})
export class PredefinedFilterFormWithZoneAndTimeComponent implements OnInit {

  @Input()
  parent: FormGroup;

  @Input()
  file: FilesModel;

  @Input()
  predefinedFilterDetails?: PredefinedFilterModel;

  private detailId;

  @Input()
  set detailsId(value: any) {
    this.getImageUrl(value);
    this.detailId = value;
  }

  get detailsId(): any {
    return this.detailId;
  }

  // detailsId: string;

  imagePath: string;
  imageUploaderConfig = {
    thumbnailHeight: 120,
    thumbnailWidth: 200,
    showUploadButton: true,
    profileImage: false,
    allowedImageTypes: ['png'],
    maxImageSize: 5, // Megabyte,
    textBrowseFile: 'Drop your image here, or browse',
    subTextBrowseFile: 'Supports PNG (100*100)',
    uploadIconName: 'insert_photo',
    hideNotFoundError: true
  };

  fieldsOptions = {
    labelTxt: 'View Model Fields',
    suggestionEnable: false,
    formControlName: 'Fields'
  } as EevoBasicChipOptions;

  excludeZoneOptions = {
    labelTxt: 'Specific Zones',
    suggestionEnable: true,
    suggestionList: [
      'Dhanmondi R.A', 'Khilgaon', 'Azimpur', 'Sayedabad', 'Uttara', 'Mirpur', 'Gulshan', 'Banani', 'Karwan Bazar',
      'Sayedabad', 'Uttara', 'Khilgaon'
    ],
    formControlName: 'ApplicableZones',
    // queryProp: 'SupportedCouponIds',

  } as ZoneAutocompleteChipOptions;

  constructor(
    private cdr: ChangeDetectorRef,
    private utilityService: UtilityService,
    private eevoStorageService: EevoStorageService,
    private userAppHomeConfigEntity: UserAppHomeConfigEntity
  ) {
  }

  ngOnInit(): void {

  }

  getImageUrl(detailsId): void {
    this.imagePath = '';
    if (detailsId) {
      this.imagePath = this.eevoStorageService.getFileUrl(
        this.userAppHomeConfigEntity.getFileKey(
          detailsId,
          this.userAppHomeConfigEntity.ImageType.Image,
          'png',
          this.userAppHomeConfigEntity.ImageFolder.PredefinedFilter,
          `?t=${new Date().getMilliseconds()}`
        )
      );
    }
  }

  onImageFileChanged(event): void {
    this.file.Files = this.file.Files.filter(item => {
      return item.Type !== this.userAppHomeConfigEntity.ImageType.Image;
    });

    this.file.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.userAppHomeConfigEntity.ImageType.Image
    });
  }

  onIsExternalOrInternalLinkChange(event: MatCheckboxChange, isExternalLinkEnable = true): void {
    const controlQuery = this.parent.get('Query');
    const controlEntityName = this.parent.get('EntityName');
    const controlLink = this.parent.get('Link');
    let isExternalOrInternalLink = false;


    if (isExternalLinkEnable) {
      isExternalOrInternalLink = this.parent.get('IsExternalLink').value;
      if (isExternalOrInternalLink) {
        this.parent.get('IsInternalLink').setValue(false);
      }
    } else {
      isExternalOrInternalLink = this.parent.get('IsInternalLink').value;
      if (isExternalOrInternalLink) {
        this.parent.get('IsExternalLink').setValue(false);
      }
    }
    const linkDisable = !((event && event.checked) || isExternalOrInternalLink);

    if (linkDisable) {
      //   Set Validators
      controlQuery.setValidators([Validators.required]);
      controlQuery.updateValueAndValidity();

      controlEntityName.setValidators([Validators.required]);
      controlEntityName.updateValueAndValidity();

      // Clear Errors && Validators
      controlLink.clearValidators();
      controlLink.setErrors(null);
    } else {
      controlLink.setValidators([Validators.required]);
      controlLink.updateValueAndValidity();

      //  Clear Validators && Errors
      controlQuery.clearValidators();
      controlQuery.setErrors(null);
      controlEntityName.clearValidators();
      controlEntityName.setErrors(null);
    }
  }

  onHasSectionItemChange($event: MatCheckboxChange): void {
    const curationName = this.parent.get('CurationName');

    if (!($event && $event.checked)) {
      //   Set Validators
      curationName.setValidators([Validators.required]);
      curationName.updateValueAndValidity();
    } else {
      //  Clear Validators && Errors
      curationName.clearValidators();
      curationName.setErrors(null);
    }
  }

  onAllZoneSelection($event: MatSlideToggleChange): void {
    const zoneNamesProperty = this.parent.get('appConfigTimeAndZone.ApplicableZones');
    if ($event.checked) {
      //   Set Validators
      // zoneNamesProperty.setValue([]);
      zoneNamesProperty.clearValidators();
      zoneNamesProperty.updateValueAndValidity();
    } else {
      //  Clear Validators && Errors
      zoneNamesProperty.setValidators([Validators.required]);
      zoneNamesProperty.setErrors(null);
    }
  }

}
