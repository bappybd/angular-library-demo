import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedFilterUpdateWithTimeAndZoneComponent } from './predefined-filter-update-with-time-and-zone.component';

describe('PredefinedFilterUpdateWithTimeAndZoneComponent', () => {
  let component: PredefinedFilterUpdateWithTimeAndZoneComponent;
  let fixture: ComponentFixture<PredefinedFilterUpdateWithTimeAndZoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedFilterUpdateWithTimeAndZoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedFilterUpdateWithTimeAndZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
