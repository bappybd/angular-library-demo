import {ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {FuseSidebarService} from '@eevo/eevo-base';
import {ConfigFormBuilder} from '../../services/config-form-builder';
import {ConfigCommandBuilderService} from '../../services/config-command-builder.service';
import {EevoFileUploadService, EevoNotifyService, FilesModel, NotifyType} from '@eevo/eevo-core';
import {forkJoin, Subscription} from 'rxjs';
import {ConfigCommandService} from '../../services/config-command.service';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {UserAppHomeConfigEntity} from '../../entities/user-app-home-config-entity';
import {PredefinedFilterModel} from "../../models/config-models";
import {SubSink} from "subsink";

@Component({
  selector: 'app-predefined-filter-update',
  templateUrl: './predefined-filter-update.component.html',
  styleUrls: ['./predefined-filter-update.component.scss']
})
export class PredefinedFilterUpdateComponent implements OnInit, OnDestroy {

  loadingFromServer = true;
  detailsId: string;
  configForm: FormGroup;
  formSubmitted = false;
  file: FilesModel;
  private subs = new SubSink();

  @Input()
  sectionId: string;

  private privatePredefinedFilterDetails;
  @Input()
  set predefinedFilterDetails(value: PredefinedFilterModel) {
    this.loadingFromServer = true;
    setTimeout(() => {
      this.loadingFromServer = false;
      this.privatePredefinedFilterDetails = value;
      this.initFormGroup();
    });
  }
  get predefinedFilterDetails(): PredefinedFilterModel {
    return this.privatePredefinedFilterDetails;
  }

  @Output() finished: EventEmitter<any> = new EventEmitter();

  constructor(
    private fuseSidebarService: FuseSidebarService,
    private eevoNotifyService: EevoNotifyService,
    private configFormBuilder: ConfigFormBuilder,
    private configCommandService: ConfigCommandService,
    private configCommandBuilderService: ConfigCommandBuilderService,
    private eevoFileUploadService: EevoFileUploadService,
    private signalrNotificationService: SignalrNotificationService,
    private userAppHomeConfigEntity: UserAppHomeConfigEntity,
    private cdr: ChangeDetectorRef
  ) {
  }

  ngOnInit(): void {
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  initFormGroup(): void {
    this.file = new FilesModel();
    this.detailsId = this.predefinedFilterDetails.SectionItemDataId;
    this.configForm = this.configFormBuilder.getForm(this.predefinedFilterDetails);
  }

  toggleSidebarOpen(key: string): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  update(): void {
    this.configForm.markAllAsTouched();
    if (this.configForm.valid) {
      this.formSubmitted = true;
      this.eevoNotifyService.displayMessage('Predefined filter config update requested', NotifyType.Info);

      const subscription = forkJoin(this.getUpdateCalls()).subscribe(data => {
        this.formSubmitted = false;
        this.finished.emit({success: true});
        this.toggleSidebarOpen('predefinedFilterUpdate');
        this.eevoNotifyService.displayMessage('Successfully updated');
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
        this.toggleSidebarOpen('predefinedFilterUpdate');
      });
      this.subs.sink = subscription;
    }
  }

  private getUpdateCalls(): any[] {
    const calls = [];

    const command = this.configCommandBuilderService.getPredefinedFilterConfigCommand(this.sectionId, this.detailsId, this.configForm);

    calls.push(
      this.configCommandService.updatePredefinedFilterConfig(
        command
      )
    );

    if (this.file.Files.length > 0) {
      calls.push(
        this.eevoFileUploadService.uploadPublicImages(
          this.signalrNotificationService,
          this.userAppHomeConfigEntity.ImageFolder.PredefinedFilter,
          this.detailsId,
          this.file
        )
      );
    }

    return calls;
  }
}
