import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedFilterUpdateComponent } from './predefined-filter-update.component';

describe('PredefinedFilterUpdateComponent', () => {
  let component: PredefinedFilterUpdateComponent;
  let fixture: ComponentFixture<PredefinedFilterUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedFilterUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedFilterUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
