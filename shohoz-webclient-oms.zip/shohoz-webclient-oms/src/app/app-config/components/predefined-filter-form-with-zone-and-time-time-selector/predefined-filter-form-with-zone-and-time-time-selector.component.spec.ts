import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent } from './predefined-filter-form-with-zone-and-time-time-selector.component';

describe('PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent', () => {
  let component: PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent;
  let fixture: ComponentFixture<PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
