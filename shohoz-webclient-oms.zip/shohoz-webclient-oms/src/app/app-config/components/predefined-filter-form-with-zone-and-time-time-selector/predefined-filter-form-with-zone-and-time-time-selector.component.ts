import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {FormGroup, Validators} from '@angular/forms';
import {MatCheckboxChange} from '@angular/material/checkbox';
import {ScheduleHourOptions} from '../../../shared/components/schedule-hour/schedule-hour.options';
import {ConfigFormBuilder} from '../../services/config-form-builder';
import {ScheduleHourService} from '../../../shared/components/schedule-hour/schedule-hour.service';
import {SubSink} from 'subsink';
import {AppConfigTimeAndZoneModel, AvailabilityType, AvailabilityTypeNames} from '../../models/config-models';

@Component({
  selector: 'app-predefined-filter-form-with-zone-and-time-time-selector',
  templateUrl: './predefined-filter-form-with-zone-and-time-time-selector.component.html',
  styleUrls: ['./predefined-filter-form-with-zone-and-time-time-selector.component.scss']
})
export class PredefinedFilterFormWithZoneAndTimeTimeSelectorComponent implements OnInit, OnDestroy {
  @Input()
  parent: FormGroup;

  @Input()
  appConfigTimeAndZone?: AppConfigTimeAndZoneModel;

  subs = new SubSink();

  scheduleHourOptions = {
    startTimeLabel: 'Available from',
    endTimeLabel: 'Available to',
    hourOverlapValidationRequired: true,
    sameForAllDaysRequired: true,
    atLeastOneDayRequired: true
  } as ScheduleHourOptions;
  availabilityTypes = [
    AvailabilityType.IsAlwaysAvailable,
    AvailabilityType.IsWeekly,
    AvailabilityType.IsDateRange
  ];
  availabilityTypeNames = AvailabilityTypeNames;

  constructor(
    private scheduleHourService: ScheduleHourService,
    private configFormBuilder: ConfigFormBuilder
  ) {
  }

  ngOnInit(): void {
    this.checkOnWeeklyTimeChange();
    this.checkIsDateRangeChange();
    this.setOrRemoveScheduleHourForm();
    this.setOrRemoveDateRangeFormFields();
    this.checkAvailabilityType();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  private checkOnWeeklyTimeChange(): void {
    this.subs.sink = this.parent.get('IsWeekly').valueChanges.subscribe((selected) => {
      if (selected) {
        this.parent.get('IsDateRange').setValue(false);
      }
      this.setOrRemoveScheduleHourForm();
    });
  }

  private checkIsDateRangeChange(): void {
    this.subs.sink = this.parent.get('IsDateRange').valueChanges.subscribe((selected) => {
      if (selected) {
        this.parent.get('IsWeekly').setValue(false);
      }
      this.setOrRemoveDateRangeFormFields();
    });
  }

  private setOrRemoveDateRangeFormFields(): void {
    const isDateRangeSelected = this.parent.get('IsDateRange').value;
    if (isDateRangeSelected) {
      this.configFormBuilder.addDateRangeFormFields(this.parent, this.appConfigTimeAndZone);
    } else {
      this.configFormBuilder.removeDateRangeFormFields(this.parent);
    }
    this.parent.updateValueAndValidity();
  }

  private setOrRemoveScheduleHourForm(): void {
    const isWeeklySelected = this.parent.get('IsWeekly').value;
    if (isWeeklySelected) {
      this.parent.addControl('ScheduledHours', this.scheduleHourService.getScheduleHoursFormGroup());
      this.fillScheduleHourForm();
    } else {
      this.parent.removeControl('ScheduledHours');
    }
    this.parent.updateValueAndValidity();
  }

  private fillScheduleHourForm(): void {
    const {ScheduledHours, ServiceHourIsSameForAllDays} = this.appConfigTimeAndZone || {};
    if (!ScheduledHours) {
      return;
    }
    this.scheduleHourService.setScheduledHoursValues(
      this.parent.get('ScheduledHours') as FormGroup,
      ServiceHourIsSameForAllDays,
      ScheduledHours
    );
  }

  onIsApplicableUntilFurtherNoticeChange($event: MatCheckboxChange): void {
    if ($event.checked) {
      this.parent.get('ApplicableToDate').clearValidators();
      this.parent.get('ApplicableToDate').updateValueAndValidity();
      this.parent.get('ApplicableToTime').clearValidators();
      this.parent.get('ApplicableToTime').updateValueAndValidity();
      return;
    }

    this.parent.get('ApplicableToDate').setValidators([Validators.required]);
    this.parent.get('ApplicableToTime').setValidators([Validators.required]);
  }

  private checkAvailabilityType(): void {
    this.subs.sink = this.parent.get('AvailabilityType').valueChanges.subscribe((selected) => {
      switch (selected){
        case 1:
          this.parent.get('IsAlwaysAvailable').setValue(false);
          this.parent.get('IsWeekly').setValue(true);
          this.parent.get('IsDateRange').setValue(false);
          break;
        case 2:
          this.parent.get('IsAlwaysAvailable').setValue(false);
          this.parent.get('IsWeekly').setValue(false);
          this.parent.get('IsDateRange').setValue(true);
          break;
        default:
          this.parent.get('IsAlwaysAvailable').setValue(true);
          this.parent.get('IsWeekly').setValue(false);
          this.parent.get('IsDateRange').setValue(false);
      }
    });
  }
}
