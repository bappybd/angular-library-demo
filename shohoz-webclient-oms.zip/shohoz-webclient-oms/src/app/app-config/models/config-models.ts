import {ScheduledHourModel} from '../../shared/models/scheduled-hour-model';

export enum AvailabilityType {
  IsAlwaysAvailable,
  IsWeekly,
  IsDateRange
}

export const AvailabilityTypeNames = {
  [AvailabilityType.IsAlwaysAvailable] : 'Always Available',
  [AvailabilityType.IsWeekly] : 'Weekly',
  [AvailabilityType.IsDateRange] : 'Date Range',
};

export interface UserAppHomeConfigListResponse {
  data: any[];
  totalCount: number;
}

export class AppConfigListModel<T> {
  TotalElements: number;
  TotalPages: number;
  Data: Array<T>;

  constructor() {
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.Data = new Array<T>();
  }
}

export class PredefinedFilterModel {
  SectionItemDataId: string;
  Name: string;
  Query: string;
  EntityName: string;
  Fields: string[];
  IsExternalLink: boolean;
  IsInternalLink: boolean;
  Link: string;
  IsActive: boolean;
  Order: number;
  EntitySortBy: string;
  EntityOrderBy: number;
  HasCurationName: boolean;
  CurationName: string;
  AppConfigTimeAndZone?: AppConfigTimeAndZoneModel;
}

export class AppConfigTimeAndZoneModel {
  IsAllZones: boolean;
  ApplicableZones: any[];
  IsWeekly?: boolean;
  IsAlwaysAvailable?: boolean;
  ServiceHourIsSameForAllDays?: boolean;
  IsDateRange?: boolean;
  ScheduledHours?: ScheduledHourModel[];
  ApplicableFrom?: string;
  ApplicableTo?: string;
  IsApplicableUntilFurtherNotice?: boolean;
}
