import {EevoCommandBase} from '@eevo/eevo-core';
import {PredefinedFilterModel} from './config-models';

export class PredefinedFilterCommand extends EevoCommandBase {
  constructor() {
    super();
  }

  SectionItemId: string;
  SectionItemData: PredefinedFilterModel;
}

