import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserHomePageSectionDetailsComponent } from './user-home-page-section-details.component';

describe('UserHomePageSectionDetailsComponent', () => {
  let component: UserHomePageSectionDetailsComponent;
  let fixture: ComponentFixture<UserHomePageSectionDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserHomePageSectionDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserHomePageSectionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
