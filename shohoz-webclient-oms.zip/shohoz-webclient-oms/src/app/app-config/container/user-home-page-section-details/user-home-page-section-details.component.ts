import {Component, OnInit, TemplateRef, ViewChild, ViewEncapsulation} from '@angular/core';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {BehaviorSubject} from 'rxjs';
import {AppConfigListModel, PredefinedFilterModel} from '../../models/config-models';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {ActivatedRoute, Router} from '@angular/router';
import {UserAppHomeConfigEntity} from '../../entities/user-app-home-config-entity';
import {ConfigQueryService} from '../../services/config-query.service';
import {fuseAnimations, FuseSidebarService} from '@eevo/eevo-base';
import {ConfigNotificationService} from '../../services/config-notification.service';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {EevoQueryService} from '@eevo/eevo-core';

@Component({
  selector: 'app-user-home-page-section-details',
  templateUrl: './user-home-page-section-details.component.html',
  styleUrls: ['./user-home-page-section-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class UserHomePageSectionDetailsComponent implements OnInit {
  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('actionTemplate', {static: true}) actionTemplate: TemplateRef<any>;

  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  isLoading = true;
  dialogRef: any;
  detailsId: string;
  sectionId: string;
  breadcrumbList: BreadcrumbModel[] = [{
    Text: 'User home page config'
  }];
  predefinedFilterDetails: PredefinedFilterModel;
  createPredefinedFilter = false;
  predefinedFilterSelected = false;
  addButtonEnable = false;

  private datatableModelInput = new BehaviorSubject<AppConfigListModel<any>>(undefined);
  public actionType: string;

  constructor(
    private router: Router,
    private actRoute: ActivatedRoute,
    private userAppHomeConfigEntity: UserAppHomeConfigEntity,
    private configQueryService: ConfigQueryService,
    public eevoQueryService: EevoQueryService,
    private fuseSidebarService: FuseSidebarService,
    private configNotificationService: ConfigNotificationService
  ) {
    this.sectionId = this.actRoute.snapshot.params.id;
    this.detailsId = this.actRoute.snapshot.params.detailId;
  }

  ngOnInit(): void {
    this.prepareDataTable();
  }

  toggleSidebarOpen(key): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  listReload($event): void {
    this.getConfigDetails(this.datatableModel);
    this.topFunction();
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getConfigDetails(tableModel);
    this.topFunction();
  }

  selectData(dataTableRow: any): void {
    // this.router.navigate(['shop', 'detail', dataTableRow.Id, 'overview']);
  }

  editData(dataTableRow: any): void {
    this.router.navigate(['shop', 'update', dataTableRow.Id, 0]);
  }

  topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  initDataTable(): void {
    this.datatableModelInput.subscribe(response => {
      this.datatableModel.TotalElements = response ? response[1][0][0] : 0;
      this.datatableModel.Data = response ? response[0] : [];
    }, err => console.warn(err));

    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  getConfigDetails(tableModel: DatatableModel<any>): void {
    this.isLoading = true;
    this.configQueryService.getUserAppHomeConfigDetails(
      this.sectionId
    ).subscribe((response) => {
      if (response && response.Whole) {
        const total = response.Whole.Data.length;
        const data = response.Whole.Data;
        this.actionType = response?.Whole?.ActionType;

        if (response?.Whole?.ActionType === 'HorizontalLinkList') {
          this.addButtonEnable = true;
        }

        this.datatableModel = {
          PageSize: this.datatableModel.PageSize,
          TotalElements: total,
          CurrentPageNumber: this.datatableModel.CurrentPageNumber,
          SortBy: this.datatableModel.SortBy,
          Descending: this.datatableModel.Descending,
          Data: data,
          ColumnMode: ColumnMode.flex
        };
      }
      this.isLoading = false;
    }, (error) => {
      this.isLoading = false;
      console.warn('Error', error);
    });
  }

  sectionDetails(row): void {
    if (this.predefinedFilterSelected) {
      this.predefinedFilterSelected = false;
    }
    setTimeout(() => {
      this.predefinedFilterSelected = true;
      this.predefinedFilterDetails = row;
      this.toggleSidebarOpen('predefinedFilterUpdate');
    });
  }

  addNewPredefined(): void {
    if (this.createPredefinedFilter) {
      this.createPredefinedFilter = false;
    }
    setTimeout(() => {
      this.createPredefinedFilter = true;

      this.toggleSidebarOpen('predefinedFilterCrate');
    });
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'Name',
          name: 'Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'IsExternalLink',
          name: 'Is External Link',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'EntityName',
          name: 'View Model Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'IsActive',
          name: 'Order',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Order',
          name: '',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.actionTemplate,
          draggable: false,
          sortable: false,
          cellClass: 'cell-width-100',
        }
      ] as TableColumn[],
      defaultSort: 'Order',
      descending: true,
      pageSize: 1000,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.getConfigDetails(this.datatableModel);
    this.initDataTable();
  }

}
