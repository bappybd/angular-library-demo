import {Component, Input, OnInit, TemplateRef, ViewChild, ViewEncapsulation} from '@angular/core';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {BehaviorSubject} from 'rxjs';
import {Router} from '@angular/router';
import {fuseAnimations, FuseSidebarService} from '@eevo/eevo-base';
import {MatDialog} from '@angular/material/dialog';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {AppConfigListModel} from '../../models/config-models';
import {UserAppHomeConfigEntity} from '../../entities/user-app-home-config-entity';
import {ConfigQueryService} from '../../services/config-query.service';
import {ConfigNotificationService} from '../../services/config-notification.service';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';

@Component({
  selector: 'app-user-home-page',
  templateUrl: './user-home-page.component.html',
  styleUrls: ['./user-home-page.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class UserHomePageComponent implements OnInit {
  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('actionTemplate', {static: true}) actionTemplate: TemplateRef<any>;
  @ViewChild('actionTypeTemplate', {static: true}) actionTypeTemplate: TemplateRef<any>;

  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  private datatableModelInput = new BehaviorSubject<AppConfigListModel<any>>(undefined);
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  isLoading = true;
  dialogRef: any;
  breadcrumbList: BreadcrumbModel[]  = [{
    Text: 'User home page config'
  }];

  constructor(
    private router: Router,
    private userAppHomeConfigEntity: UserAppHomeConfigEntity,
    private configQueryService: ConfigQueryService,
    private sidebarService: FuseSidebarService,
    public matDialog: MatDialog,
    private configNotificationService: ConfigNotificationService
  ) {
  }

  ngOnInit(): void {
    this.prepareDataTable();
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'SectionName',
          name: 'Section Name',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: false,
          sortable: true,
        },
        {
          prop: 'Whole.ActionType',
          name: 'Type',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.actionTypeTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'SectionOrder',
          name: 'Section Order',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: false,
          sortable: true,
        },
        {
          prop: 'Whole.DisplayTitle',
          name: '',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.actionTemplate,
          draggable: false,
          sortable: false,
          cellClass: 'cell-width-100',
        }
      ] as TableColumn[],
      defaultSort: 'SectionOrder',
      descending: false,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.datatableModel.Descending = this.configOption.descending;
    this.getConfigList(this.datatableModel);
    this.initDataTable();
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getConfigList(tableModel);
    this.topFunction();
  }

  selectData(dataTableRow: any): void {
    // this.router.navigate(['shop', 'detail', dataTableRow.Id, 'overview']);
  }

  editData(dataTableRow: any): void {
    this.router.navigate(['shop', 'update', dataTableRow.Id, 0]);
  }

  topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  initDataTable(): void {
    this.datatableModelInput.subscribe(response => {
      this.datatableModel.TotalElements = response ? response[1][0][0] : 0;
      this.datatableModel.Data = response ? response[0] : [];
    }, err => console.log(err));

    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.PageSize = this.configOption.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  public getConfigList(tableModel: DatatableModel<any>): void {
    this.isLoading = true;
    this.configQueryService.getUserAppHomeConfigList(tableModel).subscribe((response) => {
        this.datatableModel = {
          PageSize: this.datatableModel.PageSize,
          TotalElements: response.totalCount,
          CurrentPageNumber: this.datatableModel.CurrentPageNumber,
          SortBy: this.datatableModel.SortBy,
          Descending: this.datatableModel.Descending,
          Data: response.data,
          ColumnMode: ColumnMode.flex
        };
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = true;
        console.log('Error', error);
      });
  }

  sectionDetails(row): void {
    this.router.navigate(['app-config', 'user-home-page-section-config', row.Id, 'details']);
  }
}
