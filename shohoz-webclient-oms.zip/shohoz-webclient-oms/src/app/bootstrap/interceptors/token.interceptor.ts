import {Inject, Injectable} from '@angular/core';
import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable} from 'rxjs';
import {tap} from 'rxjs/operators';
import {TokenManagerService} from '@eevo/eevo-core';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(
    @Inject('config') private config: any,
    private tokenManagerService: TokenManagerService
  ) {
  }

  intercept(httpRequest: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(httpRequest).pipe(
      tap((response: any) => {
        try {
          if (response?.url?.startsWith(this.config['IAMService'])) {
            const {body} = response || {};
            if (body && body?.access_token) {
              this.tokenManagerService.setAccessToken(body?.access_token);
              // console.log(this.tokenManagerService.getAccessToken());
            }
          }
        } catch (e) {
          console.log(e);
        }
      })
    );
  }
}
