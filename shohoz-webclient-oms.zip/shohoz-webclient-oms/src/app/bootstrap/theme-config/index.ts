export const THEME_CONFIG = {
  layout: {
    navbar: {
      variant: 'vertical-style-2',
    },
    breadcrumb: {
      hidden: true,
    },
    footer: {
      hidden: true,
    },
    quickpanel: {
      hidden: true,
    },
    toolbar: {
      position: 'above',
    },
  },
};
