import {Navigation} from '@eevo/eevo-core';

export const navigation: Navigation[] = [
  // {
  //   id: 'dashboard',
  //   title: 'Dashboard',
  //   type: 'item',
  //   icon: 'dashboard',
  //   isFeatureFound: false,
  //   url: '/dashboard',
  // },
  // {
  //   id: 'shop',
  //   title: 'Shops',
  //   type: 'collapsable',
  //   icon: 'store',
  //   isFeatureFound: false,
  //   children: [
  //     {
  //       id: 'shop',
  //       title: 'Shop',
  //       type: 'item',
  //       url: '/shop',
  //       icon: 'store'
  //     },
  //   ]
  // },
  // {
  //   id: 'coupon',
  //   title: 'Coupons',
  //   type: 'item',
  //   icon: 'loyalty',
  //   isFeatureFound: false,
  //   url: '/coupon',
  // },
  // {
  //   id: 'zones',
  //   title: 'Zone Configs',
  //   type: 'item',
  //   icon: 'search',
  //   isFeatureFound: false,
  //   url: '/zones',
  // },
  // {
  //   id: 'app-config',
  //   title: 'App Configs',
  //   type: 'item',
  //   icon: 'settings',
  //   isFeatureFound: false,
  //   url: '/app-config/user-home-page-section-config',
  // },
];
