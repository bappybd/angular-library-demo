import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {TranslateModule} from '@ngx-translate/core';

/*----------Eevo Support Libraries Imports--------*/
import {
  EevoCoreModule,
  HttpInterceptorModule,
  NavigationProvider,
  FeatureProvider,
} from '@eevo/eevo-core';
import {EevoTemplateBootstrapModule} from '@eevo/eevo-template-bootstrap';

/*---------Root Component--------*/
import {AppComponent} from './app.component';

/*---------Environment File--------*/
import {environment} from '@environment';

/*------Import Routing Module and Routes File-----*/
import {RouterModule} from '@angular/router';
import {routes} from './routes';

/*-----------NgRx Import---------*/
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {FlexLayoutModule} from '@angular/flex-layout';

import {InMemoryWebApiModule} from 'angular-in-memory-web-api';
import {EevoNotificationModule} from '@eevo/eevo-notification';
import {ToastrModule} from 'ngx-toastr';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import {TokenInterceptor} from './interceptors/token.interceptor';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    CommonModule,
    BrowserAnimationsModule,
    EevoTemplateBootstrapModule,
    TranslateModule.forRoot(),
    FlexLayoutModule.withConfig({
      useColumnBasisZero: false,
      printWithBreakpoints: [
        'xs',
        'sm',
        'md',
        'lg',
        'xl',
        'lt-sm',
        'lt-md',
        'lt-lg',
        'lt-xl',
        'gt-xs',
        'gt-sm',
        'gt- md',
        'gt-lg',
      ],
    }),
    EevoCoreModule.forRoot({...environment}),
    HttpInterceptorModule,
    RouterModule.forRoot(routes),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: environment.production,
    }),
    EevoNotificationModule,
    ToastrModule.forRoot()
  ],
  providers: [
    NavigationProvider,
    FeatureProvider,
    {provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true}
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
}
