import {Routes} from '@angular/router';
import {AuthRedirectionModel, FeatureAccessPermission, IsAuthenticatedGuard, IsUnauthenticatedGuard} from '@eevo/eevo-core';
import {NotFoundComponent} from '../shared/components/not-found/not-found.component';
import {AppReportModule} from '../app-report/app-report.module';

export const authRedirection = [
  {
    Role: 'admin',
    Authenticated: '/dashboard',
    Unauthenticated: '/login',
  },
  {
    Role: 'restaurant_admin',
    Authenticated: '/shop',
    Unauthenticated: '/login',
  },
  {
    Role: 'restaurant_manager',
    Authenticated: '/shop',
    Unauthenticated: '/login',
  },
  {
    Role: 'delivery_by_shop',
    Authenticated: '/shop',
    Unauthenticated: '/login',
  }
] as AuthRedirectionModel[];

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full',
    data: {
      isFullScreen: true,
      redirect: authRedirection,
    },
  },

  {
    path: 'login',
    loadChildren: () =>
      import('../login/login.module').then(
        (m) => m.LoginModule
      ),
    data: {
      isFullScreen: true,
      redirect: authRedirection,
    },
    canActivate: [IsUnauthenticatedGuard]
  },
  {
    path: 'dashboard',
    loadChildren: () =>
      import('../dashboard/dashboard.module').then(
        (m) => m.DashboardModule
      ),
    data: {
      name: 'dashboard',
      isFullScreen: false,
    },
    canActivate: [IsAuthenticatedGuard, FeatureAccessPermission],
  },
  {
    path: 'shop',
    loadChildren: () =>
      import('../app-shop/app-shop.module').then(
        (m) => m.AppShopModule
      ),
    data: {
      name: 'shop',
      isFullScreen: false,
    },
    canActivate: [IsAuthenticatedGuard, FeatureAccessPermission]
  },
  {
    path: 'coupon',
    loadChildren: () =>
      import('../app-coupon/app-coupon.module').then(
        (m) => m.AppCouponModule
      ),
    data: {
      name: 'coupon',
      isFullScreen: false,
    },
    canActivate: [IsAuthenticatedGuard, FeatureAccessPermission],
  },
  {
    path: 'zones',
    loadChildren: () =>
      import('../app-zone/app-zone.module').then(
        (m) => m.AppZoneModule
      ),
    data: {
      name: 'zones',
      isFullScreen: false,
    },
    canActivate: [IsAuthenticatedGuard, FeatureAccessPermission],
  },
  {
    path: 'app-config',
    loadChildren: () =>
      import('../app-config/app-config.module').then(
        (m) => m.AppConfigModule
      ),
    data: {
      name: 'app-config',
      isFullScreen: false,
    },
    canActivate: [IsAuthenticatedGuard, FeatureAccessPermission],
  },
  {
    path: 'app-report',
    loadChildren: () =>
      import('../app-report/app-report.module').then(
        (m) => m.AppReportModule
      ),
    data: {
      name: 'app-report',
      isFullScreen: false
    },
    canActivate: [IsAuthenticatedGuard, FeatureAccessPermission]
  },
  // {
  //   path: 'uam',
  //   loadChildren: () =>
  //     import('../app-uam/app-uam.module').then(
  //       (m) => m.AppUamModule
  //     ),
  //   data: {
  //     name: 'uam',
  //     isFullScreen: false,
  //   },
  //   canActivate: [IsAuthenticatedGuard, FeatureAccessPermission],
  // },
  {
    path: '404',
    component: NotFoundComponent,
    canActivate: [IsAuthenticatedGuard],
  },
  {
    path: '**',
    redirectTo: '/404',
    canActivate: [IsAuthenticatedGuard]
  }
];
