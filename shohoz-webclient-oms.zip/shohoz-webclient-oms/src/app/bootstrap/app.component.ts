import {Component, OnInit, OnDestroy} from '@angular/core';
import {ActivatedRoute, NavigationEnd, Router} from '@angular/router';
/*---------Eevo Import----------*/
import {
  NavigationProvider,
  FeatureProvider,
  FeatureNavigationProvider,
  NotifyType,
  UserDataService, EevoNotifyService
} from '@eevo/eevo-core';
import {FuseConfigService} from '@eevo/eevo-base';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';

/*-------Navigation File-------*/
import {navigation} from './navigation/navigation';

/*-------Feature List-------*/
import {features} from './features';

import {Subject} from 'rxjs';

import {THEME_CONFIG} from './theme-config';
import {HubConnectionState, SignalrNotificationService} from '@eevo/eevo-notification';
import {AudioVisualNotificationService} from './services/audio-visual-notification.service';
import {debug} from 'ng-packagr/lib/utils/log';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})

export class AppComponent {
  private _unsubscribeAll = new Subject<any>();
  isOffline = false;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _configuration: FuseConfigService,
    private _navigationProvider: NavigationProvider,
    private _featureProvider: FeatureProvider,
    private userDataService: UserDataService,
    private notifyService: EevoNotifyService,
    private featureNavigationProvider: FeatureNavigationProvider,
    private signalrNotificationService: SignalrNotificationService,
    private audioVisualNotificationService: AudioVisualNotificationService,
    private featureGuardService: FeatureGuardService
  ) {
    this.featureNavigationProvider.set(features, navigation);
    console.log('......Root component is constucted........');
    this.playAudioNotificationOnEvent();
  }

  private playAudioNotificationOnEvent(): void{
    // @ts-ignore
    if (this.featureGuardService.isValidFeatureSync([{Key: 'Audio.Notification.DeliveryAgentFirstTimeSetEvent'}])) {
      this.audioVisualNotificationService.listenAndPlayAudioForEvent('DeliveryAgentFirstTimeSetEvent');
    }
  }

  ngOnInit() {
    this._configuration.setConfig(THEME_CONFIG, {emitEvent: true});

    this.internetConnection();
    this.notificationConnection();
  }

  private internetConnection(): void {
    const connection = navigator['connection'] || navigator['mozConnection'] || navigator['webkitConnection'];
    connection.addEventListener('change', () => {
      // let type = connection.effectiveType;

      if (!navigator.onLine) {
        this.notifyService.displayMessage('You are currently offline.', NotifyType.Warning);
      } else if (navigator.onLine && this.isOffline) {
        this.notifyService.displayMessage('Your internet connection was restored.', NotifyType.Success);
      }
      this.notificationReconnect();
      this.isOffline = !(navigator.onLine);

    });
  }

  private notificationConnection(): void {
    this.signalrNotificationService.getHubStateChange().subscribe(data => {
      console.log('Hub State Change', data);
      this.notificationReconnect();
    });
  }

  private notificationReconnect(): void {
    if (navigator.onLine && this.userDataService.isUserLoggedIn() &&
      this.signalrNotificationService.getHubState() === HubConnectionState.Disconnected) {
      console.log('reconnect initiating');
      this.signalrNotificationService.reconnect();
    }
  }
}
