import {EevoFeature} from '@eevo/eevo-core';

const adminFeatures: EevoFeature[] = [
  // {
  //   Name: 'Dashboard Page',
  //   Key: 'dashboard',
  //   Type: 'business',
  // },
  // {
  //   Name: 'shop',
  //   Key: 'shop',
  //   Type: 'business',
  // },
  // {
  //   Name: 'Shop Create',
  //   Key: 'shop.create',
  //   Type: 'business',
  // },
  // {
  //   Name: 'create',
  //   Key: 'create',
  //   Type: 'business',
  // },
  // {
  //   Name: 'product',
  //   Key: 'product',
  //   Type: 'business',
  // },
  // {
  //   Name: 'coupon',
  //   Key: 'coupon',
  //   Type: 'business',
  // },
  // {
  //   Name: 'coupon create',
  //   Key: 'coupon.create',
  //   Type: 'business',
  // },
  // {
  //   Name: 'coupon rank',
  //   Key: 'coupon.rank',
  //   Type: 'business',
  // },
  // {
  //   Name: 'coupon-assign',
  //   Key: 'coupon-assign',
  //   Type: 'business',
  // },
  // {
  //   Name: 'zones',
  //   Key: 'zones',
  //   Type: 'business',
  // },
  // {
  //   Name: 'zone create',
  //   Key: 'zone.create',
  //   Type: 'business',
  // },
  // {
  //   Name: 'app-config',
  //   Key: 'app-config',
  //   Type: 'business',
  // }
];

export const features = {
  admin: adminFeatures,
};
