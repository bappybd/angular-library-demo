import {Injectable} from '@angular/core';
import {EevoNotifyService, NotifyType} from '@eevo/eevo-core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {AudioNotification, AudioNotificationService} from '../../shared/services/audio-notification.service';

@Injectable({
  providedIn: 'root'
})
export class AudioVisualNotificationService {
  audioNotification: AudioNotification;
  openedToasts: number[] = [];

  constructor(
    private eevoNotifyService: EevoNotifyService,
    private signalrNotificationService: SignalrNotificationService,
    private ans: AudioNotificationService
  ) {
    this.audioNotification = this.ans.loadAudio('audio', null, 20);
  }

  listenAndPlayAudioForEvent(eventName: string): void {
    this.signalrNotificationService.listenByKey(eventName, () => {
      this.showToastAndPlayAudio();
    });
  }

  private showToastAndPlayAudio(): void {
    const toast = this.eevoNotifyService.displayMessageByToast('You received a new order', NotifyType.Success, null, {timeOut: 20000});
    this.audioNotification.play();
    toast.toastRef.afterActivate().subscribe(res => {
      this.openedToasts.push(toast.toastId);
    });
    toast.toastRef.afterClosed().subscribe(res => {
      this.openedToasts = this.openedToasts.filter(t => t !== toast.toastId);
      if (!this.openedToasts.length) {
        this.audioNotification.stop();
      }
    });
  }
}
