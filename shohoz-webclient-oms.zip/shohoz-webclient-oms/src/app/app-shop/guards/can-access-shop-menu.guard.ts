import {Inject, Injectable} from '@angular/core';
import {ActivatedRoute, ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree} from '@angular/router';
import {Observable} from 'rxjs';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {ShopModel, ShopStatusEnum} from '../../shared/models/shop-entity-models';
import {EevoQueryService} from '@eevo/eevo-core';
import {map} from 'rxjs/operators';
import {ShopEntity} from '../entities/shop-entity';

@Injectable({
  providedIn: 'root'
})
export class CanAccessShopMenuGuard implements CanActivate {
  constructor(
    private fgs: FeatureGuardService,
    private eevoQueryService: EevoQueryService,
    private shopEntity: ShopEntity,
    private actRoute: ActivatedRoute,
    @Inject('config') private config: any
  ) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    // @ts-ignore
    if (!this.fgs.isValidFeatureSync([{Key: 'user.isRestaurantUser'}])) {
      return true;
    }
    return this.canAccessMenu(next.params['id']);
  }

  canAccessMenu(shopId: string): Observable<boolean> {
    return this.eevoQueryService.getDetailsById<ShopModel>(
      this.config.ShopService.toQueryURL(),
      this.shopEntity.getDetailsName(),
      shopId,
      ['Settings.ShopStatus']
    ).pipe(
      map((shopData) => {
        return ![ShopStatusEnum.PermanentlyClosed, ShopStatusEnum.ClosedUntilFurtherNotice].includes(shopData?.Settings?.ShopStatus);
      })
    );
  }

}
