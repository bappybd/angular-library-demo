import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AppShopCreateComponent} from './container/app-shop-create/app-shop-create.component';
import {AppShopListComponent} from './container/app-shop-list/app-shop-list.component';
import {AppShopUpdateComponent} from './container/app-shop-update/app-shop-update.component';
import {FeatureAccessPermission} from '@eevo/eevo-core';
import {AppShopDetailsComponent} from './container/app-shop-details/app-shop-details.component';
import {GetShopDetailsResolver} from './resolvers/get-shop-details.resolver';
import {ShopExportImportComponent} from './components/shop-export-import/shop-export-import.component';
import {CanAccessShopMenuGuard} from './guards/can-access-shop-menu.guard';

const routes: Routes = [
  {
    path: '',
    component: AppShopListComponent,
    data: {isFullScreen: true}
  },
  // {
  //   path: 'detail/:id',
  //   component: AppShopDetailsComponent,
  //   resolve: {shopDetails: GetShopDetailsResolver},
  //   data: {isFullScreen: true}
  // },
  {
    path: 'create',
    component: AppShopCreateComponent,
    data: {
      isFullScreen: true,
      name: 'shop.create',
    },
    canActivate: [FeatureAccessPermission],
  },
  {
    path: 'export-import',
    component: ShopExportImportComponent,
    data: {
      isFullScreen: true,
      name: 'shop.export-import'
    },
    canActivate: [FeatureAccessPermission],
  },
  {
    path: 'update/:id/:tabIndex',
    component: AppShopUpdateComponent,
    data: {isFullScreen: true, name: 'shop.details'},
    canActivate: [FeatureAccessPermission],
  },
  {
    path: ':id/product',
    loadChildren: () =>
      import('../app-product/app-product.module').then(
        (m) => m.AppProductModule
      ),
    data: {
      name: 'shop.category.details',
      isFullScreen: false,
    },
    canActivate: [FeatureAccessPermission, CanAccessShopMenuGuard],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AppShopRoutingModule {
}
