import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

// Materials
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatChipsModule} from '@angular/material/chips';
import {MatButtonModule} from '@angular/material/button';
import {MatStepperModule} from '@angular/material/stepper';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {FlexLayoutModule} from '@angular/flex-layout';

// Container
import {AppShopCreateComponent} from './container/app-shop-create/app-shop-create.component';
// import {AppShopUpdateComponent} from './container/app-shop-update/app-shop-update.component';
import {ShopAddressComponent} from './components/shop-address/shop-address.component';
import {ShopContactComponent} from './components/shop-contact/shop-contact.component';
import {ShopDetailsComponent} from './components/shop-details/shop-details.component';
import {ShopServiceHoursComponent} from './components/shop-service-hours/shop-service-hours.component';
import {ShopSettingsComponent} from './components/shop-settings/shop-settings.component';
import {ScheduledHourComponent} from './components/scheduled-hour/scheduled-hour.component';
import {AppShopRoutingModule} from './app-shop.routing.module';
import {AppShopListComponent} from './container/app-shop-list/app-shop-list.component';
import {ShopFilterComponent} from './components/shop-filter/shop-filter.component';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {AddMediaComponent} from './components/add-media/add-media.component';
import {EevoFileUploaderModule} from '@eevo/eevo-file-uploader';
import {MatTabsModule} from '@angular/material/tabs';
import {SharedModule} from '../shared/shared.module';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatMenuModule} from '@angular/material/menu';
import {AppShopUpdateComponent} from './container/app-shop-update/app-shop-update.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {EevoImageUploaderModule} from '@eevo/eevo-image-uploader';
import {ShopNotificationService} from './services/shop-notification.service';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatCardModule} from '@angular/material/card';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {EevoPlatformAvatarModule} from '@eevo/eevo-platform-avatar';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';
import {AppShopDetailsComponent} from './container/app-shop-details/app-shop-details.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import {AppShopDetailsBasicInfoComponent} from './components/app-shop-details-basic-info/app-shop-details-basic-info.component';
import {ShopDetailsServiceHoursComponent} from './components/shop-details-service-hours/shop-details-service-hours.component';
import {ShopDetailsSettingsComponent} from './components/shop-details-settings/shop-details-settings.component';
import {FileUploadNotificationService} from './services/file-upload-notification.service';
import {MenuFileListComponent} from './components/menu-file-list/menu-file-list.component';
import {MenuUploadComponent} from './components/menu-upload/menu-upload.component';
import {ShopExportImportComponent} from './components/shop-export-import/shop-export-import.component';
import {ShopExportImportNotificationService} from './services/shop-export-import-notification.service';
import {ShopImportFileListComponent} from './components/shop-import-file-list/shop-import-file-list.component';
import {DateTimeFieldComponent} from './components/date-time-field/date-time-field.component';
import {ShopListStatusUpdateComponent} from './components/shop-list-status-update/shop-list-status-update.component';
import {ShopListTemporaryUnavailableStatusUpdateDialogComponent} from './components/shop-list-temporary-unavailable-status-update-dialog/shop-list-temporary-unavailable-status-update-dialog.component';
import {MatDialogModule} from '@angular/material/dialog';

@NgModule({
  declarations: [
    AppShopCreateComponent,
    AppShopUpdateComponent,
    ShopAddressComponent,
    ShopContactComponent,
    ShopDetailsComponent,
    ShopServiceHoursComponent,
    ShopSettingsComponent,
    ScheduledHourComponent,
    AppShopListComponent,
    ShopFilterComponent,
    AddMediaComponent,
    AppShopDetailsComponent,
    AppShopDetailsBasicInfoComponent,
    ShopDetailsServiceHoursComponent,
    ShopDetailsSettingsComponent,
    MenuFileListComponent,
    MenuUploadComponent,
    ShopExportImportComponent,
    ShopImportFileListComponent,
    DateTimeFieldComponent,
    ShopListStatusUpdateComponent,
    ShopListTemporaryUnavailableStatusUpdateDialogComponent
  ],
  exports: [DateTimeFieldComponent],
  imports: [
    CommonModule,
    SharedModule,
    AppShopRoutingModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatIconModule,
    MatInputModule,
    MatSelectModule,
    MatChipsModule,
    MatButtonModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatRadioModule,
    MatCheckboxModule,
    FormsModule,
    EevoPlatformDatatableModule,
    NgxDatatableModule,
    EevoFileUploaderModule,
    MatTabsModule,
    MatAutocompleteModule,
    MatMenuModule,
    EevoImageUploaderModule,
    MatSlideToggleModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    EevoPlatformAvatarModule,
    EevoPlatformBreadcrumbModule,
    MatDatepickerModule,
    EevoPlatformFeatureGuardModule,
    MatTooltipModule,
    MatDialogModule
  ],
  providers: [
    ShopNotificationService,
    FileUploadNotificationService,
    ShopExportImportNotificationService
  ]
})

export class AppShopModule {
}
