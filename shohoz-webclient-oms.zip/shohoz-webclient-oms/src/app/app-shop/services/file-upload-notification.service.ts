import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';
import {MenuFileEntity} from '../entities/menu-file-entity';

@Injectable({
  providedIn: 'root'
})
export class FileUploadNotificationService extends EevoNotificationBase<CommandNotificationModel> {

  constructor(
    private menuFileEntity: MenuFileEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService,
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(this.menuFileEntity.Events.FileBusinessRuleViolatedEvent, (response) => {
      const data = this.notificationHandlerService.parseNotification(response, false);
      this.deliver(data);
    });
  }
  fileCreated(): void {
    this.signalrNotificationService.listenByKey(this.menuFileEntity.Events.FileCreatedEvent , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }
  shopExportSuccess(): void {
    this.signalrNotificationService.listenByKey(this.menuFileEntity.Events.ShopExportSuccess , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }

  // shopExportFailed(): void {
  //   this.signalrNotificationService.listenByKey(this.menuFileEntity.Events.ShopImportFailed , (response) => {
  //     const data = this.notificationHandlerService.parseNotification(response, true);
  //     this.deliver(data);
  //   });
  // }

  shopImportSuccess(): void {
    this.signalrNotificationService.listenByKey(this.menuFileEntity.Events.ShopImportSuccess , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }

  shopImportFailed(): void {
    this.signalrNotificationService.listenByKey(this.menuFileEntity.Events.ShopImportFailed , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }
}
