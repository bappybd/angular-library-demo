import { Injectable } from '@angular/core';
import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {ShopExportEntity} from '../entities/shop-export-entity';
import {ShopImportEntity} from '../entities/shop-import-entity';

@Injectable({
  providedIn: 'root'
})
export class ShopExportImportNotificationService extends EevoNotificationBase<CommandNotificationModel> {

  constructor(
    private shopExportEntity: ShopExportEntity,
    private shopImportEntity: ShopImportEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService,
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(this.shopImportEntity.Events.FileBusinessRuleViolatedEvent, (response) => {
      const data = this.notificationHandlerService.parseNotification(response, false);
      this.deliver(data);
    });
  }
  fileCreated(): void {
    this.signalrNotificationService.listenByKey(this.shopImportEntity.Events.FileCreatedEvent , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }

  shopListExportSuccess(): void {
    this.signalrNotificationService.listenByKey(this.shopExportEntity.Events.ShopListExportSuccess , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }

  shopListExportFailed(): void {
    this.signalrNotificationService.listenByKey(this.shopExportEntity.Events.ShopListExportFailed, (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }

  shopListImportSuccess(): void {
    this.signalrNotificationService.listenByKey(this.shopImportEntity.Events.ShopListImportSuccess , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }

  shopListImportFailed(): void {
    this.signalrNotificationService.listenByKey(this.shopImportEntity.Events.ShopListImportFailed , (response) => {
      const data = this.notificationHandlerService.parseNotification(response, true);
      this.deliver(data);
    });
  }
  //
  // shopExportFailed(): void {
  //   this.signalrNotificationService.listenByKey(this.shopExportImportEntity.Events.ShopImportFailed , (response) => {
  //     const data = this.notificationHandlerService.parseNotification(response, true);
  //     this.deliver(data);
  //   });
  // }
  //
  // shopImportSuccess(): void {
  //   this.signalrNotificationService.listenByKey(this.shopExportImportEntity.Events.ShopImportSuccess , (response) => {
  //     const data = this.notificationHandlerService.parseNotification(response, true);
  //     this.deliver(data);
  //   });
  // }
  //
  // shopImportFailed(): void {
  //   this.signalrNotificationService.listenByKey(this.shopExportImportEntity.Events.ShopImportFailed , (response) => {
  //     const data = this.notificationHandlerService.parseNotification(response, true);
  //     this.deliver(data);
  //   });
  // }
}
