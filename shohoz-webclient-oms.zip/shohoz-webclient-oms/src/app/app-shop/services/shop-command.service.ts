import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {CreateShopCommand, ShopStatusUpdateCommand, UpdateShopFilesCommand} from '../models/shop-command';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {UtilityService} from '@eevo/eevo-core';

@Injectable({
  providedIn: 'root'
})

export class ShopCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createShopCommand(model: CreateShopCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('Create'), model).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateShopCommand(model: CreateShopCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('Update'), model).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateShopFilesCommand(model: UpdateShopFilesCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('ShopFileUpdate'), model).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  shopStatusUpdate(command: ShopStatusUpdateCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('ShopAvailabilityUpdate'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
