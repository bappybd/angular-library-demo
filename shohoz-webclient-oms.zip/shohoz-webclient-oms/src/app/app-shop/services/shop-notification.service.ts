import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {ShopEntity} from '../entities/shop-entity';
import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';

@Injectable({
  providedIn: 'root'
})
export class ShopNotificationService extends EevoNotificationBase<CommandNotificationModel> {

  constructor(
    private shopEntity: ShopEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(this.shopEntity.Events.ShopBusinessRuleViolationEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, false);
      this.deliver(data);
    });
  }

  shopCreated(): void {
    this.signalrNotificationService.listenByKey(this.shopEntity.Events.ShopCreatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.shopEntity.getMessages().CREATED);
      this.deliver(data);
    });
  }

  shopUpdated(): void {
    this.signalrNotificationService.listenByKey(this.shopEntity.Events.ShopUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.shopEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }

  shopStatusUpdatedEvent(): void {
    this.signalrNotificationService.listenByKey(this.shopEntity.Events.ShopAvailabilityUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.shopEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }
}
