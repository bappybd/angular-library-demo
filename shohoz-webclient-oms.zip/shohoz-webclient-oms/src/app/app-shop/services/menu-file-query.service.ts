import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {MenuFileEntity} from '../entities/menu-file-entity';
import {MenuFileImportEntity} from '../entities/menu-file-import-entity';
import {MenuFileListDatatableResponse} from '../models/menu-file-models';
import {DatatableModel} from '@eevo/eevo-platform-datatable';

@Injectable({
  providedIn: 'root'
})
export class MenuFileQueryService {

  constructor(
    private menuFileEntity: MenuFileEntity,
    private menuFileImportEntity: MenuFileImportEntity,
    private http: HttpClient,
    @Inject('config') private config: any
  ) { }

  fetchLastPreparedMenuDataByStatus(shopId: string, status: number[]): Observable<any> {
    const requestBody = status.map(st =>
      this.getLastPreparedMenuDataPayloadByStatus(shopId, st));

    return this.http.post(this.config.ShopService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        return status.map((s, i) =>  response[i][0] || null );
      })
    );
  }
  private getLastPreparedMenuDataPayloadByStatus(shopId: string, status?: number): any {
    let finalQuery = '';
    if (status || status === 0) {
      finalQuery = `{'ShopId' : GUID('${shopId}'), 'Status' :  ${status}  }`;
    }
    else {
       finalQuery = `{'ShopId' : GUID('${shopId}') }`;
    }

    return {
      source: this.menuFileEntity.getListName(),
      text: null,
      filter: finalQuery,
      fields: this.menuFileEntity.getDetailsFields(),
      orderBy: 'CreatedDate',
      descending: true,
      pageSize: 1,
      pageIndex: 0
    };
  }

  fetchExportKey(entityId): Observable<any> {
    const query = `{ '_id' : GUID('` + entityId + `')  }`;
    const requestBody = [
      {
        source: this.menuFileEntity.getListName(),
        text: null,
        filter: query,
        fields: ['ExportFileKey'],
        orderBy: 'CreatedDate',
        descending: true,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.ShopService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        return response[0][0];
      })
    );
  }

  fetchMenuFileList(tableModel: DatatableModel<any>, shopId: string): Observable<MenuFileListDatatableResponse> {
    const query = `{ 'ShopId' : GUID('` + shopId + `')  }`;
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.menuFileImportEntity.getListName(),
        text: null,
        filter: query,
        fields: this.menuFileImportEntity.getListFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.menuFileImportEntity.getListName(),
        text: null,
        filter: query,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        if (response && response[0]) {
          return {
            data: response[0],
            totalCount: response[1][0][0]
          } as MenuFileListDatatableResponse;
        }
        return null;
      })
    );
  }
}
