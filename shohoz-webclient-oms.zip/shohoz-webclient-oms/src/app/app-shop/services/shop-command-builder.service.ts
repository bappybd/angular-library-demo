import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {CreateShopCommand, UpdateShopFilesCommand} from '../models/shop-command';
import {FormGroup} from '@angular/forms';
import {OperatingHourModel, ScheduledHourModel} from '../../shared/models/scheduled-hour-model';
import {FileModel, UtilityService} from '@eevo/eevo-core';
import {
  AddressInfoModel,
  AllowPreorderSpecEnum,
  ContactDetailsModel, ShopAffordabilityEnum, ShopModel, ShopSettingsModel
} from '../../shared/models/shop-entity-models';

@Injectable({
  providedIn: 'root'
})
export class ShopCommandBuilderService {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getCreateShopCommandPayload(restaurantId: string, formPayload: FormGroup): CreateShopCommand {
    const form = Object.assign({}, formPayload);
    const formData = form.value;

    if (formData.Details === null || formData.Details === undefined) {
      return null;
    }
    if (formData.ContactDetails === null || formData.ContactDetails === undefined) {
      return null;
    }
    if (formData.Address === null || formData.Address === undefined) {
      return null;
    }
    if (formData.ServiceHours === null || formData.ServiceHours === undefined) {
      return null;
    }
    if (formData.PreOrderScheduledHours === null || formData.PreOrderScheduledHours === undefined) {
      return null;
    }
    if (formData.Settings === null || formData.Settings === undefined) {
      return null;
    }
    if (!formData.Settings.EnableOrderCreation) {
      formData.Settings.ShopCustomersDeliveryFee = 0;
      formData.Settings.ShopOrdersCommission = 0;
      // if (formData.Settings.ShopOrdersCommission === null) {
      //   formData.Settings.ShopOrdersCommission = 0;
      // }
      // if (formData.Settings.ShopCustomersDeliveryFee === null) {
      //   formData.Settings.ShopCustomersDeliveryFee = 0;
      // }
    }

    let allowPreorderEnd = AllowPreorderSpecEnum.None;
    let allowPreorderStart = AllowPreorderSpecEnum.None;

    if (formData.ServiceHours.IsAllowPreorderForToday && formData.ServiceHours.IsAllowPreorderForTomorrow) {
      allowPreorderStart = AllowPreorderSpecEnum.Today;
      allowPreorderEnd = AllowPreorderSpecEnum.Tomorrow;
    } else if (formData.ServiceHours.IsAllowPreorderForToday) {
      allowPreorderStart = AllowPreorderSpecEnum.Today;
      allowPreorderEnd = AllowPreorderSpecEnum.Today;
    } else if (formData.ServiceHours.IsAllowPreorderForTomorrow) {
      allowPreorderStart = AllowPreorderSpecEnum.Tomorrow;
      allowPreorderEnd = AllowPreorderSpecEnum.Tomorrow;
    }

    const isAcceptPreorder = formData.ServiceHours.IsAcceptPreorder;

    const shopModel = {
      ShopId: restaurantId,
      LogoFileId: '',
      BannerFileId: '',
      ListImageFileId: '',
      HighlightedImageFileId: '',
      Name: formData.Details.Name,
      Description: formData.Details.Description,
      Tags: formData.Details.Tags ? formData.Details.Tags : [],
      Cuisines: formData.Details?.Cuisines ? formData.Details.Cuisines : [],
      AlternativeSearchText: formData.Details.AlternativeSearchText ? formData.Details.AlternativeSearchText : [],
      Affordability: Number(formData.Details.Affordability),
      EmergencyContactDetails: this.getContactDetails(formData.ContactDetails.EmergencyContactDetails) as ContactDetailsModel,
      FrontendDeskContactDetails: this.getContactDetails(formData.ContactDetails.FrontendDeskContactDetails) as ContactDetailsModel,
      KeyAccountsManagerContactDetails: this.getContactDetails(formData.ContactDetails.KeyAccountsManagerContactDetails) as ContactDetailsModel,
      Address: this.getAddress(formData.Address) as AddressInfoModel,
      IsSameForAllDaysServiceHours: formData.ServiceHours.ScheduledHours.IsSameForAllDaysServiceHours,
      ServiceHours: this.getScheduledHours(formData.ServiceHours.ScheduledHours) as ScheduledHourModel[],
      AcceptPreOrders: isAcceptPreorder,
      AllowPreorderEnd: allowPreorderEnd,
      AllowPreorderStart: allowPreorderStart,
      // PreOrderMaxRangeDays: number,
      IsSamePreOrderAsServiceHours: formData.ServiceHours.IsSameAsStartingAndClosingTimes,
      IsSameForAllDaysPreOrderScheduledHours: formData.PreOrderScheduledHours.ScheduledHours.IsSameForAllDaysServiceHours,
      PreOrderScheduledHours: null,
      Settings: this.getSettings(formData.Settings) as ShopSettingsModel,
    } as ShopModel;

    if (formData.Details?.CuratedTags?.length) {
      shopModel.Curations = formData.Details.CuratedTags ? formData.Details.CuratedTags
        .filter(c => !!c.CuratedName)
        .map(c => {
          return {
            Name: c.CuratedName,
            Order: c.Order
          };
        }) : [];
    }

    if (isAcceptPreorder && !formData.ServiceHours.IsSameAsStartingAndClosingTimes) {
      shopModel.PreOrderScheduledHours = this.getScheduledHours(formData.PreOrderScheduledHours.ScheduledHours) as ScheduledHourModel[];
    } else {
      shopModel.PreOrderScheduledHours = shopModel.ServiceHours;
    }

    const shopModels: ShopModel[] = [];
    shopModels.push(shopModel);
    return {
      CorrelationId: this.utilityService.getNewGuid(),
      Shops: shopModels
    } as CreateShopCommand;
  }

  /* private getCurationTags(payload: any): ShopModel {
       formData.Details.CuratedTags ? formData.Details.CuratedTags.map( c => {
         return {
           Name: c.CuratedName,
           Order: c.Order
         };
       }) : []
     } as ShopModel;
   }
 */
  getUpdateFilesCommand(fileObj: FileModel, shopId: string): UpdateShopFilesCommand {
    let command = new UpdateShopFilesCommand();
    command.Shops = [{
      ShopId: shopId,
      LogoFileId: fileObj.Type === 'LogoFile' ? fileObj.FileId : null,
      BannerFileId: fileObj.Type === 'BannerFile' ? fileObj.FileId : null,
      ListImageFileId: fileObj.Type === 'ListImageFile' ? fileObj.FileId : null,
      HighlightedImageFileId: fileObj.Type === 'HighlightedImageFile' ? fileObj.FileId : null
    }];

    return command;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private combineDateWithTime(date: Date, time: string): Date {
    date = new Date(date);
    let hour = 0;
    let minute = 0;

    if (time !== '') {
      const hourAndMinute = time.split(':');
      hour = Number(hourAndMinute[0]);
      minute = Number(hourAndMinute[1]);
    }

    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      hour,
      minute
    );
  }

  private getScheduledHours(payload: any): ScheduledHourModel[] {
    const scheduledHourModels: ScheduledHourModel[] = [];

    if (payload.IsSameForAllDaysServiceHours) {
      const operatingHourList: OperatingHourModel[] = [];
      const hours = payload.SameForAllDays as any[];

      hours.forEach((hour) => {
        if (this.isValidOperatingHour(hour)) {
          operatingHourList.push(this.getOperatingHourModel(hour));
        }
      });

      payload.WeekDays.forEach((day) => {
        scheduledHourModels.push({
          Day: day.WeekDay,
          OperatingHour: operatingHourList
        } as ScheduledHourModel);
      });

    } else {
      payload.WeekDays.forEach((weekDay) => {
        const scheduledHour = this.getScheduledHour(weekDay);
        if (scheduledHour && scheduledHour.OperatingHour.length > 0) {
          scheduledHourModels.push(scheduledHour);
        }
      });
    }
    return scheduledHourModels as ScheduledHourModel[];
  }

  private getScheduledHour(payload: any): ScheduledHourModel {
    const weekDay = payload.WeekDay;
    const hours = payload.Hours as any[];
    const operatingHourList: OperatingHourModel[] = [];

    hours.forEach((hour) => {
      if (this.isValidOperatingHour(hour)) {
        operatingHourList.push(this.getOperatingHourModel(hour));
      }
    });

    const scheduledHourModel: ScheduledHourModel = {
      Day: weekDay,
      OperatingHour: operatingHourList
    };

    return scheduledHourModel as ScheduledHourModel;
  }

  private isValidOperatingHour(hour: any): boolean {
    const openingTime = hour.OpeningTime;
    const closingTime = hour.ClosingTime;

    if (openingTime === undefined || openingTime === '' || closingTime === undefined || closingTime === '') {
      return false;
    }

    return true;
  }

  private getOperatingHourModel(hour: any): OperatingHourModel {
    const opeingHour = hour.OpeningTime;
    const openingTime = {
      Minute: 0,
      Hour: 0,
    };
    const closingTime = {
      Minute: 0,
      Hour: 0,
    };

    if (opeingHour !== undefined && opeingHour !== '') {
      const opeingTimes = opeingHour.split(':');
      openingTime.Hour = Number(opeingTimes[0]);
      openingTime.Minute = Number(opeingTimes[1]);
    }

    const closingHour = hour.ClosingTime;
    if (closingHour !== undefined && closingHour !== '') {
      const closingTimes = closingHour.split(':');
      closingTime.Hour = Number(closingTimes[0]);
      closingTime.Minute = Number(closingTimes[1]);

    }

    const scheduleHour = {
      ClosingTime: closingTime,
      OpeningTime: openingTime
    } as OperatingHourModel;

    return scheduleHour;
  }

  private getSettings(payload: any): ShopSettingsModel {
    const settings = {
      ShopStatus: Number(payload.RestaurantStatus),
      ShopType: Number(payload.ShopType),
      ZoneWiseSortOrder: Number(payload.ZoneWiseSortOrder),
      TagLine: payload.TagLine,
      IsHomeCook: Boolean(payload.IsHomeCook),
      MinimumProcessingTime: (Boolean(payload.IsHomeCook)) ? Number(payload.MinimumProcessingTime) : 0,
      MinimumOrderValue: payload.MinimumOrderValue !== undefined ? Number(payload.MinimumOrderValue) : null,
      MaximumOrderValue: payload.MaximumOrderValue !== undefined ? Number(payload.MaximumOrderValue) : null,
      OrderLimit: payload.OrderLimit !== undefined ? Number(payload.OrderLimit) : null,
      isVatIncluded: Boolean(payload.IsVatIncluded),
      Vat: Number(payload.Vat),
      // ServiceCharge: Number(payload.ServiceChange),
      Commission: Number(payload.Comission),
      IsDeliveredByShop: Boolean(payload.IsDeliveredByRestaurant),
      DeliveryFee: (payload.DeliveryFee !== undefined || payload.DeliveryFee !== null) ? Number(payload.DeliveryFee) : 0,
      IncludeTransactionFee: payload.IncludeTransactionFee,
      IsCreditShop: Boolean(payload.IsCreditRestaurant),
      IsPartialCreditShop: Boolean(payload.IsPartialCreditRestaurant),
      ShopBank: {
        AccountName: (Boolean(payload.IsCreditRestaurant || payload.IsPartialCreditRestaurant)) ? payload.RestaurantBank.AccountName : null,
        AccountNumber: (Boolean(payload.IsCreditRestaurant || payload.IsPartialCreditRestaurant)) ? payload.RestaurantBank.AccountNumber : null,
        BankName: (Boolean(payload.IsCreditRestaurant || payload.IsPartialCreditRestaurant)) ? payload.RestaurantBank.BankName : null,
        BranchName: (Boolean(payload.IsCreditRestaurant || payload.IsPartialCreditRestaurant)) ? payload.RestaurantBank.BankName : null,
        RoutingNumber: (Boolean(payload.IsCreditRestaurant || payload.IsPartialCreditRestaurant)) ? payload.RestaurantBank.RoutingNumber : null
      },
      IsCompliantShop: Boolean(payload.IsComplaintRestaurant),
      PaymentMethods: payload.PaymentMethods.filter(pm => pm !== false).map(m => {
        if (m._id) {
          m.Id = m._id;
          delete m._id;
        }
        return m;
      }),
      EnableOrderCreation: Boolean(payload.EnableOrderCreation),
      ShopCustomersDeliveryFee: payload.ShopCustomersDeliveryFee,
      ShopOrdersCommission: payload.ShopOrdersCommission
    } as ShopSettingsModel;

    if (payload.TagLineStartDate) {
      settings.TagLineStartDate = this.combineDateWithTime(payload.TagLineStartDate, payload.TagLineStartTime).toISOString();
    }
    if (payload.TagLineEndDate) {
      settings.TagLineEndDate = this.combineDateWithTime(payload.TagLineEndDate, payload.TagLineEndTime).toISOString();
    }

    const temporaryUnavailableDate = this.getTemporaryUnavailableData(payload);
    if (temporaryUnavailableDate?.IsTemporaryUnavailable) {
      settings.IsTemporaryUnavailable = temporaryUnavailableDate.IsTemporaryUnavailable;
      settings.TemporaryUnavailableStartTime = temporaryUnavailableDate.TemporaryUnavailableStartTime;
      settings.TemporaryUnavailableEndTime = new Date(new Date(temporaryUnavailableDate.TemporaryUnavailableEndTime || null).setSeconds(59));
    }

    return settings;
  }

  private getTemporaryUnavailableData({IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime}):
    { IsTemporaryUnavailable: boolean, TemporaryUnavailableStartTime: Date, TemporaryUnavailableEndTime: Date } | null {
    if (!IsTemporaryUnavailable || !TemporaryUnavailableStartTime || !TemporaryUnavailableEndTime) {
      return null;
    }
    if (new Date(TemporaryUnavailableStartTime) > new Date(TemporaryUnavailableEndTime)) {
      return null;
    }

    return {IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime};
  }

  private getContactDetails(payload: any): ContactDetailsModel {
    return {
      Name: payload?.Name || null,
      Email: payload?.Email || null,
      PhoneNumber: payload?.PhoneNumber || null,
    } as ContactDetailsModel;
  }

  private getAddress(payload: any): AddressInfoModel {
    let addressInfo: AddressInfoModel = {
      Address: payload.Address,
      City: payload.City,
      PostCode: payload.PostCode,
      Latitude: Number(payload.Latitude),
      Longitude: Number(payload.Longitude),
      Zone: {
        Id: payload.Zone.id,
        Name: payload.Zone.name,
      }
    };

    if (payload.Zone?._id) {
      addressInfo.Zone = {
        Id: payload.Zone._id,
        Name: payload.Zone.Name
      };
    }

    if (payload.SubZone?.id) {
      addressInfo.SubZone = {
        Id: payload.SubZone.id,
        Name: payload.SubZone.name
      };
    }

    return addressInfo;
  }

  private getDate(date: Date, start: boolean = true): string {
    return (start) ? new Date(new Date(date).setHours(0, 0, 0, 0)).toISOString() :
      new Date(new Date(date).setHours(23, 59, 59, 999)).toISOString();
  }
}
