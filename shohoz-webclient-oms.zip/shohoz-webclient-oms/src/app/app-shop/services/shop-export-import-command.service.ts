import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';

@Injectable({
  providedIn: 'root'
})
export class ShopExportImportCommandService {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createFile(fileId: string): Observable<any> {
    const importkey = 'shop-list-import/' + fileId + '.xlsx';
    const createPresignURLCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      FileInfos: [
        {
          FileId: fileId,
          Key: importkey
        }
      ]
    };
    return this.http.post(this.config.StorageCommandService + 'Files/CreateFilesByKey',
      createPresignURLCommand
    );
  }

  uploadToPresignedURL(uploadURL: string, file: File): Observable<any> {
    const header = new HttpHeaders({
      'x-ms-blob-type': 'BlockBlob'
    });
    return this.http.put(uploadURL, file, {headers: header});
  }

  prepareShopListForExport(exportId: string): Observable<any> {
    const prepareShopListCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      ExportId: exportId
    };

    return this.http.post(this.config.ShopService + 'ProtectedCommand/ExportShopList', prepareShopListCommand);
  }

  importShopList(fileId: string): Observable<any> {
    const importShopListCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      ExportId: fileId
    };

    return this.http.post(this.config.ShopService + 'ProtectedCommand/ImportShopList', importShopListCommand);
  }
}
