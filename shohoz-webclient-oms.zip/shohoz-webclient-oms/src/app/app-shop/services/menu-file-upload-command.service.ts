import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {FilesModel, UtilityService} from '@eevo/eevo-core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {MenuFileEntity} from '../entities/menu-file-entity';

@Injectable({
  providedIn: 'root'
})
export class MenuFileUploadCommandService {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createFile(fileId: string, shopId: string): Observable<any> {
    const importkey = 'import/' + shopId + '/fileid/' + fileId + '.xlsx';
    const createPresignURLCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      FileInfos: [
        {
          FileId: fileId,
          Key: importkey
        }
      ]
    };

    return this.http.post(this.config.StorageCommandService + 'Files/CreateFilesByKey',
      createPresignURLCommand
    );
  }

  uploadToPresignedURL(uploadURL: string, file: File): Observable<any> {
    const header = new HttpHeaders({
      'x-ms-blob-type': 'BlockBlob'
    });
    return this.http.put(uploadURL, file, {headers: header});
  }

  updateFileData(shopId: string, fileId: string): Observable<any> {
    const updateFileDataCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      ShopId: shopId,
      ExportId: fileId
    };

    return this.http.post(this.config.ShopService + 'ProtectedCommand/ImportShopItems', updateFileDataCommand);
  }

  prepareMenu(exportId: string, shopId: string): Observable<any> {
    const prepareMenuCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      ShopId: shopId,
      ExportId: exportId
    };

    return this.http.post(this.config.ShopService + 'ProtectedCommand/ExportShopItems', prepareMenuCommand);
  }
}
