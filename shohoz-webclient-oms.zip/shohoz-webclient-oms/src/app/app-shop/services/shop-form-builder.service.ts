import {Injectable} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import * as _ from 'lodash';
import {OperatingHourModel, ScheduledHourModel} from '../../shared/models/scheduled-hour-model';
import {
  AllowPreorderSpecEnum,
  ShopAffordabilityEnum,
  ShopModel,
  ShopStatusEnum, ShopTypeEnum
} from '../../shared/models/shop-entity-models';
import {EevoValidator} from '../../shared/validator/eevo.validator';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';

@Injectable({
  providedIn: 'root'
})
export class ShopFormBuilderService {

  constructor(private formBuilder: FormBuilder, private scheduleHourService: ScheduleHourService) {
  }

  setShopFormData(formGroup: FormGroup, formData: ShopModel): void {
    this.setShopDetailsValues(formGroup.get('Details') as FormGroup, formData);
    this.setShopContactDetailValues(formGroup.get('ContactDetails') as FormGroup, formData);
    this.setShopAddressValues(formGroup.get('Address') as FormGroup, formData);
    this.setShopSettingsValues(formGroup.get('Settings') as FormGroup, formData);

    const isSameForAllDaysServiceHours = formData.IsSameForAllDaysServiceHours;

    this.setShopServiceHourValues(
      formGroup.get('ServiceHours').get('ScheduledHours') as FormGroup,
      isSameForAllDaysServiceHours,
      formData.ServiceHours
    );
    if (!formData.IsSamePreOrderAsServiceHours) {
      const isSameForAllDaysPreOrderScheduledHours = formData.IsSameForAllDaysPreOrderScheduledHours;
      this.setShopServiceHourValues(
        formGroup.get('PreOrderScheduledHours').get('ScheduledHours') as FormGroup,
        isSameForAllDaysPreOrderScheduledHours,
        formData.PreOrderScheduledHours
      );
    }

    formGroup.get('ServiceHours').get('IsAcceptPreorder').setValue(formData.AcceptPreOrders);
    formGroup.get('ServiceHours').get('IsSameAsStartingAndClosingTimes').setValue(formData.IsSamePreOrderAsServiceHours);
    formGroup.get('ServiceHours').get('IsAllowPreorderForToday').setValue(formData.AllowPreorderStart === AllowPreorderSpecEnum.Today);
    formGroup.get('ServiceHours').get('IsAllowPreorderForTomorrow').setValue(formData.AllowPreorderEnd === AllowPreorderSpecEnum.Tomorrow);
  }

  getShopForm(): FormGroup {
    const detailsForm = this.formBuilder.group({
      Name: new FormControl('', [Validators.required, EevoValidator.cannotWhiteSpace]),
      Description: new FormControl('', [EevoValidator.cannotWhiteSpace]),
      Tags: [''],
      Cuisines: [''],
      AlternativeSearchText: [''],
      Affordability: [ShopAffordabilityEnum.Expensive, Validators.required],
      LogoFileId: [''],
      BannerFileId: [''],
      ListImageFileId: [''],
      HighlightedImageFileId: [],
      CuratedTags: this.formBuilder.array([
        this.formBuilder.group({
          CuratedName: ['', EevoValidator.cannotWhiteSpace],
          Order: [0],
        }),
      ])
    });

    const contactForm = this.formBuilder.group({
      EmergencyContactDetails: this.getContactDetailsForm(false, false, true),
      FrontendDeskContactDetails: this.getContactDetailsForm(false, false, true),
      KeyAccountsManagerContactDetails: this.getContactDetailsForm(false, false, false),
    });

    const addressForm = this.formBuilder.group({
      Address: new FormControl('', [Validators.required, EevoValidator.cannotWhiteSpace]),
      City: new FormControl('', [Validators.required, EevoValidator.cannotWhiteSpace]),
      PostCode: new FormControl(null, Validators.compose([
        Validators.required,
        Validators.min(999),
        Validators.max(9999)
      ])),
      Latitude: ['', Validators.required],
      Longitude: ['', Validators.required],
      Zone: ['', Validators.required],
      SubZone: [''],
    });

    const settingsForm = this.formBuilder.group({
      RestaurantStatus: [ShopStatusEnum.Closed],
      ShopType: [ShopTypeEnum.Restaurant, Validators.required],
      ZoneWiseSortOrder: ['99', Validators.required],
      TagLine: [''],
      TagLineStartDate: [new Date()],
      TagLineStartTime: [''],
      TagLineEndDate: [new Date()],
      TagLineEndTime: [''],
      IsHomeCook: [false],
      MinimumProcessingTime: [''],
      MinimumOrderValue: [''],
      MaximumOrderValue: [''],
      OrderLimit: [''],
      IsVatIncluded: [false],
      Vat: ['', Validators.required],
      /* ServiceChange: [''],*/
      Comission: [''],
      IsDeliveredByRestaurant: [false],
      DeliveryFee: [''],
      IncludeTransactionFee: [false],
      IsCreditRestaurant: [''],
      IsPartialCreditRestaurant: [''],
      RestaurantBank: this.formBuilder.group({
        AccountName: [''],
        AccountNumber: [''],
        BankName: [''],
        BranchName: [''],
        RoutingNumber: [''],
      }),
      IsComplaintRestaurant: [''],
      PaymentMethods: this.formBuilder.array([], [EevoValidator.paymentMethodSelected]),
      EnableOrderCreation: [false],
      ShopCustomersDeliveryFee: [''],
      ShopOrdersCommission: ['']
      , IsTemporaryUnavailable: [false],
      TemporaryUnavailableStartTime: [new Date()],
      TemporaryUnavailableEndTime: [this.getTodayMidnightDate()],
    });

    const weekDaysFormArray = this.scheduleHourService.getWeekDaysFormArray();
    const scheduledHoursForm = this.scheduleHourService.getScheduleHoursFormGroup();

    const preOrderScheduledHoursForm = this.formBuilder.group({
      IsSameForAllDaysServiceHours: [true],
      SameForAllDays: this.formBuilder.array([
        this.formBuilder.group({
          OpeningTime: [''],
          ClosingTime: [''],
        }),
      ]),
      WeekDays: _.cloneDeep(weekDaysFormArray)
    });

    return this.formBuilder.group({
      Details: detailsForm,
      ContactDetails: contactForm,
      Address: addressForm,
      Settings: settingsForm,
      ServiceHours: this.formBuilder.group({
        IsAcceptPreorder: [false],
        IsAllowPreorderForToday: [true],
        IsAllowPreorderForTomorrow: [true],
        MinOnePreOrderDaySelected: [null],
        IsSameAsStartingAndClosingTimes: [true],
        ScheduledHours: scheduledHoursForm,
      }),
      PreOrderScheduledHours: this.formBuilder.group({
        ScheduledHours: preOrderScheduledHoursForm,
      }),
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  private getTodayMidnightDate(): Date {
    const date = new Date();
    date.setHours(23, 59, 59, 999);
    return date;
  }

  private getContactDetailsForm(nameRequired: boolean, emailRequired: boolean, phoneRequired: boolean): FormGroup {
    const contactForm = this.formBuilder.group({
      Name: new FormControl('', [EevoValidator.cannotWhiteSpace]),
      Email: new FormControl('', [Validators.email]),
      PhoneNumber: new FormControl('', [EevoValidator.cannotWhiteSpace]),
    });
    if (nameRequired) {
      contactForm.get('Name').setValidators([Validators.required]);
    }
    if (emailRequired) {
      contactForm.get('Email').setValidators([Validators.required]);
    }
    if (phoneRequired) {
      contactForm.get('PhoneNumber').setValidators([Validators.required]);
    }
    return contactForm;
  }

  private getServiceHourFormBuilder(weekDay): FormGroup {
    return this.formBuilder.group({
      WeekDay: [weekDay],
      Hours: this.formBuilder.array([
        this.formBuilder.group({
          OpeningTime: [''],
          ClosingTime: [''],
        }),
      ]),
    });
  }

  private setShopDetailsValues(formGroup: FormGroup, formData: ShopModel): void {
    formGroup.get('Name').setValue(formData.Name);
    formGroup.get('Description').setValue(formData.Description);
    formGroup.get('Tags').setValue(formData.Tags);
    formGroup.get('Cuisines').setValue(formData?.Cuisines);
    formGroup.get('AlternativeSearchText').setValue(formData.AlternativeSearchText);
    formGroup.get('Affordability').setValue(formData.Affordability);
    formGroup.get('LogoFileId').setValue(formData.LogoFileId);
    formGroup.get('BannerFileId').setValue(formData.BannerFileId);
    formGroup.get('ListImageFileId').setValue(formData.ListImageFileId);
    formGroup.get('HighlightedImageFileId').setValue(formData.HighlightedImageFileId);

    const curations = formData.Curations;
    if (curations && curations.length > 0) {
      const curatedTags = formGroup.get('CuratedTags') as FormArray; // .get('Details')
      curations.forEach((data, index) => {
        if (index === 0) {
          curatedTags.at(index).get('CuratedName').setValue(data.Name);
          curatedTags.at(index).get('Order').setValue(data.Order);
        } else {
          curatedTags.push(this.formBuilder.group({
            CuratedName: [data.Name],
            Order: [data.Order],
          }));
        }
      });
    }
  }

  private setShopContactDetailValues(formGroup: FormGroup, formData: ShopModel): void {
    formGroup.get('EmergencyContactDetails').get('Name').setValue(formData.EmergencyContactDetails.Name);
    formGroup.get('EmergencyContactDetails').get('Email').setValue(formData.EmergencyContactDetails.Email);
    formGroup.get('EmergencyContactDetails').get('PhoneNumber').setValue(formData.EmergencyContactDetails.PhoneNumber);

    formGroup.get('FrontendDeskContactDetails').get('Name').setValue(formData.FrontendDeskContactDetails.Name);
    formGroup.get('FrontendDeskContactDetails').get('Email').setValue(formData.FrontendDeskContactDetails.Email);
    formGroup.get('FrontendDeskContactDetails').get('PhoneNumber').setValue(formData.FrontendDeskContactDetails.PhoneNumber);

    formGroup.get('KeyAccountsManagerContactDetails').get('Name').setValue(formData?.KeyAccountsManagerContactDetails?.Name);
    formGroup.get('KeyAccountsManagerContactDetails').get('Email').setValue(formData?.KeyAccountsManagerContactDetails?.Email);
    formGroup.get('KeyAccountsManagerContactDetails').get('PhoneNumber').setValue(formData?.KeyAccountsManagerContactDetails?.PhoneNumber);
  }

  private setShopAddressValues(formGroup: FormGroup, formData: ShopModel): void {
    formGroup.get('Address').setValue(formData.Address.Address);
    formGroup.get('City').setValue(formData.Address.City);
    formGroup.get('PostCode').setValue(formData.Address.PostCode);
    formGroup.get('Latitude').setValue(formData.Address.Latitude);
    formGroup.get('Longitude').setValue(formData.Address.Longitude);
    formGroup.get('Zone').setValue(formData.Address.Zone);
    formGroup.get('SubZone').setValue(formData.Address.SubZone);
  }

  private setShopSettingsValues(formGroup: FormGroup, formData: ShopModel): void {
    formGroup.get('RestaurantStatus').setValue(formData.Settings.ShopStatus);
    formGroup.get('ShopType').setValue(ShopTypeEnum[formData.Settings.ShopType]);
    formGroup.get('ZoneWiseSortOrder').setValue(formData.Settings.ZoneWiseSortOrder);
    formGroup.get('TagLine').setValue(formData.Settings.TagLine);
    formGroup.get('IsHomeCook').setValue(formData.Settings.IsHomeCook);
    formGroup.get('MinimumProcessingTime').setValue(formData.Settings.MinimumProcessingTime);
    formGroup.get('MinimumOrderValue').setValue(formData.Settings.MinimumOrderValue);
    formGroup.get('MaximumOrderValue').setValue(formData.Settings.MaximumOrderValue);
    formGroup.get('Vat').setValue(formData.Settings.Vat);
    // formGroup.get('ServiceChange').setValue(formData.Settings.ServiceCharge);
    formGroup.get('Comission').setValue(formData.Settings.Commission);
    formGroup.get('IsDeliveredByRestaurant').setValue(formData.Settings.IsDeliveredByShop);
    formGroup.get('DeliveryFee').setValue(formData.Settings.DeliveryFee);
    formGroup.get('IncludeTransactionFee').setValue(formData.Settings.IncludeTransactionFee);
    formGroup.get('IsCreditRestaurant').setValue(formData.Settings.IsCreditShop);
    formGroup.get('IsPartialCreditRestaurant').setValue(formData.Settings.IsPartialCreditShop);
    formGroup.get('OrderLimit').setValue(formData.Settings.OrderLimit);
    formGroup.get('IsVatIncluded').setValue(formData.Settings.IsVatIncluded);

    if (formData.Settings.ShopBank !== null) {
      formGroup.get('RestaurantBank').get('AccountName').setValue(formData.Settings.ShopBank.AccountName);
      formGroup.get('RestaurantBank').get('AccountNumber').setValue(formData.Settings.ShopBank.AccountNumber);
      formGroup.get('RestaurantBank').get('BankName').setValue(formData.Settings.ShopBank.BankName);
      formGroup.get('RestaurantBank').get('BranchName').setValue(formData.Settings.ShopBank.BranchName);
      formGroup.get('RestaurantBank').get('RoutingNumber').setValue(formData.Settings.ShopBank.RoutingNumber);
    }

    if (formData.Settings?.TagLine && formData.Settings.TagLine !== '') {
      formGroup.get('TagLineStartDate').setValue(formData.Settings.TagLineStartDate);
      formGroup.get('TagLineStartTime').setValue(this.getTimeSlot(formData.Settings.TagLineStartDate));
      formGroup.get('TagLineEndDate').setValue(formData.Settings.TagLineEndDate);
      formGroup.get('TagLineEndTime').setValue(this.getTimeSlot(formData.Settings.TagLineEndDate));
    }

    formGroup.get('IsComplaintRestaurant').setValue(formData.Settings.IsCompliantShop);

    const paymentMethods = formData.Settings.PaymentMethods;
    if (paymentMethods && paymentMethods.length > 0) {
      const payemntMethod = formGroup.get('PaymentMethods') as FormArray;
      paymentMethods.forEach((data) => {
        payemntMethod.push(new FormControl(data));
      });
    }
    if (formData.Settings.EnableOrderCreation) {
      formGroup.get('EnableOrderCreation').setValue(formData.Settings.EnableOrderCreation);
      formGroup.get('ShopCustomersDeliveryFee').setValue(formData.Settings.ShopCustomersDeliveryFee);
      formGroup.get('ShopOrdersCommission').setValue(formData.Settings.ShopOrdersCommission);
    }

    if (formData.Settings?.IsTemporaryUnavailable) {
      formGroup.get('IsTemporaryUnavailable').setValue(formData.Settings.IsTemporaryUnavailable);
      formGroup.get('TemporaryUnavailableEndTime').setValue(formData.Settings.TemporaryUnavailableEndTime);
      formGroup.get('TemporaryUnavailableEndTime').setValidators([Validators.required]);
    }
    // formGroup.get('PaymentMethods').setValue(formData.Settings.PaymentMethods);
  }

  private getTimeSlot(date: string): string {
    const dt = new Date(date);
    return _.padStart(dt.getHours() + '', 2, '0') + ':' + _.padStart(dt.getMinutes() + '', 2, '0');
  }

  private setShopServiceHourValues(formGroup: FormGroup, isSameForAllDaysServiceHours: boolean,
                                   scheduledHours: ScheduledHourModel[]): void {

    formGroup.get('IsSameForAllDaysServiceHours').setValue(isSameForAllDaysServiceHours);

    if (isSameForAllDaysServiceHours) {
      const sameForAllDays = formGroup.get('SameForAllDays') as FormArray;

      const operatingHours = scheduledHours[0].OperatingHour;

      this.setOperatingHours(sameForAllDays, operatingHours);
    } else {
      const weekDays = formGroup.get('WeekDays') as FormArray;

      for (let i = 0; i < scheduledHours.length; i++) {
        const scheduledHour = scheduledHours[i];
        /* weekDays.at(i).get('WeekDay').setValue(scheduledHour.Day);*/
        const operatingHours = scheduledHour.OperatingHour;
        const hours = weekDays.at(scheduledHour.Day).get('Hours') as FormArray;

        this.setOperatingHours(hours, operatingHours);
      }
    }
  }

  private setOperatingHours(formArray: FormArray, operatingHours: OperatingHourModel[]): void {
    for (let hourIndex = 0; hourIndex < operatingHours.length; hourIndex++) {
      const openingTime = operatingHours[hourIndex].OpeningTime;
      const closingTime = operatingHours[hourIndex].ClosingTime;

      const openingSomoy = _.padStart(openingTime.Hour + '', 2, '0') + ':' + _.padStart(openingTime.Minute + '', 2, '0');
      const closingSomoy = _.padStart(closingTime.Hour + '', 2, '0') + ':' + _.padStart(closingTime.Minute + '', 2, '0');

      if (hourIndex === 0) {
        formArray.at(hourIndex).get('OpeningTime').setValue(openingSomoy);
        formArray.at(hourIndex).get('ClosingTime').setValue(closingSomoy);
      } else {
        formArray.push(this.formBuilder.group({
          OpeningTime: [openingSomoy],
          ClosingTime: [closingSomoy],
        }));
      }
    }
  }
}
