import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {Shop, ShopFilter, ShopListResponse} from '../models/shop-models';
import {UtilityService} from '@eevo/eevo-core';
import {DatatableModel} from '@eevo/eevo-platform-datatable';
import {ShopAffordabilityEnum, ShopModel, ShopStatusEnum} from '../../shared/models/shop-entity-models';
import {ShopEntity} from '../entities/shop-entity';

@Injectable({
  providedIn: 'root'
})

export class ShopQueryService {
  constructor(
    private http: HttpClient,
    private shopEntity: ShopEntity,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getShopDetails(shopId: string): Observable<ShopModel> {
    const query = `{ '_id' : GUID('` + shopId + `')  }`;
    const requestBody = [
      {
        source: this.shopEntity.getDetailsName(),
        text: null,
        filter: query,
        fields: this.shopEntity.getDetailsFields(),
        orderBy: 'Language',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.ShopService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        response[0].map(data => {
          data.ShopId = data.Id;
          return data;
        });

        if (response && response[0]) {
          return response[0][0] as ShopModel;
        }
        return null;
      })
    );
  }

  getShopStatusFilter(status: number): string {
    const nowISO = new Date().toISOString();
    switch (status) {
      case 1:
        return `{ "Settings.ShopStatus": ${status}, $or: [ { "Settings.IsTemporaryUnavailable": { $in: [null, false] } }, { $and: [ { "Settings.IsTemporaryUnavailable": true }, { "Settings.TemporaryUnavailableEndTime": { $lt: ISODate("${nowISO}") } } ] } ] }`;
      // Query for temporary unavailable/closed filter
      case 2.5:
        return `{ $and: [ {"Settings.IsTemporaryUnavailable": true},{ "Settings.ShopStatus": 1 }, { "Settings.TemporaryUnavailableEndTime": { $gte: ISODate("${nowISO}") } } ] }`;
      default:
        return `{ 'Settings.ShopStatus': ${status}}`;
    }
  }

  getShopList(tableModel: DatatableModel<any>, filter?: ShopFilter): Observable<ShopListResponse> {
    let rawQuery = '';
    let combinedQuery = '';
    if (filter) {
      if (filter.searchKey && filter.searchKey.length > 0) {
        let skey = this.utilityService.matchAnyCharacterRegx(filter.searchKey);
        // filter.searchKey = this.utilityService.matchAnyCharacterRegx(filter.searchKey);
        combinedQuery += `{ Name: { $regex: '${skey}', $options: 'i'} }`;
      }
      if (filter.status) {
        combinedQuery += `${this.getShopStatusFilter(+filter.status)}, `;
      }
      if (filter.affordability) {
        combinedQuery += ` { Affordability: ` + filter.affordability + `},`;
      }
      if (filter.zone !== null) {
        combinedQuery += ` { 'Address.Zone._id': '` + filter.zone.id + `' }`;
      }
      if (filter.availability) {
        combinedQuery += `{ "ServiceHours": ${(filter.availability === 1) ?
          this.getAvailableServiceHourQuery() : this.getUnavailableServiceHourQuery()} }`;
      }
    }

    if (combinedQuery.length > 0) {
      rawQuery += `{$and: [ ` + combinedQuery + ` ] }`;
    }

    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.shopEntity.getDetailsName(),
        text: null,
        filter: rawQuery.length ? rawQuery : '{}',
        fields: this.shopEntity.getListFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.shopEntity.getDetailsName(),
        text: null,
        filter: rawQuery.length ? rawQuery : '{}',
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        response[0].map(data => {
          return this.getFormattedShopList(data);
        });
        return {
          data: response[0],
          totalCount: response[1][0][0]
        };
      })
    );
  }

  private getFormattedShopList(shop: Shop): Shop {
    shop.Affordability = this.getShopAffordability(Number(shop.Affordability));
    // shop.ShopStatus = this.getShopStatus(Number(shop.ShopStatus));
    return shop;
  }

  private getShopStatus(value: number): string {
    return Object.keys(ShopStatusEnum)
      .find(key => ShopStatusEnum[key] === value) || 'closed';
  }

  private getShopAffordability(value: number): string {
    return Object.keys(ShopAffordabilityEnum)
      .find(key => ShopAffordabilityEnum[key] === value) || '-';
  }

  private getAvailableServiceHourQuery(date?: any): string {
    const time = this.getCurrentDayHourMin(date);
    const openingTime = `"OpeningTime.TotalMinute": { $lte: ${time.CurrentTimeInMinute} }`;
    const closingTime = `"ClosingTime.TotalMinute": { $gte: ${time.CurrentTimeInMinute} }`;
    return `{ $elemMatch: { "Day" : ${time.CurrentDayOfWeek}, "OperatingHour": { $elemMatch: { ${openingTime}, ${closingTime} } } } }`;
  }

  private getUnavailableServiceHourQuery(date?: any): string {
    const time = this.getCurrentDayHourMin(date);
    const openingTime = `"OpeningTime.TotalMinute": { $lte: ${time.CurrentTimeInMinute} }`;
    const closingTime = `"ClosingTime.TotalMinute": { $gte: ${time.CurrentTimeInMinute} }`;
    return `{ $elemMatch: { "Day" : ${time.CurrentDayOfWeek}, "OperatingHour": { $not: { $elemMatch: { ${openingTime}, ${closingTime} } } } } }`;
  }

  private getCurrentDayHourMin(date?: any): any {
    if (!date) {
      date = new Date();
    }
    const minutes = date.getMinutes();
    const hour = date.getHours();
    const dayOfWeek = date.getDay(); // Sunday = 0, Monday = 1, etc.
    const milliSeconds = date.getMilliseconds();
    const currTimeInMin = (hour * 60) + minutes;

    return {
      Date: date.toISOString(),
      CurrentDayOfWeek: dayOfWeek,
      CurrentHour: hour,
      CurrentMinute: minutes,
      CurrentTimeInMinute: currTimeInMin
    };
  }
}
