import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {ShopExportEntity} from '../entities/shop-export-entity';
import {DatatableModel} from '@eevo/eevo-platform-datatable';
import {MenuFileListDatatableResponse} from '../models/menu-file-models';
import {ShopImportEntity} from '../entities/shop-import-entity';
import {ShopListImportDatatableResponse} from '../models/shop-export-import-models';

@Injectable({
  providedIn: 'root'
})
export class ShopExportImportQueryService {

  constructor(
    private http: HttpClient,
    private shopExportEntity: ShopExportEntity,
    private shopImportEntity: ShopImportEntity,
    @Inject('config') private config: any
  ) { }

  fetchExportKey(entityId): Observable<any> {
    const query = `{ '_id' : GUID('` + entityId + `')  }`;
    const requestBody = [
      {
        source: this.shopExportEntity.getListName(),
        text: null,
        filter: query,
        fields: this.shopExportEntity.getDetailsFields(),
        orderBy: 'CreatedDate',
        descending: true,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.ShopService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        return response[0][0];
      })
    );
  }

  fetchShopImportFileList(tableModel: DatatableModel<any>): Observable<MenuFileListDatatableResponse> {
    const query = `{}`;
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.shopImportEntity.getListName(),
        text: null,
        filter: query,
        fields: this.shopImportEntity.getDetailsFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.shopImportEntity.getListName(),
        text: null,
        filter: query,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        if (response && response[0]) {
          return {
            data: response[0],
            totalCount: response[1][0][0]
          } as ShopListImportDatatableResponse;
        }
        return null;
      })
    );
  }

  fetchLastPreparedShopListByStatus(status: number): Observable<any> {
    const query = `{'Status' :  ${status}  }`;
    return this.http.post(this.config.ShopService.toQueryURL(), [{
        source: this.shopExportEntity.getListName(),
        text: null,
        filter: query,
        fields: this.shopExportEntity.getDetailsFields(),
        orderBy: 'CreatedDate',
        descending: true,
        pageSize: 1,
        pageIndex: 0
      },
      {
        source: this.shopExportEntity.getListName(),
        text: null,
        filter: '{}',
        fields: this.shopExportEntity.getDetailsFields(),
        orderBy: 'CreatedDate',
        descending: true,
        pageSize: 1,
        pageIndex: 0
      }],
      ).pipe(
      map(res => {
        if (res) {
          return {
            lastSuccessfulExport: res[0][0],
            lastExport: res[1][0]
          };
        }
      })
    );
  }
}
