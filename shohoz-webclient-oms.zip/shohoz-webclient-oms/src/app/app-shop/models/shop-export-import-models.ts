export interface ShopListImportModel {
  CreatedDate: any;
  InitiatedUserName: string;
  Status: number;
  Error?: string;
  ImportFileKey: string;
}

export interface ShopListImportDatatableResponse {
  data: ShopListImportModel[];
  totalCount: number;
}

export enum ShopListExportStates {
  WaitingForStorageUploadUrl,
  FileUploading,
  Success,
  Failed,
}
