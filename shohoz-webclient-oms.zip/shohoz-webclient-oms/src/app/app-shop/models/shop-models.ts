import {ShopSettingsModel, ShopStatusEnum} from '../../shared/models/shop-entity-models';

export class ShopStatusUpdateModel {
  public ShopId: string;
  public Settings: SetingsShopStatusUpdateModel;
}

export class SetingsShopStatusUpdateModel {
  public ShopStatus: ShopStatusEnum;
  public IsTemporaryUnavailable: boolean;
  public TemporaryUnavailableStartTime?: Date;
  public TemporaryUnavailableEndTime?: Date;
}

export class ShopFilesModel {
  public ShopId: string;
  public LogoFileId: string;
  public BannerFileId: string;
  public ListImageFileId: string;
  public HighlightedImageFileId: string;
}

export interface Shop {
  Id: string;
  Name: string;
  LogoFileId: string;
  Contact: string;
  Affordability: string;
  DeliveryFee: string;
  ShopStatus: number;
  Zone: string;
}

export interface ShopDetails {
  Id: string;
  Name: string;
  LogoFileId: string;
  Contact: string;
  Affordability: string;
  DeliveryFee: string;
  Zone: string;
  Settings: ShopSettingsModel;
  UpdatedByExternalUser?: boolean;
}

export interface ShopListResponse {
  data: Shop[];
  totalCount: number;
}

export interface ShopFilter {
  searchKey: string;
  status: string;
  affordability: string;
  zone: any;
  availability?: number;
}

export class ShopListConfigModel<T> {
  TotalElements: number;
  TotalPages: number;
  Data: Array<T>;

  constructor() {
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.Data = new Array<T>();
  }
}
