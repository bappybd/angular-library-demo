export interface MenuFileListModel {
  CreatedDate: any;
  InitiatedUserName: string;
  Status: number;
  Error?: string;
  ImportFileKey: string;
}

export interface MenuFileListDatatableResponse {
  data: MenuFileListModel[];
  totalCount: number;
}

export enum MenuExportStates {
  WaitingForStorageUploadUrl,
  FileUploading,
  Success,
  Failed,
}
