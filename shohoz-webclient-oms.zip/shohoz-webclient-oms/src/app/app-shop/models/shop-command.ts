import {ShopFilesModel, ShopStatusUpdateModel} from './shop-models';
import {ShopModel} from '../../shared/models/shop-entity-models';
import {EevoCommandBase} from '@eevo/eevo-core';

export class CreateShopCommand extends EevoCommandBase {
  constructor() {
    super();
  }

  public Shops: ShopModel[];
}

export class UpdateShopFilesCommand extends EevoCommandBase {
  constructor() {
    super();
  }

  public Shops: ShopFilesModel[];
}

export class ShopStatusUpdateCommand extends EevoCommandBase {
  constructor() {
    super();
  }

  public Shops: ShopStatusUpdateModel[];
}


