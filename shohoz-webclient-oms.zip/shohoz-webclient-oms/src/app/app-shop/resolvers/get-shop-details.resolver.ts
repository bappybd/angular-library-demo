import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve, Router, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs';
import {ShopModel} from '../../shared/models/shop-entity-models';
import {ShopQueryService} from '../services/shop-query.service';
import {tap} from 'rxjs/operators';

@Injectable({providedIn: 'root'})
export class GetShopDetailsResolver implements Resolve<ShopModel> {
  constructor(
    private shopQueryService: ShopQueryService,
    private router: Router
  ) {
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ShopModel> | null {
    const shopId = route.params['id'];
    return this.shopQueryService.getShopDetails(shopId).pipe(
      tap(res => {
        if (!res) {
          this.router.navigate(['/']);
        }
      })
    );
  }

}
