import {EevoEntityRoot} from '@eevo/eevo-core';
import {Injectable} from '@angular/core';

enum FileEvents {
  FileCreatedEvent = 'FileCreatedEvent',
  FileBusinessRuleViolatedEvent = 'FileBusinessRuleViolatedEvent',
  ShopExportSuccess = 'ShopExportSuccess',
  ShopImportSuccess = 'ShopImportSuccess',
  ShopImportFailed = 'ShopImportFailed'
}

@Injectable({
  providedIn: 'root'
})

export class MenuFileEntity extends EevoEntityRoot {

  Events = FileEvents;

  constructor() {
    super('ShopExportLogs');
  }

  getDetailsFields(): string[] {
    return [
      'ExportFileKey', 'CreatedDate', 'Status'
    ];
  }

  getListFields(): string[] {
    return [

    ];
  }
}
