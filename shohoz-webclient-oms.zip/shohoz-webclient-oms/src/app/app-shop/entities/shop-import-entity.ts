import {EevoEntityRoot} from '@eevo/eevo-core';
import {Injectable} from '@angular/core';

enum FileEvents {
  FileCreatedEvent = 'FileCreatedEvent',
  FileBusinessRuleViolatedEvent = 'FileBusinessRuleViolatedEvent',
  ShopListImportSuccess = 'ShopListImportSuccess',
  ShopListImportFailed = 'ShopListImportFailed'
}

@Injectable({
  providedIn: 'root'
})

export class ShopImportEntity extends EevoEntityRoot {

  Events = FileEvents;

  constructor() {
    super('ShopListImportLogs');
  }

  getDetailsFields(): string[] {
    return [
      'CreatedDate',
      'ShopId',
      'ImportFileId',
      'ImportFileKey',
      'Status',
      'Error',
      'InitiatedUserName'
    ];
  }

  getListFields(): string[] {
    return [

    ];
  }
}
