import {EevoEntityRoot} from '@eevo/eevo-core';
import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MenuFileImportEntity extends EevoEntityRoot {

  constructor() {
    super('ShopImportLogs');
  }

  getDetailsFields(): string[] {
    return [
    ];
  }

  getListFields(): string[] {
    return [
      'CreatedDate', 'InitiatedUserName', 'Status', 'Error', 'ImportFileKey'
    ];
  }
}
