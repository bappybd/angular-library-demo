import {EevoEntityRoot} from '@eevo/eevo-core';
import {Injectable} from '@angular/core';

enum FileEvents {
  FileBusinessRuleViolatedEvent = 'FileBusinessRuleViolatedEvent',
  ShopListExportSuccess = 'ShopListExportSuccess',
  ShopListExportFailed = 'ShopListExportFailed',
}

@Injectable({
  providedIn: 'root'
})

export class ShopExportEntity extends EevoEntityRoot {

  Events = FileEvents;

  constructor() {
    super('ShopListExportLogs');
  }

  getDetailsFields(): string[] {
    return [
      'ExportFileKey',
      'Status',
      'CreatedDate',
      'CreatedBy'
    ];
  }

  getListFields(): string[] {
    return [

    ];
  }
}
