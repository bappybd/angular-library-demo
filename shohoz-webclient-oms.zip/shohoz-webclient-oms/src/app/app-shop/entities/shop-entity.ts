import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ShopImageType {
  Logo = 'logo',
  Banner = 'banner',
  ListImage = 'list',
  HighlightedImage = 'highlighted',
}

enum ShopEvents {
  ShopBusinessRuleViolationEvent = 'ShopBusinessRuleViolationEvent',
  ShopFilesUpdatedEvent = 'ShopFilesUpdatedEvent',
  ShopStatusUpdateEvent = 'ShopStatusUpdateEvent',
  ShopUpdatedEvent = 'ShopUpdatedEvent',
  ShopCreatedEvent = 'ShopCreatedEvent',
  ShopAvailabilityUpdatedEvent = 'ShopAvailabilityUpdatedEvent',
}

@Injectable({
  providedIn: 'root'
})
export class ShopEntity extends EevoEntityRoot {

  Events = ShopEvents;

  ImageType = ShopImageType;

  constructor() {
    super('ShopLists');
  }

  getDetailsFields(): string[] {
    return [
      'Name', 'Description', 'AlternativeSearchText', 'Affordability', 'LogoFileId', 'BannerFileId',
      'ListImageFileId', 'HighlightedImageFileId', 'EmergencyContactDetails', 'FrontendDeskContactDetails', 'Address',
      'IsSameForAllDaysServiceHours', 'ServiceHours', 'AcceptPreOrders', 'PreOrderMaxRangeDays', 'IsSamePreOrderAsServiceHours',
      'IsSameForAllDaysPreOrderScheduledHours', 'PreOrderScheduledHours', 'Settings', 'AllowPreorderStart', 'AllowPreorderEnd',
      'isVatIncluded', 'OrderLimit', 'Tags', 'IsCompliantShop', 'Curations', 'Cuisines', 'IsTemporaryUnavailable', 'TemporaryUnavailableStartTime',
      'TemporaryUnavailableEndTime', 'KeyAccountsManagerContactDetails', 'UpdatedByExternalUser'
    ];
  }

  getListFields(): string[] {
    return [
      'Name', 'LogoFileId', 'Contact', 'Affordability', 'DeliveryFee',
      'ShopStatus', 'Address', 'EmergencyContactDetails', 'ServiceHours',
      'Settings', 'UpdatedByExternalUser'
    ];
  }

  getNameFields(): string[] {
    return [
      'Name'
    ];
  }

  getPaymentMethodEntityName(): string {
    return 'PaymentMethods';
  }

  getPaymentMethodListFields(): string[] {
    return [
      'Name', 'IsDefault', 'IsActive'
    ];
  }
}
