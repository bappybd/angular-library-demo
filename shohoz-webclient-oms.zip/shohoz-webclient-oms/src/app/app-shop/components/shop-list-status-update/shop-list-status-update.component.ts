import {Component, ElementRef, Input, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {MatSlideToggle, MatSlideToggleChange} from '@angular/material/slide-toggle';
import {SetingsShopStatusUpdateModel, ShopDetails, ShopStatusUpdateModel} from '../../models/shop-models';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {MatDialog} from '@angular/material/dialog';
import {ShopStatusEnum} from '../../../shared/models/shop-entity-models';
import {ShopStatusUpdateCommand} from '../../models/shop-command';
import {ShopCommandService} from '../../services/shop-command.service';
import {ShopNotificationService} from '../../services/shop-notification.service';
import {SubSink} from 'subsink';
import {MatDialogRef} from '@angular/material/dialog/dialog-ref';
import {ShopListTemporaryUnavailableStatusUpdateDialogComponent} from '../shop-list-temporary-unavailable-status-update-dialog/shop-list-temporary-unavailable-status-update-dialog.component';

@Component({
  selector: 'app-shop-list-status-update',
  templateUrl: './shop-list-status-update.component.html',
  styleUrls: ['./shop-list-status-update.component.scss']
})
export class ShopListStatusUpdateComponent implements OnInit {
  @Input() set row(data: ShopDetails) {
    this.shopDetails = data;
    const {ShopStatus, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = this.shopDetails.Settings;
    this.setToggleState(
      ShopStatus,
      IsTemporaryUnavailable,
      TemporaryUnavailableStartTime,
      TemporaryUnavailableEndTime
    );
  }

  shopDetails: ShopDetails;
  subs = new SubSink();
  @ViewChild('toggleElement', {static: true}) toggleElement: MatSlideToggle;

  constructor(
    public fgs: FeatureGuardService,
    private dialog: MatDialog,
    private shopCommandService: ShopCommandService,
    private shopNotificationService: ShopNotificationService,
  ) {
  }

  ngOnInit(): void {

  }

  shopStatusUpdate(event: MatSlideToggleChange): void {
    let dialogRef: MatDialogRef<any>;
    // @ts-ignore
    if (this.fgs.isValidFeatureSync([{Key: 'shop.update.status.with-temporary-unavailable'}])) {
      dialogRef = this.dialog.open(ShopListTemporaryUnavailableStatusUpdateDialogComponent, {
        data: {
          title: 'Update Status',
          message: 'Set options to update status',
          buttonText: {
            ok: 'Update',
            cancel: 'Cancel'
          },
          shopDetails: this.shopDetails
        }
      });
    } else {
      dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        data: {
          title: 'Confirmation',
          message: 'Are you sure you want to update this shop status?',
          buttonText: {
            ok: 'Yes',
            cancel: 'Cancel'
          }
        }
      });
    }

    dialogRef.afterClosed().subscribe((data: any) => {
      if (data) {
        if (typeof data === 'boolean') {
          this.updateStatusForNoTemporaryUnavailableUI(event.checked);
        } else {
          this.updateStatusForTemporaryUnavailableUI(data);
        }
      } else {
        const {ShopStatus, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = this.shopDetails.Settings;
        this.setToggleState(
          ShopStatus,
          IsTemporaryUnavailable,
          TemporaryUnavailableStartTime,
          TemporaryUnavailableEndTime
        );
      }
    });
  }

  private updateStatusForNoTemporaryUnavailableUI(checked: boolean): void {
    const Settings: SetingsShopStatusUpdateModel = {
      ShopStatus: checked ? ShopStatusEnum.Live : ShopStatusEnum.Closed,
      IsTemporaryUnavailable: checked ? false : this.shopDetails.Settings.IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: this.shopDetails.Settings.TemporaryUnavailableStartTime || new Date(),
      TemporaryUnavailableEndTime: new Date(new Date(this.shopDetails.Settings.TemporaryUnavailableEndTime || null).setSeconds(59)),
    };
    this.doShopStatusUpdate(Settings, this.shopDetails);
  }

  private updateStatusForTemporaryUnavailableUI(data: any): void {
    const temporaryUnavailable = this.getTemporaryUnavailableData(data);
    const Settings = {
      ShopStatus: +data?.Status,
      IsTemporaryUnavailable: !!temporaryUnavailable?.IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: temporaryUnavailable?.TemporaryUnavailableStartTime || new Date(),
      TemporaryUnavailableEndTime: new Date(new Date(temporaryUnavailable?.TemporaryUnavailableEndTime || null).setSeconds(59)),
    };
    this.doShopStatusUpdate(Settings, this.shopDetails);
  }

  private getTemporaryUnavailableData({IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime}):
    { IsTemporaryUnavailable: boolean, TemporaryUnavailableStartTime: Date, TemporaryUnavailableEndTime: Date } | null {
    if (!IsTemporaryUnavailable || !TemporaryUnavailableStartTime || !TemporaryUnavailableEndTime) {
      return null;
    }
    if (new Date(TemporaryUnavailableStartTime) > new Date(TemporaryUnavailableEndTime)) {
      return null;
    }

    return {IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime};
  }

  private doShopStatusUpdate(Settings: any, shop: ShopDetails): void {
    const shopStatusUpdateModel: ShopStatusUpdateModel = {
      ShopId: shop.Id,
      Settings
    };

    this.setToggleState(
      Settings?.ShopStatus,
      Settings?.IsTemporaryUnavailable,
      Settings?.TemporaryUnavailableStartTime,
      Settings?.TemporaryUnavailableEndTime);

    const command = new ShopStatusUpdateCommand();
    command.Shops = [shopStatusUpdateModel];

    this.shopNotificationService.shopStatusUpdatedEvent();
    this.subs.sink = this.shopCommandService.shopStatusUpdate(command).subscribe(data => {
      this.shopDetails.Settings.ShopStatus = shopStatusUpdateModel.Settings.ShopStatus;
      this.shopDetails.Settings.IsTemporaryUnavailable = shopStatusUpdateModel.Settings.IsTemporaryUnavailable;
      this.shopDetails.Settings.TemporaryUnavailableStartTime = shopStatusUpdateModel.Settings.TemporaryUnavailableStartTime;
      this.shopDetails.Settings.TemporaryUnavailableEndTime = shopStatusUpdateModel.Settings.TemporaryUnavailableEndTime;
    }, error => {
      this.setToggleState(
        Settings?.ShopStatus,
        Settings?.IsTemporaryUnavailable,
        Settings?.TemporaryUnavailableStartTime,
        Settings?.TemporaryUnavailableEndTime);
    });
  }

  private setToggleState(
    status: number,
    IsTemporaryUnavailable: boolean,
    TemporaryUnavailableStartTime: Date,
    TemporaryUnavailableEndTime: Date): void {
    if (+status !== 1 || !IsTemporaryUnavailable) {
      this.toggleElement.checked = status === 1;
      return;
    }
    const startDate = new Date(TemporaryUnavailableStartTime);
    const endDate = new Date(TemporaryUnavailableEndTime);
    const currentDate = new Date();
    const toggleState = !(startDate <= currentDate && currentDate <= endDate);
    this.toggleElement.checked = toggleState;
  }
}
