import {Component, ElementRef, Inject, OnDestroy, OnInit, Renderer2, ViewChild} from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {ShopExportImportCommandService} from '../../services/shop-export-import-command.service';
import {SubSink} from 'subsink';
import {EevoNotifyService, NotifyType, UtilityService} from '@eevo/eevo-core';
import {ShopExportImportNotificationService} from '../../services/shop-export-import-notification.service';
import {filter, take} from 'rxjs/operators';
import {ShopExportImportQueryService} from '../../services/shop-export-import-query.service';
import {ShopListExportStates} from '../../models/shop-export-import-models';
import {ShopImportEntity} from '../../entities/shop-import-entity';
import {ShopExportEntity} from '../../entities/shop-export-entity';

@Component({
  selector: 'app-shop-export-import',
  templateUrl: './shop-export-import.component.html',
  styleUrls: ['./shop-export-import.component.scss']
})
export class ShopExportImportComponent implements OnInit, OnDestroy {
  @ViewChild('fileInput', {static: true}) fileInputElement: ElementRef;
  breadcrumbList: BreadcrumbModel[] = [];
  disableExportButton: boolean;
  browseBtnText = 'Browse File';
  menuFile: File;
  fileSelected: boolean;
  uploadfileId: string;
  exportFileId: string;
  lastPreparedSuccessExportFileKey: string;
  lastPreparedSuccessShopListDate: Date;
  private subs = new SubSink();

  constructor(
    private renderer: Renderer2,
    private shopExportImportCommandService: ShopExportImportCommandService,
    private utilityService: UtilityService,
    private shopExportImportNotificationService: ShopExportImportNotificationService,
    private eevoNotifyService: EevoNotifyService,
    private shopExportImportQueryService: ShopExportImportQueryService,
    private shopImportEntity: ShopImportEntity,
    private shopExportEntity: ShopExportEntity,
    @Inject('config') private config: any
  ) {
  }

  ngOnInit(): void {
    this.setBreadcrumbData();
    this.listenToShopExportEvents();
    this.getLastPreparedShopList();
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Shops',
      Path: ['/shop']
    });

    this.breadcrumbList.push({
      Text: 'Export/Import Shops',
      Path: null
    });
  }

  onFileChanged(): void {
    const file = this.fileInputElement.nativeElement.files[0];
    if (!file) {
      return;
    }
    this.menuFile = file;
    this.fileSelected = true;
    if (this.fileSelected) {
      const fileExtension = this.menuFile.name.split('.').pop();
      this.browseBtnText = this.menuFile.name.substring(0, 15) + '...' + '' + fileExtension;
    }
  }

  onBrowseFileClicked(): void {
    this.renderer.selectRootElement(this.fileInputElement.nativeElement).click();
  }

  onFileUpload(): void {
    this.shopExportImportNotificationService.fileCreated();
    this.subs.sink = this.shopExportImportNotificationService.onReceived()
      .pipe(
        filter(eventData => eventData.ActionName === this.shopImportEntity.Events.FileCreatedEvent
          && eventData?.Details?.FileUri?.FileId === this.uploadfileId),
        take(1)
      )
      .subscribe(eventData => {
        this.uploadFile(eventData);
      });
    this.eevoNotifyService.displayMessage('File upload request submitted!');
    this.uploadfileId = this.utilityService.getNewGuid();
    this.subs.sink = this.shopExportImportCommandService.createFile(this.uploadfileId).subscribe(response => {
    }, error => {
      console.log(error);
    });
  }

  uploadFile(eventData: any): void {
    this.eevoNotifyService.displayMessage('Please wait. Uploading the file...', NotifyType.Info);
    this.subs.sink = this.shopExportImportCommandService
      .uploadToPresignedURL(eventData?.Details?.UploadUri?.UploadUriWithSas, this.menuFile)
      .subscribe(response => {
        this.importShopList(eventData);
        this.eevoNotifyService.displayMessage('File uploaded successfully!', NotifyType.Success);
        this.browseBtnText = 'Browse File';
      });
  }

  importShopList(fileEventData: any): void {
    this.shopExportImportNotificationService.onReceived()
      .pipe(
        filter(event =>
          (event.ActionName === this.shopImportEntity.Events.ShopListImportSuccess)
          || (event.ActionName === this.shopImportEntity.Events.ShopListImportFailed)),
        take(1)
      ).subscribe(event => {
      switch (event.ActionName) {
        case this.shopImportEntity.Events.ShopListImportSuccess:
          this.eevoNotifyService.displayMessage('Shop import successfull!', NotifyType.Success);
          break;
        case this.shopImportEntity.Events.ShopListImportFailed:
          this.eevoNotifyService.displayMessage('Shop import failed!', NotifyType.Error);
          break;
      }
    });
    this.subs.sink = this.shopExportImportCommandService.importShopList(fileEventData?.Details?.FileId)
      .subscribe(response => {
          this.shopExportImportNotificationService.shopListImportSuccess();
          this.shopExportImportNotificationService.shopListImportFailed();
          this.fileSelected = false;
          this.menuFile = null;
        },
        error => {
          this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
          this.menuFile = null;
        });
  }

  listenToShopExportEvents(): void {
    this.shopExportImportNotificationService.shopListExportSuccess();
    this.shopExportImportNotificationService.shopListExportFailed();
    this.subs.sink = this.shopExportImportNotificationService.onReceived()
      .pipe(
        filter(eventData =>
          (eventData.ActionName === this.shopExportEntity.Events.ShopListExportSuccess)
          || (eventData.ActionName === this.shopExportEntity.Events.ShopListExportFailed)),
      )
      .subscribe(eventData => {
        switch (eventData.ActionName) {
          case this.shopExportEntity.Events.ShopListExportSuccess:
            this.eevoNotifyService.displayMessage('Shop Export Successful!', NotifyType.Success);
            this.fetchExportKey(eventData?.Details?.EntityId);
            break;
          case (this.shopExportEntity.Events.ShopListExportFailed):
            this.eevoNotifyService.displayMessage('Shop Export Failed!', NotifyType.Error);
            break;
        }
        this.disableExportButton = false;
      });
  }

  onExportShops(): void {
    this.disableExportButton = true;
    this.exportFileId = this.utilityService.getNewGuid();
    this.subs.sink = this.shopExportImportCommandService.prepareShopListForExport(this.exportFileId).subscribe(response => {
        this.eevoNotifyService.displayMessage('Please wait. Downloading the file...', NotifyType.Info);
        // this.shopExportImportNotificationService.shopListExportSuccess();
        // this.shopExportImportNotificationService.shopListExportFailed();
      },
      error => {
        console.log(error);
      });
  }

  private fetchExportKey(entityId: string): void {
    this.subs.sink = this.shopExportImportQueryService.fetchExportKey(entityId)
      .subscribe(res => {
        this.downloadFile(res.ExportFileKey);
        this.getLastPreparedShopList();
      });
  }

  getLastPreparedShopList(): void {
    this.subs.sink = this.shopExportImportQueryService
      .fetchLastPreparedShopListByStatus(ShopListExportStates.Success)
      .subscribe(response => {
        this.lastPreparedSuccessExportFileKey = response?.lastSuccessfulExport?.ExportFileKey;
        this.lastPreparedSuccessShopListDate = response?.lastSuccessfulExport?.CreatedDate;
        if (response.lastExport.Status === ShopListExportStates.WaitingForStorageUploadUrl ||
          response.lastExport.Status === ShopListExportStates.FileUploading) {
          this.disableExportButton = true;
        }
      });
  }

  onPreviousExportDownload(): void {
    this.downloadFile(this.lastPreparedSuccessExportFileKey);
  }

  downloadFile(exportFileKey: string): void {
    const downloadURL = this.config.FileUriPrefix + exportFileKey;
    window.open(downloadURL, '_blank');
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
