import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {AbstractControl, FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {SubSink} from 'subsink';

@Component({
  selector: 'app-date-time-field',
  templateUrl: './date-time-field.component.html',
  styleUrls: ['./date-time-field.component.scss']
})
export class DateTimeFieldComponent implements OnInit, OnDestroy {
  @Input() fieldControl: AbstractControl;
  @Input() minDate: Date;

  form: FormGroup;
  subs = new SubSink();

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      dateControl: [],
      timeControl: []
    });
  }

  ngOnInit(): void {
    this.setDateAndTimeValueFormDateData(this.fieldControl.value);
    this.setValueOnFormValueChange();
    this.onFormChangeSetControlValue();
    this.setValidatorsToForm();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  private setValueOnFormValueChange(): void {
    this.subs.sink = this.fieldControl.valueChanges.subscribe(value => {
      this.setDateAndTimeValueFormDateData(value);
    });
  }

  private setValidatorsToForm(): void {
    this.form.get('dateControl').setValidators(this.fieldControl.validator);
    this.form.get('timeControl').setValidators(this.fieldControl.validator);
  }

  private setDateAndTimeValueFormDateData(value: any): void {
    if (!value) {
      return;
    }
    const date = new Date(value);
    const hours = date.getHours().toLocaleString().padStart(2, '0');
    const minutes = date.getMinutes().toLocaleString().padStart(2, '0');
    const timeString = `${hours}:${minutes}`;
    this.form.get('dateControl').setValue(date, {emitEvent: false});
    this.form.get('timeControl').setValue(timeString, {emitEvent: false});
  }

  private onFormChangeSetControlValue(): void {
    this.subs.sink = this.form.valueChanges.subscribe(value => {
      try {
        const {dateControl, timeControl} = value;
        const date = new Date(dateControl.toISOString());
        if (timeControl) {
          const time = timeControl.split(':');
          date.setHours(+time[0]);
          date.setMinutes(+time[1]);
        }
        if (date < this.minDate) {
          throw new Error('Invalid date');
        }
        this.fieldControl.setValue(date);
      } catch (e) {
        this.fieldControl.setValue(null, {emitEvent: false});
      }
    });
  }
}
