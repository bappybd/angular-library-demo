import {Component, ElementRef, Inject, Input, OnDestroy, OnInit, Renderer2, ViewChild} from '@angular/core';
import {EevoFileUploadService, EevoNotifyService, NotifyType, UtilityService} from '@eevo/eevo-core';
import {ShopModel} from '../../../shared/models/shop-entity-models';
import {MenuFileUploadCommandService} from '../../services/menu-file-upload-command.service';
import {FileUploadNotificationService} from '../../services/file-upload-notification.service';
import {MenuFileQueryService} from '../../services/menu-file-query.service';
import {SubSink} from 'subsink';
import {MenuExportStates} from '../../models/menu-file-models';
import {filter, take} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {FileSaverService} from 'ngx-filesaver';

@Component({
  selector: 'app-menu-upload',
  templateUrl: './menu-upload.component.html',
  styleUrls: ['./menu-upload.component.scss']
})
export class MenuUploadComponent implements OnInit, OnDestroy {
  @Input()
  shop: ShopModel;
  @ViewChild('fileInput', {static: true}) fileInputElement: ElementRef;
  menuFile: File;
  fileSelected: boolean;
  uploadfileId: string;
  exportFileId: string;
  lastPreparedSuccessMenuDate: Date;
  lastPreparedSuccessExportFileKey: string;
  disableExportButton = true;
  browseBtnText = 'Browse File';
  private subs = new SubSink();

  constructor(
    private renderer: Renderer2,
    private eevoFileUploadService: EevoFileUploadService,
    private utilityService: UtilityService,
    private menuFileUploadCommandService: MenuFileUploadCommandService,
    private fileUploadNotificationService: FileUploadNotificationService,
    private eevoNotifyService: EevoNotifyService,
    private menuFileQueryService: MenuFileQueryService,
    private http: HttpClient,
    private fileSaverService: FileSaverService,
    @Inject('config') private config: any
  ) {
  }

  ngOnInit(): void {
    this.getLastPreparedMenuData();
    this.listenToFileUploadNotification();
  }

  onBrowseFileClicked(): void {
    this.renderer.selectRootElement(this.fileInputElement.nativeElement).click();
  }

  onFileChanged(): void {
    const file = this.fileInputElement.nativeElement.files[0];
    if (!file) {
      return;
    }
    this.menuFile = file;
    this.fileSelected = true;
    if (this.fileSelected) {
      const fileExtension = this.menuFile.name.split('.').pop();
      this.browseBtnText = this.menuFile.name.substring(0, 15) + '...' + '' + fileExtension;
    }
  }

  onFileUpload(): void {
    this.fileUploadNotificationService.fileCreated();
    this.subs.sink = this.fileUploadNotificationService.onReceived()
      .pipe(
        filter(eventData => eventData.ActionName === 'FileCreatedEvent' && eventData?.Details?.FileUri?.FileId === this.uploadfileId),
        take(1)
      )
      .subscribe(eventData => {
        this.uploadFile(eventData);
      });
    this.eevoNotifyService.displayMessage('File upload request submitted!');
    this.uploadfileId = this.utilityService.getNewGuid();
    this.subs.sink = this.menuFileUploadCommandService.createFile(this.uploadfileId, this.shop.ShopId).subscribe(response => {
    }, error => {
    });
  }

  onPreviousExportDownload(): void {
    this.downloadFile(this.lastPreparedSuccessExportFileKey);
  }

  getLastPreparedMenuData(): void {
    this.subs.sink = this.menuFileQueryService
      .fetchLastPreparedMenuDataByStatus(this.shop.ShopId, [null, MenuExportStates.Success])
      .subscribe(response => {
        this.disableExportButton = response[0] && ![MenuExportStates.Success, MenuExportStates.Failed].includes(response[0]?.Status);
        this.lastPreparedSuccessMenuDate = response[1]?.CreatedDate;
        this.lastPreparedSuccessExportFileKey = response[1]?.ExportFileKey;
      });
  }

  uploadFile(eventData: any): void {
    this.subs.sink = this.menuFileUploadCommandService
      .uploadToPresignedURL(eventData?.Details?.UploadUri?.UploadUriWithSas, this.menuFile)
      .subscribe(response => {
        // this.eevoNotifyService.displayMessage('File uploaded successfully!', NotifyType.Success);
        this.browseBtnText = 'Browse File';
        this.updateFileData(eventData);
      }, error => {
        this.eevoNotifyService.displayMessage('File upload failed!', NotifyType.Error);
      });
  }

  updateFileData(eventData: any): void {
    this.subs.sink = this.menuFileUploadCommandService.updateFileData(this.shop.ShopId, eventData?.Details?.FileId)
      .subscribe(response => {
          this.fileSelected = false;
          this.menuFile = null;
        },
        error => {
          this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
          this.menuFile = null;
        });
  }

  onExportMenu(): void {
    this.disableExportButton = true;
    this.fileUploadNotificationService.shopExportSuccess();
    this.subs.sink = this.fileUploadNotificationService.onReceived()
      .pipe(
        filter(eventData => eventData.ActionName === 'ShopExportSuccess' && eventData?.Details?.EntityId === this.exportFileId),
        take(1)
      )
      .subscribe(eventData => {
        this.fetchExportKey(eventData?.Details?.EntityId);
      });
    this.exportFileId = this.utilityService.getNewGuid();
    this.subs.sink = this.menuFileUploadCommandService.prepareMenu(this.exportFileId, this.shop.ShopId).subscribe(response => {
      },
      error => {
        this.disableExportButton = false;
      });
  }

  private fetchExportKey(entityId: string): void {
    this.subs.sink = this.menuFileQueryService.fetchExportKey(entityId)
      .subscribe(res => {
        this.downloadFile(res.ExportFileKey);
        this.getLastPreparedMenuData();
      });
  }

  downloadFile(exportFileKey: string): void {
    const downloadURL = this.config.FileUriPrefix + exportFileKey;
    window.open(downloadURL, '_blank');
  }

  // downloadFile(exportFileKey: string): void {
  //   const downloadURL = this.config.FileUriPrefix + exportFileKey;
  //   const fileName = exportFileKey.split('/').pop();
  //   this.http.get(downloadURL, {responseType: 'blob'})
  //     .pipe(take(1))
  //     .subscribe(res => {
  //       this.fileSaverService.save(res, fileName);
  //     });
  // }

  listenToFileUploadNotification(): void {
    this.fileUploadNotificationService.shopImportSuccess();
    this.fileUploadNotificationService.shopImportFailed();
    this.subs.sink = this.fileUploadNotificationService.onReceived().subscribe(eventData => {
      if (eventData.ActionName === 'ShopImportSuccess'){
        this.eevoNotifyService.displayMessage('Menu Imported Successfully!', NotifyType.Success);
      }
      if (eventData.ActionName === 'ShopImportFailed') {
        this.eevoNotifyService.displayMessage('Menu Import Failed!', NotifyType.Error);
      }
    });

  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
