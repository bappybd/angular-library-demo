import {Component, Inject, Input, OnDestroy, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormControl, FormGroup, Validators} from '@angular/forms';
import {MatCheckboxChange} from '@angular/material/checkbox';
import {EevoQueryService} from '@eevo/eevo-core';
import {ShopEntity} from '../../entities/shop-entity';
import {SubSink} from 'subsink';
import {EevoValidator} from '../../../shared/validator/eevo.validator';
import {ShopModel} from '../../../shared/models/shop-entity-models';

@Component({
  selector: 'app-shop-settings',
  templateUrl: './shop-settings.component.html',
  styleUrls: ['./shop-settings.component.scss']
})
export class ShopSettingsComponent implements OnInit, OnDestroy {
  @Input()
  parent: FormGroup;

  @Input()
  shopDetails?: ShopModel;

  isTagLineRequired = false;
  paymentMethodList: any[] = [];

  minimumProcessingTime = false;
  private subs = new SubSink();
  private valueChangeSubs = new SubSink();

  constructor(
    private shopEntity: ShopEntity,
    private eevoQueryService: EevoQueryService,
    @Inject('config') private config: any
  ) {
  }

  ngOnInit(): void {
    this.getPaymentMethods();
    this.setValidatorForMaxOrderValue();
    this.highlightTextChanged(true);
  }

  onStatusChange(value: number): void {
    if (value === 1) {
      return;
    }
    this.parent.get('Settings').get('IsTemporaryUnavailable').setValue(false);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  isCreditRestaurantChanged(event: MatCheckboxChange): void {
    if (event.checked) {
      const control = this.parent.get('Settings').get('IsPartialCreditRestaurant').setValue(false);
    }
    this.toggleRestaurantBankInfoForCreditShop(event);
  }

  isPartialCreditRestaurantChanged(event: MatCheckboxChange): void {
    if (event.checked) {
      const control = this.parent.get('Settings').get('IsCreditRestaurant').setValue(false);
    }
    this.toggleRestaurantBankInfoForCreditShop(event);
  }

  toggleRestaurantBankInfoForCreditShop(event: MatCheckboxChange): void {
    const control = this.parent.get('Settings').get('RestaurantBank');
    if (event && event.checked) {
      control.get('AccountName').setValidators([Validators.required]);
      control.get('AccountNumber').setValidators([Validators.required]);
      control.get('BankName').setValidators([Validators.required]);
      control.get('BranchName').setValidators([Validators.required]);
      control.get('RoutingNumber').setValidators([Validators.required]);
      control.updateValueAndValidity();
    } else {
      control.get('AccountName').clearValidators();
      control.get('AccountNumber').clearValidators();
      control.get('BankName').clearValidators();
      control.get('BranchName').clearValidators();
      control.get('RoutingNumber').clearValidators();

      control.get('AccountName').setErrors(null);
      control.get('AccountNumber').setErrors(null);
      control.get('BankName').setErrors(null);
      control.get('BranchName').setErrors(null);
      control.get('RoutingNumber').setErrors(null);
    }
  }

  onHomeCookChange(event: MatCheckboxChange): void {
    const control = this.parent.get('Settings').get('MinimumProcessingTime');

    if (event && event.checked) {
      //   Set Validators
      control.setValidators([Validators.required]);
      control.updateValueAndValidity();
    } else {
      //  Clear Validators
      control.clearValidators();

      //   Clear Errors
      control.setErrors(null);
    }
  }

  highlightTextChanged($event: any): void {
    const tagLineControl = this.parent.get('Settings').get('TagLine');
    const tagLineEndDateControl = this.parent.get('Settings').get('TagLineEndDate');
    const tagLineEndTimeControl = this.parent.get('Settings').get('TagLineEndTime');
    const tagLineStartDateControl = this.parent.get('Settings').get('TagLineStartDate');
    const tagLineStartTimeControl = this.parent.get('Settings').get('TagLineStartTime');

    const tagLineValue = tagLineControl.value;

    if (tagLineValue && tagLineValue !== '') {
      this.isTagLineRequired = true;
      //   Set Validators
      tagLineEndDateControl.setValidators([Validators.required]);
      tagLineEndDateControl.updateValueAndValidity();
      tagLineEndTimeControl.setValidators([Validators.required, EevoValidator.highlightTextDateTime('TagLineStartTime')]);
      tagLineEndTimeControl.updateValueAndValidity();
      tagLineStartDateControl.setValidators([Validators.required]);
      tagLineStartDateControl.updateValueAndValidity();
      tagLineStartTimeControl.setValidators([Validators.required]);
      tagLineStartTimeControl.updateValueAndValidity();

      this.valueChangeSubs.sink = tagLineEndDateControl.valueChanges.subscribe(value => {
        tagLineEndTimeControl.setValidators(EevoValidator.highlightTextDateTime('TagLineStartTime'));
        tagLineEndTimeControl.updateValueAndValidity();
      });

      this.valueChangeSubs.sink = tagLineStartTimeControl.valueChanges.subscribe(value => {
        tagLineEndTimeControl.setValidators(EevoValidator.highlightTextDateTime('TagLineStartTime'));
        tagLineEndTimeControl.updateValueAndValidity();
      });

    } else {
      this.isTagLineRequired = false;
      //  Clear Validators and Errors
      tagLineEndDateControl.clearValidators();
      tagLineEndDateControl.setErrors(null);
      tagLineEndTimeControl.clearValidators();
      tagLineEndTimeControl.setErrors(null);
      tagLineStartDateControl.clearValidators();
      tagLineStartDateControl.setErrors(null);
      tagLineStartTimeControl.clearValidators();
      tagLineStartTimeControl.setErrors(null);

      this.valueChangeSubs.unsubscribe();
    }

  }

  // onDeliveredByRestaurant(event: MatCheckboxChange): void {
  //   const control = this.parent.get('Settings').get('DeliveryFee');
  //
  //   if (event && event.checked) {
  //     //   Set Validators
  //     control.setValidators([Validators.required]);
  //     control.updateValueAndValidity();
  //   } else {
  //     //  Clear Validators
  //     control.clearValidators();
  //
  //     //   Clear Errors
  //     control.setErrors(null);
  //   }
  // }

  getPaymentMethods(): void {
    const url = this.config.AppConfigService.toQueryURL();
    this.eevoQueryService.getList<any>(
      url,
      this.shopEntity.getPaymentMethodEntityName(),
      this.shopEntity.getPaymentMethodListFields(),
      `{'IsActive' : true}`
    ).subscribe((dataList) => {
      if (dataList) {
        this.paymentMethodList = dataList;
        this.setPaymentMethodsFormData();
      }
    });
  }

  isPaymentMethodEmpty(): boolean {
    let paymentMethods = this.parent.get('Settings').get('PaymentMethods') as FormArray;
    const paymentMethodLists = paymentMethods.value;
    let isEmptyFlag = true;
    paymentMethodLists.forEach(data => {
      if (data !== false) {
        isEmptyFlag = false;
      }
    });
    return isEmptyFlag;
  }

  setPaymentMethodsFormData(): void {
    if (this.isPaymentMethodEmpty()) {
      let paymentMethodsForm = this.parent.get('Settings').get('PaymentMethods') as FormArray;
      const pmListLength = this.paymentMethodList.length;
      for (let i = 0; i < pmListLength; i++) {
        paymentMethodsForm.push(new FormControl(false));
      }
      for (let i = 0; i < pmListLength; i++) {
        if (this.paymentMethodList[i].IsDefault) {
          paymentMethodsForm.at(i).setValue({
            Id: this.paymentMethodList[i].Id,
            Name: this.paymentMethodList[i].Name
          });
        }
      }

      paymentMethodsForm.valueChanges.subscribe(checkbox => {
        paymentMethodsForm.setValue(
          paymentMethodsForm.value.map((value, i) => value ? {
            Id: this.paymentMethodList[i].Id,
            Name: this.paymentMethodList[i].Name
          } : false),
          {emitEvent: false}
        );
      });
    } else {
      let paymentMethods = this.parent.get('Settings').get('PaymentMethods') as FormArray;

      const pmsLen = paymentMethods.length;
      const pmListLen = this.paymentMethodList.length;

      for (let i = 0; i < pmListLen - pmsLen; i++) {
        paymentMethods.push(new FormControl(false));
      }

      const paymentMethodLists = paymentMethods.value;

      for (let i = 0; i < pmListLen; i++) {
        const spm = this.paymentMethodList[i];

        let flag = true;
        // tslint:disable-next-line:prefer-for-of
        for (let j = 0; j < paymentMethodLists.length; j++) {
          const pm = paymentMethodLists[j];
          if (pm.Id === spm.Id || pm._id === spm.Id) {
            flag = false;
            paymentMethods.at(i).setValue(pm);
            break;
          }
        }

        if (flag) {
          paymentMethods.at(i).setValue(false);
        }
      }

      // this.paymentMethodList.forEach(() => {
      //   paymentMethods.push(new FormControl(false));
      // });

      paymentMethods.valueChanges.subscribe(checkbox => {
        paymentMethods.setValue(
          paymentMethods.value.map((value, i) => value ? {
            Id: this.paymentMethodList[i].Id,
            Name: this.paymentMethodList[i].Name
          } : false),
          {emitEvent: false}
        );
      });
    }
  }

  private setValidatorForMaxOrderValue(): void {
    const minOrderValueControl = this.parent.get('Settings.MinimumOrderValue');
    const maxOrderValueControl = this.parent.get('Settings.MaximumOrderValue');
    maxOrderValueControl.setValidators([(control: AbstractControl) => EevoValidator
      .minByFieldNameOrZero('MinimumOrderValue')(control)]);

    this.subs.sink = minOrderValueControl.valueChanges.subscribe(value => {
      maxOrderValueControl.clearValidators();
      maxOrderValueControl.setValidators([(control: AbstractControl) => EevoValidator
        .minByFieldNameOrZero('MinimumOrderValue')(control)]);
      maxOrderValueControl.updateValueAndValidity();
    });
  }

  onEnableOrderCreationChange(event: MatCheckboxChange): void {
    const enableOrderCreationControl = this.parent.get('Settings').get('EnableOrderCreation');
    const shopCustomersDeliveryFeeControl = this.parent.get('Settings').get('ShopCustomersDeliveryFee');
    const shopOrdersCommissionControl = this.parent.get('Settings').get('ShopOrdersCommission');

    if (event && event.checked) {
      //   Set Validators
      enableOrderCreationControl.setValidators([Validators.required]);
      shopCustomersDeliveryFeeControl.setValidators([Validators.required]);
      shopOrdersCommissionControl.setValidators([Validators.required]);

      //  Update Value
      enableOrderCreationControl.updateValueAndValidity();
      shopCustomersDeliveryFeeControl.updateValueAndValidity();
      shopOrdersCommissionControl.updateValueAndValidity();
    } else {
      //  Clear Validators
      enableOrderCreationControl.clearValidators();
      shopCustomersDeliveryFeeControl.clearValidators();
      shopOrdersCommissionControl.clearValidators();

      //  Clear values
      shopOrdersCommissionControl.reset();
      shopCustomersDeliveryFeeControl.reset();

      //   Clear Errors
      enableOrderCreationControl.setErrors(null);
      shopCustomersDeliveryFeeControl.setErrors(null);
      shopOrdersCommissionControl.setErrors(null);
    }
  }

  updateValidationForOtherFields(event: MatCheckboxChange, fieldNames: string[], validatorNames: string[]): void {
    const fieldsToSetValidation: AbstractControl[] = fieldNames.map(fieldName => this.parent.get('Settings').get(fieldName));
    const validators = validatorNames.map(name => Validators[name]);
    if (event && event.checked) {
      //   Set Validators
      fieldsToSetValidation.forEach(field => {
        field.setValidators(validators);
        field.updateValueAndValidity();
      });
    } else {
      //  Clear Validators
      fieldsToSetValidation.forEach(field => {
        field.clearValidators();
        field.updateValueAndValidity();
        field.setErrors(null);
      });
    }
  }

}
