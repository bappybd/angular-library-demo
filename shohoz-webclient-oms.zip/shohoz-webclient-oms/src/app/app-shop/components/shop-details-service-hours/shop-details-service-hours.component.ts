import {Component, Input, OnInit} from '@angular/core';
import {ShopModel} from '../../../shared/models/shop-entity-models';
import {TimeModel} from '../../../shared/models/scheduled-hour-model';
import {DayOfWeek} from '../../../shared/enums/day-of-week.enum';

@Component({
  selector: 'app-shop-details-service-hours',
  templateUrl: './shop-details-service-hours.component.html',
  styleUrls: ['./shop-details-service-hours.component.scss']
})
export class ShopDetailsServiceHoursComponent implements OnInit {
  @Input() shopDetails: ShopModel;

  daysOfWeekEnum = DayOfWeek;

  constructor() {
  }

  ngOnInit(): void {
  }

  getTimeStringFromTimeModel(time: TimeModel): string {
    const hour = time.Hour % 12 === 0 ? 12 : time.Hour % 12;
    const minute = time.Minute;
    const meridiem = hour < 12 ? 'AM' : 'PM';

    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} ${meridiem}`;
  }
}
