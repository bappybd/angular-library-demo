import {Component, Input, OnInit} from '@angular/core';
import {FormArray, FormGroup} from '@angular/forms';
import {ShopAffordabilityEnum} from '../../../shared/models/shop-entity-models';
import {EevoBasicChipOptions} from '../../../shared/components/eevo-basic-chip-list/eevo-basic-chip-list.component';

@Component({
  selector: 'app-shop-details',
  templateUrl: './shop-details.component.html',
  styleUrls: ['./shop-details.component.scss']
})
export class ShopDetailsComponent implements OnInit {
  @Input()
  parent: FormGroup;

  affordabilityList: { value: ShopAffordabilityEnum; display: string }[] = [
    {
      display: '‎৳',
      value: ShopAffordabilityEnum.Affordable,
    },
    {
      display: '‎৳‎৳',
      value: ShopAffordabilityEnum.Moderate,
    },
    {
      display: '‎৳‎৳‎৳',
      value: ShopAffordabilityEnum.Expensive,
    },
  ];

  alternativeSearchTextOptions = {
    labelTxt : 'Alternative Search Text',
    suggestionEnable: true,
    suggestionList: [
      'Biryani', 'Burger', 'Pizza', 'Diet Food', 'Cake & Pastries', 'Kebab Thali', 'Snacks', 'Tea Time', 'Grocery', 'Chicken'
    ],
    formControlName: 'AlternativeSearchText'
  } as EevoBasicChipOptions;

  tagsOptions = {
    labelTxt : 'Tags',
    suggestionEnable: true,
    suggestionList: [
      'PopularRestaurants', 'HomeCook', 'Breakfast', 'SpecialLunch', 'SpicyBurger', 'MorokPolao'
    ],
    formControlName: 'Tags'
  } as EevoBasicChipOptions;

  cuisinesOptions = {
    labelTxt : 'Cuisines',
    suggestionEnable: false,
    suggestionList: [],
    formControlName: 'Cuisines'
  } as EevoBasicChipOptions;

  constructor() {
  }

  ngOnInit(): void {
  }

}
