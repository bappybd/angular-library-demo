import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {ScheduleHourOptions} from '../../../shared/components/schedule-hour/schedule-hour.options';
import {MatCheckboxChange} from '@angular/material/checkbox';
import {SubSink} from 'subsink';
import {merge} from 'rxjs';

@Component({
  selector: 'app-shop-service-hours',
  templateUrl: './shop-service-hours.component.html',
  styleUrls: ['./shop-service-hours.component.scss']
})
export class ShopServiceHoursComponent implements OnInit, OnDestroy {
  @Input()
  parent: FormGroup;

  subs = new SubSink();

  scheduleHourOptions = {
    sameForAllDaysRequired: true,
    atLeastOneDayRequired: true,
    allDaysLabelEnable: true,
    hourOverlapValidationRequired: true,
  } as ScheduleHourOptions;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.checkPreOrderDaySelectionValidation();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  // onHomeCookChange(event: MatCheckboxChange): void {
  //   const control = this.parent.get('Settings').get('MinimumProcessingTime');
  //
  //   if (event && event.checked) {
  //     //   Set Validators
  //     control.setValidators([Validators.required]);
  //     control.updateValueAndValidity();
  //   } else {
  //     //  Clear Validators
  //     control.clearValidators();
  //
  //     //   Clear Errors
  //     control.setErrors(null);
  //   }
  // }

  public setIsAcceptPreorder(event: MatCheckboxChange): void {
    if (!event.checked) {
      this.clearValidationForPreOrderTimeSelector();
    }
  }

  private clearIndividualDaysValidationForPreorder(): void {
    const operationHoursForDays = this.parent.get('PreOrderScheduledHours').get('ScheduledHours').get('WeekDays') as FormArray;
    for (let i = 0; i < operationHoursForDays.length; i++) {
      const operationHoursOfDay = operationHoursForDays.at(i).get('Hours') as FormArray;
      for (let j = 0; j < operationHoursOfDay.length; j++) {
        const operationHour = operationHoursOfDay.at(j) as FormControl;
        this.clearOperationHourValidator(operationHour);
      }
    }
    operationHoursForDays.clearValidators();
    operationHoursForDays.updateValueAndValidity();
  }

  private clearSameForAllDayValidationForPreorder(): void {
    const operationHoursForEveryDay = this.parent.get('PreOrderScheduledHours').get('ScheduledHours').get('SameForAllDays') as FormArray;
    for (let i = 0; i < operationHoursForEveryDay.length; i++) {
      const operationHour = operationHoursForEveryDay.at(i) as FormControl;
      this.clearOperationHourValidator(operationHour);
    }
  }

  private clearOperationHourValidator(operationHour: FormControl): void {
    const openingTime = operationHour.get('OpeningTime');
    openingTime.clearValidators();
    openingTime.setErrors(null);

    const closingTime = operationHour.get('ClosingTime');
    closingTime.clearValidators();
    closingTime.setErrors(null);
  }

  get isAcceptPreorder(): boolean {
    return this.parent.get('ServiceHours').get('IsAcceptPreorder').value;
  }

  get isSameAsStartingAndClosingTimes(): boolean {
    return this.parent.get('ServiceHours').get('IsSameAsStartingAndClosingTimes').value;
  }

  private checkPreOrderDaySelectionValidation(): void {
    const IsAcceptPreorder = this.parent.get('ServiceHours.IsAcceptPreorder');
    const MinOnePreOrderDaySelected = this.parent.get('ServiceHours.MinOnePreOrderDaySelected');
    const IsAllowPreorderForToday = this.parent.get('ServiceHours.IsAllowPreorderForToday');
    const IsAllowPreorderForTomorrow = this.parent.get('ServiceHours.IsAllowPreorderForTomorrow');

    if (IsAcceptPreorder.value) {
      MinOnePreOrderDaySelected.setValidators(Validators.required);
    }
    MinOnePreOrderDaySelected.setValue((IsAllowPreorderForToday.value || IsAllowPreorderForTomorrow.value) ? 'Selected' : null);
    MinOnePreOrderDaySelected.updateValueAndValidity();

    this.subs.sink = IsAcceptPreorder.valueChanges
      .subscribe(res => {
        if (res) {
          MinOnePreOrderDaySelected.setValidators(Validators.required);
        } else {
          MinOnePreOrderDaySelected.clearValidators();
        }
        MinOnePreOrderDaySelected.updateValueAndValidity();
      });

    this.subs.sink = merge(
      IsAllowPreorderForToday.valueChanges,
      IsAllowPreorderForTomorrow.valueChanges
    ).subscribe(res => {
      MinOnePreOrderDaySelected.setValue((IsAllowPreorderForToday.value || IsAllowPreorderForTomorrow.value) ? 'Selected' : null);
    });
  }

  onSameAsStartCloseTimeClick($event: MatCheckboxChange): void {
    if ($event.checked) {
      this.clearValidationForPreOrderTimeSelector();
    }
  }

  private clearValidationForPreOrderTimeSelector(): void {
    this.clearSameForAllDayValidationForPreorder();
    this.clearIndividualDaysValidationForPreorder();
  }
}
