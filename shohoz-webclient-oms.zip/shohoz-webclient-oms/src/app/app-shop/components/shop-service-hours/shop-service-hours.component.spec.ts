import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ShopServiceHoursComponent} from './shop-service-hours.component';

describe('ShopServiceHoursComponent', () => {
  let component: ShopServiceHoursComponent;
  let fixture: ComponentFixture<ShopServiceHoursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ShopServiceHoursComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShopServiceHoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
