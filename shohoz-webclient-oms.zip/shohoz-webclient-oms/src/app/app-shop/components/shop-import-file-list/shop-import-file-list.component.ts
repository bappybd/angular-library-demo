import {Component, Inject, OnDestroy, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {SubSink} from 'subsink';
import {FileSaverService} from 'ngx-filesaver';
import {HttpClient} from '@angular/common/http';
import {ColumnMode, TableColumn} from '@swimlane/ngx-datatable';
import {take} from 'rxjs/operators';
import {ShopExportImportQueryService} from '../../services/shop-export-import-query.service';
import {ShopExportImportNotificationService} from '../../services/shop-export-import-notification.service';
import {EevoNotifyService, NotifyType} from '@eevo/eevo-core';
import {ShopImportEntity} from '../../entities/shop-import-entity';
import {ShopExportEntity} from '../../entities/shop-export-entity';
import {InfoViewerDialogComponent} from "../../../shared/components/info-viewer-dialog/info-viewer-dialog.component";
import {MatDialog} from "@angular/material/dialog";

@Component({
  selector: 'app-shop-import-file-list',
  templateUrl: './shop-import-file-list.component.html',
  styleUrls: ['./shop-import-file-list.component.scss']
})
export class ShopImportFileListComponent implements OnInit, OnDestroy {

  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('dateCell', {static: true}) dateCellTemplate: TemplateRef<any>;
  @ViewChild('uploadedByCell', {static: true}) uploadedByCellTemplate: TemplateRef<any>;
  @ViewChild('statusCell', {static: true}) statusCellTemplate: TemplateRef<any>;
  @ViewChild('errorCell', {static: true}) errorCellTemplate: TemplateRef<any>;
  @ViewChild('uploadedFileCell', {static: true}) uploadedFileCellTemplate: TemplateRef<any>;
  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;

  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  fileURLprefix: string;
  private subs = new SubSink();
  ImportLogStatus = {
    0: 'Import Initiated',
    1: 'File Downloading',
    2: 'Success',
    3: 'Failed'
  };

  constructor(
    private shopExportImportQueryService: ShopExportImportQueryService,
    private shopExportImportNotificationService: ShopExportImportNotificationService,
    private http: HttpClient,
    private fileSaverService: FileSaverService,
    private eevoNotifyService: EevoNotifyService,
    private shopImportEntity: ShopImportEntity,
    private shopExportEntity: ShopExportEntity,
    private dialog: MatDialog,
    @Inject('config') private config: any
  ) {
  }

  ngOnInit(): void {
    this.listenToShopListEvents();
    this.prepareDataTable();
    this.fileURLprefix = this.config.FileUriPrefix;
  }

  listenToShopListEvents(): void {
    this.shopExportImportNotificationService.shopListImportSuccess();
    this.shopExportImportNotificationService.shopListImportFailed();
    this.subs.sink = this.shopExportImportNotificationService.onReceived()
      .subscribe(eventData => {
        if (eventData.ActionName === this.shopImportEntity.Events.ShopListImportSuccess
          || eventData.ActionName === this.shopImportEntity.Events.ShopListImportFailed) {
          this.getShopFileList();
        }
      });
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'CreatedDate',
          name: 'Date',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.dateCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'InitiatedUserName',
          name: 'Uploaded By',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.uploadedByCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'ImportFileKey',
          name: 'Uploaded File',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.uploadedFileCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'Status',
          name: 'Status',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.statusCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'Error',
          name: 'Error Log',
          flexGrow: 1.5,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.errorCellTemplate,
          draggable: false,
          sortable: false,
        }
      ] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.initDataTable();
  }

  getShopFileList(): void {
    this.subs.sink = this.shopExportImportQueryService.fetchShopImportFileList(this.datatableModel).subscribe(response => {
      this.datatableModel = {
        PageSize: this.datatableModel.PageSize,
        TotalElements: response.totalCount,
        CurrentPageNumber: this.datatableModel.CurrentPageNumber,
        SortBy: this.datatableModel.SortBy,
        Descending: this.datatableModel.Descending,
        Data: response.data,
        ColumnMode: ColumnMode.flex
      };
    });
  }

  private initDataTable(): void {
    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getShopFileList();
  }

  selectData($event: any): void {

  }

  downLoadFile(row): void {
    const downloadURL = this.config.FileUriPrefix + row?.ImportFileKey;
    const fileName = row?.ImportFileKey.split('/').pop();
    this.http.get(downloadURL, {responseType: 'blob'})
      .pipe(take(1))
      .subscribe(res => {
          this.fileSaverService.save(res, fileName);
          this.eevoNotifyService.displayMessage('File download successful!', NotifyType.Success);
        },
        error => {
          this.eevoNotifyService.displayMessage('The file couldn\'t be downloaded!', NotifyType.Error);
        });
  }

  viewCompleteErrorMessage(errorMessage: any): void {
    this.dialog.open(InfoViewerDialogComponent, {
      data: errorMessage
    });
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

}
