import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {ShopFilter} from '../../models/shop-models';
import {debounceTime, distinctUntilChanged, map, startWith} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {ZoneService} from '@eevo/eevo-core';

@Component({
  selector: 'app-shop-filter',
  templateUrl: './shop-filter.component.html',
  styleUrls: ['./shop-filter.component.scss']
})
export class ShopFilterComponent implements OnInit {
  @Output() getDataOnSubmit: EventEmitter<any> = new EventEmitter();
  searchClicked = false;
  zoneList: any[] = [];
  filteredZoneList: Observable<any[]>;
  shopFilterForm: FormGroup;

  shopFilter: ShopFilter = {
    affordability: '',
    searchKey: '',
    status: '',
    zone: null,
    availability: null
  };

  constructor(
    private zoneService: ZoneService,
    private formBuilder: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.initShopFilterForm();
    this.loadZoneList();
    this.onShopFilterChanges();
  }

  initShopFilterForm(): void {
    this.shopFilterForm = this.formBuilder.group({
      searchKey: [''],
      zone: [''],
      affordability: [''],
      status: [''],
      availability: ['']
    });
  }

  onShopFilterChanges(): void {
    this.shopFilterForm.get('searchKey').valueChanges
      .pipe(
        debounceTime(600),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.shopFilter.searchKey = value;
        this.getDataOnSubmit.emit(this.shopFilter);
      });
  }

  private setFilteredZones(): void {
    this.filteredZoneList = this.shopFilterForm.get('zone').valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this.zoneFilter(name) : this.zoneList.slice())
      );
  }

  loadZoneList(): void {
    this.zoneService.getFoodZones().subscribe((response) => {
      this.zoneList = response.data;
      this.setFilteredZones();
    });
  }

  zoneOptionSelected($event): void {
    this.shopFilter.zone = $event.option.value;
    this.getDataOnSubmit.emit(this.shopFilter);
  }

  zoneOptionDeselected(): void {
    this.shopFilterForm.get('zone').setValue('');
    this.shopFilter.zone = null;
    this.getDataOnSubmit.emit(this.shopFilter);

  }

  private zoneFilter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.zoneList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  zoneDisplayFn(data: any): string {
    return data && data.name ? data.name : '';
  }

  onSearchClose(): void {
    this.searchClicked = false;
    this.shopFilterForm.get('searchKey').reset();
    this.shopFilter.searchKey = '';
    this.getDataOnSubmit.emit(this.shopFilter);
  }

  onSearchSubmit(): void {
    this.searchClicked = true;
    this.shopFilter = this.shopFilterForm.get('searchKey').value;
    this.getDataOnSubmit.emit(this.shopFilter);
  }

  affordabilityChanged(event: any): void {
    this.shopFilter.affordability = this.shopFilterForm.get('affordability').value;
    this.getDataOnSubmit.emit(this.shopFilter);
  }

  statusChanged(event: any): void {
    this.shopFilter.status = this.shopFilterForm.get('status').value;
    this.getDataOnSubmit.emit(this.shopFilter);
  }
  availabilityChanged(event: any): void {
    this.shopFilter.availability = this.shopFilterForm.get('availability').value;
    this.getDataOnSubmit.emit(this.shopFilter);
  }
}
