import {AfterViewInit, Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormGroup, ValidatorFn, Validators} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {ZoneService} from '@eevo/eevo-core';
import {EevoValidator} from '../../../shared/validator/eevo.validator';

// function dataSelectedValidator(): ValidatorFn {
//   return (control: AbstractControl): { [key: string]: any } | null => {
//     if (control.value !== '' && typeof control.value === 'string') {
//       return {
//         invalidDataSelected: {
//           value: control.value
//         }
//       };
//     }
//     return null;
//   };
// }

@Component({
  selector: 'app-shop-address',
  templateUrl: './shop-address.component.html',
  styleUrls: ['./shop-address.component.scss']
})
export class ShopAddressComponent implements OnInit, AfterViewInit {
  @Input()
  parent: FormGroup;

  zoneList: any[] = [];
  filteredZoneList: Observable<any[]>;

  subzoneList: any[] = [];
  filteredSubzoneList: Observable<any[]>;

  private selectedZone;

  constructor(private zoneService: ZoneService) {
  }

  ngOnInit(): void {
    this.disableSubZoneAtFirst();
  }

  disableSubZoneAtFirst(): void {
    if (this.parent.get('Address').get('Zone').value === "") {
      this.parent.get('Address').get('SubZone').disable();
    }
  }

  ngAfterViewInit(): void {
    this.loadZoneList();
  }

  setZoneValue(): void {
    const zoneData = this.parent.get('Address').get('Zone').value;

    let zoneId = '';
    if (zoneData && zoneData.Id) {
      zoneId = zoneData.Id;
    } else if (zoneData && zoneData._id) {
      zoneId = zoneData._id;
    }

    if (zoneId !== '') {
      const zone = this.zoneList.find(z => z.id === zoneId);

      if (zone) {
        this.parent.get('Address').get('Zone').setValue(zone);

        const subZoneData = this.parent.get('Address').get('SubZone').value;

        let subZoneId = '';
        if (subZoneData && subZoneData.Id) {
          subZoneId = subZoneData.Id;
        } else if (subZoneData && subZoneData._id) {
          subZoneId = subZoneData._id;
        }

        this.subzoneList = zone.restaurants;
        this.setSubZoneFiltered();

        if (subZoneId !== '') {
          const subzone = this.subzoneList.find(sz => sz.id === subZoneId);

          if (subzone) {
            this.parent.get('Address').get('SubZone').setValue(subzone);
          }
        }
      }
    }
  }

  loadZoneList(): void {
    this.zoneService.getFoodZones().subscribe((response) => {
      this.zoneList = response.data;
      this.setFilteredZones();
      this.setZoneValidation();
      this.setZoneValue();
    });
  }

  zoneDisplayFn(data: any): string {
    return data && data.name ? data.name : '';
  }

  zoneOptionSelected($event): void {
    const zone = $event.option.value;

    this.subzoneList = zone.restaurants;

    if (zone != this.selectedZone) {
      this.selectedZone = zone;
      this.parent.get('Address').get('SubZone').setValue('');
      if (this.subzoneList.length < 1) {
        this.parent.get('Address').get('SubZone').disable();
      } else {
        this.parent.get('Address').get('SubZone').enable();
      }
    }

    this.setSubZoneFiltered();
  }

  private setSubZoneFiltered(): void {
    this.setSubzoneValidation();

    this.filteredSubzoneList = this.parent.get('Address').get('SubZone').valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this.subzoneFilter(name) : this.subzoneList.slice())
      );
  }

  private setFilteredZones(): void {
    this.filteredZoneList = this.parent.get('Address').get('Zone').valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this.zoneFilter(name) : this.zoneList.slice())
      );
  }

  private zoneFilter(value: string): any[] {
    const filterValue = value.toLowerCase();

    return this.zoneList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  private setZoneValidation(): void {
    const control = this.parent.get('Address').get('Zone');

    if (this.zoneList && this.zoneList.length) {
      //   Set Validators
      control.setValidators([Validators.required, EevoValidator.dataSelectedValidator()]);
      control.updateValueAndValidity();
    } else {
      //  Clear Validators
      control.clearValidators();

      //   Clear Errors
      control.setErrors(null);
    }
  }

  private subzoneFilter(value: string): any[] {
    const filterValue = value.toLowerCase();

    return this.subzoneList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  private setSubzoneValidation(): void {
    const control = this.parent.get('Address').get('SubZone');

    if (this.subzoneList && this.subzoneList.length) {
      //   Set Validators
      control.setValidators([EevoValidator.dataSelectedValidator()]);
      control.updateValueAndValidity();
    } else {
      //  Clear Validators
      control.clearValidators();

      //   Clear Errors
      control.setErrors(null);
    }
  }

}
