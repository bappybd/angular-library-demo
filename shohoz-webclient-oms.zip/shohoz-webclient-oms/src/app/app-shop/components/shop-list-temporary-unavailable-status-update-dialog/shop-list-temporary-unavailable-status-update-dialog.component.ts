import {AfterViewInit, Component, Inject, OnInit, ViewChild} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {ShopDetails} from '../../models/shop-models';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatCheckboxChange} from '@angular/material/checkbox';

export interface StatusUpdateDialogModel {
  title: string;
  message: string;
  buttonText: {
    ok: string;
    cancel: string;
  };
  shopDetails: ShopDetails;
}

@Component({
  selector: 'app-shop-list-temporary-unavailable-status-update-dialog',
  templateUrl: './shop-list-temporary-unavailable-status-update-dialog.component.html',
  styleUrls: ['./shop-list-temporary-unavailable-status-update-dialog.component.scss']
})
export class ShopListTemporaryUnavailableStatusUpdateDialogComponent implements AfterViewInit {
  title = '';
  message = 'Update status?';
  confirmButtonText = 'Yes';
  cancelButtonText = 'Cancel';
  updateStatusForm: FormGroup;

  @ViewChild('messageElement', {static: true}) messageElement;

  constructor(
    private sanitizer: DomSanitizer,
    @Inject(MAT_DIALOG_DATA) public data: StatusUpdateDialogModel,
    private dialogRef: MatDialogRef<ShopListTemporaryUnavailableStatusUpdateDialogComponent>,
    private fb: FormBuilder
  ) {
    if (data) {
      this.title = data.title || this.title;
      this.message = data.message || this.message;
      if (data.buttonText) {
        this.confirmButtonText = data.buttonText.ok || this.confirmButtonText;
        this.cancelButtonText = data.buttonText.cancel || this.cancelButtonText;
      }
    }
    this.buildForm(this.data.shopDetails);
  }

  onConfirmClick(): void {
    const formData = this.updateStatusForm.value;
    this.dialogRef.close(formData);
  }

  ngAfterViewInit(): void {
    this.messageElement.nativeElement.innerHTML = this.message;
  }

  private buildForm(shopDetails: ShopDetails): void {
    this.updateStatusForm = this.fb.group({
      Status: [shopDetails.Settings.ShopStatus],
      IsTemporaryUnavailable: [shopDetails.Settings.IsTemporaryUnavailable],
      TemporaryUnavailableStartTime: [new Date()],
      TemporaryUnavailableEndTime: shopDetails.Settings.IsTemporaryUnavailable ?
        [shopDetails.Settings.TemporaryUnavailableEndTime, Validators.required] : [this.getTodayMidnightDate()]
    });
  }

  private getTodayMidnightDate(): Date {
    const date = new Date();
    date.setHours(23, 59, 59, 999);
    return date;
  }

  updateValidationForOtherFields(event: MatCheckboxChange, fieldNames: string[], validatorNames: string[]): void {
    const fieldsToSetValidation: AbstractControl[] = fieldNames.map(fieldName => this.updateStatusForm.get(fieldName));
    const validators = validatorNames.map(name => Validators[name]);
    if (event && event.checked) {
      //   Set Validators
      fieldsToSetValidation.forEach(field => {
        field.setValidators(validators);
        field.updateValueAndValidity();
      });
    } else {
      //  Clear Validators
      fieldsToSetValidation.forEach(field => {
        field.clearValidators();
        field.updateValueAndValidity();
        field.setErrors(null);
      });
    }
  }

  onStatusChange(value: number): void {
    if (value === 1) {
      return;
    }
    this.updateStatusForm.get('IsTemporaryUnavailable').setValue(false);
  }
}
