import {Component, Inject, Input, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation} from '@angular/core';
import {ColumnMode, TableColumn} from '@swimlane/ngx-datatable';
import {MenuFileQueryService} from '../../services/menu-file-query.service';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {FileUploadNotificationService} from '../../services/file-upload-notification.service';
import {SubSink} from 'subsink';
import {ShopModel} from '../../../shared/models/shop-entity-models';
import {FileSaverService} from 'ngx-filesaver';
import {HttpClient} from '@angular/common/http';
import {take} from 'rxjs/operators';
import {MatDialog} from "@angular/material/dialog";
import {InfoViewerDialogComponent} from "../../../shared/components/info-viewer-dialog/info-viewer-dialog.component";

@Component({
  selector: 'app-menu-file-list',
  templateUrl: './menu-file-list.component.html',
  styleUrls: ['./menu-file-list.component.scss'],
})
export class MenuFileListComponent implements OnInit, OnDestroy {
  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('dateCell', {static: true}) dateCellTemplate: TemplateRef<any>;
  @ViewChild('uploadedByCell', {static: true}) uploadedByCellTemplate: TemplateRef<any>;
  @ViewChild('statusCell', {static: true}) statusCellTemplate: TemplateRef<any>;
  @ViewChild('errorCell', {static: true}) errorCellTemplate: TemplateRef<any>;
  @ViewChild('uploadedFileCell', {static: true}) uploadedFileCellTemplate: TemplateRef<any>;
  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  @Input()
  shopInfo: ShopModel;
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  fileURLprefix: string;
  private subs = new SubSink();
  ImportLogStatus = {
    0: 'Import Initiated',
    1: 'File Downloading',
    2: 'Success',
    3: 'Failed'
  };
  constructor(
    private menuFileQueryService: MenuFileQueryService,
    private fileUploadNotificationService: FileUploadNotificationService,
    private fileSaverService: FileSaverService,
    private http: HttpClient,
    private dialog: MatDialog,
    @Inject('config') private config: any
  ) { }

  ngOnInit(): void {
    this.prepareDataTable();
    this.fileURLprefix = this.config.FileUriPrefix;
    this.fileUploadNotificationService.shopImportSuccess();
    this.fileUploadNotificationService.shopImportFailed();
    this.subs.sink = this.fileUploadNotificationService.onReceived().subscribe(eventData => {
      if (eventData.ActionName === 'ShopImportSuccess' || eventData.ActionName === 'ShopImportFailed') {
        this.getMenuFileList();
      }
    });
}

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'CreatedDate',
          name: 'Date',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.dateCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'InitiatedUserName',
          name: 'Uploaded By',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.uploadedByCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'ImportFileKey',
          name: 'Uploaded File',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.uploadedFileCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'Status',
          name: 'Status',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.statusCellTemplate,
          draggable: false,
          sortable: false,
        },
        {
          prop: 'Error',
          name: 'Error Log',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.errorCellTemplate,
          draggable: false,
          sortable: false,
        }
      ] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.initDataTable();
  }

  getMenuFileList(): void {
    this.subs.sink = this.menuFileQueryService.fetchMenuFileList(this.datatableModel, this.shopInfo.ShopId).subscribe(response => {
      this.datatableModel = {
        PageSize: this.datatableModel.PageSize,
        TotalElements: response.totalCount,
        CurrentPageNumber: this.datatableModel.CurrentPageNumber,
        SortBy: this.datatableModel.SortBy,
        Descending: this.datatableModel.Descending,
        Data: response.data,
        ColumnMode: ColumnMode.flex
      };
    });
  }

  private initDataTable(): void {
    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getMenuFileList();
  }

  selectData($event: any): void {

  }

  downLoadFile(row): void {
    const downloadURL = this.config.FileUriPrefix + row?.ImportFileKey;
    const fileName = row?.ImportFileKey.split('/').pop();
    this.http.get(downloadURL, {responseType: 'blob'})
      .pipe(take(1))
      .subscribe(res => {
      this.fileSaverService.save(res, fileName);
    });
  }

  viewCompleteErrorMessage(errorMessage: any): void {
    console.log(errorMessage);
    const dialogRef = this.dialog.open(InfoViewerDialogComponent, {
      data: errorMessage
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
      } else {
      }
    });
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
