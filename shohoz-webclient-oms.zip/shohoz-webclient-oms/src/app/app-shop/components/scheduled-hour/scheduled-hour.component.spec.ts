import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ScheduledHourComponent} from './scheduled-hour.component';

describe('ScheduledHourComponent', () => {
  let component: ScheduledHourComponent;
  let fixture: ComponentFixture<ScheduledHourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ScheduledHourComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduledHourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
