import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormBuilder, FormGroup, Validators} from "@angular/forms";
import {DayOfWeek} from '../../../shared/enums/day-of-week.enum';
import {MatCheckboxChange} from "@angular/material/checkbox";

@Component({
  selector: 'app-scheduled-hour',
  templateUrl: './scheduled-hour.component.html',
  styleUrls: ['./scheduled-hour.component.scss']
})
export class ScheduledHourComponent implements OnInit {
  @Input()
  parent: FormGroup;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
  }


  //--------------------------------------------------------------
  // @ Public Methods
  //--------------------------------------------------------------

  getNameOfWeekDay(enumValue): string {
    return DayOfWeek[enumValue];
  }

  /**
   * Every Day Time Slot gettes
   */

  get allDaysServicesHours(): AbstractControl[] {
    return (this.parent.get('ScheduledHours').get('SameForAllDays') as FormArray)
      .controls;
  }

  get isSameForAllDays(): boolean {
    return this.parent.get('ScheduledHours').get('IsSameForAllDaysServiceHours')
      .value;
  }

  get eachDaysServicesHours(): AbstractControl[] {
    return (this.parent.get('ScheduledHours').get('WeekDays') as FormArray).controls;
  }

  weekDayServicesHours(index): AbstractControl[] {
    const weekDays = (this.parent.get('ScheduledHours').get('WeekDays') as FormArray);

    const data = (weekDays.at(index).get('Hours') as FormArray).controls;

    return data;
  }

  get numberOfSlot(): number {
    const {length} = this.allDaysServicesHours;
    return length;
  }

  addControl(variation: string, dayIndex?: number): void {
    switch (variation) {
      case 'EveryDayVariation':
        this.addTimeSlot('SameForAllDays');
        break;
      case 'EachDayVariation':
        this.addTimeSlot('WeekDays', dayIndex);
    }
  }

  addTimeSlot(control: string, day?: number): void {
    const SERVICE_HOURS = this.parent.get('ScheduledHours') as FormGroup;

    if (day !== undefined && !!String(day)) {
      (SERVICE_HOURS.get(control).get('' + day).get('Hours') as FormArray).push(
        this.createTimeSlot()
      );
    } else {
      (SERVICE_HOURS.get(control) as FormArray).push(this.createTimeSlot());
    }
  }

  createTimeSlot(): FormGroup {
    return this.fb.group({
      OpeningTime: ['', Validators.required],
      ClosingTime: ['', Validators.required],
    });
  }

  removeControl(index: number): void {
    (this.parent
      .get('ScheduledHours')
      .get('SameForAllDays') as FormArray).removeAt(index); // this.numberOfSlot - 1
  }

  removeEachDayControl(parentIndex: number, selfIndex: number): void {
    (this.parent
      .get('ScheduledHours')
      .get('WeekDays')
      .get('' + parentIndex).get('Hours') as FormArray).removeAt(selfIndex);
  }

  onIsSameForAllDaysServiceHoursChange(event: MatCheckboxChange): void {
    const control = this.parent.get('ScheduledHours').get('IsSameForAllDaysServiceHours');
    if (event && event.checked) {
      control.setValidators([Validators.required]);
      control.updateValueAndValidity();
    } else {
      control.clearValidators();
      control.setErrors(null);
    }
  }
}
