import {Component, Input, OnInit} from '@angular/core';
import {ShopModel} from '../../../shared/models/shop-entity-models';

@Component({
  selector: 'app-shop-details-basic-info',
  templateUrl: './app-shop-details-basic-info.component.html',
  styleUrls: ['./app-shop-details-basic-info.component.scss']
})
export class AppShopDetailsBasicInfoComponent implements OnInit {
  @Input() shopDetails: ShopModel;

  constructor() {
  }

  ngOnInit(): void {
  }

}
