import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';

@Component({
  selector: 'app-shop-contact',
  templateUrl: './shop-contact.component.html',
  styleUrls: ['./shop-contact.component.scss']
})
export class ShopContactComponent implements OnInit {
  @Input()
  parent: FormGroup;

  constructor() {
  }

  ngOnInit(): void {
  }

}
