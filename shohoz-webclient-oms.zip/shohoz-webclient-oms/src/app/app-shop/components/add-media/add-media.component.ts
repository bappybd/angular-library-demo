import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {EevoStorageService, FilesModel, UtilityService} from '@eevo/eevo-core';
import * as _ from 'lodash';
import {ShopModel} from '../../../shared/models/shop-entity-models';
import {ShopEntity} from '../../entities/shop-entity';

@Component({
  selector: 'app-add-media',
  templateUrl: './add-media.component.html',
  styleUrls: ['./add-media.component.scss']
})
export class AddMediaComponent implements OnInit {

  @Input()
  parent: FilesModel;

  @Input()
  shop: ShopModel;

  fileInfo: any[];
  highlightedImageUrl: string;
  listImageUrl: string;
  bannerImageUrl: string;
  logoImageUrl: string;

  imageUploaderConfig = {
    thumbnailHeight: 192,
    thumbnailWidth: 200,
    showUploadButton: true,
    // defaultImage: '../../../../../assets/images/no_Image.svg',
    profileImage: false,
    allowedImageTypes: ['png'],
    maxImageSize: 5, // Megabyte,
    textBrowseFile: 'Drop your logo image here, or browse',
    subTextBrowseFile: 'Supports PNG (70*70)',
    uploadIconName: 'insert_photo',
    hideNotFoundError: true
  };

  imageBannerUploaderConfig = _.cloneDeep(this.imageUploaderConfig);
  imageListImageUploaderConfig = _.cloneDeep(this.imageUploaderConfig);
  imageHighlightedImageUploaderConfig = _.cloneDeep(this.imageUploaderConfig);

  constructor(
    private utilityService: UtilityService,
    private shopEntity: ShopEntity,
    private storageService: EevoStorageService
  ) {
    this.imageBannerUploaderConfig.subTextBrowseFile = 'Supports PNG (360*188)';
    this.imageListImageUploaderConfig.subTextBrowseFile = 'Supports PNG (105*105)';
    this.imageHighlightedImageUploaderConfig.subTextBrowseFile = 'Supports PNG (147*105)';
  }

  ngOnInit(): void {
    if (this.shop && this.shop.Id) {
      this.highlightedImageUrl = this.storageService.getFileUrl(
        this.shopEntity.getFileKey(this.shop.Id, this.shopEntity.ImageType.HighlightedImage)) + '?t=' + new Date().getMilliseconds();
      this.listImageUrl = this.storageService.getFileUrl(
        this.shopEntity.getFileKey(this.shop.Id, this.shopEntity.ImageType.ListImage)) + '?t=' + new Date().getMilliseconds();
      this.bannerImageUrl = this.storageService.getFileUrl(
        this.shopEntity.getFileKey(this.shop.Id, this.shopEntity.ImageType.Banner)) + '?t=' + new Date().getMilliseconds();
      this.logoImageUrl = this.storageService.getFileUrl(
        this.shopEntity.getFileKey(this.shop.Id, this.shopEntity.ImageType.Logo)) + '?t=' + new Date().getMilliseconds();
    }
  }

  onLogoFilesChanged(event): void {
    // if (typeof event === 'boolean') {
    this.parent.Files = this.parent.Files.filter(item => {
      return item.Type !== this.shopEntity.ImageType.Logo;
    });
    // }

    this.parent.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.shopEntity.ImageType.Logo
    });
  }

  onBannerFilesChanged(event): void {
    // if (typeof event === 'boolean') {
    this.parent.Files = this.parent.Files.filter(item => {
      return item.Type !== this.shopEntity.ImageType.Banner;
    });
    // }

    this.parent.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.shopEntity.ImageType.Banner
    });
  }

  onListImageFilesChanged(event): void {
    // if (typeof event === 'boolean') {
    this.parent.Files = this.parent.Files.filter(item => {
      return item.Type !== this.shopEntity.ImageType.ListImage;
    });
    // }

    this.parent.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.shopEntity.ImageType.ListImage
    });
  }

  onHighlightedImageFilesChanged(event): void {
    // if (typeof event === 'boolean') {
    this.parent.Files = this.parent.Files.filter(item => {
      return item.Type !== this.shopEntity.ImageType.HighlightedImage;
    });
    // }

    this.parent.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.shopEntity.ImageType.HighlightedImage
    });
  }
}
