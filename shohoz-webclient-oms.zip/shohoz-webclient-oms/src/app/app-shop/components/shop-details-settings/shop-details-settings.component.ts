import {Component, Input, OnInit} from '@angular/core';
import {ShopModel} from '../../../shared/models/shop-entity-models';

@Component({
  selector: 'app-shop-details-settings',
  templateUrl: './shop-details-settings.component.html',
  styleUrls: ['./shop-details-settings.component.scss']
})
export class ShopDetailsSettingsComponent implements OnInit {
  @Input() shopDetails: ShopModel;

  constructor() {
  }

  ngOnInit(): void {
  }

}
