import {AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {forkJoin, Subject, Subscription} from 'rxjs';
import {
  EevoFileUploadService,
  EevoNotifyService, FilesModel,
  NotifyType,
  UtilityService
} from '@eevo/eevo-core';
import {fuseAnimations} from '@eevo/eevo-base';
import {ShopCommandBuilderService} from '../../services/shop-command-builder.service';
import {ShopFormBuilderService} from '../../services/shop-form-builder.service';
import {ShopNotificationService} from '../../services/shop-notification.service';
import {CommandNotificationModel} from '../../../shared/models/command-notification-model';
import {Router} from '@angular/router';
import {ShopCommandService} from '../../services/shop-command.service';
import {ShopEntity} from '../../entities/shop-entity';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {SubSink} from 'subsink';

@Component({
  selector: 'app-app-shop-create',
  templateUrl: './app-shop-create.component.html',
  styleUrls: ['./app-shop-create.component.scss'],
  // encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class AppShopCreateComponent implements AfterViewInit, OnInit, OnDestroy {
  constructor(
    private router: Router,
    private cdr: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private eevoNotifyService: EevoNotifyService,
    private eevoFileUploadService: EevoFileUploadService,
    private signalrNotificationService: SignalrNotificationService,
    private shopEntity: ShopEntity,
    private shopCommandService: ShopCommandService,
    private shopFormBuilderService: ShopFormBuilderService,
    private shopCommandBuilderService: ShopCommandBuilderService,
    private shopNotificationService: ShopNotificationService,
  ) {

    // Set the private defaults
    this.unsubscribeAll = new Subject();

    this.shopFiles = new FilesModel();
  }

  get mediaSelected() {
    let isValid = false;
    this.shopFiles.Files.forEach(file => {
      if (file.FileData) {
        isValid = true;
      }
    });
    return isValid;
  }
  shopId: string;
  shopForm: FormGroup;
  shopFiles: FilesModel;
  selectedIndex = 0;
  shopCreateSubmited = false;
  tabStatus = {
    detailsEnable: true,
    serviceHoursEnable: true,
    settingsEnable: false,
    mediaEnable: false,
  };
  breadcrumbList: BreadcrumbModel[] = [];
  private subs = new SubSink();

  // Private
  private unsubscribeAll: Subject<any>;
  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  formSubmitted: boolean;

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    this.setBreadcrumbData();
    this.shopForm = this.shopFormBuilderService.getShopForm();
    this.tabEnableByValidation();
    this.subs.sink = this.shopNotificationService
      .onReceived().subscribe((data: CommandNotificationModel) => {
    });
  }

  ngAfterViewInit(): void {
    this.cdr.detectChanges();
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this.unsubscribeAll.next();
    this.unsubscribeAll.complete();
    this.subs.unsubscribe();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  goToShopListPage = () => {
    this.router.navigate(['shop']);
  }

  currentIndex(index): void {
    this.selectedIndex = index;
  }

  nextStep(index): void {
    if (index === 0) {
      this.shopForm.get('Details').markAllAsTouched();
      this.shopForm.get('ContactDetails').markAllAsTouched();
      this.shopForm.get('Address').markAllAsTouched();
      if (this.shopForm.get('Details').valid && this.shopForm.get('ContactDetails').valid && this.shopForm.get('Address').valid) {
        this.selectedIndex = 1;
      }
    } else if (index === 1) {
      this.shopForm.get('ServiceHours').markAllAsTouched();
      this.shopForm.get('PreOrderScheduledHours').markAllAsTouched();
      if (this.shopForm.get('ServiceHours').valid && this.shopForm.get('PreOrderScheduledHours').valid) {
        this.selectedIndex = 2;
      }
    } else if (index === 2) {
      this.shopForm.get('Settings').markAllAsTouched();
      if (this.shopForm.get('Settings').valid) {
        this.selectedIndex = 3;
      }
    }

    // const maxNumberOfTabs = 4;
    // if (this.shopForm.valid && this.selectedIndex !== maxNumberOfTabs) {
    //   this.selectedIndex = this.selectedIndex + 1;
    // }
  }

  previousStep(index): void {
    if (index === 1) {
      this.selectedIndex = 0;
    } else if (index === 2) {
      this.selectedIndex = 1;
    } else if (index === 3) {
      this.selectedIndex = 2;
    }

    // if (this.selectedIndex !== 0) {
    //   this.selectedIndex = this.selectedIndex - 1;
    // }
  }

  /*createShopCommand(): void {
    this.shopId = this.utilityService.getNewGuid();
    const command = this.shopCommandBuilderService.getCreateShopCommandPayload(this.shopId, this.shopForm);

    if (command.Shops[0].Settings.PaymentMethods.length === 0) {
      this.eevoNotifyService.displayMessage('There must have a payment method', NotifyType.Error);
      return;
    }

    this.formSubmitted = true;
    this.shopNotificationService.shopCreated();

    this.eevoNotifyService.displayMessage(this.shopEntity.getMessages().CREATE_REQUEST, NotifyType.Info);

    this.shopCommandService.createShopCommand(command).subscribe((success) => {
      this.formSubmitted = false;
      this.shopForm = this.shopFormBuilderService.getShopForm();

      this.selectedIndex = 3;
      this.tabStatus = {
        detailsEnable: false,
        serviceHoursEnable: false,
        settingsEnable: false,
        mediaEnable: true,
      };

    }, (error) => {
      this.formSubmitted = false;
      this.eevoNotifyService.displayMessage('Shop create' + this.shopEntity.getMessages().ERROR, NotifyType.Error);
    });
  }

  uploadImage(): void {
    if (this.shopFiles.Files.length > 0) {
      this.eevoNotifyService.displayMessage('File upload request submitted!', NotifyType.Info);
      this.goToShopListPage();
      this.eevoFileUploadService.uploadPublicImages(
        this.signalrNotificationService,
        this.shopEntity.getFolderName(),
        this.shopId,
        this.shopFiles
      ).subscribe(data => {
      });
    }
  }
*/

  createShop(): void {
    this.formSubmitted = true;
    this.shopNotificationService.shopCreated();
    this.eevoNotifyService.displayMessage(this.shopEntity.getMessages().CREATE_REQUEST, NotifyType.Info);

    this.subs.sink = forkJoin(this.getShopCreateCalls()).subscribe(data => {
      this.formSubmitted = false;
      this.shopForm = this.shopFormBuilderService.getShopForm();
      this.goToShopListPage();
    }, (error) => {
      this.formSubmitted = false;
      this.eevoNotifyService.displayMessage('Shop create' + this.shopEntity.getMessages().ERROR, NotifyType.Error);
    });
  }

  private getShopCreateCalls(): any[] {
    const calls = [];

    this.shopId = this.utilityService.getNewGuid();
    const command = this.shopCommandBuilderService.getCreateShopCommandPayload(this.shopId, this.shopForm);
    calls.push(
      this.shopCommandService.createShopCommand(command)
    );

    if (this.mediaSelected) {
      this.eevoNotifyService.displayMessage('File upload request submitted!', NotifyType.Info);
      calls.push(
        this.eevoFileUploadService.uploadPublicImages(
          this.signalrNotificationService,
          this.shopEntity.getFolderName(),
          this.shopId,
          this.shopFiles
        )
      );
    }

    return calls;
  }

  private tabEnableByValidation(): void {
    this.subs.sink = this.shopForm.valueChanges.subscribe(() => {
      const isValidDetails = this.shopForm.get('Details').valid;
      const isValidContactDetails = this.shopForm.get('ContactDetails').valid;
      const isValidAddress = this.shopForm.get('Address').valid;

      if (!(isValidDetails && isValidContactDetails && isValidAddress)) {
        this.tabStatus.serviceHoursEnable = false;
        if (this.tabStatus.settingsEnable) {
          this.tabStatus.settingsEnable = false;
        }
      } else {
        this.tabStatus.serviceHoursEnable = true;

        const isValidServiceHours = this.shopForm.get('ServiceHours').valid;
        const isContactPreOrderScheduledHours = this.shopForm.get('PreOrderScheduledHours').valid;

        if (!(isValidServiceHours && isContactPreOrderScheduledHours)) {
          this.tabStatus.settingsEnable = false;
        } else {
          this.tabStatus.settingsEnable = true;
        }
        const isValidSettingsHours = this.shopForm.get('Settings').valid;
        if (!(isValidSettingsHours)) {
          this.tabStatus.mediaEnable = false;
        } else {
          this.tabStatus.mediaEnable = true;
        }
      }
    });
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Shops',
      Path: ['/shop']
    });

    this.breadcrumbList.push({
      Text: 'Create Shop'
    });
  }
}

// this.storageService.createFiles(createFileModels).subscribe((response) => {
//   this.goToShopListPage();
//   this.shopNotificationService.shopFileCreated();
// });
//
// this.shopNotificationService.onReceivedFile().subscribe((response) => {
//   const fileObject = this.getPotentialFile(response.FileId);
//   if (fileObject) {
//     this.storageService.uploadFile(fileObject.FileData, response.UploadUri.UploadUriWithSas).subscribe(() => {
//       const command = this.getUpdateFilesCommand(fileObject);
//
//       // listening events of file added to the shops
//       this.shopNotificationService.shopFilesUpdated();
//
//
//       this.shopCommandService.updateShopFilesCommand(command).subscribe(data => {
//       });
//
//       // this.snackBar.open('Shop file uploaded.', null, {
//       //   panelClass: ['success', 'notification'],
//       //   announcementMessage: 'File Upload Completed!',
//       //   duration: 2000,
//       //   horizontalPosition: 'right',
//       //   verticalPosition: 'bottom',
//       // });
//     });
//   }
// });


// const createFiles$ = this.storageService.createFiles(createFileModels);
// const createFilesNotificationReceived$ = this.shopNotificationService.onReceivedFile();
// let fileObject = null;
// let command = null;
// createFiles$.pipe(
//   take(1),
//   tap(() => {
//     this.goToShopListPage();
//     this.shopNotificationService.shopFileCreated();
//   }),
//   concatMap(() => createFilesNotificationReceived$),
//   tap(response => {
//     fileObject = this.getPotentialFile(response.FileId);
//     if (!fileObject) {
//       return response;
//     }
//   }),
//   concatMap((response) =>
//     this.storageService.uploadFile(
//       fileObject.FileData, response.UploadUri.UploadUriWithSas
//     )
//   ),
//   tap(() => {
//     command = this.shopCommandBuilderService.getUpdateFilesCommand(fileObject, this.shopId);
//     this.shopNotificationService.shopFilesUpdated();
//   }),
//   concatMap(() =>
//     this.shopCommandService.updateShopFilesCommand(command)
//   )
// ).subscribe(data => {
//   if (!fileObject) {
//   }
// });
