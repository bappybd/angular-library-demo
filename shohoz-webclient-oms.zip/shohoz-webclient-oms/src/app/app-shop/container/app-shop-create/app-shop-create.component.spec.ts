import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {AppShopCreateComponent} from './app-shop-create.component';

describe('AppShopCreateComponent', () => {
  let component: AppShopCreateComponent;
  let fixture: ComponentFixture<AppShopCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppShopCreateComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppShopCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
