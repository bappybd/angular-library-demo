import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {AppShopListComponent} from './app-shop-list.component';

describe('AppShopListComponent', () => {
  let component: AppShopListComponent;
  let fixture: ComponentFixture<AppShopListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppShopListComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppShopListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
