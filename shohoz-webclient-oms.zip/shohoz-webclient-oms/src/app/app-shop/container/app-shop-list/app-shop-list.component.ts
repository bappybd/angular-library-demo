import {Component, Input, OnDestroy, OnInit, TemplateRef, ViewChild, ViewEncapsulation} from '@angular/core';
import {Router} from '@angular/router';
import {ShopDetails, ShopFilter, ShopListConfigModel} from '../../models/shop-models';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {BehaviorSubject} from 'rxjs';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {ShopQueryService} from '../../services/shop-query.service';
import {ShopNotificationService} from '../../services/shop-notification.service';
import {ShopEntity} from '../../entities/shop-entity';
import {MatDialog} from '@angular/material/dialog';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {SubSink} from 'subsink';
import {ShopSettingsModel, ShopStatusEnum} from '../../../shared/models/shop-entity-models';

@Component({
  selector: 'app-app-shop-list',
  templateUrl: './app-shop-list.component.html',
  styleUrls: ['./app-shop-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppShopListComponent implements OnInit, OnDestroy {
  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('nameHeader', {static: true}) nameHeaderTemplate: TemplateRef<any>;
  @ViewChild('nameCell', {static: true}) nameCellTemplate: TemplateRef<any>;
  @ViewChild('zoneCell', {static: true}) zoneCellTemplate: TemplateRef<any>;
  @ViewChild('contactCell', {static: true}) contactCellTemplate: TemplateRef<any>;
  @ViewChild('statusCell', {static: true}) statusCellTemplate: TemplateRef<any>;
  @ViewChild('availabilityCell', {static: true}) availabilityCellTemplate: TemplateRef<any>;
  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  private datatableModelInput = new BehaviorSubject<ShopListConfigModel<any>>(undefined);
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  searchKey: string;
  shopFilter: ShopFilter;
  isLoading = true;
  @Input() searchFilter: string;
  subs = new SubSink();

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private shopEntity: ShopEntity,
    private shopQueryService: ShopQueryService,
    private shopNotificationService: ShopNotificationService,
    public fgs: FeatureGuardService
  ) {
  }

  ngOnInit(): void {
    this.prepareDataTable();
    this.subs.sink = this.shopNotificationService.onReceived().subscribe(data => {
      if (data.ActionName === 'ShopCreatedEvent') {
        this.getShopList(this.datatableModel, this.shopFilter);
      }
    });
  }

  addNewShop = () => {
    this.router.navigate(['shop', 'create']);
  };

  getSearchFilterData($event: ShopFilter): void {
    this.shopFilter = $event;
    this.datatableModel.CurrentPageNumber = 0;
    this.getShopList(this.datatableModel, this.shopFilter);
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'Name',
          name: 'Name',
          flexGrow: 1.5,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.nameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'EmergencyContactDetails.Email',
          name: 'Contact',
          flexGrow: 1.2,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.contactCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Affordability',
          name: 'Affordability',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Settings.DeliveryFee',
          name: 'Delivery Fee',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Address',
          name: 'Zone',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.zoneCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ServiceHours',
          name: 'Operating Hours',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.availabilityCellTemplate,
          draggable: true,
          sortable: false,
        },
        {
          prop: 'Settings.ZoneWiseSortOrder',
          name: 'Sort Order',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Settings.ShopStatus',
          name: 'Status',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.statusCellTemplate,
          draggable: true,
          sortable: true,
          maxWidth: 230,
          minWidth: 230,
        }
      ] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.getShopList(this.datatableModel, this.shopFilter);
    this.initDataTable();
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getShopList(tableModel, this.shopFilter);
    this.topFunction();
  }

  selectData(dataTableRow: any): void {
    // this.router.navigate(['shop', 'detail', dataTableRow.Id, 'overview']);
  }

  editData(dataTableRow: any): void {
    this.router.navigate(['shop', 'update', dataTableRow.Id, 0]);
  }

  addMenu(dataTableRow: any): void {
    this.router.navigate(['shop', dataTableRow.Id, 'product']);
  }

  topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  initDataTable(): void {
    this.subs.sink = this.datatableModelInput.subscribe(response => {
      this.datatableModel.TotalElements = response ? response[1][0][0] : 0;
      this.datatableModel.Data = response ? response[0] : [];
    }, err => console.log(err));

    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  public getShopList(tableModel: DatatableModel<any>, shopFilter?: ShopFilter): void {
    this.isLoading = true;
    this.subs.sink = this.shopQueryService.getShopList(tableModel, shopFilter).subscribe((response) => {
        this.datatableModel = {
          PageSize: this.datatableModel.PageSize,
          TotalElements: response.totalCount,
          CurrentPageNumber: this.datatableModel.CurrentPageNumber,
          SortBy: this.datatableModel.SortBy,
          Descending: this.datatableModel.Descending,
          Data: response.data,
          ColumnMode: ColumnMode.flex
        };
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = true;
      });
  }

  getFileKey(shop: any): string {
    const date = new Date();
    const params = '?t=' + date.getMilliseconds();

    return this.shopEntity.getFileKey(
      shop.Id,
      this.shopEntity.ImageType.Logo
    );
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }


  getShopAvailability(serviceHours: any): boolean {
    const currentDate = new Date();
    const day = currentDate.getUTCDay();
    const hour = currentDate.getHours();
    const minute = currentDate.getMinutes();
    const totalMinute = (hour * 60) + minute;

    if (totalMinute >= serviceHours[day]?.OperatingHour[0]?.OpeningTime?.TotalMinute
      && totalMinute <= serviceHours[day]?.OperatingHour[0]?.ClosingTime?.TotalMinute) {
      return true;
    }
    return false;
  }

  navigateToExportImportPage(): void {
    this.router.navigate(['shop', 'export-import']);
  }

  canUpdateStatus(shop: ShopDetails): boolean {
    // @ts-ignore
    const isRestaurantUser = this.fgs.isValidFeatureSync([{Key: 'user.isRestaurantUser'}]);
    return !([ShopStatusEnum.PermanentlyClosed, ShopStatusEnum.ClosedUntilFurtherNotice].includes(shop.Settings.ShopStatus) && isRestaurantUser);
  }

  isTemporaryClosed(Settings: ShopSettingsModel): boolean {
    const {IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = Settings;
    if (!IsTemporaryUnavailable) {
      return false;
    }
    const startDate = new Date(TemporaryUnavailableStartTime);
    const endDate = new Date(TemporaryUnavailableEndTime);
    const currentDate = new Date();
    return (startDate <= currentDate && currentDate <= endDate);
  }

  getShopStatus(Settings: ShopSettingsModel): { text: string, time?: Date } {
    switch (Settings.ShopStatus) {
      case ShopStatusEnum.Live:
        return this.isTemporaryClosed(Settings) ?
          {text: 'Temporary Unavailable till', time: new Date(Settings.TemporaryUnavailableEndTime)} : {text: 'Live'};
      case ShopStatusEnum.Closed:
        return {text: 'Closed'};
      case ShopStatusEnum.Unavailable:
        return {text: 'Unavailable'};
      case ShopStatusEnum.ClosedUntilFurtherNotice:
        return {text: 'Closed until further notice'};
      case ShopStatusEnum.PermanentlyClosed:
        return {text: 'Permanently Closed'};
    }
  }
}
