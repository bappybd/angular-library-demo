import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {AppShopUpdateComponent} from './app-shop-update.component';

describe('AppShopUpdateComponent', () => {
  let component: AppShopUpdateComponent;
  let fixture: ComponentFixture<AppShopUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppShopUpdateComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppShopUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
