import {AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {forkJoin, Subject, Subscription} from 'rxjs';
import {
  EevoFileUploadService,
  EevoNotifyService, FilesModel,
  NotifyType,
  UtilityService
} from '@eevo/eevo-core';
import {fuseAnimations} from '@eevo/eevo-base';
import {ActivatedRoute, Router} from '@angular/router';
import {ShopFormBuilderService} from '../../services/shop-form-builder.service';
import {ShopNotificationService} from '../../services/shop-notification.service';
import {ShopCommandBuilderService} from '../../services/shop-command-builder.service';
import {ShopCommandService} from '../../services/shop-command.service';
import {ShopQueryService} from '../../services/shop-query.service';
import {ShopModel} from '../../../shared/models/shop-entity-models';
import {ShopEntity} from '../../entities/shop-entity';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {SubSink} from "subsink";

@Component({
  selector: 'app-app-shop-update',
  templateUrl: './app-shop-update.component.html',
  styleUrls: ['./app-shop-update.component.scss'],
  // encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class AppShopUpdateComponent implements AfterViewInit, OnInit, OnDestroy {
  shopId: string;
  shopDetails: ShopModel;
  shopForm: FormGroup;
  selectedIndex = 0;
  tabStatus = {
    detailsEnable: true,
    serviceHoursEnable: true,
    settingsEnable: true,
    mediaEnable: true,
  };
  shopFiles: FilesModel;
  breadcrumbList: BreadcrumbModel[] = [];
  loadingFromServer = true;
  private subs = new SubSink();

  // Private
  private unsubscribeAll: Subject<any>;

  constructor(
    private actRoute: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    private utilityService: UtilityService,
    private eevoNotifyService: EevoNotifyService,
    private eevoFileUploadService: EevoFileUploadService,
    private signalrNotificationService: SignalrNotificationService,
    private shopEntity: ShopEntity,
    private shopQueryService: ShopQueryService,
    private shopCommandService: ShopCommandService,
    private shopFormBuilderService: ShopFormBuilderService,
    private shopCommandBuilderService: ShopCommandBuilderService,
    private shopNotificationService: ShopNotificationService,
  ) {

    this.shopFiles = new FilesModel();

    this.shopId = this.actRoute.snapshot.params.id;

    // Set the private defaults
    this.unsubscribeAll = new Subject();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    this.shopForm = this.shopFormBuilderService.getShopForm();
    this.tabEnableByValidation();
    this.subs.sink = this.shopQueryService.getShopDetails(this.shopId).subscribe((data) => {
      this.loadingFromServer = false;
      if (data && data.ShopId) {
        this.shopDetails = data;
        this.setBreadcrumbData();
        this.shopFormBuilderService.setShopFormData(this.shopForm, this.shopDetails);
      }
    });
  }

  ngAfterViewInit(): void {
    this.cdr.detectChanges();
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this.unsubscribeAll.next();
    this.unsubscribeAll.complete();
    this.subs.unsubscribe();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  goToShopListPage = () => {
    this.router.navigate(['shop']);
  }

  currentIndex(index): void {
    this.selectedIndex = index;
  }

  nextStep(index): void {
    if (index === 0) {
      this.shopForm.get('Details').markAllAsTouched();
      this.shopForm.get('ContactDetails').markAllAsTouched();
      this.shopForm.get('Address').markAllAsTouched();
      if (this.shopForm.get('Details').valid && this.shopForm.get('ContactDetails').valid && this.shopForm.get('Address').valid) {
        this.selectedIndex = 1;
      }
    } else if (index === 1) {
      this.shopForm.get('ServiceHours').markAllAsTouched();
      this.shopForm.get('PreOrderScheduledHours').markAllAsTouched();
      if (this.shopForm.get('ServiceHours').valid && this.shopForm.get('PreOrderScheduledHours').valid) {
        this.selectedIndex = 2;
      }
    } else if (index === 2) {
      this.shopForm.get('Settings').markAllAsTouched();
      if (this.shopForm.get('Settings').valid) {
        this.selectedIndex = 3;
      }
    }
  }

  previousStep(index): void {
    if (index === 1) {
      this.selectedIndex = 0;
    } else if (index === 2) {
      this.selectedIndex = 1;
    } else if (index === 3) {
      this.selectedIndex = 2;
    }

    // if (this.selectedIndex !== 0) {
    //   this.selectedIndex = this.selectedIndex - 1;
    // }
  }

  get mediaSelected(): boolean {
    let isValid = false;
    this.shopFiles.Files.forEach(file => {
      if(file.FileData) {
        isValid = true;
      }
    });
    return isValid;
  }

  updateShop(): void {
    this.formSubmitted = true;
    this.shopNotificationService.shopUpdated();
    this.eevoNotifyService.displayMessage(this.shopEntity.getMessages().UPDATE_REQUEST, NotifyType.Info);

    this.subs.sink = forkJoin(this.getShopUpdateCalls()).subscribe(data => {
      this.formSubmitted = false;
    },  (error) => {
      this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
      this.formSubmitted = false;
    });
  }

  private getShopUpdateCalls(): any[] {
    const calls = [];
    const command = this.shopCommandBuilderService.getCreateShopCommandPayload(this.shopId, this.shopForm);
    calls.push(
      this.shopCommandService.updateShopCommand(command)
    );

    if (this.mediaSelected) {
      this.eevoNotifyService.displayMessage('File upload request submitted!', NotifyType.Info);
      calls.push(
        this.eevoFileUploadService.uploadPublicImages(
          this.signalrNotificationService,
          this.shopEntity.getFolderName(),
          this.shopId,
          this.shopFiles
        )
      );
    }

    return calls;
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  formSubmitted: boolean;

  private tabEnableByValidation(): void {
    this.subs.sink = this.shopForm.valueChanges.subscribe(() => {
      const isValidDetails = this.shopForm.get('Details').valid;
      const isValidContactDetails = this.shopForm.get('ContactDetails').valid;
      const isValidAddress = this.shopForm.get('Address').valid;

      if (!(isValidDetails && isValidContactDetails && isValidAddress)) {
        this.tabStatus.serviceHoursEnable = false;
        if (this.tabStatus.settingsEnable) {
          this.tabStatus.settingsEnable = false;
        }
        if (this.tabStatus.mediaEnable) {
          this.tabStatus.mediaEnable = false;
        }
      } else {
        this.tabStatus.serviceHoursEnable = true;

        const isValidServiceHours = this.shopForm.get('ServiceHours').valid;
        const isContactPreOrderScheduledHours = this.shopForm.get('PreOrderScheduledHours').valid;

        if (!(isValidServiceHours && isContactPreOrderScheduledHours)) {
          this.tabStatus.settingsEnable = false;
        } else {
          this.tabStatus.settingsEnable = true;
        }
        const isValidSettingsHours = this.shopForm.get('Settings').valid;
        if (!(isValidSettingsHours && isValidServiceHours)) {
          this.tabStatus.mediaEnable = false;
        } else {
          this.tabStatus.mediaEnable = true;
        }
      }
    });
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Shops',
      Path: ['/shop']
    });

    this.breadcrumbList.push({
      Text: (this.shopDetails.Name.length > 30) ? (this.shopDetails.Name.substr(0, 30) + '...') : this.shopDetails.Name
    });
  }
}
