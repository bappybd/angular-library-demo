import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, ActivatedRouteSnapshot} from '@angular/router';
import {CurationInfoModel, ShopModel} from '../../../shared/models/shop-entity-models';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {EevoStorageService} from '@eevo/eevo-core';
import {ShopEntity} from '../../entities/shop-entity';

@Component({
  selector: 'app-app-shop-details',
  templateUrl: './app-shop-details.component.html',
  styleUrls: ['./app-shop-details.component.scss']
})
export class AppShopDetailsComponent implements OnInit {

  shopDetails: ShopModel;
  arSnapshot: ActivatedRouteSnapshot;
  breadcrumbList: BreadcrumbModel[] = [];

  bannerImageUrl: string;
  highlightedImageUrl: string;
  listImageUrl: string;
  logoImageUrl: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private storageService: EevoStorageService,
    private shopEntity: ShopEntity,
  ) {
    this.arSnapshot = activatedRoute.snapshot;
  }

  ngOnInit(): void {
    this.getShopDetailsFromResolver();
    this.setBreadcrumbData();
    this.getShopImages();
  }

  private getShopDetailsFromResolver(): void {
    this.shopDetails = this.arSnapshot.data['shopDetails'];
    console.log(this.shopDetails);
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Shops',
      Path: ['/shop']
    });

    this.breadcrumbList.push({
      Text: (this.shopDetails.Name.length > 30) ? (this.shopDetails.Name.substr(0, 30) + '...') : this.shopDetails.Name,
      Path: null
    });

    this.breadcrumbList.push({
      Text: 'Detail'
    });
  }

  private getShopImages(): void {
    this.highlightedImageUrl = this.storageService.getFileUrl(
      this.shopEntity.getFileKey(this.shopDetails.Id, this.shopEntity.ImageType.HighlightedImage)) + '?t=' + new Date().getMilliseconds();
    this.listImageUrl = this.storageService.getFileUrl(
      this.shopEntity.getFileKey(this.shopDetails.Id, this.shopEntity.ImageType.ListImage)) + '?t=' + new Date().getMilliseconds();
    this.bannerImageUrl = this.storageService.getFileUrl(
      this.shopEntity.getFileKey(this.shopDetails.Id, this.shopEntity.ImageType.Banner)) + '?t=' + new Date().getMilliseconds();
    this.logoImageUrl = this.storageService.getFileUrl(
      this.shopEntity.getFileKey(this.shopDetails.Id, this.shopEntity.ImageType.Logo)) + '?t=' + new Date().getMilliseconds();
  }
}
