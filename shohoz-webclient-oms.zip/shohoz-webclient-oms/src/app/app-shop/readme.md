# Shohoz (OMS) Shop Module

- Partner - is on boarder with Shohoz
- Non partner - not onboarded with Shohoz, but are important for the business (e.g. Star kebab)

### Required Web Services (API)

- `Notification Service` 
- `Shop Subsystem` 
- `Storage Subsystem` 
- `Zone Service` 

### Required @eevo Module / Libraries

- `@eevo/eevo-base`
- `@eevo/eevo-core`
- `@eevo/eevo-file-uploader`
- `@eevo/eevo-image-uploader`
- `@eevo/eevo-notification`
- `@eevo/eevo-platform-datatable`
