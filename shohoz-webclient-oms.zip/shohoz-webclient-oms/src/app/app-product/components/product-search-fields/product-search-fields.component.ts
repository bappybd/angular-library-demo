import {Component, Input, OnDestroy, OnInit, Output, EventEmitter} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {SubSink} from 'subsink';
import {ProductQueryService} from '../../services/product-query.service';
import {ProductCategoryDataModel, ProductItemSearchModel} from '../../models/product-models';
import {debounceTime, take} from 'rxjs/operators';

export interface ProductSearchFieldData {
  productFilter: string;
  categoryFilter: {
    length: number,
    firstItemName: string,
    ids: string[]
  };
}

@Component({
  selector: 'app-product-search-fields',
  templateUrl: './product-search-fields.component.html',
  styleUrls: ['./product-search-fields.component.scss']
})
export class ProductSearchFieldsComponent implements OnInit, OnDestroy {
  private _shopId: string;
  @Output() OnSearch: EventEmitter<ProductSearchFieldData> = new EventEmitter<ProductSearchFieldData>();
  @Output() Reset: EventEmitter<boolean> = new EventEmitter<boolean>();
  private categoriesLoading: boolean;

  @Input() set shopId(id: string) {
    this._shopId = id;
    this.getProductCategoryList();
  }

  get shopId(): string {
    return this._shopId;
  }

  private subs = new SubSink();
  public allCategoriesForShop: ProductCategoryDataModel[] = [];
  public allCategoriesForShopIdMap: { [id: string]: ProductCategoryDataModel } = {};
  searchForm: FormGroup;
  categorySelectionData = {
    length: 0,
    firstItemName: '',
    ids: []
  };

  pageData = {
    pageSize: 10,
    pageNumber: 0,
    isLastPage: false
  };

  constructor(
    private formBuilder: FormBuilder,
    private productQueryService: ProductQueryService,
  ) {
    this.createForm();
  }


  ngOnInit(): void {
    this.setSelectedCategories();
    this.getItemsOnSearch();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  private createForm(): void {
    this.searchForm = this.formBuilder.group({
      itemOrCategoryName: this.formBuilder.control(''),
      categoryIds: this.formBuilder.control([])
    });
  }

  getProductCategoryList(): void {
    if (this.categoriesLoading) {
      return;
    }
    this.categoriesLoading = true;
    this.subs.sink = this.productQueryService.getCategoryListByShopId(this.shopId, this.pageData.pageNumber, this.pageData.pageSize, 'Name')
      .pipe(take(1))
      .subscribe((res: ProductCategoryDataModel[]) => {
        this.allCategoriesForShop.push(...res);
        res.forEach(cat => this.allCategoriesForShopIdMap[cat.Id] = {...cat});
        this.pageData.pageNumber++;
        this.categoriesLoading = false;
        this.pageData.isLastPage = res.length < this.pageData.pageSize;
      }, error => {
        this.categoriesLoading = false;
      });
  }

  private setSelectedCategories(): void {
    this.searchForm.get('categoryIds').valueChanges
      .pipe(debounceTime(500))
      .subscribe((res: ProductItemSearchModel[]) => {
        const searchKey = this.searchForm.get('itemOrCategoryName').value;
        this.categorySelectionData = {
          length: res.length,
          firstItemName: res.length > 0 ? res[0].Name : '',
          ids: res.map(c => c.Id)
        };
        if ((searchKey === '') && (this?.categorySelectionData?.length === 0)) {
          this.Reset.emit(true);
          return;
        }
        const filterData = {
          productFilter: searchKey,
          categoryFilter: this.categorySelectionData
        };
        this.OnSearch.emit(filterData);
      }, error => console.error(error));
  }

  private getItemsOnSearch(): void {
    this.searchForm.get('itemOrCategoryName').valueChanges
      .pipe(debounceTime(500))
      .subscribe((res: ProductItemSearchModel[]) => {
        const searchKey = this.searchForm.get('itemOrCategoryName').value;
        if ((searchKey === '') && (this?.categorySelectionData?.length === 0)) {
          this.Reset.emit(true);
          return;
        }
        const filterData = {
          productFilter: searchKey,
          categoryFilter: this.categorySelectionData
        };
        this.OnSearch.emit(filterData);
      }, error => console.error(error));
  }
}
