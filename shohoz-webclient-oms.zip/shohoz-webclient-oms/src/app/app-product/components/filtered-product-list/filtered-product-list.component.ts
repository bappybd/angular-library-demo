import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {fuseAnimations} from '@eevo/eevo-base';
import {SubSink} from 'subsink';
import {ProductQueryService} from '../../services/product-query.service';
import {ProductEntity} from '../../entities/product-entity';
import {ProductNotificationService} from '../../services/product-notification.service';
import {filter} from 'rxjs/operators';
import {ProductSearchFieldData} from '../product-search-fields/product-search-fields.component';
import {ProductItemSearchModel} from '../../models/product-models';

@Component({
  selector: 'app-filtered-product-list',
  templateUrl: './filtered-product-list.component.html',
  styleUrls: ['./filtered-product-list.component.scss'],
  animations: fuseAnimations
})
export class FilteredProductListComponent implements OnInit, OnDestroy {
  @Input()
  shopId: string;

  private filterData: ProductSearchFieldData;
  @Input()
  set searchFilterData(value: ProductSearchFieldData) {
    this.filterData = value;
    this.productList = [];
    this.pageIndex = 0;
    this.getProducts();
  }

  @Output()
  onItemUpdate: EventEmitter<any> = new EventEmitter();

  productLoading: boolean;
  productList: ProductItemSearchModel[] = [];
  pageIndex = 0;
  pageSize = 20;

  subs = new SubSink();

  constructor(
    private productQueryService: ProductQueryService,
    private productEntity: ProductEntity,
    private productNotificationService: ProductNotificationService,
  ) {
  }

  ngOnInit(): void {
    this.listenToProductEvents();
  }

  updateItem($event: any): void {
    this.onItemUpdate.emit($event);
  }

  getProducts(): void {
    this.productLoading = true;
    this.subs.sink = this.productQueryService
      .getProductForFilteredListComponent(this.shopId, this.pageSize, this.pageIndex, this.filterData?.productFilter,
        this.filterData?.categoryFilter.ids)
      .subscribe((data) => {
        this.productList.push(...data);
        this.productLoading = false;
      });
  }

  onScrolledDown(): void {
    this.pageIndex = this.pageIndex + 1;
    this.getProducts();
  }

  private listenToProductEvents(): void {
    this.productNotificationService.productActiveEvent();
    this.productNotificationService.productUpdated();
    const actionNamesToListen = [
      this.productEntity.Events.ProductUpdatedEvent,
      this.productEntity.Events.ProductActiveEvent
    ];
    this.subs.sink = this.productNotificationService.onReceived()
      .pipe(filter(event => !!actionNamesToListen.includes(this.productEntity.Events[event?.ActionName])))
      .subscribe(data => {
        this.productList = [];
        this.pageIndex = 0;
        this.getProducts();
      });
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
