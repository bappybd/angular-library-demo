import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {FuseSidebarService} from '@eevo/eevo-base';
import {EevoNotifyService, NotifyType, UtilityService} from '@eevo/eevo-core';
import {ActivatedRoute} from '@angular/router';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductCategoryDataModel} from '../../models/product-models';
import {ProductCategoryCommand} from '../../models/product-command';
import {ProductCategoryModel} from '../../../shared/models/product-entity-models';
import {ProductQueryService} from '../../services/product-query.service';
import {ProductCategoryEntity} from '../../entities/product-category-entity';
import {SubSink} from 'subsink';
import {MatCheckboxChange} from '@angular/material/checkbox';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.scss']
})
export class UpdateCategoryComponent implements OnInit, OnDestroy {
  updateCategoryForm: FormGroup;
  loadingFromServer = true;
  private subs = new SubSink();
  @Output() categoryCreated: EventEmitter<boolean> = new EventEmitter<boolean>(false);

  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private fuseSidebarService: FuseSidebarService,
    private eevoNotifyService: EevoNotifyService,
    private productCategoryEntity: ProductCategoryEntity,
    private menuQueryService: ProductQueryService,
    private menuCommandService: ProductCommandService,
    private menuNotificationService: ProductNotificationService,
  ) {
  }

  private _category: ProductCategoryDataModel;

  @Input()
  set category(value: ProductCategoryDataModel) {
    this.loadingFromServer = true;

    this.subs.sink = this.menuQueryService.getProductCategory(value.Id).subscribe(data => {
      this._category = data;
      this.loadingFromServer = false;
      this.initCategoryUpdateForm(this._category);
    });
  }

  get category(): ProductCategoryDataModel {
    return this._category;
  }

  ngOnInit(): void {
    // this.initCategoryUpdateForm();
  }

  initCategoryUpdateForm(data?: ProductCategoryDataModel): void {
    this.updateCategoryForm = this.formBuilder.group({
      name: [data && data.Name || '', Validators.required],
      description: [data && data.Description || ''],
      order: [data && data.CategoryOrderInCatalogue || 0, Validators.required],
      isActive: [data && data.IsActive],
      IsTemporaryUnavailable: [data && data.IsTemporaryUnavailable || false],
      TemporaryUnavailableStartTime: [new Date()],
      TemporaryUnavailableEndTime: [data && data?.IsTemporaryUnavailable ?
        data.TemporaryUnavailableEndTime : this.getTodayMidnightDate(),
        data.IsTemporaryUnavailable ? Validators.required : []
      ],
    });
  }

  private getTodayMidnightDate(): Date {
    const date = new Date();
    date.setHours(23, 59, 59, 999);
    return date;
  }

  toggleSidebarOpen(key: string): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  updateCategory(): void {
    this.updateCategoryForm.markAllAsTouched();
    if (this.updateCategoryForm.valid) {
      this.menuNotificationService.productCategoryUpdated();

      const productCategory: ProductCategoryModel = {
        ProductCategoryId: this.category.Id,
        Name: this.updateCategoryForm.get('name').value,
        Description: this.updateCategoryForm.get('description').value,
        CategoryOrderInCatalogue: Number(this.updateCategoryForm.get('order').value),
        ProductCatalogueId: this.category.ProductCatalogueId,
        ShopId: this.category.ShopId,
        IsActive: Boolean(this.updateCategoryForm.get('isActive').value),
      };
      const tempUnavailable = this.getTemporaryUnavailableData(this.updateCategoryForm.value);
      if (tempUnavailable?.IsTemporaryUnavailable) {
        productCategory.IsTemporaryUnavailable = !!tempUnavailable?.IsTemporaryUnavailable;
        productCategory.TemporaryUnavailableStartTime = tempUnavailable.TemporaryUnavailableStartTime;
        productCategory.TemporaryUnavailableEndTime = new Date(new Date(tempUnavailable.TemporaryUnavailableEndTime || null).setSeconds(59)).toISOString();
      }

      const categoryCommand: ProductCategoryCommand = {
        CorrelationId: this.utilityService.getNewGuid(),
        Categories: [productCategory]
      };

      this.eevoNotifyService.displayMessage(
        this.productCategoryEntity.getMessages().UPDATE_REQUEST,
        NotifyType.Info
      );

      this.subs.sink = this.menuCommandService.updateCategory(categoryCommand).subscribe(data => {
        this.categoryCreated.emit(true);
        this.initCategoryUpdateForm(this.category);
        this.fuseSidebarService.getSidebar('editCategoryPanel').toggleOpen();
      }, (error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.initCategoryUpdateForm(this.category);
        this.fuseSidebarService.getSidebar('editCategoryPanel').toggleOpen();
      }));
    }
  }

  private getTemporaryUnavailableData({IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime}):
    { IsTemporaryUnavailable: boolean, TemporaryUnavailableStartTime: string, TemporaryUnavailableEndTime: string } | null {
    if (!IsTemporaryUnavailable || !TemporaryUnavailableStartTime || !TemporaryUnavailableEndTime) {
      return null;
    }
    if (new Date(TemporaryUnavailableStartTime) > new Date(TemporaryUnavailableEndTime)) {
      return null;
    }

    return {
      IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: new Date(TemporaryUnavailableStartTime).toISOString(),
      TemporaryUnavailableEndTime: new Date(TemporaryUnavailableEndTime).toISOString()
    };
  }

  discard(key: string): void {
    this.initCategoryUpdateForm(this._category);
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  updateValidationForOtherFields(event: MatCheckboxChange, fieldNames: string[], validatorNames: string[]): void {
    const fieldsToSetValidation: AbstractControl[] = fieldNames.map(fieldName => this.updateCategoryForm.get(fieldName));
    const validators = validatorNames.map(name => Validators[name]);
    if (event && event.checked) {
      //   Set Validators
      fieldsToSetValidation.forEach(field => {
        field.setValidators(validators);
        field.updateValueAndValidity();
      });
    } else {
      //  Clear Validators
      fieldsToSetValidation.forEach(field => {
        field.clearValidators();
        field.updateValueAndValidity();
        field.setErrors(null);
      });
    }
  }

  onStatusChange(value: boolean): void {
    if (value) {
      return;
    }
    this.updateCategoryForm.get('IsTemporaryUnavailable').setValue(false);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
