import {Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import {FuseSidebarService} from '@eevo/eevo-base';
import {EevoNotifyService, NotifyType, UtilityService} from '@eevo/eevo-core';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductCategoryDataModel} from '../../models/product-models';
import {ProductFormBuilderService} from '../../services/product-form-builder.service';
import {ProductCommandBuilderService} from '../../services/product-command-builder.service';
import {ProductEntity} from '../../entities/product-entity';
import {SubSink} from "subsink";

@Component({
  selector: 'app-create-item',
  templateUrl: './create-item.component.html',
  styleUrls: ['./create-item.component.scss']
})
export class CreateItemComponent implements OnInit, OnDestroy {
  private _shopDetails;
  private subs = new SubSink();
  @Input()
  set shopDetails(value: any) {
    this._shopDetails = value;
    this.prepTimeValidation();
  }

  get shopDetails(): any {
    return this._shopDetails;
  }
  createItemForm: FormGroup;
  formSubmitted = false;
  @Output() itemCreated: EventEmitter<boolean> = new EventEmitter<boolean>(false);

  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private fuseSidebarService: FuseSidebarService,
    private utilityService: UtilityService,
    private eevoNotifyService: EevoNotifyService,
    private productEntity: ProductEntity,
    private productCommandService: ProductCommandService,
    private productNotificationService: ProductNotificationService,
    private productFormBuilderService: ProductFormBuilderService,
    private productCommandBuilderService: ProductCommandBuilderService,
  ) {
  }

  private _category: ProductCategoryDataModel;
  @Input()
  set category(value: ProductCategoryDataModel) {
    this._category = value;
    this.initItemCreationForm();
  }

  get category(): ProductCategoryDataModel {
    return this._category;
  }

  ngOnInit(): void {

  }
  prepTimeValidation():void {
    if (this.shopDetails.IsHomeCook) {
      this.createItemForm.controls.PreparationTime.setValidators(Validators.required);
    }
  }
  initItemCreationForm(): void {
    this.createItemForm = this.productFormBuilderService.getForm(this.category);
  }

  toggleSidebarOpen(key: string): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  createItem(): void {
    this.createItemForm.markAllAsTouched();
    if (this.createItemForm.valid) {
      this.formSubmitted = true;

      this.productNotificationService.productCreated();
      this.eevoNotifyService.displayMessage(
        this.productEntity.getMessages().CREATE_REQUEST,
        NotifyType.Info
      );

      const command = this.productCommandBuilderService.getProductCommand(this.createItemForm, this.category);
      this.subs.sink = this.productCommandService.createItem(command).subscribe(data => {
        this.formSubmitted = false;
        this.discard('createItemPanel');
      }, (error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
        this.discard('createItemPanel');
      }));
    }
  }

  discard(key: string): void {
    this.initItemCreationForm();
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  onStatusChange(value: boolean): void {
    if (value) {
      return;
    }
    this.createItemForm.get('IsTemporaryUnavailable').setValue(false);
  }

}
