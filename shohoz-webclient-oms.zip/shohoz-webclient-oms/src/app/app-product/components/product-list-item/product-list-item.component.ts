import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  ViewChildren
} from '@angular/core';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductCategoryDataModel, ProductItemActiveModel, ProductItemModel} from '../../models/product-models';
import {ActiveProductCommand} from '../../models/product-command';
import {ProductEntity} from '../../entities/product-entity';
import {MatSlideToggleChange} from '@angular/material/slide-toggle';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {MatDialog} from '@angular/material/dialog';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {SubSink} from "subsink";

@Component({
  selector: 'app-product-list-item',
  templateUrl: './product-list-item.component.html',
  styleUrls: ['./product-list-item.component.scss']
})
export class ProductListItemComponent implements OnInit, OnDestroy {
  takaSymbol = '‎৳';
  private subs = new SubSink();

  @Input()
  productCategory: ProductCategoryDataModel;

  @Input()
  productItem: ProductItemModel;

  @Output()
  onItemUpdate: EventEmitter<any> = new EventEmitter();

  @ViewChildren('toggleElement') toggleElementRef: QueryList<ElementRef>;

  constructor(
    private dialog: MatDialog,
    private productEntity: ProductEntity,
    private productCommandService: ProductCommandService,
    private productNotificationService: ProductNotificationService,
    public fgs: FeatureGuardService
  ) {
  }

  ngOnInit(): void {
  }

  updateItem(product: ProductItemModel): void {
    this.onItemUpdate.emit({
      category: this.productCategory,
      product,
    });
  }

  activeProduct(event: MatSlideToggleChange, product: ProductItemModel): void {
    const toggleRef: any = this.toggleElementRef.find((ref: any) => {
      return ref.id === product.Id;
    });

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Confirmation',
        message: 'Are you sure you want to update this item status?',
        buttonText: {
          ok: 'Yes',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.doActiveProduct(event.checked, product);
        toggleRef.checked = event.checked;
      } else {
        toggleRef.checked = !event.checked;
      }
    });
  }

  doActiveProduct(isActive: boolean, product: ProductItemModel): void {
    const productActiveItem: ProductItemActiveModel = {
      IsActive: isActive,
      ProductCatalogueId: product.ProductCatalogueId,
      ProductCategoryId: this.productCategory.Id,
      ProductId: product.Id,
      ShopId: product.ShopId
    };

    let command = new ActiveProductCommand();
    command.Products = [productActiveItem];

    this.productNotificationService.productActiveEvent();

    this.subs.sink = this.productCommandService.activeProduct(command).subscribe(data => {
      /* product.IsActive = isActive;*/
    });
  }

  getFileKey(productItem: ProductItemModel): string {
    return this.productEntity.getFileKey(productItem.Id, 'item');
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
