import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormGroup, Validators} from '@angular/forms';
import {MatCheckboxChange} from '@angular/material/checkbox';

@Component({
  selector: 'app-product-basic-item',
  templateUrl: './product-basic-item.component.html',
  styleUrls: ['./product-basic-item.component.scss']
})
export class ProductBasicItemComponent implements OnInit {

  @Input()
  parent: FormGroup;

  constructor() {
  }

  ngOnInit(): void {
    this.setPriceOnPriceWithSDOrSdChange();
  }

  onTemporaryItemChanged($event: MatCheckboxChange): void {
    const tempStartDate = this.parent.get('TempStartDate');
    const tempEndDate = this.parent.get('TempEndDate');

    if ($event && $event.checked) {
      tempStartDate.setValidators([Validators.required]);
      tempEndDate.setValidators([Validators.required]);
      tempStartDate.updateValueAndValidity();
      tempEndDate.updateValueAndValidity();
    } else {
      tempStartDate.clearValidators();
      tempEndDate.clearValidators();
      tempStartDate.setErrors(null);
      tempEndDate.setErrors(null);
    }
  }

  private setPriceOnPriceWithSDOrSdChange(): void {
    this.parent.get('PriceWithSD').valueChanges
      .subscribe(val => {
        const sd = this.parent.get('SupplementaryDuty').value / 100;
        const price = val / (1 + sd);
        this.parent.get('Price').setValue(price.toFixed(2));
      });

    this.parent.get('SupplementaryDuty').valueChanges
      .subscribe(val => {
        const sd = +val / 100;
        const priceWithSd = this.parent.get('PriceWithSD').value;
        const price = priceWithSd / (1 + sd);
        this.parent.get('Price').setValue(price.toFixed(2));
      });
  }

  updateValidationForOtherFields(event: MatCheckboxChange, fieldNames: string[], validatorNames: string[]): void {
    const fieldsToSetValidation: AbstractControl[] = fieldNames.map(fieldName => this.parent.get(fieldName));
    const validators = validatorNames.map(name => Validators[name]);
    if (event && event.checked) {
      //   Set Validators
      fieldsToSetValidation.forEach(field => {
        field.setValidators(validators);
        field.updateValueAndValidity();
      });
    } else {
      //  Clear Validators
      fieldsToSetValidation.forEach(field => {
        field.clearValidators();
        field.updateValueAndValidity();
        field.setErrors(null);
      });
    }
  }
}
