import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ProductBasicItemComponent} from './product-basic-item.component';

describe('ProductBasicItemComponent', () => {
  let component: ProductBasicItemComponent;
  let fixture: ComponentFixture<ProductBasicItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProductBasicItemComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductBasicItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
