import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {SubSink} from 'subsink';
import {MatSlideToggle, MatSlideToggleChange} from '@angular/material/slide-toggle';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {MatDialog} from '@angular/material/dialog';
import {MatDialogRef} from '@angular/material/dialog/dialog-ref';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {CategoryListTemporaryUnavailableStatusUpdateDialogComponent} from '../category-list-temporary-unavailable-status-update-dialog/category-list-temporary-unavailable-status-update-dialog.component';
import {ProductCategoryDataModel} from '../../models/product-models';
import {ProductCategoryModel} from '../../../shared/models/product-entity-models';
import {ProductCategoryCommand} from '../../models/product-command';
import {UtilityService} from '@eevo/eevo-core';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductCommandService} from '../../services/product-command.service';

@Component({
  selector: 'app-category-list-status-update',
  templateUrl: './category-list-status-update.component.html',
  styleUrls: ['./category-list-status-update.component.scss']
})
export class CategoryListStatusUpdateComponent implements OnInit {

  @Input() set category(data: ProductCategoryDataModel) {
    this.categoryDetails = data;
  }

  categoryDetails: ProductCategoryDataModel;
  subs = new SubSink();
  @ViewChild('toggleElement', {static: true}) toggleElement: MatSlideToggle;

  constructor(
    public fgs: FeatureGuardService,
    private dialog: MatDialog,
    private utilityService: UtilityService,
    private productNotificationService: ProductNotificationService,
    private productCommandService: ProductCommandService,
  ) {
  }

  ngOnInit(): void {
    const {IsActive, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = this.categoryDetails;
    this.setToggleState(
      IsActive,
      IsTemporaryUnavailable,
      TemporaryUnavailableStartTime,
      TemporaryUnavailableEndTime
    );
  }

  categoryStatusUpdate(event: MatSlideToggleChange): void {
    let dialogRef: MatDialogRef<any>;
    // @ts-ignore
    if (this.fgs.isValidFeatureSync([{Key: 'category.update.status.with-temporary-unavailable'}])) {
      dialogRef = this.dialog.open(CategoryListTemporaryUnavailableStatusUpdateDialogComponent, {
        data: {
          title: 'Update Status',
          message: 'Set options to update status',
          buttonText: {
            ok: 'Update',
            cancel: 'Cancel'
          },
          categoryDetails: this.categoryDetails
        }
      });
    } else {
      dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        data: {
          title: 'Confirmation',
          message: 'Are you sure you want to update this category status?',
          buttonText: {
            ok: 'Yes',
            cancel: 'Cancel'
          }
        }
      });
    }

    dialogRef.afterClosed().subscribe((data: any) => {
      if (data) {
        if (typeof data === 'boolean') {
          this.updateStatusForNoTemporaryUnavailableUI(event.checked);
        } else {
          this.updateStatusForTemporaryUnavailableUI(data);
        }
      } else {
        const {IsActive, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = this.categoryDetails;
        this.setToggleState(
          IsActive,
          IsTemporaryUnavailable,
          TemporaryUnavailableStartTime,
          TemporaryUnavailableEndTime
        );
      }
    });
  }

  private updateStatusForNoTemporaryUnavailableUI(checked: boolean): void {
    const categoryObj: ProductCategoryModel = {
      ProductCategoryId: this.categoryDetails?.Id,
      Name: this.categoryDetails?.Name,
      Description: this.categoryDetails?.Description,
      CategoryOrderInCatalogue: this.categoryDetails?.CategoryOrderInCatalogue,
      ProductCatalogueId: this.categoryDetails?.ProductCatalogueId,
      ShopId: this.categoryDetails?.ShopId,
      IsActive: checked,
      IsTemporaryUnavailable: checked ? false : this.categoryDetails.IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: this.categoryDetails?.TemporaryUnavailableStartTime,
      TemporaryUnavailableEndTime: new Date(new Date(this.categoryDetails?.TemporaryUnavailableEndTime || null).setSeconds(59)).toISOString(),
    };
    this.doCategoryStatusUpdate(categoryObj, this.categoryDetails);
  }

  private updateStatusForTemporaryUnavailableUI(data: any): void {
    const tempUnavailable = this.getTemporaryUnavailableData(data);
    const categoryObj: ProductCategoryModel = {
      ProductCategoryId: this.categoryDetails?.Id,
      Name: this.categoryDetails?.Name,
      Description: this.categoryDetails?.Description,
      CategoryOrderInCatalogue: this.categoryDetails?.CategoryOrderInCatalogue,
      ProductCatalogueId: this.categoryDetails?.ProductCatalogueId,
      ShopId: this.categoryDetails?.ShopId,
      IsActive: data?.IsActive,
      IsTemporaryUnavailable: !!tempUnavailable?.IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: tempUnavailable?.TemporaryUnavailableStartTime,
      TemporaryUnavailableEndTime: new Date(new Date(tempUnavailable?.TemporaryUnavailableEndTime || null).setSeconds(59)).toISOString(),
    };
    this.doCategoryStatusUpdate(categoryObj, this.categoryDetails);
  }

  private getTemporaryUnavailableData({IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime}):
    { IsTemporaryUnavailable: boolean, TemporaryUnavailableStartTime: string, TemporaryUnavailableEndTime: string } | null {
    if (!IsTemporaryUnavailable || !TemporaryUnavailableStartTime || !TemporaryUnavailableEndTime) {
      return null;
    }
    if (new Date(TemporaryUnavailableStartTime) > new Date(TemporaryUnavailableEndTime)) {
      return null;
    }

    return {
      IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: new Date(TemporaryUnavailableStartTime).toISOString(),
      TemporaryUnavailableEndTime: new Date(TemporaryUnavailableEndTime).toISOString()
    };
  }

  private doCategoryStatusUpdate(categoryStatusUpdateModel: ProductCategoryModel, categoryDetails: ProductCategoryDataModel): void {
    if (!categoryStatusUpdateModel.IsTemporaryUnavailable) {
      categoryStatusUpdateModel.TemporaryUnavailableStartTime = new Date().toISOString();
      categoryStatusUpdateModel.TemporaryUnavailableEndTime = new Date().toISOString();
    }

    this.setToggleState(
      categoryStatusUpdateModel?.IsActive,
      categoryStatusUpdateModel?.IsTemporaryUnavailable,
      categoryStatusUpdateModel?.TemporaryUnavailableStartTime,
      categoryStatusUpdateModel?.TemporaryUnavailableEndTime);

    const categoryStatusUpdateCommand: ProductCategoryCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      Categories: [categoryStatusUpdateModel]
    };
    this.productNotificationService.productCategoryAvailabilityEvent();
    this.subs.sink = this.productCommandService.updateProductCategoryAvailability(categoryStatusUpdateCommand).subscribe(data => {
      this.categoryDetails.IsActive = categoryStatusUpdateModel.IsActive;
      this.categoryDetails.IsTemporaryUnavailable = categoryStatusUpdateModel.IsTemporaryUnavailable;
      this.categoryDetails.TemporaryUnavailableStartTime = categoryStatusUpdateModel.TemporaryUnavailableStartTime;
      this.categoryDetails.TemporaryUnavailableEndTime = categoryStatusUpdateModel.TemporaryUnavailableEndTime;
    }, error => {
      this.setToggleState(
        categoryDetails?.IsActive,
        categoryDetails?.IsTemporaryUnavailable,
        categoryDetails?.TemporaryUnavailableStartTime,
        categoryDetails?.TemporaryUnavailableEndTime);
    });
  }

  private setToggleState(
    IsActive: boolean,
    IsTemporaryUnavailable: boolean,
    TemporaryUnavailableStartTime: string,
    TemporaryUnavailableEndTime: string): void {
    if (IsActive !== true || !IsTemporaryUnavailable) {
      this.toggleElement.checked = IsActive;
      return;
    }
    const startDate = new Date(TemporaryUnavailableStartTime);
    const endDate = new Date(TemporaryUnavailableEndTime);
    const currentDate = new Date();
    const toggleState = !(startDate <= currentDate && currentDate <= endDate);
    this.toggleElement.checked = toggleState;
  }

}
