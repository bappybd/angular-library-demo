import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryListStatusUpdateComponent } from './category-list-status-update.component';

describe('CategoryListStatusUpdateComponent', () => {
  let component: CategoryListStatusUpdateComponent;
  let fixture: ComponentFixture<CategoryListStatusUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoryListStatusUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoryListStatusUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
