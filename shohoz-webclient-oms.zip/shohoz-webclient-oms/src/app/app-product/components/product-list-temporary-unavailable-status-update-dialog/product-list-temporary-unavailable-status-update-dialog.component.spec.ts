import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductListTemporaryUnavailableStatusUpdateDialogComponent } from './product-list-temporary-unavailable-status-update-dialog.component';

describe('ProductListTemporaryUnavailableStatusUpdateDialogComponent', () => {
  let component: ProductListTemporaryUnavailableStatusUpdateDialogComponent;
  let fixture: ComponentFixture<ProductListTemporaryUnavailableStatusUpdateDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductListTemporaryUnavailableStatusUpdateDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductListTemporaryUnavailableStatusUpdateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
