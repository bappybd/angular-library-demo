import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {ProductItemModel} from '../../models/product-models';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {DomSanitizer} from '@angular/platform-browser';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MatCheckboxChange} from '@angular/material/checkbox';

export interface StatusUpdateDialogModel {
  title: string;
  message: string;
  buttonText: {
    ok: string;
    cancel: string;
  };
  productDetails: ProductItemModel;
}

@Component({
  selector: 'app-product-list-temporary-unavailable-status-update-dialog',
  templateUrl: './product-list-temporary-unavailable-status-update-dialog.component.html',
  styleUrls: ['./product-list-temporary-unavailable-status-update-dialog.component.scss']
})
export class ProductListTemporaryUnavailableStatusUpdateDialogComponent implements OnInit {

  title = '';
  message = 'Update status?';
  confirmButtonText = 'Yes';
  cancelButtonText = 'Cancel';
  productUpdateStatusForm: FormGroup;
  @ViewChild('messageElement', {static: true}) messageElement;

  constructor(
    private sanitizer: DomSanitizer,
    @Inject(MAT_DIALOG_DATA) private data: StatusUpdateDialogModel,
    private dialogRef: MatDialogRef<ProductListTemporaryUnavailableStatusUpdateDialogComponent>,
    private fb: FormBuilder
  ) {
    if (data) {
      this.title = data.title || this.title;
      this.message = data.message || this.message;
      if (data.buttonText) {
        this.confirmButtonText = data.buttonText.ok || this.confirmButtonText;
        this.cancelButtonText = data.buttonText.cancel || this.cancelButtonText;
      }
    }
    this.buildForm(this.data.productDetails);
  }

  ngOnInit(): void {
  }

  private buildForm(productDetails: ProductItemModel): void {
    this.productUpdateStatusForm = this.fb.group({
      IsActive: [productDetails.IsActive],
      IsTemporaryUnavailable: [productDetails.IsTemporaryUnavailable],
      TemporaryUnavailableStartTime: [new Date()],
      TemporaryUnavailableEndTime: [productDetails.IsTemporaryUnavailable ?
        productDetails.TemporaryUnavailableEndTime : this.getTodayMidnightDate(),
        productDetails.IsTemporaryUnavailable ? [Validators.required] : null]
    });
  }

  private getTodayMidnightDate(): Date {
    const date = new Date();
    date.setHours(23, 59, 59, 999);
    return date;
  }

  updateValidationForOtherFields(event: MatCheckboxChange, fieldNames: string[], validatorNames: string[]): void {
    const fieldsToSetValidation: AbstractControl[] = fieldNames.map(fieldName => this.productUpdateStatusForm.get(fieldName));
    const validators = validatorNames.map(name => Validators[name]);
    if (event && event.checked) {
      //   Set Validators
      fieldsToSetValidation.forEach(field => {
        field.setValidators(validators);
        field.updateValueAndValidity();
      });
    } else {
      //  Clear Validators
      fieldsToSetValidation.forEach(field => {
        field.clearValidators();
        field.updateValueAndValidity();
        field.setErrors(null);
      });
    }
  }

  onConfirmClick(): void {
    const formData = this.productUpdateStatusForm.value;
    this.dialogRef.close(formData);
  }

  onStatusChange(value: boolean): void {
    if (value) {
      return;
    }
    this.productUpdateStatusForm.get('IsTemporaryUnavailable').setValue(false);
  }
}
