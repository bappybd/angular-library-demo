import {AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {CustomizationTag, CustomizationType, NumberOfItemType} from '../../../shared/models/product-entity-models';
import {EevoValidator} from '../../../shared/validator/eevo.validator';
import {SubSink} from 'subsink';
import {
  CustomizationTagData, CustomizationTagPrefillData,
  NumberOfCustomizationTypeListData,
  OriginalNumberOfItemTypeListData
} from '../../const/product-customization.const';
import {MatSelectChange} from '@angular/material/select';
import {merge, Observable, Subscription} from 'rxjs';
import {debounceTime, filter, map, take} from 'rxjs/operators';

@Component({
  selector: 'app-product-customization',
  templateUrl: './product-customization.component.html',
  styleUrls: ['./product-customization.component.scss']
})
export class ProductCustomizationComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input()
  index: number;
  @Input()
  parent: FormGroup;
  NumberOfItemTypeList: { value: NumberOfItemType; display: string }[];
  OriginalNumberOfItemTypeList = OriginalNumberOfItemTypeListData;
  NumberOfCustomizationTypeList = NumberOfCustomizationTypeListData;
  CustomizationTags: CustomizationTag[] = CustomizationTagData;
  subs = new SubSink();
  tagSubs = new SubSink();
  private tagRelatedChangeSubscriptions: Subscription;

  constructor(private formBuilder: FormBuilder, private cdr: ChangeDetectorRef) {
  }

  ngOnInit(): void {
    if (this.parent.get('Customizations').get(this.index + '').get('IsOptional').value) {
      this.makeNumberOfItemTypeOnlyMaximum();
    } else {
      this.NumberOfItemTypeList = this.OriginalNumberOfItemTypeList;
    }

    this.listenToCustomizationTagRelatedDataChange();
  }

  ngAfterViewInit(): void {
    this.cdr.detectChanges();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
    this.tagRelatedChangeSubscriptions?.unsubscribe();
    this.tagSubs.unsubscribe();
  }

  customizationTypeChange($event, index): void {
    if ($event && $event.value === 'Single') {
      const minSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MinSelectableItemCount');
      minSelectableItemCount.clearValidators();
      minSelectableItemCount.setErrors(null);
      minSelectableItemCount.updateValueAndValidity();

      const maxSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MaxSelectableItemCount');
      maxSelectableItemCount.clearValidators();
      maxSelectableItemCount.setErrors(null);
      maxSelectableItemCount.updateValueAndValidity();

      const exactSelectableItemCount = this.parent.get('Customizations').get(index + '').get('ExactSelectableItemCount');
      exactSelectableItemCount.clearValidators();
      exactSelectableItemCount.setErrors(null);
      exactSelectableItemCount.updateValueAndValidity();
    } else {
      const customizationType = this.parent.get('Customizations').get(index + '').get('NumberOfItemType').value;
      this.numberOfItemToSelectTypeChange({value: customizationType}, index);
    }
    this.setValidatorOnMaxSelectableItemCount(index);
  }

  itemsOfCustomizationIncludedChange($event, index, i): void {
    const customization = this.parent.get('Customizations').get(index + '');
    const customizationTag = customization.get('CustomizationTag').value;
    const itemPrice = customization.get('Items').get(i + '').get('ItemPrice');
    if ($event && $event.checked) {
      itemPrice.clearValidators();
      itemPrice.setErrors(null);
      itemPrice.setValue(0);
      itemPrice.disable();
      if (['Addons', 'Variation'].includes(customizationTag)) {
        customization.get('CustomizationTag').setValue('');
      }
    } else {
      itemPrice.setValidators([Validators.required]);
      itemPrice.updateValueAndValidity();
      itemPrice.setValue(null);
      itemPrice.enable();

      if (['Choices'].includes(customizationTag)) {
        customization.get('CustomizationTag').setValue('');
      }
    }
  }

  itemsOfCustomizationIncluded(index, i): boolean {
    return this.parent.get('Customizations').get(index + '').get('Items').get(i + '').get('Included').value;
  }

  numberOfItemToSelectTypeChange($event, index): void {
    const minSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MinSelectableItemCount');
    const maxSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MaxSelectableItemCount');
    const exactSelectableItemCount = this.parent.get('Customizations').get(index + '').get('ExactSelectableItemCount');

    this.clearItemCountValidators([minSelectableItemCount, maxSelectableItemCount, exactSelectableItemCount]);

    if ($event && $event.value === 'Minimum') {
      minSelectableItemCount.setValidators([Validators.required]);
      minSelectableItemCount.updateValueAndValidity();
    } else if ($event && $event.value === 'Maximum') {
      maxSelectableItemCount.setValidators([Validators.required, Validators.min(1)]);
      maxSelectableItemCount.updateValueAndValidity();
    } else if ($event && $event.value === 'Exact') {
      exactSelectableItemCount.setValidators([Validators.required, Validators.min(2)]);
      exactSelectableItemCount.updateValueAndValidity();
    } else {
      minSelectableItemCount.setValidators([Validators.required, Validators.min(1)]);
      minSelectableItemCount.updateValueAndValidity();
      maxSelectableItemCount.setValidators([Validators.required, Validators.min(1), EevoValidator.greaterThanOrEqual('MinSelectableItemCount')]);
      maxSelectableItemCount.updateValueAndValidity();
      this.subs.sink = minSelectableItemCount.valueChanges.subscribe(value => {
        maxSelectableItemCount.setValidators([Validators.required, Validators.min(2), EevoValidator.greaterThanOrEqual('MinSelectableItemCount')]);
        maxSelectableItemCount.updateValueAndValidity();
      });
    }
  }

  private clearItemCountValidators(controls: AbstractControl[]): void {
    this.subs.unsubscribe();
    controls.forEach((control, index) => {
      control.clearValidators();
      control.updateValueAndValidity();
      control.setErrors(null);
    });
  }

  numberOfItemToSelectType(index: number): any {
    return this.parent.get('Customizations').get(index + '').get('NumberOfItemType').value;
  }

  get itemsOfCustomization(): AbstractControl[] {
    const customization = this.parent.get('Customizations') as FormArray;
    return (customization.controls[this.index].get('Items') as FormArray)
      .controls;
  }

  get numberOfSlot(): number {
    const {length} = this.itemsOfCustomization;
    return length;
  }

  addControl(): void {
    const customizationTag = this.parent.get('Customizations').get(this.index.toString()).get('CustomizationTag').value;
    const customization = this.parent.get('Customizations') as FormArray;
    const items = customization.controls[this.index].get('Items') as FormArray;
    items.push(this.createItemForm(CustomizationTagPrefillData[customizationTag]?.Included));
  }

  isItemFormValid(): boolean {
    const customization = this.parent.get('Customizations') as FormArray;
    const items = customization.controls[this.index].get('Items') as FormArray;
    return items.valid;
  }

  createItemForm(isIncluded?: boolean): FormGroup {
    return this.formBuilder.group({
      CustomizationItemName: ['', [Validators.required, EevoValidator.cannotWhiteSpace]],
      ItemPrice: [{value: null, disabled: isIncluded}, [Validators.required]],
      Included: [isIncluded || false]
    });
  }

  removeControl(index: number): void {
    const customization = this.parent.get('Customizations') as FormArray;
    const items = customization.controls[this.index].get('Items') as FormArray;
    items.removeAt(index);
  }

  isOptionalItemChanged($event: any, index: number): void {
    const minSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MinSelectableItemCount');
    const maxSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MaxSelectableItemCount');
    const exactSelectableItemCount = this.parent.get('Customizations').get(index + '').get('ExactSelectableItemCount');

    if ($event.checked) {
      this.clearItemCountValidators([minSelectableItemCount, maxSelectableItemCount, exactSelectableItemCount]);
      this.makeNumberOfItemTypeOnlyMaximum();
    } else {
      this.NumberOfItemTypeList = this.OriginalNumberOfItemTypeList;
    }
    this.setValidatorOnMaxSelectableItemCount(index);
  }

  makeNumberOfItemTypeOnlyMaximum(): void {
    this.parent.get('Customizations').get(this.index + '').get('NumberOfItemType').setValue(NumberOfItemType.Maximum);
    this.NumberOfItemTypeList = this.OriginalNumberOfItemTypeList.filter(t => t.value === NumberOfItemType.Maximum);
  }

  private setValidatorOnMaxSelectableItemCount(index: number): void {
    setTimeout(() => {
      const maxSelectableItemCount = this.parent.get('Customizations').get(index + '').get('MaxSelectableItemCount');
      const customization = this.parent.get('Customizations').get(index + '').value;
      if (customization?.CustomizationType === 'Multiple' && customization?.IsOptional) {
        maxSelectableItemCount.setValidators([Validators.required, Validators.min(1)]);
        maxSelectableItemCount.updateValueAndValidity();
      }
    }, 500);
  }

  onCustomizationTagChange($event: MatSelectChange): void {
    this.tagRelatedChangeSubscriptions?.unsubscribe();
    const selectedTag = $event.value as string;
    const customizationFormGroup = this.parent.get('Customizations').get(this.index.toString());
    customizationFormGroup.valueChanges.pipe(take(1)).subscribe(res => {
      this.tagSubs.unsubscribe();
      this.listenToCustomizationTagRelatedDataChange();
    });

    const properties = (({Included, ...o}) => o)(CustomizationTagPrefillData[selectedTag]); // remove b and c
    customizationFormGroup.patchValue(properties || {});
    this.setIncludesForAllChoicesItem(CustomizationTagPrefillData[selectedTag]?.Included);

    if (CustomizationTagPrefillData[selectedTag]?.IsOptional !== undefined) {
      this.isOptionalItemChanged({checked: !!CustomizationTagPrefillData[selectedTag]?.IsOptional}, this.index);
    }

    if (CustomizationTagPrefillData[selectedTag]?.CustomizationType !== undefined) {
      this.customizationTypeChange({value: CustomizationTagPrefillData[selectedTag]?.CustomizationType}, this.index);
    }
  }

  private setIncludesForAllChoicesItem(included?: boolean): void {
    const customizationFormGroup = this.parent.get('Customizations').get(this.index.toString());
    const itemForms = customizationFormGroup.get('Items') as FormArray;
    for (const form of itemForms.controls) {
      if (included === true) {
        form.get('Included').setValue(included);
        form.get('ItemPrice').setValue(null);
        form.get('ItemPrice').disable();
      } else if (included === false) {
        form.get('Included').setValue(included);
        form.get('ItemPrice').enable();
      }
    }
  }

  private listenToCustomizationTagRelatedDataChange(): void {
    const customizationFormGroup = this.parent.get('Customizations').get(this.index.toString());
    let customizationTagValue = customizationFormGroup.get('CustomizationTag').value;

    const valueChanges: Observable<any>[] = [];
    valueChanges.push(customizationFormGroup.get('IsOptional').valueChanges.pipe(map(res => ['IsOptional', res])));
    valueChanges.push(customizationFormGroup.get('CustomizationType').valueChanges.pipe(map(res => ['CustomizationType', res])));
    valueChanges.push(customizationFormGroup.get('NumberOfItemType').valueChanges.pipe(map(res => ['NumberOfItemType', res])));
    valueChanges.push(customizationFormGroup.get('MaxSelectableItemCount').valueChanges.pipe(map(res => ['MaxSelectableItemCount', res])));

    this.tagSubs.sink = this.tagRelatedChangeSubscriptions = merge(...valueChanges)
      .pipe(
        filter(res => !!customizationTagValue),
      )
      .subscribe(res => {
        const prefillData = CustomizationTagPrefillData[customizationFormGroup.get('CustomizationTag').value][res[0]];
        if (prefillData !== null && prefillData !== res[1]) {
          customizationFormGroup.patchValue({CustomizationTag: ''});
          customizationTagValue = '';
        }
      });
  }
}
