import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryListTemporaryUnavailableStatusUpdateDialogComponent } from './category-list-temporary-unavailable-status-update-dialog.component';

describe('CategoryListTemporaryUnavailableStatusUpdateDialogComponent', () => {
  let component: CategoryListTemporaryUnavailableStatusUpdateDialogComponent;
  let fixture: ComponentFixture<CategoryListTemporaryUnavailableStatusUpdateDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoryListTemporaryUnavailableStatusUpdateDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoryListTemporaryUnavailableStatusUpdateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
