import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  ViewChildren
} from '@angular/core';
import {SubSink} from 'subsink';
import {ProductCategoriesModel, ProductItemActiveModel, ProductItemModel} from '../../models/product-models';
import {MatDialog} from '@angular/material/dialog';
import {ProductEntity} from '../../entities/product-entity';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductNotificationService} from '../../services/product-notification.service';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {MatSlideToggleChange} from '@angular/material/slide-toggle';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {ActiveProductCommand} from '../../models/product-command';

@Component({
  selector: 'app-filtered-product-list-item',
  templateUrl: './filtered-product-list-item.component.html',
  styleUrls: ['./filtered-product-list-item.component.scss']
})
export class FilteredProductListItemComponent implements OnInit, OnDestroy {

  takaSymbol = '‎৳';
  private subs = new SubSink();

  @Input()
  productCategory: ProductCategoriesModel;

  @Input()
  productItem: ProductItemModel;

  @Output()
  onItemUpdate: EventEmitter<any> = new EventEmitter();

  constructor(
    private dialog: MatDialog,
    private productEntity: ProductEntity,
    public fgs: FeatureGuardService
  ) {
  }

  ngOnInit(): void {
  }

  updateItem(product: ProductItemModel): void {
    this.onItemUpdate.emit({
      category: {
        Name: this.productCategory.ProductCategoryName,
        Id: this.productCategory.ProductCategoryId,
        ShopId: this.productItem.ShopId,
        ProductCatalogueId: this.productItem.ProductCatalogueId
      },
      product
    });
  }

  getFileKey(productItem: ProductItemModel): string {
    return this.productEntity.getFileKey(productItem.Id, 'item');
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

}
