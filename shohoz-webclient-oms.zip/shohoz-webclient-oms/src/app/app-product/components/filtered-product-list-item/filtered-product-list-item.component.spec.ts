import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredProductListItemComponent } from './filtered-product-list-item.component';

describe('FilteredProductListItemComponent', () => {
  let component: FilteredProductListItemComponent;
  let fixture: ComponentFixture<FilteredProductListItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredProductListItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredProductListItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
