import {Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewEncapsulation} from '@angular/core';
import {AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, Validators} from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import {FuseSidebarService} from '@eevo/eevo-base';
import {EevoFileUploadService, EevoNotifyService, FilesModel, NotifyType, UtilityService} from '@eevo/eevo-core';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductCategoryDataModel, ProductItemModel} from '../../models/product-models';
import {forkJoin} from 'rxjs';
import {ProductFormBuilderService} from '../../services/product-form-builder.service';
import {ProductQueryService} from '../../services/product-query.service';
import {ProductCommandBuilderService} from '../../services/product-command-builder.service';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {ProductEntity} from '../../entities/product-entity';
import {MatDialog} from '@angular/material/dialog';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {ScheduleHourOptions} from '../../../shared/components/schedule-hour/schedule-hour.options';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {SubSink} from 'subsink';

@Component({
  selector: 'app-update-item',
  templateUrl: './update-item.component.html',
  styleUrls: ['./update-item.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class UpdateItemComponent implements OnInit, OnDestroy {
  updateItemForm: FormGroup;
  formSubmitted = false;
  itemFiles: FilesModel;
  loadingFromServer = true;
  private subs = new SubSink();
  scheduleHourOptions = {
    startTimeLabel: 'Available from',
    endTimeLabel: 'Available to',
    hourOverlapValidationRequired: true,
    sameForAllDaysRequired: true,
    atLeastOneDayRequired: true
  } as ScheduleHourOptions;
  @Output() itemCreated: EventEmitter<boolean> = new EventEmitter<boolean>(false);

  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private fuseSidebarService: FuseSidebarService,
    private utilityService: UtilityService,
    private eevoNotifyService: EevoNotifyService,
    private eevoFileUploadService: EevoFileUploadService,
    private signalrNotificationService: SignalrNotificationService,
    private productEntity: ProductEntity,
    private productQueryService: ProductQueryService,
    private productCommandService: ProductCommandService,
    private productNotificationService: ProductNotificationService,
    private productFormBuilderService: ProductFormBuilderService,
    private productCommandBuilderService: ProductCommandBuilderService,
    private dialog: MatDialog,
    public fgs: FeatureGuardService
  ) {
    this.itemFiles = new FilesModel();
  }

  private _shopDetails;
  @Input()
  set shopDetails(value: any) {
    this._shopDetails = value;
  }
  get shopDetails(): any {
    return this._shopDetails;
  }

  private _category: ProductCategoryDataModel;
  @Input()
  set category(value: ProductCategoryDataModel) {
    this._category = value;
  }

  get category(): ProductCategoryDataModel {
    return this._category;
  }

  private _item: ProductItemModel;

  @Input()
  set item(value: ProductItemModel) {
    setTimeout(() => { // making asynchronous for a reason
      this.loadingFromServer = true;
      this.subs.sink = this.productQueryService.getProduct(value.Id).subscribe(data => {
        this._item = data;
        this.loadingFromServer = false;
        this.initItemUpdateForm();
        this.prepTimeValidation();
      });
    });
  }

  get item(): ProductItemModel {
    return this._item;
  }

  ngOnInit(): void {
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  prepTimeValidation(): void {
    if (this.shopDetails.IsHomeCook) {
      this.updateItemForm.controls.PreparationTime.setValidators(Validators.required);
    }
  }

  initItemUpdateForm(): void {
    this.updateItemForm = this.productFormBuilderService.getForm(this._category, this._item);
  }

  discard(key: string): void {
     this.initItemUpdateForm();
     this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  toggleSidebarOpen(key: string): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  updateItem(): void {
    this.updateItemForm.markAllAsTouched();
    if (this.updateItemForm.valid) {
      this.formSubmitted = true;
      this.eevoNotifyService.displayMessage(this.productEntity.getMessages().UPDATE_REQUEST, NotifyType.Info);
      this.productNotificationService.productUpdated();
      this.subs.sink = forkJoin(this.getProductUpdateCalls()).subscribe(data => {
        this.formSubmitted = false;
        this.fuseSidebarService.getSidebar('updateItemPanel').close();
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
        this.fuseSidebarService.getSidebar('updateItemPanel').toggleOpen();
      });
    }
  }

  private getProductUpdateCalls(): any[] {
    const calls = [];
    calls.push(
      this.productCommandService.updateItem(
        this.productCommandBuilderService.getProductCommand(this.updateItemForm, this.category, this.item)
      )
    );
    if (this.itemFiles.Files.length > 0) {
      calls.push(
        this.eevoFileUploadService.uploadPublicImages(
          this.signalrNotificationService,
          this.productEntity.getFolderName(),
          this.item.Id,
          this.itemFiles
        )
      );
    }

    return calls;
  }

  addCustomizationForm(): void {
   // this.isExpanded = true;
    const customizations = this.updateItemForm.get('Customizations') as FormArray;
    const customizationForm = this.productFormBuilderService.getProductCustomizationForm();
    customizationForm.get('Expanded').setValue(true);
    customizations.push(customizationForm);
    customizations.updateValueAndValidity();
  }

  get customizations(): AbstractControl[] {
    return (this.updateItemForm.get('Customizations') as FormArray).controls;
  }

  getCustomizationTitle(idx: number): string{
    const customizationFormValue =  (this.updateItemForm.get('Customizations') as FormArray).controls[idx].value;
    const totalCustomizationItems = customizationFormValue.Items.length;
    return customizationFormValue.CustomizationName;
  }

  getTotalCustomizationItems(idx: number): string{
    const customizationFormValue =  (this.updateItemForm.get('Customizations') as FormArray).controls[idx].value;
    const totalCustomizationItems = customizationFormValue.Items.length;
    return `(${totalCustomizationItems} items)`;
  }

  get numberOfCustomizations(): number {
    return (this.updateItemForm.get('Customizations') as FormArray).length;
  }

  removeControl(index: number): void {
    const customization = this.updateItemForm.get('Customizations') as FormArray;
    customization.removeAt(index);
  }

  openDialog(index: number): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent,{
      data: {
        title: 'Confirmation',
        message: 'Are you sure you want to delete this customization?',
        buttonText: {
          ok: 'Yes',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.removeControl(index);
      }
    });
  }

  IsExpanded(idx: number) {
    const customizationFormValue =  (this.updateItemForm.get('Customizations') as FormArray).controls[idx].value;
    return customizationFormValue.Expanded;
  }

  onStatusChange(value: boolean): void {
    if (value) {
      return;
    }
    this.updateItemForm.get('IsTemporaryUnavailable').setValue(false);
  }
}
