import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductListStatusUpdateComponent } from './product-list-status-update.component';

describe('ProductListStatusUpdateComponent', () => {
  let component: ProductListStatusUpdateComponent;
  let fixture: ComponentFixture<ProductListStatusUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductListStatusUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductListStatusUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
