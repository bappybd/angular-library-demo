import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {ProductItemActiveModel, ProductItemModel} from '../../models/product-models';
import {SubSink} from 'subsink';
import {MatSlideToggle, MatSlideToggleChange} from '@angular/material/slide-toggle';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {MatDialog} from '@angular/material/dialog';
import {MatDialogRef} from '@angular/material/dialog/dialog-ref';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {ProductListTemporaryUnavailableStatusUpdateDialogComponent} from '../product-list-temporary-unavailable-status-update-dialog/product-list-temporary-unavailable-status-update-dialog.component';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductCommandService} from '../../services/product-command.service';
import {ActiveProductCommand} from '../../models/product-command';

@Component({
  selector: 'app-product-list-status-update',
  templateUrl: './product-list-status-update.component.html',
  styleUrls: ['./product-list-status-update.component.scss']
})
export class ProductListStatusUpdateComponent implements OnInit {
  @Input() set product(data: ProductItemModel) {
    this.productDetails = data;
  }

  productDetails: ProductItemModel;
  subs = new SubSink();
  @ViewChild('toggleElement', {static: true}) toggleElement: MatSlideToggle;

  constructor(
    public fgs: FeatureGuardService,
    private dialog: MatDialog,
    private productNotificationService: ProductNotificationService,
    private productCommandService: ProductCommandService,
  ) {
  }

  ngOnInit(): void {
    const {IsActive, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = this.productDetails;
    this.setToggleState(IsActive, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime);
  }

  productStatusUpdate(event: MatSlideToggleChange): void {
    let dialogRef: MatDialogRef<any>;
    // @ts-ignore
    if (this.fgs.isValidFeatureSync([{Key: 'product.update.status.with-temporary-unavailable'}])) {
      dialogRef = this.dialog.open(ProductListTemporaryUnavailableStatusUpdateDialogComponent, {
        data: {
          title: 'Update Status',
          message: 'Set options to update status',
          buttonText: {
            ok: 'Update',
            cancel: 'Cancel'
          },
          productDetails: this.productDetails
        }
      });
    } else {
      dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        data: {
          title: 'Confirmation',
          message: 'Are you sure you want to update this item status?',
          buttonText: {
            ok: 'Yes',
            cancel: 'Cancel'
          }
        }
      });
    }

    dialogRef.afterClosed().subscribe((data: any) => {
      if (data) {
        if (typeof data === 'boolean') {
          this.updateStatusForNoTemporaryUnavailableUI(event.checked);
        } else {
          this.updateStatusForTemporaryUnavailableUI(data);
        }
      } else {
        const {IsActive, IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime} = this.productDetails;
        this.setToggleState(
          IsActive,
          IsTemporaryUnavailable,
          TemporaryUnavailableStartTime,
          TemporaryUnavailableEndTime
        );
      }
    });
  }

  private doProductStatusUpdate(productStatusUpdateModel: ProductItemActiveModel, product: ProductItemModel): void {
    if (!productStatusUpdateModel.IsTemporaryUnavailable) {
      productStatusUpdateModel.TemporaryUnavailableStartTime  = new Date().toISOString();
      productStatusUpdateModel.TemporaryUnavailableEndTime = new Date().toISOString();
    }

    this.setToggleState(
      productStatusUpdateModel?.IsActive,
      productStatusUpdateModel?.IsTemporaryUnavailable,
      productStatusUpdateModel?.TemporaryUnavailableStartTime,
      productStatusUpdateModel?.TemporaryUnavailableEndTime);

    const command = new ActiveProductCommand();
    command.Products = [productStatusUpdateModel];

    this.productNotificationService.productAvailabilityEvent();
    this.subs.sink = this.productCommandService.updateProductAvailability(command).subscribe(data => {
      this.productDetails.IsActive = productStatusUpdateModel.IsActive;
      this.productDetails.IsTemporaryUnavailable = productStatusUpdateModel.IsTemporaryUnavailable;
      this.productDetails.TemporaryUnavailableStartTime  = productStatusUpdateModel.TemporaryUnavailableStartTime;
      this.productDetails.TemporaryUnavailableEndTime = productStatusUpdateModel.TemporaryUnavailableEndTime;
    }, error => {
      this.setToggleState(
        productStatusUpdateModel?.IsActive,
        productStatusUpdateModel?.IsTemporaryUnavailable,
        productStatusUpdateModel?.TemporaryUnavailableStartTime,
        productStatusUpdateModel?.TemporaryUnavailableEndTime);
    });
  }

  private setToggleState(
    IsActive: boolean,
    IsTemporaryUnavailable: boolean,
    TemporaryUnavailableStartTime: string | Date,
    TemporaryUnavailableEndTime: string | Date): void {
    if (IsActive !== true || !IsTemporaryUnavailable) {
      this.toggleElement.checked = IsActive;
      return;
    }
    const startDate = new Date(TemporaryUnavailableStartTime);
    const endDate = new Date(TemporaryUnavailableEndTime);
    const currentDate = new Date();
    const toggleState = !(startDate <= currentDate && currentDate <= endDate);
    this.toggleElement.checked = toggleState;
  }

  private updateStatusForNoTemporaryUnavailableUI(checked: boolean): void {
    const productObj: ProductItemActiveModel = {
      ProductCatalogueId: this.productDetails?.ProductCatalogueId,
      ProductCategoryId: this.productDetails?.ProductCategories[0]?.ProductCategoryId,
      ProductId: this.productDetails?.Id,
      ShopId: this.productDetails?.ShopId,
      IsActive: checked,
      IsTemporaryUnavailable: checked ? false : this.productDetails?.IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: this.productDetails?.TemporaryUnavailableStartTime,
      TemporaryUnavailableEndTime: new Date(new Date(this.productDetails?.TemporaryUnavailableEndTime || null).setSeconds(59)).toISOString(),
    };
    this.doProductStatusUpdate(productObj, this.productDetails);
  }

  private updateStatusForTemporaryUnavailableUI(data: any): void {
    const tempUnavailable = this.getTemporaryUnavailableData(data);
    const productObj: any = {
      ProductCatalogueId: this.productDetails?.ProductCatalogueId,
      ProductCategoryId: this.productDetails?.ProductCategories[0]?.ProductCategoryId,
      ProductId: this.productDetails?.Id,
      ShopId: this.productDetails?.ShopId,
      IsActive: data?.IsActive,
      IsTemporaryUnavailable: !!tempUnavailable?.IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: tempUnavailable?.TemporaryUnavailableStartTime,
      TemporaryUnavailableEndTime: new Date(new Date(tempUnavailable?.TemporaryUnavailableEndTime || null).setSeconds(59)),
    };

    this.doProductStatusUpdate(productObj, this.productDetails);
  }

  private getTemporaryUnavailableData({IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime}):
    { IsTemporaryUnavailable: boolean, TemporaryUnavailableStartTime: string, TemporaryUnavailableEndTime: string } | null {
    if (!IsTemporaryUnavailable || !TemporaryUnavailableStartTime || !TemporaryUnavailableEndTime) {
      return null;
    }
    if (new Date(TemporaryUnavailableStartTime) > new Date(TemporaryUnavailableEndTime)) {
      return null;
    }

    return {
      IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: new Date(TemporaryUnavailableStartTime).toISOString(),
      TemporaryUnavailableEndTime: new Date(TemporaryUnavailableEndTime).toISOString()
    };
  }
}
