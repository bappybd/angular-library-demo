import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {FuseSidebarService} from '@eevo/eevo-base';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {EevoNotifyService, NotifyType, UtilityService} from '@eevo/eevo-core';
import {ActivatedRoute} from '@angular/router';
import {concatMap} from 'rxjs/operators';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductQueryService} from '../../services/product-query.service';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductCatalogueModel, ProductCategoryModel} from '../../../shared/models/product-entity-models';
import {ProductCategoryEntity} from '../../entities/product-category-entity';
import {SubSink} from 'subsink';
import {MatCheckboxChange} from '@angular/material/checkbox';

@Component({
  selector: 'app-create-category',
  templateUrl: './create-category.component.html',
  styleUrls: ['./create-category.component.scss']
})
export class CreateCategoryComponent implements OnInit, OnDestroy {
  createCategoryForm: FormGroup;
  shopId: string;
  @Output() categoryCreated: EventEmitter<boolean> = new EventEmitter<boolean>(false);
  isFormSubmitted = false;
  private subs = new SubSink();

  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private utilityService: UtilityService,
    private fuseSidebarService: FuseSidebarService,
    private eevoNotifyService: EevoNotifyService,
    private productCategoryEntity: ProductCategoryEntity,
    private menuQueryService: ProductQueryService,
    private menuCommandService: ProductCommandService,
    private productNotificationService: ProductNotificationService,
  ) {
  }

  ngOnInit(): void {
    this.subs.sink = this.activatedRoute.params.subscribe(params => {
      this.shopId = params.id;
    });
    this.initCategoryCreationForm();
  }

  initCategoryCreationForm(): void {
    this.createCategoryForm = this.formBuilder.group({
      name: ['', Validators.required],
      description: [''],
      order: [99, Validators.required],
      isActive: [false],
      IsTemporaryUnavailable: [false],
      TemporaryUnavailableStartTime: [new Date()],
      TemporaryUnavailableEndTime: [this.getTodayMidnightDate()],
    });
  }

  private getTodayMidnightDate(): Date {
    const date = new Date();
    date.setHours(23, 59, 59, 999);
    return date;
  }

  toggleSidebarOpen(key: string): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  saveCategory(): void {
    this.createCategoryForm.markAllAsTouched();
    if (this.createCategoryForm.valid) {
      this.isFormSubmitted = true;
      this.productNotificationService.productCategoryCreated();
      this.eevoNotifyService.displayMessage(
        this.productCategoryEntity.getMessages().CREATE_REQUEST,
        NotifyType.Info
      );

      this.subs.sink = this.menuQueryService.getProductCatalogue(this.shopId).pipe(
        concatMap((response: ProductCatalogueModel) => {
            const category: ProductCategoryModel = {
              ProductCategoryId: this.utilityService.getNewGuid(),
              Name: this.createCategoryForm.get('name').value,
              Description: this.createCategoryForm.get('description').value,
              CategoryOrderInCatalogue: Number(this.createCategoryForm.get('order').value),
              ProductCatalogueId: response.Id,
              ShopId: response.ShopId,
              IsActive: Boolean(this.createCategoryForm.get('isActive').value)
            };

            if (this.createCategoryForm.get('IsTemporaryUnavailable').value) {
              category.IsTemporaryUnavailable = this.createCategoryForm.get('IsTemporaryUnavailable').value;
              category.TemporaryUnavailableStartTime  = this.createCategoryForm.get('TemporaryUnavailableStartTime').value;
              category.TemporaryUnavailableEndTime = this.createCategoryForm.get('TemporaryUnavailableEndTime').value;
            }

            return this.menuCommandService.createCategory({
              CorrelationId: this.utilityService.getNewGuid(),
              Categories: [
                category
              ]
            });
          }
        )
      ).subscribe(response => {
        this.fuseSidebarService.getSidebar('createCategoryPanel').close();
        this.isFormSubmitted = false;
        this.categoryCreated.emit(true);
        this.initCategoryCreationForm();
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.isFormSubmitted = false;
      });
    }

  }

  discard(key: string): void {
    this.initCategoryCreationForm();
    // this.createCategoryForm.reset();
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  updateValidationForOtherFields(event: MatCheckboxChange, fieldNames: string[], validatorNames: string[]): void {
    const fieldsToSetValidation: AbstractControl[] = fieldNames.map(fieldName => this.createCategoryForm.get(fieldName));
    const validators = validatorNames.map(name => Validators[name]);
    if (event && event.checked) {
      //   Set Validators
      fieldsToSetValidation.forEach(field => {
        field.setValidators(validators);
        field.updateValueAndValidity();
      });
    } else {
      //  Clear Validators
      fieldsToSetValidation.forEach(field => {
        field.clearValidators();
        field.updateValueAndValidity();
        field.setErrors(null);
      });
    }
  }

  onStatusChange(value: boolean): void {
    if (value) {
      return;
    }
    this.createCategoryForm.get('IsTemporaryUnavailable').setValue(false);
  }
}
