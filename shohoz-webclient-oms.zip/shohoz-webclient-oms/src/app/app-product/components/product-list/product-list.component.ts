import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {ProductCategoryDataModel, ProductItemModel} from '../../models/product-models';
import {fuseAnimations} from '@eevo/eevo-base';
import {SubSink} from 'subsink';
import {ProductQueryService} from '../../services/product-query.service';
import {debounceTime, filter, tap} from 'rxjs/operators';
import {ProductEntity} from '../../entities/product-entity';
import {ProductNotificationService} from '../../services/product-notification.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss'],
  animations: fuseAnimations
})
export class ProductListComponent implements OnInit, OnDestroy {
  @Input()
  category: ProductCategoryDataModel;

  @Input()
  searchKey: string;

  @Output()
  onItemUpdate: EventEmitter<any> = new EventEmitter();

  productLoading: boolean;

  subs = new SubSink();

  pageData = {
    pageSize: 25,
    pageNumber: 0,
    totalPages: 0,
    total: 0,
    hasNextPage: false
  };

  constructor(
    private productQueryService: ProductQueryService,
    private productEntity: ProductEntity,
    private productNotificationService: ProductNotificationService,
  ) {
  }

  ngOnInit(): void {
    this.listenToProductEvents();
    this.getProducts();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  updateItem($event: any): void {
    this.onItemUpdate.emit($event);
  }

  getProducts(pageSize = this.pageData.pageSize, pageNumber = this.pageData.pageNumber): void {
    this.productLoading = true;
    this.subs.sink = this.productQueryService
      .getProductListByCategoryIdAndName(this.category.Id, this.searchKey, pageSize, pageNumber)
      .subscribe(([data, count]) => {
        if (pageNumber) {
          this.category.Products.push(...data);
        } else {
          this.category.Products = [...data];
        }
        this.category.Expanded = true;
        this.productLoading = false;
        this.calculatePageData(data, count);
      });
  }

  private calculatePageData(data: ProductItemModel[], count: number): void {
    this.pageData.pageNumber++;
    this.pageData.total = count;
    this.pageData.totalPages = Math.ceil(this.pageData.total / this.pageData.pageSize);
    this.pageData.hasNextPage = this.pageData.pageNumber < this.pageData.totalPages;
  }

  private listenToProductEvents(): void {
    this.productNotificationService.productActiveEvent();
    this.productNotificationService.productCreated();
    this.productNotificationService.productUpdated();
    const actionNamesToListen = [
      this.productEntity.Events.ProductCreatedEvent,
      this.productEntity.Events.ProductUpdatedEvent,
      this.productEntity.Events.ProductActiveEvent,
      this.productEntity.Events.ProductAvailabilityEvent,
    ];
    this.subs.sink = this.productNotificationService.onReceived()
      .pipe(filter(event => !!actionNamesToListen.includes(this.productEntity.Events[event?.ActionName])),)
      .subscribe(data => {
        if (data?.ActionName === this.productEntity.Events.ProductCreatedEvent) {
          this.getProducts(this.pageData.total + 1, 0);
        } else {
          this.getProducts(this.pageData.total, 0);
        }
      });
  }
}
