import {Component, Input, OnInit} from '@angular/core';
import * as _ from 'lodash';
import {EevoStorageService, FilesModel, UtilityService} from '@eevo/eevo-core';
import {ProductItemModel} from '../../models/product-models';
import {ProductEntity} from '../../entities/product-entity';

@Component({
  selector: 'app-item-media',
  templateUrl: './item-media.component.html',
  styleUrls: ['./item-media.component.scss']
})
export class ItemMediaComponent implements OnInit {
  @Input()
  parent: FilesModel;

  @Input()
  item: ProductItemModel;

  fileInfo: any[];

  imageUploaderConfig = {
    thumbnailHeight: 120,
    thumbnailWidth: 200,
    showUploadButton: true,
    profileImage: false,
    allowedImageTypes: ['png'],
    maxImageSize: 5, // Megabyte,
    textBrowseFile: 'Drop your logo image here, or browse',
    subTextBrowseFile: 'Supports PNG (40*40)',
    uploadIconName: 'insert_photo',
    hideNotFoundError: true
  };

  ItemImageUploaderConfig = _.cloneDeep(this.imageUploaderConfig);
  ItemFocusImageUploaderConfig = _.cloneDeep(this.imageUploaderConfig);

  ItemImageUrl: string;
  FocusImageUrl: string;

  constructor(
    private utilityService: UtilityService,
    private eevostorageService: EevoStorageService,
    private productEntity: ProductEntity
  ) {
    this.ItemImageUploaderConfig.subTextBrowseFile = 'Supports PNG (80*80)';
    this.ItemFocusImageUploaderConfig.subTextBrowseFile = 'Supports PNG (147*105)';
  }

  ngOnInit(): void {
    this.ItemImageUrl = this.eevostorageService.getFileUrl(
      this.productEntity.getFileKey(
        this.item.Id, this.productEntity.ImageType.Item
      )
    );
    this.FocusImageUrl = this.eevostorageService.getFileUrl(
      this.productEntity.getFileKey(
        this.item.Id, this.productEntity.ImageType.Focus
      )
    );
  }

  onItemImageFileChanged(event): void {
    // if (typeof event === 'boolean') {
      this.parent.Files = this.parent.Files.filter(item => {
        return item.Type !== this.productEntity.ImageType.Item;
      });
    // }

    this.parent.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.productEntity.ImageType.Item
    });
  }

  onItemFocusImageFileChanged(event): void {
    // if (typeof event === 'boolean') {
      this.parent.Files = this.parent.Files.filter(item => {
        return item.Type !== this.productEntity.ImageType.Focus;
      });
    // }

    this.parent.Files.push({
      FileId: this.utilityService.getNewGuid(),
      FileData: event && event[0] ? event[0] : null,
      Type: this.productEntity.ImageType.Focus
    });
  }
}
