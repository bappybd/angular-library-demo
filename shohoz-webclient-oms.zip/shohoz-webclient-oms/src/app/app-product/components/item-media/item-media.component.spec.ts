import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ItemMediaComponent} from './item-media.component';

describe('ItemMediaComponent', () => {
  let component: ItemMediaComponent;
  let fixture: ComponentFixture<ItemMediaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ItemMediaComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemMediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
