import {CustomizationTag, CustomizationType, NumberOfItemType} from '../../shared/models/product-entity-models';

export const OriginalNumberOfItemTypeListData: { value: NumberOfItemType; display: string }[] = [
  {
    display: 'Minimum',
    value: NumberOfItemType.Minimum,
  },
  {
    display: 'Maximum',
    value: NumberOfItemType.Maximum,
  },
  {
    display: 'Exact',
    value: NumberOfItemType.Exact,
  },
  {
    display: 'Range',
    value: NumberOfItemType.Range,
  },
];

export const NumberOfCustomizationTypeListData: { value: CustomizationType; display: string }[] = [
  {
    display: 'Single',
    value: CustomizationType.Single,
  },
  {
    display: 'Multiple',
    value: CustomizationType.Multiple,
  }
];

export const CustomizationTagData: CustomizationTag[] = [
  {name: 'Addons', value: 'Addons'},
  {name: 'Variation', value: 'Variation'},
  {name: 'Choices', value: 'Choices'},
  {name: 'Others', value: ''},
];

export const CustomizationTagPrefillData = {
  Addons: {
    CustomizationType: 'Multiple',
    IsOptional: true,
    NumberOfItemType: 'Maximum',
    MaxSelectableItemCount: 1000,
    Included: false
  },
  Variation: {
    CustomizationType: 'Single',
    IsOptional: false,
    NumberOfItemType: 'Minimum',
    MinSelectableItemCount: 0,
    MaxSelectableItemCount: 1000,
    Included: false
  },
  Choices: {
    CustomizationType: 'Multiple',
    IsOptional: false,
    NumberOfItemType: 'Maximum',
    ExactSelectableItemCount: '',
    MaxSelectableItemCount: null,
    Included: true
  },
  Others: {},
};
