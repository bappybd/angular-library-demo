import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ProductComponent} from './container/product/product.component';
import {AppProductRoutingModule} from './app-product.routing.module';
import {FlexModule} from '@angular/flex-layout';
import {AppShopModule} from '../app-shop/app-shop.module';
import {MatButtonModule} from '@angular/material/button';
import {FuseMaterialColorPickerModule, FuseSharedModule, FuseSidebarModule} from '@eevo/eevo-base';
import {CreateCategoryComponent} from './components/create-category/create-category.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatDialogModule} from '@angular/material/dialog';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatCardModule} from '@angular/material/card';
import {UpdateCategoryComponent} from './components/update-category/update-category.component';
import {ProductNotificationService} from './services/product-notification.service';
import {SharedModule} from '../shared/shared.module';
import {CreateItemComponent} from './components/create-item/create-item.component';
import {UpdateItemComponent} from './components/update-item/update-item.component';
import {ItemMediaComponent} from './components/item-media/item-media.component';
import {EevoImageUploaderModule} from '@eevo/eevo-image-uploader';
import {ProductListItemComponent} from './components/product-list-item/product-list-item.component';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {ProductBasicItemComponent} from './components/product-basic-item/product-basic-item.component';
import {EevoPlatformAvatarModule} from '@eevo/eevo-platform-avatar';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import {ProductCustomizationComponent} from './components/product-customization/product-customization.component';
import {MatRadioModule} from '@angular/material/radio';
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';
import {ProductSearchFieldsComponent} from './components/product-search-fields/product-search-fields.component';
import {ProductListComponent} from './components/product-list/product-list.component';
import {MatSelectInfiniteScrollModule} from 'ng-mat-select-infinite-scroll';
import {FilteredProductListComponent} from './components/filtered-product-list/filtered-product-list.component';
import {FilteredProductListItemComponent} from './components/filtered-product-list-item/filtered-product-list-item.component';
import {InfiniteScrollModule} from 'ngx-infinite-scroll';
import {ProductListStatusUpdateComponent} from './components/product-list-status-update/product-list-status-update.component';
import {ProductListTemporaryUnavailableStatusUpdateDialogComponent} from './components/product-list-temporary-unavailable-status-update-dialog/product-list-temporary-unavailable-status-update-dialog.component';
import {CategoryListStatusUpdateComponent} from "./components/category-list-status-update/category-list-status-update.component";
import {CategoryListTemporaryUnavailableStatusUpdateDialogComponent} from "./components/category-list-temporary-unavailable-status-update-dialog/category-list-temporary-unavailable-status-update-dialog.component";

@NgModule({
  declarations: [
    ProductComponent,
    CreateCategoryComponent,
    UpdateCategoryComponent,
    CreateItemComponent,
    UpdateItemComponent,
    ItemMediaComponent,
    ProductListItemComponent,
    ProductBasicItemComponent,
    ProductCustomizationComponent,
    ProductSearchFieldsComponent,
    ProductListComponent,
    FilteredProductListComponent,
    FilteredProductListItemComponent,
    ProductListStatusUpdateComponent,
    ProductListTemporaryUnavailableStatusUpdateDialogComponent,
    FilteredProductListItemComponent,
    CategoryListStatusUpdateComponent,
    CategoryListTemporaryUnavailableStatusUpdateDialogComponent
  ],
  imports: [
    CommonModule,
    AppProductRoutingModule,
    FlexModule,
    AppShopModule,
    MatButtonModule,
    FuseSidebarModule,
    FuseMaterialColorPickerModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    MatIconModule,
    FuseSharedModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatToolbarModule,
    MatDialogModule,
    MatExpansionModule,
    MatCardModule,
    SharedModule,
    EevoImageUploaderModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatDatepickerModule,
    EevoPlatformAvatarModule,
    EevoPlatformBreadcrumbModule,
    MatRadioModule,
    EevoPlatformFeatureGuardModule,
    MatSelectInfiniteScrollModule,
    InfiniteScrollModule,
  ],
  providers: [
    ProductNotificationService
  ]
})
export class AppProductModule {
}
