import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ActiveProductCommand, ProductCategoryCommand, ProductCommand} from '../models/product-command';

@Injectable({
  providedIn: 'root'
})

export class ProductCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createCategory(productCategoryCommand: ProductCategoryCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('CreateProductCategory'),
      productCategoryCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateCategory(productCategoryCommand: ProductCategoryCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('UpdateProductCategory'),
      productCategoryCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateProductCategoryAvailability(productCategoryCommand: ProductCategoryCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('UpdateProductCategoryAvailability'),
      productCategoryCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  categoryStatusUpdate(productCategoryCommand: ProductCategoryCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('ActiveProductCategory'),
      productCategoryCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  createItem(productCommand: ProductCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('CreateProduct'),
      productCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateItem(productCommand: ProductCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('UpdateProduct'),
      productCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  activeProduct(command: ActiveProductCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('ActiveProduct'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateProductAvailability(command: ActiveProductCommand): Observable<any> {
    return this.http.post(this.config.ShopService.toCommandURL('UpdateProductAvailability'),
      command
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
