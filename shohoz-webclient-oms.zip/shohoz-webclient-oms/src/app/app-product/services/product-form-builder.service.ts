import {Injectable} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import * as _ from 'lodash';
import {ShopModel} from '../../shared/models/shop-entity-models';
import {ProductCategoryDataModel, ProductItemModel} from '../models/product-models';
import {CustomizationType, NumberOfItemType} from '../../shared/models/product-entity-models';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';
import {EevoValidator} from '../../shared/validator/eevo.validator';

@Injectable({
  providedIn: 'root'
})
export class ProductFormBuilderService {

  constructor(private formBuilder: FormBuilder, private scheduleHourService: ScheduleHourService) {
  }

  private itemForm = this.formBuilder.group({
    Id: [''],
    CustomizationItemName: ['', [Validators.required, EevoValidator.cannotWhiteSpace, EevoValidator.cannotContainStrings([':', ';', '#', '$'])]],
    ItemPrice: ['', [Validators.min(0)]],
    Included: [false]
  });

  private customizationForm = this.formBuilder.group({
    Id: [''],
    CustomizationName: ['', [Validators.required, EevoValidator.cannotWhiteSpace, EevoValidator.cannotContainStrings([':', ';', '#', '$'])]],
    CustomizationTag: [''],
    CustomizationType: [CustomizationType.Single, Validators.required],
    IsOptional: [false],
    NumberOfItemType: [NumberOfItemType.Minimum, Validators.required],
    MinSelectableItemCount: ['', [Validators.min(0)]],
    MaxSelectableItemCount: ['', [Validators.min(0)]],
    ExactSelectableItemCount: ['', [Validators.min(0)]],
    Items: this.formBuilder.array([_.cloneDeep(this.itemForm)]),
    Expanded: [false] // For mat expansion panel
  });

  setFormData(formGroup: FormGroup, formData: ShopModel): void {

  }

  getProductCustomizationForm(): FormGroup {
    return _.cloneDeep(this.customizationForm);
  }

  getProductCustomizationItemForm(): FormGroup {
    return _.cloneDeep(this.itemForm);
  }

  getForm(category: ProductCategoryDataModel, item?: ProductItemModel): FormGroup {
    const hasItemData = item && item.Id ? true : false;
    const order = this.getProductOrderInProductCategory(category.Id, item);

    const productForm = this.formBuilder.group({
      CategoryName: [{value: category.Name || '', disabled: true}, Validators.required],
      Order: [hasItemData ? order : 99, Validators.required],
      Name: [hasItemData ? item.Name : '', [Validators.required, EevoValidator.cannotWhiteSpace]],
      // Vat: [hasItemData ? item.Vat : 0],
      Price: [{value: hasItemData ? item.Price : '', disabled: true}, Validators.required],
      PriceWithSD: [hasItemData ? item.PriceWithSD : '', [Validators.min(0), Validators.required]],
      // PriceWithSD: [hasItemData ? (item.Price * (1 + item.SupplementaryDuty / 100)).toFixed(2) : '', Validators.required],
      SupplementaryDuty: [hasItemData ? item.SupplementaryDuty : 0, [Validators.min(0)]],
      Description: [hasItemData ? item.Description : ''],
      MaximumAddLimit: [hasItemData ? item.MaximumAddLimit : 0, Validators.min(0)],
      IsTempProduct: [hasItemData ? item.IsTempProduct : false],
      TempStartDate: [hasItemData && item.IsTempProduct ? item.TempStartDate : new Date()],
      TempEndDate: [hasItemData && item.IsTempProduct ? item.TempEndDate : new Date()],
      isActive: [hasItemData ? item.IsActive : false],
      Customizations: this.formBuilder.array([]),
      ScheduledHours: hasItemData ? this.scheduleHourService.getScheduleHoursFormGroup() : [],
      PreparationTime: [
        hasItemData && item.PreparationTime ? item.PreparationTime.Minute : ''
      ],
      CuratedTags: this.formBuilder.array([
        this.formBuilder.group({
          CuratedName: [''],
          Order: [0],
        })
      ]),
      IsTemporaryUnavailable: [hasItemData ? item.IsTemporaryUnavailable : false],
      TemporaryUnavailableStartTime: [new Date()],
      TemporaryUnavailableEndTime: (hasItemData && item.IsTemporaryUnavailable) ?
        [item.TemporaryUnavailableEndTime, Validators.required] : [this.getTodayMidnightDate()]
    });

    if (item && item.Customizations.length > 0) {
      this.setCustomizationFormValue(item, productForm);
    }

    if (item && item.ServiceHours.length > 0) {
      this.scheduleHourService.setScheduledHoursValues(
        productForm.get('ScheduledHours') as FormGroup,
        item.IsSameForAllDaysServiceHours,
        item.ServiceHours
      );
    }

    if (item && item.Curations && item.Curations.length > 0) {
      const curations = item.Curations;
      if (curations && curations.length > 0) {
        const curatedTags = productForm.get('CuratedTags') as FormArray;
        curations.forEach((data, index) => {
          if (index === 0) {
            curatedTags.at(index).get('CuratedName').setValue(data.Name);
            curatedTags.at(index).get('Order').setValue(data.Order);
          } else {
            curatedTags.push(this.formBuilder.group({
              CuratedName: [data.Name],
              Order: [data.Order],
            }));
          }
        });
      }
    }

    return productForm;
  }

  private getTodayMidnightDate(): Date {
    const date = new Date();
    date.setHours(23, 59, 59, 999);
    return date;
  }

  private capitalizeFirstLetter(text: string): string {
    if (!text) {
      return '';
    }
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  private setCustomizationFormValue(item: ProductItemModel, form: FormGroup): void {
    const customizationFormValue = form.get('Customizations') as FormArray;
    item.Customizations.forEach(customization => {
      const newCustomizationForm = this.getProductCustomizationForm();
      newCustomizationForm.get('Id').setValue(customization._id);
      newCustomizationForm.get('CustomizationName').setValue(customization.Title);
      newCustomizationForm.get('CustomizationType').setValue(customization.CustomizationType);
      newCustomizationForm.get('CustomizationTag').setValue(this.capitalizeFirstLetter(customization.CustomizationTag));
      newCustomizationForm.get('IsOptional').setValue(customization.IsOptional);
      newCustomizationForm.get('NumberOfItemType').setValue(customization.NumberOfItemType);
      newCustomizationForm.get('MinSelectableItemCount').setValue(customization.MinimumSelectable);
      newCustomizationForm.get('MaxSelectableItemCount').setValue(customization.MaximumSelectable);
      newCustomizationForm.get('ExactSelectableItemCount').setValue(customization.ExactSelectable);

      const newCustomizationFormItems = newCustomizationForm.get('Items') as FormArray;
      newCustomizationFormItems.removeAt(0); // removing initial item

      customization.Items.forEach((item) => {
        const itemForm = this.getProductCustomizationItemForm();
        itemForm.get('Id').setValue(item._id);
        itemForm.get('CustomizationItemName').setValue(item.Title);
        itemForm.get('ItemPrice').setValue(item.Price);
        itemForm.get('Included').setValue(item.IsIncluded);
        if (itemForm.get('Included').value) {
          itemForm.get('ItemPrice').disable();
        }
        newCustomizationFormItems.push(itemForm);
      });
      customizationFormValue.push(newCustomizationForm);
    });
  }

  private getProductOrderInProductCategory(categoryId: string, item: ProductItemModel): number {

    if (categoryId && item && item.ProductCategories) {
      const productCategories = item.ProductCategories.find((data) => {
        return data.ProductCategoryId === categoryId;
      });
      return productCategories && productCategories.ProductOrderInProductCategory;
    }

    return null;
  }
}
