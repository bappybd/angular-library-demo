import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {UtilityService} from '@eevo/eevo-core';
import {ProductCategoryCommand, ProductCommand} from '../models/product-command';
import {
  CustomizationType, NumberOfItemType,
  ProductCategoryDto, ProductCategoryModel, ProductCustomizationItemModel,
  ProductCustomizationModel,
  ProductModel
} from '../../shared/models/product-entity-models';
import {ProductCategoryDataModel, ProductItemModel} from '../models/product-models';
import {ScheduleHourService} from '../../shared/components/schedule-hour/schedule-hour.service';

@Injectable({
  providedIn: 'root'
})
export class ProductCommandBuilderService {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    private scheduleHourService: ScheduleHourService,
    @Inject('config') private config: any) {
  }

  getProductCommand(formPayload: FormGroup, category: ProductCategoryDataModel, item?: ProductItemModel): ProductCommand {
    const form = Object.assign({}, formPayload);
    const formData = form.value;

    let tempEndDate = formPayload.get('TempEndDate').value;
    tempEndDate = tempEndDate !== '' ? this.getDate(tempEndDate, false) : null;

    let tempStartDate = formPayload.get('TempStartDate').value;
    tempStartDate = tempStartDate !== '' ? this.getDate(tempStartDate, true) : null;

    const product: ProductModel = {
      ProductId: item && item.Id || this.utilityService.getNewGuid(),
      ShopId: category.ShopId,
      ProductCatalogueId: category.ProductCatalogueId,

      Name: formPayload.get('Name').value,
      Description: formPayload.get('Description').value,
      Price: formPayload.get('Price').value,
      PriceWithSD: formPayload.get('PriceWithSD').value,
      IsActive: Boolean(formPayload.get('isActive').value),
      PreparationTime: {
        Hour: 0,
        Minute: Number(formPayload.get('PreparationTime').value)
      },
      SupplementaryDuty: formPayload.get('SupplementaryDuty').value || 0,
      IsTempProduct: formPayload.get('IsTempProduct').value,
      MaximumAddLimit: formPayload.get('MaximumAddLimit').value,
      // Vat: formPayload.get('Vat').value,
      TempEndDate: tempEndDate,
      TempStartDate: tempStartDate,
      ProductCategories: this.getUpdatedProductCategories(category, item, formPayload),
      Customizations: (item && item.Id) ?
        this.getProductCustomizationsFormValue(formData.Customizations) : [],
      IsSameForAllDaysServiceHours: (item && item.Id) ?
        Boolean(formPayload.get('ScheduledHours').get('IsSameForAllDaysServiceHours').value) : false,
      ServiceHours: (item && item.Id) ?
        this.scheduleHourService.getScheduledHoursPayload(formPayload.get('ScheduledHours').value) : [],
    };
    const tempUnavailableData = this.getTemporaryUnavailableData(formPayload.value);
    if (tempUnavailableData?.IsTemporaryUnavailable) {
      product.IsTemporaryUnavailable = !!tempUnavailableData?.IsTemporaryUnavailable;
      product.TemporaryUnavailableStartTime  = tempUnavailableData.TemporaryUnavailableStartTime;
      product.TemporaryUnavailableEndTime = new Date(new Date(tempUnavailableData.TemporaryUnavailableEndTime || null).setSeconds(59)).toISOString();
    }
    if (formData.CuratedTags[0].CuratedName) {
      product.Curations = formData.CuratedTags ? formData.CuratedTags.map(c => {
        return {
          Name: c.CuratedName,
          Order: c.Order
        };
      }) : [];
    }
    const createItemCommand = new ProductCommand();
    createItemCommand.Products = [product];

    return createItemCommand;
  }

  private getTemporaryUnavailableData({IsTemporaryUnavailable, TemporaryUnavailableStartTime, TemporaryUnavailableEndTime}):
    { IsTemporaryUnavailable: boolean, TemporaryUnavailableStartTime: string, TemporaryUnavailableEndTime: string } | null {
    if (!IsTemporaryUnavailable || !TemporaryUnavailableStartTime || !TemporaryUnavailableEndTime) {
      return null;
    }
    if (new Date(TemporaryUnavailableStartTime) > new Date(TemporaryUnavailableEndTime)) {
      return null;
    }

    return {
      IsTemporaryUnavailable,
      TemporaryUnavailableStartTime: new Date(TemporaryUnavailableStartTime).toISOString(),
      TemporaryUnavailableEndTime: new Date(TemporaryUnavailableEndTime).toISOString()
    };
  }

  getProductCategoryActivateCommand(category: ProductCategoryDataModel, isActive: boolean): ProductCategoryCommand {
    const productCategory: ProductCategoryModel = {
      ProductCategoryId: category.Id,
      CategoryOrderInCatalogue: category.CategoryOrderInCatalogue,
      Description: category.Description,
      IsActive: isActive,
      Name: category.Name,
      ProductCatalogueId: category.ProductCatalogueId,
      ShopId: category.ShopId,
    };
    return {
      CorrelationId: this.utilityService.getNewGuid(),
      Categories: [productCategory]
    };
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  private getUpdatedProductCategories(
    category: ProductCategoryDataModel,
    item: ProductItemModel,
    formPayload: FormGroup): ProductCategoryDto[] {

    if (item && item.ProductCategories) {
      const index = item.ProductCategories.findIndex(data => data.ProductCategoryId === category.Id);
      item.ProductCategories[index].ProductOrderInProductCategory = formPayload.get('Order').value;

      return item.ProductCategories;
    }

    return [{
      ProductCategoryId: category.Id,
      ProductOrderInProductCategory: formPayload.get('Order').value,
    }];
  }

  private getProductCustomizationsFormValue(payload: any): ProductCustomizationModel[] {
    const model: ProductCustomizationModel[] = [];

    payload.forEach((customization) => {
      const allowMaxSelectable = customization.CustomizationType === CustomizationType.Multiple
        && [NumberOfItemType.Maximum, NumberOfItemType.Range].includes(customization?.NumberOfItemType);
      const allowMinSelectable = customization.CustomizationType === CustomizationType.Multiple
        && [NumberOfItemType.Minimum, NumberOfItemType.Range].includes(customization?.NumberOfItemType);
      const allowExactSelectable = customization.CustomizationType === CustomizationType.Multiple
        && [NumberOfItemType.Exact].includes(customization?.NumberOfItemType);

      model.push({
        Id: (customization.Id) ? customization.Id : this.utilityService.getNewGuid(),
        NumberOfItemType: customization.NumberOfItemType,
        Title: customization.CustomizationName,
        CustomizationTag: customization.CustomizationTag,
        CustomizationType: customization.CustomizationType,
        IsOptional: Boolean(customization.IsOptional),
        MaximumSelectable: allowMaxSelectable ? Number(customization.MaxSelectableItemCount) : 0,
        MinimumSelectable: allowMinSelectable ? Number(customization.MinSelectableItemCount) : 0,
        ExactSelectable: allowExactSelectable ? Number(customization.ExactSelectableItemCount) : 0,
        Items: this.getProductCustomizationItemsFormValue(customization)
      });
    });

    return model;
  }

  private getProductCustomizationItemsFormValue(customization: any): ProductCustomizationItemModel[] {
    const model: ProductCustomizationItemModel[] = [];

    customization.Items.forEach(item => {
      model.push({
        Id: (item.Id) ? item.Id : this.utilityService.getNewGuid(),
        Title: item.CustomizationItemName,
        AdditionalPrice: 0,
        IsIncluded: Boolean(item.Included),
        Price: item.ItemPrice ? Number(item.ItemPrice) : 0
      });
    });

    return model;
  }

  getDate(date: Date, start: boolean = true): string {
    return (start) ? new Date(new Date(date).setHours(0, 0, 0, 0)).toISOString() :
      new Date(new Date(date).setHours(23, 59, 59, 999)).toISOString();
  }
}
