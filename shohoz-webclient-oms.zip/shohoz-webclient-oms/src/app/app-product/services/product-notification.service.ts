import {EventEmitter, Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {EevoNotificationBase} from '@eevo/eevo-core';
import {ProductEntity} from '../entities/product-entity';
import {ProductCategoryEntity} from '../entities/product-category-entity';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';

@Injectable({
  providedIn: 'root'
})
export class ProductNotificationService extends EevoNotificationBase<CommandNotificationModel> {
  constructor(
    private productEntity: ProductEntity,
    private productCategoryEntity: ProductCategoryEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(
      this.productCategoryEntity.Events.ProductCategoryBusinessRuleViolationEvent, (response) => {
        const data = this.notificationHandlerService.parseNotification(response, false);
        this.deliver(data);
      });

    this.signalrNotificationService.listenByKey(this.productEntity.Events.ProductBusinessRuleViolationEvent, (response) => {
      const data = this.notificationHandlerService.parseNotification(response, false);
      this.deliver(data);
    });
  }

  productCategoryCreated(): void {
    this.signalrNotificationService.listenByKey(this.productCategoryEntity.Events.ProductCategoryCreatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(
        response, true, this.productCategoryEntity.getMessages().CREATED
      );
      this.deliver(data);
    });
  }

  productCategoryUpdated(): void {
    this.signalrNotificationService.listenByKey(this.productCategoryEntity.Events.ProductCategoryUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(
        response,
        true,
        this.productCategoryEntity.getMessages().UPDATED
      );
      this.deliver(data);
    });
  }

  productCreated(): void {
    this.signalrNotificationService.listenByKey(this.productEntity.Events.ProductCreatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.productEntity.getMessages().CREATED);
      this.deliver(data);
    });
  }

  productUpdated(): void {
    this.signalrNotificationService.listenByKey(this.productEntity.Events.ProductUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.productEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }

  productActiveEvent(): void {
    this.signalrNotificationService.listenByKey(this.productEntity.Events.ProductActiveEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.productEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }

  productCategoryActiveEvent(): void {
    this.signalrNotificationService.listenByKey(this.productCategoryEntity.Events.ProductCategoryActiveEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.productEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }

  productAvailabilityEvent(): void {
    this.signalrNotificationService.listenByKey(this.productEntity.Events.ProductAvailabilityEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.productEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }

  productCategoryAvailabilityEvent(): void {
    this.signalrNotificationService.listenByKey(this.productCategoryEntity.Events.ProductCategoryAvailabilityEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.productCategoryEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }
}
