import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {Observable, of} from 'rxjs';
import {map} from 'rxjs/operators';
import {ProductCategoryDataModel, ProductItemModel, ProductItemSearchModel} from '../models/product-models';
import {ProductCatalogueModel} from '../../shared/models/product-entity-models';
import {ProductEntity} from '../entities/product-entity';
import {ProductCategoryEntity} from '../entities/product-category-entity';
import {ProductCatalogueEntity} from '../entities/product-catalogue-entity';

@Injectable({
  providedIn: 'root'
})

export class ProductQueryService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    private productEntity: ProductEntity,
    private productCatalogueEntity: ProductCatalogueEntity,
    private productCategoryEntity: ProductCategoryEntity,
    @Inject('config') private config: any
  ) {
  }

  getCategoryCountByShopId(shopId: string): Observable<number> {
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productCategoryEntity.getListName(),
        text: null,
        filter: `{ 'ShopId' : GUID('` + shopId + `')  }`,
        fields: this.productCategoryEntity.getListFields(),
        orderBy: 'CategoryOrderInCatalogue',
        descending: false,
        CountOnly: true,
      }
    ]).pipe(
      map((response: any) => {
        return response[0][0][0];
      })
    );
  }

  getCategoryListByShopId(shopId: string, pageNo = 0, pageSize = 100, order = 'CategoryOrderInCatalogue'): Observable<ProductCategoryDataModel[]> {
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productCategoryEntity.getListName(),
        text: null,
        filter: `{ 'ShopId' : GUID('` + shopId + `')  }`,
        fields: this.productCategoryEntity.getListFields(),
        orderBy: order,
        descending: false,
        pageSize,
        pageIndex: pageNo
      }
    ]).pipe(
      map((response: any) => {
        return response[0];
      })
    );
  }

  getProductListByCategoryIdAndName(categoryId: string, searchKey?: string, pageSize = 100, pageNumber = 0): Observable<[ProductItemModel[], number]> {
    const queries = [];
    if (searchKey) {
      searchKey = this.utilityService.matchAnyCharacterRegx(searchKey);
      queries.push(`{ 'Name' : { $regex: '.*${searchKey}.*', $options: 'i'} }`);
    }

    if (categoryId) {
      queries.push(`{ 'ProductCategories.ProductCategoryId' : GUID('${categoryId}')  }`);
    }

    const query = `{ $and : [${queries.join(',')}] }`;

    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productEntity.getListName(),
        text: null,
        filter: query,
        fields: this.productEntity.getListFields(),
        orderBy: 'ProductCategories.ProductOrderInProductCategory',
        descending: false,
        pageSize,
        pageIndex: pageNumber
      },
      {
        source: this.productEntity.getListName(),
        text: null,
        filter: query,
        fields: this.productEntity.getListFields(),
        orderBy: 'ProductCategories.ProductOrderInProductCategory',
        descending: false,
        CountOnly: true
      }
    ]).pipe(
      map((response: any) => {
        return [response[0], response[1][0][0]];
      })
    );
  }

  getProductCatalogue(shopId: string): Observable<ProductCatalogueModel> {
    const query = `{ 'ShopId' : GUID('` + shopId + `')  }`;

    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productCatalogueEntity.getListName(),
        text: null,
        filter: query,
        fields: this.productCatalogueEntity.getListFields(),
        orderBy: 'CreatedDate',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return response[0][0];
      })
    );
  }

  getProductCategory(productCategoryId: string): Observable<ProductCategoryDataModel> {
    const query = `{ '_id' : GUID('` + productCategoryId + `')  }`;
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productCategoryEntity.getListName(),
        text: null,
        filter: query,
        fields: this.productCategoryEntity.getListFields(),
        orderBy: 'CreatedDate',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return response[0][0];
      })
    );
  }

  getProduct(productId: string): Observable<ProductItemModel> {
    const query = `{ '_id' : GUID('` + productId + `')  }`;
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productEntity.getDetailsName(),
        text: null,
        filter: query,
        fields: this.productEntity.getDetailsFields(),
        orderBy: 'CreatedDate',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return response[0][0];
      })
    );
  }

  getProductForFilteredListComponent(shopId: string, listPageSize: number, listPageIndex: number,
                                     searchKey?: string, categoryIds?: string[]): Observable<ProductItemSearchModel[]> {
    if (!searchKey && !(categoryIds && categoryIds.length)) {
      return of([]);
    }
    const queries = [
      `{ 'ShopId' : GUID('${shopId}')  }`
    ];
    if (searchKey) {
      searchKey = this.utilityService.matchAnyCharacterRegx(searchKey);
      queries.push(`{ 'Name' : { $regex: '.*${searchKey}.*', $options: 'i'} }`);
    }

    if (categoryIds && categoryIds.length) {
      queries.push(`{ 'ProductCategories' : { $elemMatch: { 'ProductCategoryId' : {$in: [${categoryIds.map(id => 'GUID(\'' + id + '\')').join(',')}]}  } } }`);
    }

    const query = `{ $and : [${queries.join(',')}] }`;
    return this.http.post(this.config.ShopService.toQueryURL(), [
      {
        source: this.productEntity.getListName(),
        text: null,
        filter: query,
        fields: this.productEntity.getListFields(),
        orderBy: 'ProductCategories.ProductCategoryId',
        descending: false,
        pageSize: listPageSize,
        pageIndex: listPageIndex
      }
    ]).pipe(
      map((response: any) => {
        return response[0];
      })
    );
  }
}
