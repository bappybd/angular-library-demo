import {ProductItemActiveModel} from './product-models';
import {ProductCategoryModel, ProductModel} from '../../shared/models/product-entity-models';
import {EevoCommandBase} from '@eevo/eevo-core';

export class ProductCommand extends EevoCommandBase {
  constructor() {
    super();
  }

  public Products: ProductModel[];
}

export class ActiveProductCommand extends EevoCommandBase {
  constructor() {
    super();
  }

  public Products: ProductItemActiveModel[];
}

export interface ProductCategoryCommand {
  CorrelationId: string;
  Categories: ProductCategoryModel[];
}
