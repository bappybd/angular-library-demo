import {ScheduledHourModel, TimeModel} from '../../shared/models/scheduled-hour-model';
import {
  ProductCategoryDto,
  ProductCustomizationModel,
  ProductCustomizationViewModel
} from '../../shared/models/product-entity-models';

export interface ProductCategoryDataModel { // ProductCategoryList
  Id: string;
  ShopId: string;
  Name: string;
  IsActive: boolean;
  Description: string;
  ProductCatalogueId: string;
  CategoryOrderInCatalogue: number;
  Expanded: boolean;
  IsTemporaryUnavailable: boolean;
  TemporaryUnavailableEndTime: string;
  TemporaryUnavailableStartTime: string;
  Products: ProductItemModel[];
}

export interface ProductItemModel { // ProductListModel
  Id: string;
  ShopId: string;
  Name: string;
  Description: string;
  ProductCatalogueId: string;
  ProductCategories: ProductCategoryDto[];
  PreparationTime: TimeModel;
  SupplementaryDuty: number;
  Price: number;
  PriceWithSD: number;
  CategoryOrderInCatalogue: string;
  ImageFileId: string;
  FocusImageId: string;
  IsActive: boolean;
  MaximumAddLimit: number;
  IsTempProduct: boolean;
  TempStartDate: string;
  TempEndDate: string;
  Customizations: ProductCustomizationViewModel[];
  // Vat: number;
  ServiceHours: ScheduledHourModel[];
  IsSameForAllDaysServiceHours: boolean;
  Curations: CuratedInfoModel[];
  IsTemporaryUnavailable: boolean;
  TemporaryUnavailableStartTime: string;
  TemporaryUnavailableEndTime: string;
}

export interface ProductCategoriesModel{
  ProductCategoryId: string;
  ProductCategoryName: string;
  ProductCategoryIsActive: boolean;
  ProductCategoryIsMarkedToDelete: boolean;
  ProductOrderInProductCategory: number;
}

export class ProductItemSearchModel { // ProductListModel
  Id: string;
  ShopId: string;
  Name: string;
  Description: string;
  ProductCatalogueId: string;
  ProductCategories: ProductCategoriesModel[];
  PreparationTime: TimeModel;
  SupplementaryDuty: number;
  Price: number;
  PriceWithSD: number;
  CategoryOrderInCatalogue: string;
  ImageFileId: string;
  FocusImageId: string;
  IsActive: boolean;
  MaximumAddLimit: number;
  IsTempProduct: boolean;
  TempStartDate: string;
  TempEndDate: string;
  Customizations: ProductCustomizationViewModel[];
  Vat: number;
  ServiceHours: ScheduledHourModel[];
  IsSameForAllDaysServiceHours: boolean;
  Curations: CuratedInfoModel[];
}

export class CuratedInfoModel
{
  Name: string;

  Order: number;
}

export interface ProductItemActiveModel { // ProductItemActiveModel
  ShopId: string;
  ProductCatalogueId: string;
  ProductCategoryId: string;
  ProductId: string;
  IsActive: boolean;
  IsTemporaryUnavailable?: boolean;
  TemporaryUnavailableStartTime?: string;
  TemporaryUnavailableEndTime?: string;
}
