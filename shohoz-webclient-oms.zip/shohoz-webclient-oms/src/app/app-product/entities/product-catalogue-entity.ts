import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ProductCatalogueImageType {
}

enum ProductCatalogueEvents {
}

@Injectable({
  providedIn: 'root'
})
export class ProductCatalogueEntity extends EevoEntityRoot {

  ImageType = ProductCatalogueImageType;

  Events = ProductCatalogueEvents;

  constructor() {
    super('ProductCatalogueLists', 'Product catalogue');
  }

  getDetailsFields(): string[] {
    return [
      'ShopId', 'Name', 'Description'
    ];
  }

  getListFields(): string[] {
    return [
      'ShopId', 'Name', 'Description'
    ];
  }
}
