import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ProductImageType {
  Item = 'item',
  Focus = 'focus'
}

enum ProductEvents {
  ProductBusinessRuleViolationEvent = 'ProductBusinessRuleViolationEvent',
  ProductUpdatedEvent = 'ProductUpdatedEvent',
  ProductCreatedEvent = 'ProductCreatedEvent',
  ProductActiveEvent = 'ProductActiveEvent',
  FileCreatedEvent = 'FileCreatedEvent',
  ProductAvailabilityEvent = 'ProductAvailabilityEvent'
}

@Injectable({
  providedIn: 'root'
})
export class ProductEntity extends EevoEntityRoot {

  Events = ProductEvents;

  ImageType = ProductImageType;

  constructor() {
    super('ProductLists');
  }

  getShopListEntityName(): string {
    return 'ShopLists';
  }

  getDetailsFields(): string[] {
    return [
      'ShopId', 'Name', 'Description', 'ProductCategories',
      'PreparationTime', 'SupplementaryDuty', 'Price', 'Customizations',
      'ProductCatalogueId', 'MaximumAddLimit', 'IsTempProduct', 'TempStartDate',
      'TempEndDate', 'IsActive', 'Customizations', 'Vat',
      'IsSameForAllDaysServiceHours', 'ServiceHours', 'Curations', 'PriceWithSD',
      'IsTemporaryUnavailable', 'TemporaryUnavailableStartTime', 'TemporaryUnavailableEndTime'
    ];
  }

  getListFields(): string[] {
    return [
      'Name', 'Description', 'Price', 'ShopId', 'ProductCatalogueId', 'IsActive', 'PriceWithSD', 'ProductCategories',
      'IsTemporaryUnavailable', 'TemporaryUnavailableStartTime', 'TemporaryUnavailableEndTime'
    ];
  }

  getSearchListFields(): string[] {
    return [
      'Name',
      'Description',
      'Price',
      'ShopId',
      'ProductCatalogueId',
      'IsActive',
      'ProductCategories',
      'PriceWithSD'
    ];
  }
}
