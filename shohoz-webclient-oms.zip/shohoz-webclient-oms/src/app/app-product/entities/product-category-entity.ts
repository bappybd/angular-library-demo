import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum ProductCategoryImageType {
}

enum ProductCatalogueEvents {
  ProductCategoryCreatedEvent = 'ProductCategoryCreatedEvent',
  ProductCategoryUpdatedEvent = 'ProductCategoryUpdatedEvent',
  ProductCategoryActiveEvent = 'ProductCategoryActiveEvent',
  ProductCategoryBusinessRuleViolationEvent = 'ProductCategoryBusinessRuleViolationEvent',
  ProductCategoryAvailabilityEvent = 'ProductCategoryAvailabilityEvent'
}

@Injectable({
  providedIn: 'root'
})
export class ProductCategoryEntity extends EevoEntityRoot {

  ImageType = ProductCategoryImageType;

  Events = ProductCatalogueEvents;

  constructor() {
    super('ProductCategoryLists', 'Product category');
  }

  getDetailsFields(): string[] {
    return [
      'Name', 'ShopId', 'ProductCatalogueId', 'Description', 'CategoryOrderInCatalogue', 'IsActive',
      'IsTemporaryUnavailable', 'TemporaryUnavailableStartTime', 'TemporaryUnavailableEndTime'
    ];
  }

  getListFields(): string[] {
    return [
      'Name', 'ShopId', 'ProductCatalogueId', 'CategoryOrderInCatalogue', 'IsActive',
      'IsTemporaryUnavailable', 'TemporaryUnavailableStartTime', 'TemporaryUnavailableEndTime',
      'Description'
    ];
  }
}
