import {
  Component,
  ElementRef,
  Inject,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren,
  ViewEncapsulation
} from '@angular/core';
import {fuseAnimations, FuseSidebarService} from '@eevo/eevo-base';
import {ActivatedRoute} from '@angular/router';
import {ProductNotificationService} from '../../services/product-notification.service';
import {ProductQueryService} from '../../services/product-query.service';
import {ProductCategoryDataModel, ProductItemModel} from '../../models/product-models';
import {ShopModel} from '../../../shared/models/shop-entity-models';
import {ProductEntity} from '../../entities/product-entity';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {MatSlideToggleChange} from '@angular/material/slide-toggle';
import {ProductCommandService} from '../../services/product-command.service';
import {ProductCommandBuilderService} from '../../services/product-command-builder.service';
import {ProductCategoryEntity} from '../../entities/product-category-entity';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {MatDialog} from '@angular/material/dialog';
import {SubSink} from 'subsink';
import {ProductSearchFieldData} from '../../components/product-search-fields/product-search-fields.component';
import {filter, take} from 'rxjs/operators';

@Component({
  selector: 'app-menu',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
  // encapsulation: ViewEncapsulation.None,
  animations: fuseAnimations
})
export class ProductComponent implements OnInit, OnDestroy {
  shopId: string;
  shopDetails: any;
  breadcrumbList: BreadcrumbModel[] = [];
  productCategoryList: ProductCategoryDataModel[];
  selectedCategory: ProductCategoryDataModel;
  selectedCategoryForItemCreation: ProductCategoryDataModel;
  selectedCategoryForItemUpdate: ProductCategoryDataModel;
  selectedItem: ProductItemModel;
  productLoading = false;
  categoryDataLoaded = false;
  openedCategory: any;
  productSearchMode: boolean;
  pageData = {
    total: 0,
    pageSize: 50,
    pageNumber: 0,
    totalPages: 0
  };
  private subs = new SubSink();

  @ViewChildren('toggleElement') toggleElementRef: QueryList<ElementRef>;
  public searchData: ProductSearchFieldData;

  constructor(
    private dialog: MatDialog,
    private actRoute: ActivatedRoute,
    public fuseSidebarService: FuseSidebarService,
    private eevoQueryService: EevoQueryService,
    private productEntity: ProductEntity,
    private productQueryService: ProductQueryService,
    private productNotificationService: ProductNotificationService,
    private productCommandBuilderService: ProductCommandBuilderService,
    private eevoNotifyService: EevoNotifyService,
    private productCategoryEntity: ProductCategoryEntity,
    private productCommandService: ProductCommandService,
    @Inject('config') private config: any
  ) {
    this.productCategoryList = [];
    this.shopId = this.actRoute.snapshot.params.id;
    this.getTotalCategoriesCount();
  }

  ngOnInit(): void {
    this.getProductCategoryList(this.pageData.pageSize, this.pageData.pageNumber);
    this.getShopDetails();
    this.listenToCategoryEvents();
  }

  private getShopDetails(): void {
    this.subs.sink = this.eevoQueryService.getDetailsById<ShopModel>(
      this.config.ShopService.toQueryURL(),
      this.productEntity.getShopListEntityName(),
      this.shopId,
      ['Name', 'IsHomeCook']
    ).subscribe((data) => {
      if (data && data.Id) {
        this.shopDetails = data;
        this.setBreadcrumbData();
      }
    });
  }

  getTotalCategoriesCount(): void {
    this.subs.sink = this.productQueryService.getCategoryCountByShopId(this.shopId).subscribe(data => {
      this.pageData.total = data;
      this.pageData.totalPages = Math.ceil(this.pageData.total / this.pageData.pageSize);
    });
  }

  getProductCategoryList(pageSize?: number, pageNumber?: number): void {
    this.categoryDataLoaded = false;
    let resetDataList = false;
    if (!pageSize || !pageNumber) {
      this.pageData.pageNumber = 0;
      resetDataList = true;
      pageSize = this.pageData.pageSize;
      pageNumber = this.pageData.pageNumber;
    }
    this.subs.sink = this.productQueryService.getCategoryListByShopId(this.shopId, pageNumber, pageSize)
      .pipe(take(1))
      .subscribe(data => {
        this.categoryDataLoaded = true;
        if (resetDataList) {
          this.productCategoryList = [];
        }
        this.productCategoryList.push(...data);
      });
  }

  toggleSidebarOpen(key): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }


  updateCategory(category: ProductCategoryDataModel): void {
    this.selectedCategory = category;
    this.fuseSidebarService.getSidebar('editCategoryPanel').toggleOpen();
  }

  itemCreated($event: boolean): void {
  }

  createItem(category: ProductCategoryDataModel): void {
    this.selectedCategoryForItemCreation = category;
    this.fuseSidebarService.getSidebar('createItemPanel').toggleOpen();
  }

  onCategoryClick(category: ProductCategoryDataModel): void {
    this.openedCategory = category;
    category.Expanded = true;
  }

  updateItem($event: any): void {
    this.selectedCategoryForItemUpdate = $event.category;
    this.selectedItem = $event.product;
    this.fuseSidebarService.getSidebar('updateItemPanel').toggleOpen();
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Shops',
      Path: ['/shop']
    });

    this.breadcrumbList.push({
      Text: (this.shopDetails.Name.length > 30) ? (this.shopDetails.Name.substr(0, 30) + '...') : this.shopDetails.Name,
      Path: ['/shop/update/', this.shopId, '0']
    });

    this.breadcrumbList.push({
      Text: 'Menu'
    });
  }

  activeProductCategory($event: MatSlideToggleChange, category: ProductCategoryDataModel): void {
    const toggleRef: any = this.toggleElementRef.find((ref: any) => {
      return ref.id === category.Id;
    });

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Confirmation',
        message: 'Are you sure you want to update this category status?',
        buttonText: {
          ok: 'Yes',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.processActiveProductCategory($event, category);
        toggleRef.checked = $event.checked;
      } else {
        toggleRef.checked = !$event.checked;
      }
    });
  }

  private processActiveProductCategory($event: MatSlideToggleChange, category: ProductCategoryDataModel): void {
    const command = this.productCommandBuilderService.getProductCategoryActivateCommand(category, $event.checked);
    // this.productNotificationService.productCategoryUpdated();
    this.productNotificationService.productCategoryActiveEvent();
    this.eevoNotifyService.displayMessage(
      'Product category active/inactive request submitted!',
      NotifyType.Info
    );
    this.subs.sink = this.productCommandService.categoryStatusUpdate(command).subscribe(data => {
      category.IsActive = $event.checked;
    }, (error => {
      this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
    }));
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }


  private listenToCategoryEvents(): void {
    this.productNotificationService.productCategoryCreated();
    this.productNotificationService.productCategoryUpdated();
    this.productNotificationService.productCategoryActiveEvent();
    const actionNamesToListen = [
      this.productCategoryEntity.Events.ProductCategoryCreatedEvent,
      this.productCategoryEntity.Events.ProductCategoryUpdatedEvent,
      this.productCategoryEntity.Events.ProductCategoryActiveEvent,
      this.productCategoryEntity.Events.ProductCategoryAvailabilityEvent
    ];
    this.subs.sink = this.productNotificationService.onReceived()
      .pipe(
        filter(event => !!actionNamesToListen.includes(this.productCategoryEntity.Events[event?.ActionName])),
      )
      .subscribe(data => {
        this.getProductCategoryList();
      });
  }

  onSearch(searchFieldData: any): void {
    this.productSearchMode = true;
    this.searchData = searchFieldData;
  }

  onSearchReset($event: boolean): void {
    this.productSearchMode = false;
    this.getProductCategoryList();
    this.searchData = null;
  }

  loadMoreData(): void {
    this.pageData.pageNumber++;
    this.getProductCategoryList(this.pageData.pageSize, this.pageData.pageNumber);
  }
}
