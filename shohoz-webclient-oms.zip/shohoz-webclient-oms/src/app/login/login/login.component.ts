import {Component, OnInit} from '@angular/core';
// @ts-ignore
import {EevoLoginOption, LoginConfiguration} from '@eevo/eevo-platform-login';
import {authRedirection} from '../../bootstrap/routes';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  private bodyLogoPath = 'assets/images/logos/shohoz.svg';
  private formLogoPath = 'assets/images/logos/shohoz.svg';

  public loginOption = {
    defaultRedirectUrl: '/dashboard',
    authRedirection,
    allow2FALogin: true,
    allowSocialLogin: false,
    allowCreateAccount: false,
    allowRememberMe: false,
    allowForgotPassword: false,
    allowLanguageOption: false
  } as EevoLoginOption;
  public loginPageData =
    {
      loginBodyHeader: 'Welcome to the SHOHOZ!',
      loginBodySubHeader: 'Outlet Management Panel',
      loginBodyContent: 'For inquiry or assistance, please call 09666797777 or email us at food.sales@shohoz.com',
      loginBodyLogo: {
        src: this.bodyLogoPath,
        url: 'https://www.shohoz.com',
      },
      loginFormHeaderText: 'LOGIN TO YOUR ACCOUNT',
      loginFormSubHeaderText: 'For the purpose of accessing the panel, your details are required.',
      loginFormLogo: {
        src: this.formLogoPath,
        url: 'https://www.shohoz.com',
      },
    } as any | LoginConfiguration;

  constructor() {
  }

  ngOnInit(): void {
  }

  loginSuccess($event: any): void {
  }
}
