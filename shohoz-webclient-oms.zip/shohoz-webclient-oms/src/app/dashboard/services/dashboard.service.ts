import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {Observable, pipe} from 'rxjs';
import {map} from 'rxjs/operators';
import {DatatableModel} from "@eevo/eevo-platform-datatable";
import {CreateFileModel} from "../models/dashboard.model";
import {CookieService} from "ngx-cookie-service";

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(
    private http: HttpClient,
    private cookieService: CookieService,
    @Inject('config') private config: any) {
  }

  createFile(fileModel: CreateFileModel): Observable<any> {
    const header = new HttpHeaders({
      'x-service-id': 'restaurants',
      // Authorization: 'Bearer ' + this.cookieService.get('ACCESS_TOKEN')
    });
    return this.http.post(this.config.StorageService + 'Files/CreateFiles', {
      FileInfos: [
        fileModel
      ],
      CorrelationId: '8ec2c2b0-3243-4179-ab38-8a63969cc2d3'
    }, {headers: header}).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getFileUploadUrl(fileIds: string[]): Observable<any> {
    const header = new HttpHeaders({
      'x-service-id': 'restaurants',
      // Authorization: 'Bearer ' + this.cookieService.get('ACCESS_TOKEN')
    });
    return this.http.post(this.config.StorageService + '/Files/CreateUploadUrls', {
      FildIds: fileIds
    }, {headers: header}).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  uploadFile(file: File, url: string): Observable<any> {
    const header = new HttpHeaders({
      'x-ms-blob-type': 'BlockBlob'
    });

    let blob = new Blob([file], {type: 'image/jpeg'})

    return this.http.put(url, file, {headers: header}).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getAllUsers(): Observable<any> {
    return this.http.get('https://iam-dev.shohoz.com/v1/user/list?pageNumber=0&pageSize=5');
  }

  getUserDetails(): Observable<any> {
    return this.http.get('' + 'User/GetUserById?Id=ee2a6c45-52d2-4238-9096-243207a11754');
  }

  getRestaurants(tableModel: DatatableModel<any>, searchKey?: string): Observable<any> {
    const header = new HttpHeaders({
      'x-service-id': 'restaurants',
    });
    let rawQuery = '';
    if (searchKey) {
      rawQuery += `{$or: [ { ShowTime: /` + searchKey + `/i }, {HallId: /` + searchKey + `/i} ] }`;
    }
    return this.http.post(this.config.QueryService, [
      {
        source: 'Resturants',
        text: null,
        filter: rawQuery.length ? rawQuery : '{}',
        fields: [
          'ShowTime',
          'HallId',
          'ShowDate'
        ],
        orderBy: tableModel.SortBy,
        descending: false,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: 'Resturants',
        text: null,
        filter: rawQuery.length ? rawQuery : '{}',
        CountOnly: true
      }
    ], {headers: header}).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
