import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {RestaurantSummaryDataModel} from '../models/summary-data.model';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RestaurantSummaryQueryService {

  constructor(
    private httpClient: HttpClient,
    @Inject('config') private config: any
  ) {
  }

  getRestaurantSummaryData(): Observable<any> {
    const payload = [
      {
        source: 'ShopLists',
        text: null,
        filter: '{}',
        CountOnly: true,
        pageSize: 1,
        pageIndex: 0
      },
      {
        source: 'ShopLists',
        text: null,
        filter: '{IsCompliantShop: true}',
        CountOnly: true,
        pageSize: 1,
        pageIndex: 0
      },
      {
        source: 'ShopLists',
        text: null,
        filter: '{ShopStatus: 1}',
        CountOnly: true,
        pageSize: 1,
        pageIndex: 0
      },
      {
        source: 'ProductLists',
        text: null,
        filter: '{}',
        CountOnly: true
      },
      {
        source: 'ProductLists',
        text: null,
        filter: '{IsActive: true}',
        CountOnly: true,
        pageSize: 1,
        pageIndex: 0
      }
    ];
    return this.httpClient.post(this.config.ShopService.toQueryURL(), payload)
      .pipe(map(res => this.mapResponseToRestaurantSummaryData(res)));
  }

  private mapResponseToRestaurantSummaryData(response: any): RestaurantSummaryDataModel {
    const TotalRestaurants = response[0][0][0];
    const TotalCompliantRestaurants = response[1][0][0];
    const TotalActiveRestaurants = response[2][0][0];
    const TotalItems = response[3][0][0];
    const TotalActiveItems = response[4][0][0];
    return {
      TotalRestaurants,
      TotalCompliantRestaurants,
      TotalNonCompliantRestaurants: TotalRestaurants - TotalCompliantRestaurants,
      TotalActiveRestaurants,
      TotalInactiveRestaurants: TotalRestaurants - TotalActiveRestaurants,
      TotalItems,
      TotalActiveItems,
      TotalInactiveItems: TotalItems - TotalActiveItems
    } as RestaurantSummaryDataModel;
  }
}
