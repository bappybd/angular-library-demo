import {NgModule} from '@angular/core';
import {DashboardComponent} from './containers/dashboard/dashboard.component';
import {MatTableModule} from '@angular/material/table';
import {MatMenuModule} from '@angular/material/menu';
import {FuseSharedModule, FuseSidebarModule, FuseWidgetModule} from '@eevo/eevo-base';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatIconModule} from '@angular/material/icon';
import {MatDividerModule} from '@angular/material/divider';
import {MatTabsModule} from '@angular/material/tabs';
import {NgxChartsModule} from '@swimlane/ngx-charts';
import {MatButtonModule} from '@angular/material/button';
import {DashboardRoutingModule} from './dashboard-routing.module';
import { RestaurantSummaryTabComponent } from './components/restaurant-summary-tab/restaurant-summary-tab.component';
import {EevoPipeModule} from '@eevo/eevo-core';
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';

@NgModule({
  declarations: [DashboardComponent, RestaurantSummaryTabComponent],
  imports: [
    DashboardRoutingModule,
    MatButtonModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    MatSelectModule,
    MatTableModule,
    MatTabsModule,

    NgxChartsModule,

    FuseSharedModule,
    FuseSidebarModule,
    FuseWidgetModule,
    EevoPipeModule,
    EevoPlatformFeatureGuardModule
  ],
})
export class DashboardModule {
}
