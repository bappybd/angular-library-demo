import {Component, OnInit, ViewEncapsulation} from '@angular/core';

import {fuseAnimations} from '@eevo/eevo-base';
import {DashboardService} from '../../services/dashboard.service';
import {UserDataService} from '@eevo/eevo-core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: fuseAnimations
})
export class DashboardComponent implements OnInit {
  selectedIndex: number;
  userInfo: any;

  constructor(
    private dashboardService: DashboardService,
    private userDataService: UserDataService
  ) {
    this.userInfo = this.userDataService.getUserData();
  }


  ngOnInit(): void {
  }
}
