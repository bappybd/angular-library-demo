import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import {Subject, Subscription} from 'rxjs';
import {RestaurantSummaryQueryService} from '../../services/restaurant-summary-query.service';
import {RestaurantSummaryDataModel} from '../../models/summary-data.model';
import {fuseAnimations} from '@eevo/eevo-base';
import {SubSink} from "subsink";

interface FuseWidgetBoxDataModel {
  title: string;
  description?: string;
  value: number;
  total?: number;
  color: string;
}

@Component({
  selector: 'app-restaurant-summary-tab',
  templateUrl: './restaurant-summary-tab.component.html',
  styleUrls: ['./restaurant-summary-tab.component.scss'],
  animations: fuseAnimations
})
export class RestaurantSummaryTabComponent implements OnInit, OnDestroy {
  @Output() loading: EventEmitter<boolean> = new EventEmitter<boolean>();
  fuseWidgetBoxData: FuseWidgetBoxDataModel[] = [];
  summaryData: RestaurantSummaryDataModel;
  private subs = new SubSink();

  constructor(
    private rsQueryService: RestaurantSummaryQueryService
  ) {
  }

  ngOnInit(): void {
    this.getRestaurantSummaryData();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

  private getRestaurantSummaryData(): void {
     this.subs.sink = this.rsQueryService.getRestaurantSummaryData()
        .subscribe(res => {
          this.summaryData = res;
          this.createWidgetBoxDataOnNewSummaryData(res);
        });
  }

  private createWidgetBoxDataOnNewSummaryData(data: RestaurantSummaryDataModel): void {
    this.fuseWidgetBoxData = [
      {
        title: 'Total Restaurants',
        value: data?.TotalRestaurants,
        total: data?.TotalRestaurants,
        description: 'Restaurants',
        color: '#0693ff'
      },
      {
        title: 'Total Compliant Restaurant',
        value: data?.TotalCompliantRestaurants,
        total: data?.TotalRestaurants,
        description: 'Restaurants',
        color: '#4caf50'
      },
      {
        title: 'Total Non Compliant Restaurant',
        value: data?.TotalNonCompliantRestaurants,
        total: data?.TotalRestaurants,
        description: 'Restaurants',
        color: '#535353'
      },
      {
        title: 'Total Active Restaurant',
        value: data?.TotalActiveRestaurants,
        total: data?.TotalRestaurants,
        description: 'Restaurants',
        color: '#f8415b'
      },
      {
        title: 'Total Inactive Restaurants',
        value: data?.TotalInactiveRestaurants,
        total: data?.TotalRestaurants,
        description: 'Restaurants',
        color: '#f8415b'
      },
      {title: 'Total Items', value: data?.TotalItems, total: data?.TotalItems, description: 'Items', color: '#d292f8'},
      {title: 'Total Active Items', value: data?.TotalActiveItems, total: data?.TotalItems, description: 'Items', color: '#4be1f8'},
      {
        title: 'Total Inactive Items',
        value: data?.TotalInactiveItems,
        total: data?.TotalItems,
        description: 'Items',
        color: '#4caf50'
      },
    ];
    this.loading.emit(false);
  }
}
