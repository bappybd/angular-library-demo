import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantSummaryTabComponent } from './restaurant-summary-tab.component';

describe('RestaurantSummaryTabComponent', () => {
  let component: RestaurantSummaryTabComponent;
  let fixture: ComponentFixture<RestaurantSummaryTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantSummaryTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantSummaryTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
