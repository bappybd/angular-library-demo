export class DashboardConfigModel<T> {
  TotalElements: number;
  TotalPages: number;
  Data: Array<T>;

  constructor() {
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.Data = new Array<T>();
  }
}

export interface CreateFileModel {
  FileId: string;
  Name: string;
  AccessType: string;
  MetaData: object;
}
