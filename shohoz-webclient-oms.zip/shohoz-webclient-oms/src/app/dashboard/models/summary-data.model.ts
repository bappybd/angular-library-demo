export interface RestaurantSummaryDataModel {
  TotalRestaurants: number;
  TotalCompliantRestaurants: number;
  TotalNonCompliantRestaurants: number;
  TotalActiveRestaurants: number;
  TotalInactiveRestaurants: number;
  TotalItems: number;
  TotalActiveItems: number;
  TotalInactiveItems: number;
}
