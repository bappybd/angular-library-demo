import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AppCouponListComponent} from './container/app-coupon-list/app-coupon-list.component';
import {AppCouponCreateComponent} from './container/app-coupon-create/app-coupon-create.component';
import {AppCouponUpdateComponent} from './container/app-coupon-update/app-coupon-update.component';
import {CompatibleCouponUpdateComponent} from './components/compatible-coupon-update/compatible-coupon-update.component';
import {FeatureAccessPermission} from '@eevo/eevo-core';

const routes: Routes = [
  {
    path: '',
    component: AppCouponListComponent,
    data: {isFullScreen: true}
  },
  {
    path: 'create',
    component: AppCouponCreateComponent,
    data: {isFullScreen: true, name: 'coupon.create'},
    canActivate: [FeatureAccessPermission]
  },
  {
    path: 'update/:id',
    component: AppCouponUpdateComponent,
    data: {isFullScreen: true, name: 'coupon.details'},
    canActivate: [FeatureAccessPermission]
  },
  {
    path: 'update/:id/compatible-coupon',
    component: CompatibleCouponUpdateComponent,
    data: {isFullScreen: true, name: 'coupon.compatible'},
    canActivate: [FeatureAccessPermission]
  },
  {
    path: ':id',
    loadChildren: () =>
      import('../app-coupon-assign/app-coupon-assign.module').then(
        (m) => m.AppCouponAssignModule
      ),
    data: {
      name: 'coupon-assign',
      isFullScreen: false,
    },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppCouponRoutingModule {
}
