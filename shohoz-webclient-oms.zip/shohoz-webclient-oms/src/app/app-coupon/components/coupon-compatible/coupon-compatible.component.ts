import {Component, EventEmitter, Inject, Input, OnInit, Output} from '@angular/core';
import {FormArray, FormControl, FormGroup} from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {EevoQueryService} from '@eevo/eevo-core';
import {CouponEntity} from '../../entities/coupon-entity';
import {EevoBasicChipOptions} from '../../../shared/components/eevo-basic-chip-list/eevo-basic-chip-list.component';
import {EevoAutocompleteChipOptions} from '../../../shared/components/eevo-autocomplete-chip-list/eevo-autocomplete-chip-list.component';
import {ActivatedRoute} from '@angular/router';
import {ZoneAutocompleteChipOptions} from '../../../shared/components/zone-autocomplete-chip-list/zone-autocomplete-chip-list.component';
import {CityAutocompleteOptions} from '../../../shared/components/city-autocomplete-chip-list/city-autocomplete-chip-list.component';
import {CouponAssignEntity} from "../../../app-coupon-assign/entities/coupon-assign-entity";

@Component({
  selector: 'app-coupon-compatible',
  templateUrl: './coupon-compatible.component.html',
  styleUrls: ['./coupon-compatible.component.scss']
})
export class CouponCompatibleComponent implements OnInit {
  @Input()
  couponData: any;

  paymentMethodList: any[] = [];
  discountPartnerList: any[] = [];
  parent: FormGroup;
  removable = true;

  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  applicableCityOptions = {
    labelTxt : 'Applicable City',
    suggestionEnable: true,
    suggestionList: [
      'Chittagong', 'Sylhet', 'Dinajpur', 'Rajshahi', 'Bogra', 'Comilla'
    ],
    formControlName: 'ApplicableCity'
  } as CityAutocompleteOptions;

  compatibleCouponsOptions = {
    labelTxt : 'Compatible Coupons',
    suggestionEnable: true,
    suggestionList: [
      'SHOHOZFF’20', 'MATHANOSTO’20', 'FOOD4LIFE', 'FREEDELIVERY'
    ],
    formControlName: 'CompatibleCoupons',
    keyProp: 'Id',
    valueProp: 'CouponName',
    dataUrl: null,
    dataSource: 'CouponViewModelsDetails',
    ignoreKeyDatas: []
  } as EevoAutocompleteChipOptions;
  @Output()
  loadingCompatibleCouponData: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    private actRoute: ActivatedRoute,
    private eevoQueryService: EevoQueryService,
    private couponEntity: CouponEntity,
    @Inject('config') private config: any
    ) {
    this.compatibleCouponsOptions.ignoreKeyDatas = [this.actRoute.snapshot.params.id];
    this.compatibleCouponsOptions.dataUrl = this.config.CouponService.toQueryURL();
  }

  ngOnInit(): void {
    this.parent = this.couponData.form;
    this.getDiscountPartners();
    this.getPaymentMethods();
  }

  getPaymentMethods(): void {
    const url = this.config.AppConfigService.toQueryURL();
    this.eevoQueryService.getList<any>(
      url,
      this.couponEntity.getPaymentMethodEntityName(),
      this.couponEntity.getPaymentMethodListFields()
    ).subscribe((dataList) => {
      if (dataList) {
        this.paymentMethodList = dataList;
        this.setPaymentMethodsFormData();
        if (this.couponData.state === 'Published' || this.couponData.state === 'Inactive'){
          this.parent.disable();
        }
      }
    });
  }

  getDiscountPartners(): void {
    const url = this.config.AppConfigService.toQueryURL();
    this.eevoQueryService.getList<any>(
      url,
      this.couponEntity.getDiscountPartnersEntityName(),
      this.couponEntity.getDiscountPartnersListFields()
    ).subscribe((dataList) => {
      if (dataList) {
        this.discountPartnerList = dataList;
        this.setDiscountPartnersFormData();
      }
    });
  }

  setPaymentMethodsFormData(): void {
    let paymentMethods = this.parent.get('ApplicablePaymentMethod') as FormArray;
    const pmsLen = paymentMethods.length;
    const pmListLen = this.paymentMethodList.length;

    for (let i = 0; i < pmListLen - pmsLen; i++) {
      paymentMethods.push(new FormControl(false));
    }

    const paymentMethodLists = paymentMethods.value;

    for (let i = 0; i < pmListLen; i++) {
      const spm = this.paymentMethodList[i];

      let flag = true;
      // tslint:disable-next-line:prefer-for-of
      for (let j = 0; j < paymentMethodLists.length; j++) {
        const pm = paymentMethodLists[j];
        if (pm === spm.Id || pm === spm._id) {
          flag = false;
          paymentMethods.at(i).setValue(spm);
          break;
        }
      }
      if (flag) {
        paymentMethods.at(i).setValue(false);
      }
    }
    paymentMethods.valueChanges.subscribe(checkbox => {
      paymentMethods.setValue(
        paymentMethods.value.map((value, i) => value ? this.paymentMethodList[i] : false),
        {emitEvent: false}
      );
    });
  }

  setDiscountPartnersFormData(): void {
    const exclusiveTo = this.parent.get('DiscountPartners') as FormArray;

    const exclusiveToLen = exclusiveTo.length;
    const discountPartnerListLen = this.discountPartnerList.length;

    for (let i = 0; i < discountPartnerListLen - exclusiveToLen; i++) {
      exclusiveTo.push(new FormControl(false));
    }

    const exclusiveToLists = exclusiveTo.value;

    for (let i = 0; i < discountPartnerListLen; i++) {
      const spm = this.discountPartnerList[i];

      let flag = true;
      // tslint:disable-next-line:prefer-for-of
      for (let j = 0; j < exclusiveToLists.length; j++) {
        const pm = exclusiveToLists[j];
        if (pm === spm.Id || pm === spm.Id) {
          flag = false;
          exclusiveTo.at(i).setValue(spm);
          break;
        }
      }
      if (flag) {
        exclusiveTo.at(i).setValue(false);
      }
    }
    exclusiveTo.valueChanges.subscribe(checkbox => {
      exclusiveTo.setValue(
        exclusiveTo.value.map((value, i) => value ? this.discountPartnerList[i] : false),
        {emitEvent: false}
      );
    });
  }

}
