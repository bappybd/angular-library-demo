import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponCompatibleComponent } from './coupon-compatible.component';

describe('CouponCompatibleComponent', () => {
  let component: CouponCompatibleComponent;
  let fixture: ComponentFixture<CouponCompatibleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponCompatibleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponCompatibleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
