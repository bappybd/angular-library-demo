import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponRankingDialogComponent } from './coupon-ranking-dialog.component';

describe('CouponRankingDialogComponent', () => {
  let component: CouponRankingDialogComponent;
  let fixture: ComponentFixture<CouponRankingDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponRankingDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponRankingDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
