import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {Coupon} from "../../models/coupon-models";
import {CouponCommandService} from "../../services/coupon-command.service";
import {CouponCommandBuilderService} from "../../services/coupon-command-builder.service";
import {EevoNotifyService, NotifyType} from "@eevo/eevo-core";
import {CouponEntity} from "../../entities/coupon-entity";
import {CouponNotificationService} from "../../services/coupon-notification.service";

@Component({
  selector: 'app-coupon-ranking-dialog',
  templateUrl: './coupon-ranking-dialog.component.html',
  styleUrls: ['./coupon-ranking-dialog.component.scss']
})
export class CouponRankingDialogComponent implements OnInit {
  selectedCouponList: Coupon[] = [];
  constructor(
    public matDialogRef: MatDialogRef<CouponRankingDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private couponCommandBuilderService: CouponCommandBuilderService,
    private couponCommandService: CouponCommandService,
    private eevoNotifyService: EevoNotifyService,
    private couponEntity: CouponEntity,
    private couponNotificationService: CouponNotificationService) { }

  ngOnInit(): void {
  }

  handleCouponListSelected($event: Coupon[]) {
    this.selectedCouponList = $event;
  }

  updateCouponRanking() {
    const command = this.couponCommandBuilderService.getUpdateCouponRankCommand(this.selectedCouponList);
    this.couponNotificationService.couponRankUpdated();
    this.eevoNotifyService.displayMessage(
      'Coupon Ranking update requested!',
      NotifyType.Info
    );

    this.couponCommandService.updateCouponRank(command).subscribe(data => {
    }, error => {
      this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
    });
  }
}
