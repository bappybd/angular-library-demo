import {Component, EventEmitter, OnInit, Output, ViewChild} from '@angular/core';
import {CouponQueryService} from '../../services/coupon-query.service';
import {DatatableModel} from '@eevo/eevo-platform-datatable';
import {Coupon} from '../../models/coupon-models';
import {MatTable, MatTableDataSource} from '@angular/material/table';
import {CdkDragDrop, CdkDropList, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import {EevoNotifyService, NotifyType} from '@eevo/eevo-core';

@Component({
  selector: 'app-coupon-ranking-list',
  templateUrl: './coupon-ranking-list.component.html',
  styleUrls: ['./coupon-ranking-list.component.scss']
})
export class CouponRankingListComponent implements OnInit {
  @ViewChild('table') table: MatTable<Coupon>;
  @ViewChild('list') list: CdkDropList;
  @Output() couponListSelected: EventEmitter<Coupon[]> = new EventEmitter<Coupon[]>();
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  displayedColumns: string[] = ['CouponName', 'CouponCode', 'Rank', 'ApplicableTime'];
  dataSource: MatTableDataSource<Coupon>;
  couponList: Coupon[] = [];
  sortedCouponList: Coupon[] = [];
  scrollDistance = 1.5;
  currentPageNumber = 0;
  private lastCoupon: Coupon;
  private totalCoupons = 0;

  constructor(
    private couponQueryService: CouponQueryService,
    private eevoNotifyService: EevoNotifyService,
  ) {
  }

  ngOnInit(): void {
    this.initDatatableModel();
  }

  initDatatableModel(): void {
    this.datatableModel.PageSize = 20;
    this.datatableModel.CurrentPageNumber = 0;
    this.datatableModel.SortBy = 'Rank';
    this.datatableModel.Descending = false;
    this.getCouponList('Rank', false, 20, true);
  }

  insertIntoSortedList(coupon: Coupon): void {
    const idx = this.sortedCouponList.findIndex(cp => cp.Id === coupon.Id);
    if (idx > -1) {
      this.sortedCouponList[idx].Rank = coupon.Rank;
    } else {
      this.sortedCouponList.push(coupon);
    }

    this.couponListSelected.emit(this.sortedCouponList);
  }

  dropTable(event: CdkDragDrop<Coupon[]>): void {
    const curIdx = event.currentIndex;
    const prevIdx = event.previousIndex;
    if (+curIdx === prevIdx) {
      return;
    }
    if (curIdx + 1 === this.totalCoupons) {
      event.container.data[prevIdx].Rank = Number((event.container.data[curIdx].Rank * 1.5).toFixed(3));
      this.insertIntoSortedList(event.container.data[prevIdx]);
    } else if (curIdx + 1 === this.couponList.length) {
      const tempRank = event.container.data[curIdx].Rank + this.lastCoupon.Rank;
      event.container.data[prevIdx].Rank = Number((tempRank / 2.0).toFixed(3));
      this.insertIntoSortedList(event.container.data[prevIdx]);
    } else if (curIdx === 0) {
      event.container.data[prevIdx].Rank = Number((event.container.data[curIdx].Rank * 0.5).toFixed(3));
      this.insertIntoSortedList(event.container.data[prevIdx]);
    } else {
      const tempRank = event.container.data[curIdx].Rank +
        ((prevIdx > curIdx) ? event.container.data[curIdx - 1].Rank : event.container.data[curIdx + 1].Rank);
      event.container.data[prevIdx].Rank = Number((tempRank / 2.0).toFixed(3));
      this.insertIntoSortedList(event.container.data[prevIdx]);
    }

    if (event.previousContainer === event.container) {
      moveItemInArray(
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex
      );
    }
    this.table.renderRows();
  }

  public getCouponList(sortBy: string, isDescending: boolean, couponListPageSize: number, getTotalCoupons = false): void {
    this.couponQueryService.getCouponListForRankingWithExtra(sortBy, isDescending, couponListPageSize, this.currentPageNumber, getTotalCoupons)
      .subscribe(([coupons, lastCoupon, total]) => {
          coupons.forEach(coupon => {
            this.couponList.push(coupon);
          });
          this.dataSource = new MatTableDataSource(this.couponList);
          this.lastCoupon = (lastCoupon || this.couponList?.length) ? lastCoupon || this.couponList[this.couponList.length - 1] : null;
          this.totalCoupons = total || this.totalCoupons;
          this.currentPageNumber = this.currentPageNumber + 1;
        },
        (error) => {
          console.log('Error', error);
          this.eevoNotifyService.displayMessage('Failed to fetch new coupons', NotifyType.Error);
        });
  }

  onScrollDown(): void {
    this.getCouponList('Rank', false, 20);
  }
}
