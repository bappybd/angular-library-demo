import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponRankingListComponent } from './coupon-ranking-list.component';

describe('CouponRankingListComponent', () => {
  let component: CouponRankingListComponent;
  let fixture: ComponentFixture<CouponRankingListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponRankingListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponRankingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
