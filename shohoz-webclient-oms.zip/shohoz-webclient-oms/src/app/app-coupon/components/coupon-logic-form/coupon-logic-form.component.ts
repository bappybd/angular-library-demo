import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormControl, FormGroup} from '@angular/forms';
import {CouponFormBuilder} from '../../services/coupon-form-builder';

@Component({
  selector: 'app-coupon-logic-form',
  templateUrl: './coupon-logic-form.component.html',
  styleUrls: ['./coupon-logic-form.component.scss']
})
export class CouponLogicFormComponent implements OnInit {
  @Input()
  index: number;

  @Input()
  parent: FormGroup;

  constructor(private couponFormBuilder: CouponFormBuilder) { }

  ngOnInit(): void {
  }

  addControl(): void {
    const couponLogic = this.parent.get('CouponLogic') as FormArray;
    couponLogic.push(this.createCouponLogicForm());
  }

  get couponLogic(): AbstractControl[] {
    return (this.parent.get('CouponLogic') as FormArray).controls;
  }

  get numberOfSlot(): number {
    const {length} = this.couponLogic;
    return length;
  }

  removeControl(i: number): void {
    const couponLogic = this.parent.get('CouponLogic') as FormArray;
    couponLogic.removeAt(i);
  }

  isCouponLogicFormValid(): boolean {
    const couponLogic = this.parent.get('CouponLogic') as FormArray;
    return couponLogic.valid;
  }


  private createCouponLogicForm(): FormGroup  {
    return this.couponFormBuilder.getLogicForm();
  }
}
