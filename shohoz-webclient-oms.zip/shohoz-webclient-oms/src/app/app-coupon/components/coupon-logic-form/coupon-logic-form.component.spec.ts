import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponLogicFormComponent } from './coupon-logic-form.component';

describe('CouponLogicFormComponent', () => {
  let component: CouponLogicFormComponent;
  let fixture: ComponentFixture<CouponLogicFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponLogicFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponLogicFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
