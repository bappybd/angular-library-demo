import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';

@Component({
  selector: 'app-coupon-info',
  templateUrl: './coupon-info.component.html',
  styleUrls: ['./coupon-info.component.scss']
})
export class CouponInfoComponent implements OnInit {

  @Input()
  parent: FormGroup;

  constructor() { }

  ngOnInit(): void {
  }

}
