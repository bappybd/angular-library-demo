import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponValidityComponent } from './coupon-validity.component';

describe('CouponValidityComponent', () => {
  let component: CouponValidityComponent;
  let fixture: ComponentFixture<CouponValidityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponValidityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponValidityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
