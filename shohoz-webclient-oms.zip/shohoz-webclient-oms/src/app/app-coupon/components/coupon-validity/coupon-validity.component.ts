import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {EevoValidator} from "../../../shared/validator/eevo.validator";

@Component({
  selector: 'app-coupon-validity',
  templateUrl: './coupon-validity.component.html',
  styleUrls: ['./coupon-validity.component.scss']
})
export class CouponValidityComponent implements OnInit {
  @Input()
  parent: FormGroup;
  currentDate: Date;
  constructor() {
    this.currentDate = new Date();
  }

  ngOnInit(): void {
    this.setValidators();
  }

  setValidators(): void {
    this.parent.get('RedeemableTimes').valueChanges.subscribe(value => {
      this.parent.get('RedeemableTimesPerUsers').setValidators(EevoValidator.lessThan('RedeemableTimes'));
      this.parent.get('RedeemableTimesPerUsers').updateValueAndValidity();
    });

    this.parent.get('RedeemableTimesPerUsers').valueChanges.subscribe(value => {
      this.parent.get('MaxRedeemCountPerUserPerDay').setValidators(EevoValidator.lessThan('RedeemableTimesPerUsers'));
      this.parent.get('MaxRedeemCountPerUserPerDay').updateValueAndValidity();
    });

    this.parent.get('ExpiredDate').valueChanges.subscribe(value => {
      this.parent.get('ExpiredTime').setValidators(EevoValidator.dateTimeLessThan('AppliedTime'));
      this.parent.get('ExpiredTime').updateValueAndValidity();
    });

    /*this.parent.get('AppliedDate').valueChanges.subscribe(value => {
      this.parent.get('ExpiredTime').setValidators(EevoValidator.dateTimeLessThan('AppliedTime'));
      this.parent.get('ExpiredTime').updateValueAndValidity();
    });*/

    this.parent.get('AppliedTime').valueChanges.subscribe(value => {
      this.parent.get('ExpiredTime').setValidators(EevoValidator.dateTimeLessThan('AppliedTime'));
      this.parent.get('ExpiredTime').updateValueAndValidity();
    });

  }

}
