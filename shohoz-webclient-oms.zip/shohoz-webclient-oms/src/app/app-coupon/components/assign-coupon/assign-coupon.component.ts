import { Component, OnInit } from '@angular/core';
import {FuseSidebarService} from "@eevo/eevo-base";

@Component({
  selector: 'app-assign-coupon',
  templateUrl: './assign-coupon.component.html',
  styleUrls: ['./assign-coupon.component.scss']
})
export class AssignCouponComponent implements OnInit {

  constructor(private fuseSidebarService: FuseSidebarService) { }

  ngOnInit(): void {
  }

  toggleSidebarOpen(key): void {
    this.fuseSidebarService.getSidebar(key).toggleOpen();
  }
}
