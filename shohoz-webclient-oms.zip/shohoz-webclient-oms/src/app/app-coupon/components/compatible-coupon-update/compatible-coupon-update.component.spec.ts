import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompatibleCouponUpdateComponent } from './compatible-coupon-update.component';

describe('CompatibleCouponUpdateComponent', () => {
  let component: CompatibleCouponUpdateComponent;
  let fixture: ComponentFixture<CompatibleCouponUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompatibleCouponUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompatibleCouponUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
