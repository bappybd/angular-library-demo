import {Component, Inject, OnInit} from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {CouponService} from '../../services/coupon-service';
import {CouponModel, CouponState} from '../../../shared/models/coupon-entity-models';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {CouponEntity} from '../../entities/coupon-entity';
import {CouponFormBuilder} from '../../services/coupon-form-builder';
import {FormGroup} from '@angular/forms';
import {EevoAutocompleteChipOptions} from '../../../shared/components/eevo-autocomplete-chip-list/eevo-autocomplete-chip-list.component';
import {ActivatedRoute, Router} from '@angular/router';
import {fuseAnimations} from '@eevo/eevo-base';
import {CouponCommandBuilderService} from '../../services/coupon-command-builder.service';
import {CouponNotificationService} from '../../services/coupon-notification.service';
import {CouponCommandService} from '../../services/coupon-command.service';

@Component({
  selector: 'app-compatible-coupon-update',
  templateUrl: './compatible-coupon-update.component.html',
  styleUrls: ['./compatible-coupon-update.component.scss'],
  animations: fuseAnimations
})
export class CompatibleCouponUpdateComponent implements OnInit {
  breadcrumbList: BreadcrumbModel[] = [];
  couponForm: FormGroup;
  couponId: string;
  dataLoaded: boolean;
  formSubmitted: boolean;
  couponDetails: CouponModel;
  couponDataLoading = false;
  compatibleCouponsOptions = {
    labelTxt : 'Compatible Coupons',
    suggestionEnable: true,
    suggestionList: [
      'SHOHOZFF’20', 'MATHANOSTO’20', 'FOOD4LIFE', 'FREEDELIVERY'
    ],
    formControlName: 'CompatibleCoupons',
    keyProp: 'Id',
    valueProp: 'CouponName',
    dataUrl: null,
    dataSource: 'CouponViewModelsDetails',
    ignoreKeyDatas: []
  } as EevoAutocompleteChipOptions;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private couponService: CouponService,
    private couponEntity: CouponEntity,
    private couponFormBuilder: CouponFormBuilder,
    @Inject('config') private config: any,
    private eevoQueryService: EevoQueryService,
    private couponCommandBuilderService: CouponCommandBuilderService,
    private couponNotificationService: CouponNotificationService,
    private eevoNotifyService: EevoNotifyService,
    private couponCommandService: CouponCommandService
  ) {
    this.couponId = this.activatedRoute.snapshot.params.id;
    this.compatibleCouponsOptions.ignoreKeyDatas = [this.couponId];
    this.compatibleCouponsOptions.dataUrl = this.config.CouponService.toQueryURL();
  }

  ngOnInit(): void {
    const url = this.config.CouponService.toQueryURL();
    this.eevoQueryService.getDetailsById<CouponModel>(
      url, this.couponEntity.getDetailsName(), this.couponId , this.couponEntity.getDetailsFields()
    ).subscribe((response) => {
      if (response && response.Id) {
        response.CouponId = response.Id;
        this.couponDetails = response;
        this.setBreadcrumbData(response);
        this.couponForm = this.couponFormBuilder.getCouponForm(response);
        this.dataLoaded = true;
      }
    }, error => {
      this.dataLoaded = false;
    });
  }

  private setBreadcrumbData(data: CouponModel): void {
    this.breadcrumbList.push({
      Text: 'Coupons',
      Path: ['/coupon']
    });

    this.breadcrumbList.push({
      Text: 'Update Compatible Coupon'
    });

    this.breadcrumbList.push({
      Text: data.CouponName
    });
  }

  updateCoupon(): void {
    this.formSubmitted = true;
    const command = this.couponCommandBuilderService.getUpdateSupportedCouponIdsCommand(this.couponForm, this.couponDetails);
    this.couponNotificationService.couponUpdated();
    this.eevoNotifyService.displayMessage(
      this.couponEntity.getMessages().UPDATE_REQUEST,
      NotifyType.Info
    );

    this.couponCommandService.updateSupportedCouponIds(command).subscribe(data => {
      this.formSubmitted = false;
      this.discard();
    }, error => {
      this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
      this.formSubmitted = false;
    });
  }

  discard(): void {
    this.router.navigate(['coupon']);
  }
}
