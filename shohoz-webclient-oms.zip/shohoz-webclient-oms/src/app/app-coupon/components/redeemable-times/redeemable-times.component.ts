import {Component, Input, OnInit} from '@angular/core';
import {FormGroup} from '@angular/forms';

@Component({
  selector: 'app-redeemable-times',
  templateUrl: './redeemable-times.component.html',
  styleUrls: ['./redeemable-times.component.scss']
})
export class RedeemableTimesComponent implements OnInit {
  @Input()
  parent: FormGroup;

  constructor() { }

  ngOnInit(): void {
  }

}
