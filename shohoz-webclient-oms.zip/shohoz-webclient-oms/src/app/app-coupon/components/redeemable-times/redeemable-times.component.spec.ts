import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RedeemableTimesComponent } from './redeemable-times.component';

describe('RedeemableTimesComponent', () => {
  let component: RedeemableTimesComponent;
  let fixture: ComponentFixture<RedeemableTimesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RedeemableTimesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RedeemableTimesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
