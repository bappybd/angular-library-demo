import { CouponState } from 'src/app/shared/models/coupon-entity-models';

export interface Coupon {
  _id: string;
  Id: string;
  CouponName: string;
  CouponCode: string;
  Rank: number;
  Category: string;
  ValidFrom: string;
  ValidTill: string;
  CouponState: CouponState;
  Active: string;
  Weight: string;
}

export interface CouponListResponse {
  data: Coupon[];
  totalCount: number;
}

export interface CouponFilter {
  searchKey: string;
  status: string;
  affordability: string;
  zone: any;
}

export class CouponListConfigModel<T> {
  TotalElements: number;
  TotalPages: number;
  Data: Array<T>;

  constructor() {
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.Data = new Array<T>();
  }
}

export interface UpdateCouponRank {
  CouponId: string;
  Rank: number;
}
