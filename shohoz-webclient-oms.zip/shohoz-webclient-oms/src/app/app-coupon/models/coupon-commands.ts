import {EevoCommandBase} from '@eevo/eevo-core';
import {CouponLogicModel, CouponState} from '../../shared/models/coupon-entity-models';
import {UpdateCouponRank} from "./coupon-models";

export class CouponCreateCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  public CouponId: string;
  public CouponName: string;
  public CouponCode: string;
  public Category: string;
  public ValidFrom: string;
  public ValidTill: string;
  public MaximumDiscountAmount: number;
  public CouponLogics: CouponLogicModel[];
  public Rank: number;
  public SupportedCouponIds: string[];
  public Description_En: string;
  public Description_Bn: string;
  public HighlightText_En: string;
  public HighlightText_Bn: string;
  public MaxRedeemCountPerUser?: number;
  public MaxRedeemCountPerUserPerDay?: number;
  public MaxRedeemCount?: number;
  public ShohozPortionOfDiscount: number;
  public AutoApplied: boolean;
  public IsProductCoupon: boolean;
  public IsGlobalCoupon: boolean;
  public CouponState: CouponState;
  public CityIds: string[];
  public PaymentMethodIds: string[];
  public DiscountPartnerIds: string[];
}

export class CouponUpdateCommand extends EevoCommandBase {
  constructor() {
    super();
  }
}

export class CouponRankUpdateCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  CouponRanks: UpdateCouponRank[] = [];
}

export class DuplicateCouponCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  CouponId: string;
  DuplicateCouponId: string;
}


export class UpdateSupportedCouponIdsCommand extends EevoCommandBase {
  constructor() {
    super();
  }
  CouponId: string;
  SupportedCouponIdsToBeAdded: string[];
  SupportedCouponIdsToBeRemoved: string[];
}
