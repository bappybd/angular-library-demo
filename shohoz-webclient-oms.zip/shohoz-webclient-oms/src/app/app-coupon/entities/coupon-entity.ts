import {Injectable} from '@angular/core';
import {EevoEntityRoot} from '@eevo/eevo-core';

enum CouponEvents {
  CouponBusinessRuleViolatedEvent = 'CouponBusinessRuleViolatedEvent',
  CouponDeactivatedEvent = 'CouponDeactivatedEvent',
  CouponUpdatedEvent = 'CouponUpdatedEvent',
  CouponCreatedEvent = 'CouponCreatedEvent',
  CouponRankUpdatedEvent = 'CouponRankUpdatedEvent'
}

@Injectable({
  providedIn: 'root'
})
export class CouponEntity extends EevoEntityRoot {
  Events = CouponEvents;

  constructor() {
    super('CouponViewModels', 'Coupon');
  }

  getDetailsFields(): string[] {
    return [
      'CouponName', 'Category', 'ValidFrom', 'ValidTill', 'MaximumDiscountAmount', 'CouponLogics',
      'Rank', 'SupportedCouponIds', 'Description_En', 'Description_Bn', 'HighlightText_Bn',
      'HighlightText_En', 'MaxRedeemCountPerUser', 'MaxRedeemCountPerUserPerDay',
      'MaxRedeemCount', 'ShohozPortionOfDiscount', 'CouponCode', 'AutoApplied', 'CouponState',
      'CityIds', 'PaymentMethodIds', 'DiscountPartnerIds', 'IsProductCoupon', 'IsGlobalCoupon',
    ];
  }

  getListFields(): string[] {
    return [
      'CouponName', 'ValidFrom', 'ValidTill', 'CouponState', 'Rank', 'CouponCode', 'AutoApplied', 'IsGlobalCoupon'
    ];
  }

  getPaymentMethodEntityName(): string {
    return 'PaymentMethods';
  }

  getPaymentMethodListFields(): string[] {
    return [
      'Name'
    ];
  }

  getDiscountPartnersEntityName(): string {
    return 'DiscountPartners';
  }

  getDiscountPartnersListFields(): string[] {
    return [
      'Name'
    ];
  }
}
