import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {AppCouponRoutingModule} from './app-coupon-routing.module';
import {AppCouponListComponent} from './container/app-coupon-list/app-coupon-list.component';
import {AppCouponCreateComponent} from './container/app-coupon-create/app-coupon-create.component';
import {AppCouponUpdateComponent} from './container/app-coupon-update/app-coupon-update.component';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {EevoPlatformAvatarModule} from '@eevo/eevo-platform-avatar';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {CouponFilterComponent} from './components/coupon-filter/coupon-filter.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {FuseDirectivesModule, FuseSidebarModule} from '@eevo/eevo-base';
import {AssignCouponComponent} from './components/assign-coupon/assign-coupon.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {CouponLogicFormComponent} from './components/coupon-logic-form/coupon-logic-form.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatChipsModule} from '@angular/material/chips';
import {CouponNotificationService} from './services/coupon-notification.service';
import {SharedModule} from '../shared/shared.module';
import {CouponInfoComponent} from './components/coupon-info/coupon-info.component';
import {RedeemableTimesComponent} from './components/redeemable-times/redeemable-times.component';
import {CouponValidityComponent} from './components/coupon-validity/coupon-validity.component';
import {CouponCompatibleComponent} from './components/coupon-compatible/coupon-compatible.component';
import {CouponRankingDialogComponent} from './components/coupon-ranking-dialog/coupon-ranking-dialog.component';
import {MatDialogModule} from '@angular/material/dialog';
import {FlexLayoutModule, FlexModule} from '@angular/flex-layout';
import {CouponRankingListComponent} from './components/coupon-ranking-list/coupon-ranking-list.component';
import {MatTableModule} from '@angular/material/table';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {CompatibleCouponUpdateComponent} from './components/compatible-coupon-update/compatible-coupon-update.component';
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';
import {InfiniteScrollModule} from 'ngx-infinite-scroll';
import {MatTooltipModule} from '@angular/material/tooltip';


@NgModule({
  declarations: [
    AppCouponListComponent,
    AppCouponCreateComponent,
    AppCouponUpdateComponent,
    CouponFilterComponent,
    AssignCouponComponent,
    CouponLogicFormComponent,
    CouponInfoComponent,
    RedeemableTimesComponent,
    CouponValidityComponent,
    CouponCompatibleComponent,
    CouponRankingDialogComponent,
    CouponRankingListComponent,
    CompatibleCouponUpdateComponent
  ],
  imports: [
    CommonModule,
    AppCouponRoutingModule,
    FlexModule,
    MatButtonModule,
    MatCardModule,
    EevoPlatformDatatableModule,
    NgxDatatableModule,
    EevoPlatformAvatarModule,
    MatSlideToggleModule,
    MatIconModule,
    MatMenuModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSelectModule,
    FuseSidebarModule,
    MatToolbarModule,
    FuseDirectivesModule,
    MatProgressBarModule,
    MatExpansionModule,
    EevoPlatformBreadcrumbModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatChipsModule,
    SharedModule,
    MatDialogModule,
    MatTableModule,
    DragDropModule,
    EevoPlatformFeatureGuardModule,
    FlexLayoutModule,
    InfiniteScrollModule,
    MatTooltipModule
  ],
  exports: [
    CouponFilterComponent
  ],
  providers: [
    CouponNotificationService
  ]
})
export class AppCouponModule {
}
