import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCouponCreateComponent } from './app-coupon-create.component';

describe('AppCouponCreateComponent', () => {
  let component: AppCouponCreateComponent;
  let fixture: ComponentFixture<AppCouponCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCouponCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCouponCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
