import {Component, OnDestroy, OnInit} from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {CouponFormBuilder} from '../../services/coupon-form-builder';
import {FormGroup, Validators} from '@angular/forms';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {CouponEntity} from '../../entities/coupon-entity';
import {CouponCommandBuilderService} from '../../services/coupon-command-builder.service';
import {CouponCommandService} from '../../services/coupon-command.service';
import {CouponNotificationService} from '../../services/coupon-notification.service';
import {fuseAnimations} from '@eevo/eevo-base';
import {Router} from '@angular/router';
import {MatSlideToggleChange} from "@angular/material/slide-toggle";
import {EevoValidator} from "../../../shared/validator/eevo.validator";
import {SubSink} from "subsink";

@Component({
  selector: 'app-app-coupon-create',
  templateUrl: './app-coupon-create.component.html',
  styleUrls: ['./app-coupon-create.component.scss'],
  animations: fuseAnimations
})
export class AppCouponCreateComponent implements OnInit, OnDestroy {

  formSubmitted = false;
  breadcrumbList: BreadcrumbModel[] = [];
  couponForm: FormGroup;
  compatibleData: any;
  private subs = new SubSink();

  constructor(
    private router: Router,
    private couponFormBuilder: CouponFormBuilder,
    private couponEntity: CouponEntity,
    private couponCommandBuilderService: CouponCommandBuilderService,
    private couponCommandService: CouponCommandService,
    private eevoNotifyService: EevoNotifyService,
    private couponNotificationService: CouponNotificationService) { }

  ngOnInit(): void {
    this.setBreadcrumbData();
    this.couponForm = this.couponFormBuilder.getCouponForm();
    this.couponFormBuilder.setAdditionalValidators(this.couponForm);
    this.compatibleData = {form: this.couponForm};
  }

  goToCouponListPage(): void {
    this.router.navigate(['coupon']);
  }

  createCoupon(): void {
    this.couponForm.markAllAsTouched();
    if (this.couponForm.valid) {
      this.formSubmitted = true;
      const command = this.couponCommandBuilderService.getCouponCommand(this.couponForm);
      this.couponNotificationService.couponCreated();
      this.eevoNotifyService.displayMessage(
        this.couponEntity.getMessages().CREATE_REQUEST,
        NotifyType.Info
      );

      this.subs.sink = this.couponCommandService.createCoupon(command).subscribe(data => {
        this.formSubmitted = false;
        this.goToCouponListPage();
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
      });
    }
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Coupons',
      Path: ['/coupon']
    });

    this.breadcrumbList.push({
      Text: 'Create New Coupon'
    });
  }

  setAndClearValidators(value: MatSlideToggleChange): void {
    if (!value.checked) {
      this.couponForm.get('CouponCode').setValidators([Validators.required]);
      this.couponForm.get('CouponCode').updateValueAndValidity();
      this.couponForm.get('RedeemableTimes').setValidators([Validators.required]);
      this.couponForm.get('RedeemableTimes').updateValueAndValidity();
      this.couponForm.get('RedeemableTimesPerUsers').setValidators([Validators.required]);
      this.couponForm.get('RedeemableTimesPerUsers').updateValueAndValidity();
      this.couponForm.get('MaxRedeemCountPerUserPerDay').setValidators([Validators.required]);
      this.couponForm.get('MaxRedeemCountPerUserPerDay').updateValueAndValidity();

    }
    else {
      this.couponForm.get('CouponCode').clearValidators();
      this.couponForm.get('CouponCode').setErrors(null);
      this.couponForm.get('RedeemableTimes').clearValidators();
      this.couponForm.get('RedeemableTimes').setErrors(null);
      this.couponForm.get('RedeemableTimesPerUsers').clearValidators();
      this.couponForm.get('RedeemableTimesPerUsers').setErrors(null);
      this.couponForm.get('MaxRedeemCountPerUserPerDay').clearValidators();
      this.couponForm.get('MaxRedeemCountPerUserPerDay').setErrors(null);
    }
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }

}
