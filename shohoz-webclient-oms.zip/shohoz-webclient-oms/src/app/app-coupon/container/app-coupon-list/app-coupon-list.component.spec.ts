import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCouponListComponent } from './app-coupon-list.component';

describe('AppCouponListComponent', () => {
  let component: AppCouponListComponent;
  let fixture: ComponentFixture<AppCouponListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCouponListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCouponListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
