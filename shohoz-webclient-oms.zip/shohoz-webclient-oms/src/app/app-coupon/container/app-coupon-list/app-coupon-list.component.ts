import {Component, Input, OnInit, TemplateRef, ViewChild, ViewChildren, ViewEncapsulation} from '@angular/core';
import {DatatableModel, EevoPlatformTableComponent} from '@eevo/eevo-platform-datatable';
import {BehaviorSubject} from 'rxjs';
import {Router} from '@angular/router';
import {ColumnMode, SelectionType, TableColumn} from '@swimlane/ngx-datatable';
import {FuseSidebarService} from '@eevo/eevo-base';
import {CouponQueryService} from '../../services/coupon-query.service';
import {Coupon, CouponFilter, CouponListConfigModel} from '../../models/coupon-models';
import {MatDialog} from '@angular/material/dialog';
import {CouponRankingDialogComponent} from '../../components/coupon-ranking-dialog/coupon-ranking-dialog.component';
import {CouponNotificationService} from '../../services/coupon-notification.service';
import {CouponEntity} from '../../entities/coupon-entity';
import {CouponState} from '../../../shared/models/coupon-entity-models';
// @ts-ignore
import {CouponService} from '../../services/coupon-service';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {CouponCommandBuilderService} from '../../services/coupon-command-builder.service';
import {EevoNotifyService, NotifyType} from '@eevo/eevo-core';
import {CouponCommandService} from '../../services/coupon-command.service';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';
import {take} from 'rxjs/operators';

@Component({
  selector: 'app-app-coupon-list',
  templateUrl: './app-coupon-list.component.html',
  styleUrls: ['./app-coupon-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppCouponListComponent implements OnInit {
  @ViewChild('headerTemplate', {static: true}) headerTemplate: TemplateRef<any>;
  @ViewChild('nameCell', {static: true}) nameCellTemplate: TemplateRef<any>;
  @ViewChild('actionCell', {static: true}) actionCellTemplate: TemplateRef<any>;
  @ViewChild('appliedOnCell', {static: true}) appliedOnCellTemplate: TemplateRef<any>;
  @ViewChild('expiredOnCell', {static: true}) expiredOnCellTemplate: TemplateRef<any>;
  @ViewChild('couponStateCell', {static: true}) couponStateCellTemplate: TemplateRef<any>;
  @ViewChild('couponCodeCell', {static: true}) couponCodeCellTemplate: TemplateRef<any>;
  @ViewChild('couponRankingCell', {static: true}) couponRankingCellTemplate: TemplateRef<any>;

  @ViewChild(EevoPlatformTableComponent, {static: true}) datatable: EevoPlatformTableComponent<any>;
  private datatableModelInput = new BehaviorSubject<CouponListConfigModel<Coupon>>(undefined);
  datatableModel: DatatableModel<any> = new DatatableModel<any>(undefined);
  configOption: any = {};
  searchKey: string;
  couponFilter: CouponFilter;
  isLoading = true;
  @Input() searchFilter: string;
  dialogRef: any;

  constructor(
    private router: Router,
    private couponEntity: CouponEntity,
    private couponQueryService: CouponQueryService,
    private sidebarService: FuseSidebarService,
    public matDialog: MatDialog,
    private couponNotificationService: CouponNotificationService,
    private couponService: CouponService,
    private couponCommandBuilderService: CouponCommandBuilderService,
    private eevoNotifyService: EevoNotifyService,
    private couponCommandService: CouponCommandService,
    private fgs: FeatureGuardService
  ) {
  }

  ngOnInit(): void {
    this.prepareDataTable();

    this.couponNotificationService.onReceived().subscribe(data => {
      if (data.ActionName !== this.couponEntity.Events.CouponBusinessRuleViolatedEvent) {
        this.getCouponList(this.datatableModel, this.couponFilter);
      }
    });
  }

  getSearchFilterData($event: CouponFilter): void {
    this.couponFilter = $event;
    this.datatableModel.CurrentPageNumber = 0;
    this.getCouponList(this.datatableModel, this.couponFilter);
  }

  private prepareDataTable(): void {
    this.configOption = {
      columns: [
        {
          prop: 'CouponName',
          name: 'Coupon Name',
          flexGrow: 1.5,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.nameCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'CouponCode',
          name: 'Coupon Code',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.couponCodeCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'Rank',
          name: 'Ranking',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.couponRankingCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ValidFrom',
          name: 'Applied On',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.appliedOnCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'ValidTill',
          name: 'Expired On',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.expiredOnCellTemplate,
          draggable: true,
          sortable: true,
        },
        {
          prop: 'CouponState',
          name: 'Status',
          flexGrow: 1,
          headerTemplate: this.headerTemplate,
          cellTemplate: this.couponStateCellTemplate,
          draggable: true,
          sortable: true,
        }
      ] as TableColumn[],
      defaultSort: 'CreatedDate',
      descending: true,
      pageSize: 10,
      messages: {
        emptyMessage: '<img alt="No Result Found" src="../../../../assets/images/no-data.jpg"/>',
        totalMessage: 'Total'
      },
    };
    this.addActionColumn();
    this.getCouponList(this.datatableModel, this.couponFilter);
    this.initDataTable();
  }

  fetchDataRequired(tableModel: DatatableModel<any>): void {
    this.getCouponList(tableModel, this.couponFilter);
    this.topFunction();
  }

  selectData(dataTableRow: any): void {
    // this.router.navigate(['shop', 'detail', dataTableRow.Id, 'overview']);
  }

  editData(dataTableRow: any): void {
    this.router.navigate(['shop', 'update', dataTableRow.Id, 0]);
  }

  topFunction(): void {
    document.getElementById('container-3').scrollTop = 0;
  }

  initDataTable(): void {
    this.datatableModelInput.subscribe(response => {
      this.datatableModel.TotalElements = response ? response[1][0][0] : 0;
      this.datatableModel.Data = response ? response[0] : [];
    }, err => console.log(err));

    this.datatableModel.SortBy = this.configOption.defaultSort;
    this.datatableModel.Descending = this.configOption.descending;
    this.datatableModel.PageSize = this.configOption.pageSize;
    this.datatableModel.SelectionType = SelectionType.checkbox;

    if (this.datatable) {
      this.datatable.columns = this.configOption.columns;
      this.datatable.messages = this.configOption.messages;
    }
  }

  public getCouponList(tableModel: DatatableModel<any>, couponFilter?: CouponFilter): void {
    this.isLoading = true;
    this.couponQueryService.getCouponList(tableModel, couponFilter).subscribe((response) => {
        this.datatableModel = {
          PageSize: this.datatableModel.PageSize,
          TotalElements: response.totalCount,
          CurrentPageNumber: this.datatableModel.CurrentPageNumber,
          SortBy: this.datatableModel.SortBy,
          Descending: this.datatableModel.Descending,
          Data: response.data,
          ColumnMode: ColumnMode.flex
        };
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = true;
        console.log('Error', error);
      });
  }

  addNewCoupon(): void {
    this.router.navigate(['coupon', 'create']);
  }

  assign(row: any): void {
    this.router.navigate(['coupon', row.Id, 'assign']);
  }

  manageAssigned(row: any): void {
    this.router.navigate(['coupon', row.Id, 'manageAssigned']);
  }

  manageCohort(row: any): void {
    this.router.navigate(['coupon', row.Id, 'manageCohort']);
  }

  updateCompatibleCoupon(row: any): void {
    this.router.navigate(['coupon', 'update', row.Id, 'compatible-coupon']);
  }

  rankCouponDialog(): void {
    this.dialogRef = this.matDialog.open(CouponRankingDialogComponent, {
      panelClass: 'coupon-ranking-dialog',
      width: '1000px',
      height: '700px'
    });
  }

  isNotPublishedCoupon(coupon: Coupon): boolean {
    return coupon.CouponState !== CouponState.Published;
  }

  duplicateCouponDialog(row): void {
    const dialogRef = this.matDialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Confirmation',
        message: `Are you sure you want to duplicate this coupon?`,
        buttonText: {
          ok: 'Yes',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.duplicateCoupon(row);
      }
    });
  }

  duplicateCoupon(row: any): void {
    const command = this.couponCommandBuilderService.getDuplicateCouponCommand(row.Id);
    this.couponNotificationService.couponCreated();
    this.eevoNotifyService.displayMessage(
      this.couponEntity.getMessages().CREATE_REQUEST,
      NotifyType.Info
    );

    this.couponCommandService.duplicateCoupon(command).subscribe(data => {
    }, error => {
      this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
    });
  }

  private addActionColumn(): void {
    // @ts-ignore
    this.fgs.isValidFeature([{Key: 'coupon.assign'}, {Key: 'coupon.unassign'}, {Key: 'coupon.cohort'}, {Key: 'coupon.compatible'}, {Key: 'coupon.copy'}])
      .pipe(take(1))
      .subscribe(res => {
        if (res) {
          this.configOption.columns.push({
            prop: '-',
            name: 'Action',
            flexGrow: 1,
            headerTemplate: this.headerTemplate,
            cellTemplate: this.actionCellTemplate,
            draggable: true,
            sortable: true,
            maxWidth: 150,
            minWidth: 150,
            cellClass: 'action-cell'
          });
        }
      });
  }
}
