import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppCouponUpdateComponent } from './app-coupon-update.component';

describe('AppCouponUpdateComponent', () => {
  let component: AppCouponUpdateComponent;
  let fixture: ComponentFixture<AppCouponUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppCouponUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppCouponUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
