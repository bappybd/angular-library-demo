import {Component, Inject, OnInit} from '@angular/core';
import {fuseAnimations} from '@eevo/eevo-base';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {FormGroup, Validators} from '@angular/forms';
import {CouponFormBuilder} from '../../services/coupon-form-builder';
import {EevoNotifyService, EevoQueryService, NotifyType} from '@eevo/eevo-core';
import {CouponEntity} from '../../entities/coupon-entity';
import {CouponCommandBuilderService} from '../../services/coupon-command-builder.service';
import {CouponCommandService} from '../../services/coupon-command.service';
import {CouponNotificationService} from '../../services/coupon-notification.service';
import {ActivatedRoute, Router} from '@angular/router';
import {CouponQueryService} from '../../services/coupon-query.service';
import {CouponModel, CouponState} from '../../../shared/models/coupon-entity-models';
import {ConfirmationDialogComponent} from '../../../shared/components/confirmation-dialog/confirmation-dialog.component';
import {MatDialog} from '@angular/material/dialog';
import {EevoValidator} from "../../../shared/validator/eevo.validator";
import {MatSlideToggleChange} from "@angular/material/slide-toggle";

@Component({
  selector: 'app-app-coupon-update',
  templateUrl: './app-coupon-update.component.html',
  styleUrls: ['./app-coupon-update.component.scss'],
  animations: fuseAnimations
})
export class AppCouponUpdateComponent implements OnInit {
  couponId: string;
  couponDetails: CouponModel;
  loadingFromServer = true;
  breadcrumbList: BreadcrumbModel[] = [];
  couponForm: FormGroup;
  compatibleData: any;

  formSubmitted = false;
  couponDataLoading = false;

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private actRoute: ActivatedRoute,
    private couponFormBuilder: CouponFormBuilder,
    private couponEntity: CouponEntity,
    private couponCommandBuilderService: CouponCommandBuilderService,
    private couponCommandService: CouponCommandService,
    private eevoQueryService: EevoQueryService,
    private eevoNotifyService: EevoNotifyService,
    private couponQueryService: CouponQueryService,
    private couponNotificationService: CouponNotificationService,
    @Inject('config') private config: any
  ) {
    this.couponId = this.actRoute.snapshot.params.id;
  }

  ngOnInit(): void {
    const url = this.config.CouponService.toQueryURL();
    this.eevoQueryService.getDetailsById<CouponModel>(
      url, this.couponEntity.getDetailsName(), this.couponId, this.couponEntity.getDetailsFields()
    ).subscribe((data) => {
      if (data && data.Id) {
        data.CouponId = data.Id;
        this.couponDetails = data;
        this.setBreadcrumbData();
        this.couponForm = this.couponFormBuilder.getCouponForm(data);
        this.couponFormBuilder.setAdditionalValidators(this.couponForm);
        this.compatibleData = {
          form: this.couponForm,
          state: this.couponDetails.CouponState
        };
        this.loadingFromServer = false;
      }
    });
  }

  setAndClearValidators(value: MatSlideToggleChange): void {
    if (!value.checked) {
      this.couponForm.get('CouponCode').setValidators([Validators.required]);
      this.couponForm.get('CouponCode').updateValueAndValidity();
    }
    else {
      this.couponForm.get('CouponCode').clearValidators();
      this.couponForm.get('CouponCode').setErrors(null);
      this.couponForm.get('RedeemableTimes').clearValidators();
      this.couponForm.get('RedeemableTimes').setErrors(null);
      this.couponForm.get('RedeemableTimesPerUsers').clearValidators();
      this.couponForm.get('RedeemableTimesPerUsers').setErrors(null);
      this.couponForm.get('MaxRedeemCountPerUserPerDay').clearValidators();
      this.couponForm.get('MaxRedeemCountPerUserPerDay').setErrors(null);
    }
  }

  goToCouponListPage(): void {
    this.router.navigate(['coupon']);
  }

  loadPublishDialog(): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Confirmation',
        message: `Are you sure you want to published?<br/>After publish you cannot change any information.`,
        buttonText: {
          ok: 'Yes',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.saveCoupon(CouponState.Published);
      }
    });
  }

  publishCoupon(): void {
    this.couponForm.get('AppliedTime').setValidators(EevoValidator.dateTimeLessThanCurrentTime('AppliedTime'));
    this.couponForm.get('AppliedTime').updateValueAndValidity();
    this.couponForm.markAllAsTouched();
    this.couponQueryService.getCouponNameCount(this.couponForm.controls.CouponName.value, this.couponForm.controls.CouponCode.value ).subscribe(value => {
      if (this.couponForm.valid) {
        if ((value.couponNameCount === 0 || value.couponNameCount === 1)  && value.couponCodeCount === 0) {
          this.loadPublishDialog();
        }
        else {
          if (value.couponNameCount > 1) {
            this.eevoNotifyService.displayMessage('This coupon name already exists', NotifyType.Error);
          }
          if (value.couponCodeCount > 0) {
            this.eevoNotifyService.displayMessage('This coupon code already exists', NotifyType.Error);
          }
        }
      }
    });
  }

  inactiveCoupon(): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'Confirmation',
        message: `Are you sure you want to inactive?`,
        buttonText: {
          ok: 'Yes',
          cancel: 'Cancel'
        }
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (confirmed) {
        this.updateInactiveCoupon();
      }
    });

  }

  updateCoupon(): void {
    this.saveCoupon(CouponState.Draft);
  }

  private saveCoupon(couponState): void {
    this.couponForm.markAllAsTouched();
    if (this.couponForm.valid) {
      this.formSubmitted = true;
      const command = this.couponCommandBuilderService.getCouponCommand(this.couponForm, couponState, this.couponId);

      this.couponNotificationService.couponUpdated();
      this.eevoNotifyService.displayMessage(
        this.couponEntity.getMessages().UPDATE_REQUEST,
        NotifyType.Info
      );

      this.couponCommandService.updateCoupon(command).subscribe(data => {
        this.formSubmitted = false;
        this.goToCouponListPage();
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
      });
    }
  }

  private updateInactiveCoupon(): void {
    if (this.couponId) {
      this.formSubmitted = true;

      this.couponNotificationService.couponDeactivated();
      this.eevoNotifyService.displayMessage(
        this.couponEntity.getMessages().UPDATE_REQUEST,
        NotifyType.Info
      );

      this.couponCommandService.inactiveCouponRank(this.couponId).subscribe(data => {
        this.formSubmitted = false;
        this.goToCouponListPage();
      }, error => {
        this.eevoNotifyService.displayMessage(error.statusText, NotifyType.Error, error.status);
        this.formSubmitted = false;
      });
    }
  }

  private setBreadcrumbData(): void {
    this.breadcrumbList.push({
      Text: 'Coupons',
      Path: ['/coupon']
    });

    this.breadcrumbList.push({
      Text: this.couponDetails.CouponName
    });
  }

}
