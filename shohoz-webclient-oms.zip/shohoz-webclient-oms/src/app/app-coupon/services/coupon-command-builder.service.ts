import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {FormGroup} from '@angular/forms';
import {
  CouponCreateCommand,
  CouponRankUpdateCommand,
  DuplicateCouponCommand,
  UpdateSupportedCouponIdsCommand
} from '../models/coupon-commands';
import {CouponCategory, CouponLogicModel, CouponModel, CouponState} from '../../shared/models/coupon-entity-models';
import {Coupon} from '../models/coupon-models';

@Injectable({
  providedIn: 'root'
})

export class CouponCommandBuilderService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getCouponCommand(formPayload: FormGroup, couponState?: CouponState, couponId?: string): CouponCreateCommand {
    const form = Object.assign({}, formPayload);
    const formData = form.value;

    if (!couponState) {
      couponState = CouponState.Draft;
    }
    let supportedCouponIds = [];
    if (formData.CompatibleCoupons) {
      supportedCouponIds = formData.CompatibleCoupons.map(data => {
        return data.key;
      });
    }
    const couponCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      CouponId: couponId ? couponId : this.utilityService.getNewGuid(),
      CouponState: couponState,

      CouponName: formData.CouponName,
      CouponCode: formData.CouponCode,
      Category: CouponCategory.Default,
      Description_En: formData.Description,
      Description_Bn: formData.Description,
      HighlightText_En: formData.HighlightedText,
      HighlightText_Bn: formData.HighlightedText,
      AutoApplied: formData.AutoApplicable,
      IsProductCoupon: formData.IsProductCoupon === null ? false : formData.IsProductCoupon,
      IsGlobalCoupon: formData.IsGlobalCoupon === null ? false : formData.IsGlobalCoupon,

      CouponLogics: this.getCouponLogic(formData),

      ValidFrom: this.combineDateWithTime(formData.AppliedDate, formData.AppliedTime).toISOString(),
      ValidTill: this.combineDateWithTime(formData.ExpiredDate, formData.ExpiredTime).toISOString(),

      DiscountPartnerIds: this.getIds(formData.DiscountPartners),
      PaymentMethodIds: this.getIds(formData.ApplicablePaymentMethod),
      CityIds: formData.ApplicableCity ? this.getIds(formData.ApplicableCity) : [],
      SupportedCouponIds: supportedCouponIds,
      ShohozPortionOfDiscount: formData.ShohozPortionOfDiscount,
      Rank: formData.CouponRanking,
      MaximumDiscountAmount: formData.MaximumDiscountAmount,
    } as CouponCreateCommand;
    if (!formData.AutoApplicable) {
      couponCommand.MaxRedeemCount = formData.RedeemableTimes;
      couponCommand.MaxRedeemCountPerUser = formData.RedeemableTimesPerUsers;
      couponCommand.MaxRedeemCountPerUserPerDay = formData.MaxRedeemCountPerUserPerDay;
    }
    return couponCommand;
  }

  private getIds(formData: any): string[] {
    let ids: string[] = [];
    formData.forEach(pm => {
      if (pm.Id) {
        ids.push(pm.Id);
      }
    });
    return ids;
  }

  private combineDateWithTime(date: Date, time: string): Date {
    date = new Date(date);
    let hour = 0;
    let minute = 0;

    if (time !== '') {
      const hourAndMinute = time.split(':');
      hour = Number(hourAndMinute[0]);
      minute = Number(hourAndMinute[1]);
    }

    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      hour,
      minute
    );
  }

  private getCouponLogic(formData: any): CouponLogicModel[] {
    let result: CouponLogicModel[] = [];
    const {IsFlatDiscount = false} = formData;

    formData.CouponLogic.forEach(logicFormValue => {
      result.push({
        _id: logicFormValue.Id,
        Id: logicFormValue.Id,
        Calculation: logicFormValue.Calculation,
        Condition: logicFormValue.Condition,
        Description: logicFormValue.Description,
        IsFlatDiscount,
      });
    });

    return result;
  }

  public getUpdateCouponRankCommand(coupons: Coupon[]): CouponRankUpdateCommand {
    let command = new CouponRankUpdateCommand();
    coupons.forEach(item => {
      command.CouponRanks.push({
        CouponId: item.Id,
        Rank: item.Rank
      });
    });

    return command;
  }

  public getDuplicateCouponCommand(couponId: string): DuplicateCouponCommand {
    let command = new DuplicateCouponCommand();
    command.CouponId = couponId;
    command.DuplicateCouponId = this.utilityService.getNewGuid();
    return command;
  }


  public getUpdateSupportedCouponIdsCommand(newCouponFormPayload: FormGroup, previousCoupon: CouponModel): UpdateSupportedCouponIdsCommand {
    const form = Object.assign({}, newCouponFormPayload);
    const newCouponFormData = form.value;
    let newSupportedCouponIds = [];
    if (newCouponFormData.CompatibleCoupons) {
      newSupportedCouponIds = newCouponFormData.CompatibleCoupons.map(data => {
        return data.key;
      });
    }
    const command = new UpdateSupportedCouponIdsCommand();
    command.CouponId = previousCoupon.Id;
    command.SupportedCouponIdsToBeAdded = newSupportedCouponIds.filter(
      id => !previousCoupon.SupportedCouponIds.includes(id)
    );
    command.SupportedCouponIdsToBeRemoved = previousCoupon.SupportedCouponIds.filter(
      id => !newSupportedCouponIds.includes(id)
    );
    return command;
  }
}
