import {Inject, Injectable} from "@angular/core";
import {Subject} from "rxjs";

@Injectable({
  providedIn: 'root'
})

export class CouponService {

  couponInfoEmitter = new Subject<any>();

  constructor(){

  }

}
