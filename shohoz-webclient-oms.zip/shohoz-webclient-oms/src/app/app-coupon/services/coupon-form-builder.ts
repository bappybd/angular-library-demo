import {Injectable} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import * as _ from 'lodash';
import {UtilityService} from '@eevo/eevo-core';
import {CouponLogicModel, CouponModel} from '../../shared/models/coupon-entity-models';
import {EevoValidator} from '../../shared/validator/eevo.validator';

@Injectable({
  providedIn: 'root'
})
export class CouponFormBuilder {

  constructor(
    private formBuilder: FormBuilder,
    private utilityService: UtilityService
  ) {
  }

  getCouponForm(coupon?: CouponModel): FormGroup {
    const hasCoupon = !!(coupon && coupon.CouponId);
    return this.formBuilder.group({
      CouponName: [hasCoupon ? coupon.CouponName : '', [Validators.required, EevoValidator.cannotWhiteSpace]],
      CouponCode: [hasCoupon ? coupon.CouponCode : ''],
      Description: [hasCoupon ? coupon.Description_En : '', EevoValidator.cannotWhiteSpace],
      HighlightedText: [hasCoupon ? coupon.HighlightText_En : '', EevoValidator.cannotWhiteSpace],
      AutoApplicable: [hasCoupon ? coupon.AutoApplied : true],
      IsProductCoupon: [hasCoupon ? coupon.IsProductCoupon : true],
      IsGlobalCoupon: [hasCoupon ? coupon.IsGlobalCoupon : true],
      IsFlatDiscount: [hasCoupon ? coupon.CouponLogics.some(cl => !!cl.IsFlatDiscount) : false],
      RedeemableTimes: [hasCoupon ? (coupon.MaxRedeemCount > 0) ? coupon.MaxRedeemCount : 1 : 1],
      RedeemableTimesPerUsers: [hasCoupon ? (coupon.MaxRedeemCountPerUser > 0) ? coupon.MaxRedeemCountPerUser : 1 : 1],
      MaxRedeemCountPerUserPerDay: [hasCoupon ? (coupon.MaxRedeemCountPerUserPerDay > 0) ? coupon.MaxRedeemCountPerUserPerDay : 1 : 1],
      AppliedDate: [hasCoupon ? coupon.ValidFrom : new Date(), Validators.required],
      AppliedTime: [hasCoupon ? this.getTimeSlot(coupon.ValidFrom) : '', Validators.required],
      ExpiredDate: [hasCoupon ? coupon.ValidTill : new Date(), Validators.required],
      ExpiredTime: [hasCoupon ? this.getTimeSlot(coupon.ValidTill) : '', Validators.required],
      CouponRanking: [hasCoupon ? coupon.Rank : this.getRank()],
      ShohozPortionOfDiscount: [hasCoupon ? coupon.ShohozPortionOfDiscount : '', [Validators.min(0), Validators.max(100)]],
      MaximumDiscountAmount: [hasCoupon ? coupon.MaximumDiscountAmount : ''],
      ApplicableCity: [hasCoupon ? coupon.CityIds : ''],
      CompatibleCoupons: [hasCoupon ? coupon.SupportedCouponIds : ''],

      // IsCompatibleCoupons: [true],
      DiscountPartners: (hasCoupon && coupon.DiscountPartnerIds.length > 0) ?
        this.formBuilder.array(coupon.DiscountPartnerIds) : this.formBuilder.array([]),
      ApplicablePaymentMethod: (hasCoupon && coupon.PaymentMethodIds.length > 0) ?
        this.formBuilder.array(coupon.PaymentMethodIds) : this.formBuilder.array([], [EevoValidator.paymentMethodSelected]),

      CouponLogic: this.getCouponLogicForm(hasCoupon ? coupon.CouponLogics : null),
    });
  }

  setAdditionalValidators(form: FormGroup): void {
    /* form.get('AppliedTime').setValidators(EevoValidator.dateTimeLessThanCurrentTime('AppliedTime'));*/
    form.get('ExpiredTime').setValidators(EevoValidator.dateTimeLessThan('AppliedTime'));
    form.get('RedeemableTimesPerUsers').setValidators(EevoValidator.lessThan('RedeemableTimes'));
    form.get('MaxRedeemCountPerUserPerDay').setValidators(EevoValidator.lessThan('RedeemableTimesPerUsers'));
  }

  getLogicForm(couponLogics?: CouponLogicModel): FormGroup {
    const hasLogic = !!(couponLogics && couponLogics._id);

    return this.formBuilder.group({
      Id: hasLogic ? couponLogics._id : this.utilityService.getNewGuid(),
      Condition: [hasLogic ? couponLogics.Condition : '', [Validators.required, EevoValidator.cannotWhiteSpace]],
      Calculation: [hasLogic ? couponLogics.Calculation : '', [Validators.required, EevoValidator.cannotWhiteSpace]],
      Description: [hasLogic ? couponLogics.Description : '', [Validators.required, EevoValidator.cannotWhiteSpace]],
    });
  }

  private getCouponLogicForm(couponLogics?: CouponLogicModel[]): FormArray {
    const formArray = this.formBuilder.array([]);
    if (couponLogics) {
      couponLogics.forEach(logic => {
        const logicForm = _.cloneDeep(this.getLogicForm(logic));
        formArray.push(logicForm);
      });
    } else {
      const logicForm = _.cloneDeep(this.getLogicForm());
      formArray.push(logicForm);
    }

    return formArray;
  }

  private getTimeSlot(date: string): string {
    const dt = new Date(date);
    return _.padStart(dt.getHours() + '', 2, '0') + ':' + _.padStart(dt.getMinutes() + '', 2, '0');
  }

  private getRank(): number {
    const date = new Date();
    const milTime = date.getTime();
    /*const totalSec = milTime / 1000;*/
    return ((1000000000 / milTime) * 10000000000000);
  }
}
