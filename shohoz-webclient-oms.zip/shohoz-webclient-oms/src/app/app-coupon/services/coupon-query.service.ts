import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {DatatableModel} from '@eevo/eevo-platform-datatable';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {CouponEntity} from '../entities/coupon-entity';
import {Coupon, CouponFilter, CouponListResponse} from '../models/coupon-models';
import {CouponModel, CouponState} from '../../shared/models/coupon-entity-models';

@Injectable({
  providedIn: 'root'
})

export class CouponQueryService {
  constructor(
    private http: HttpClient,
    private couponEntity: CouponEntity,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  getCouponDetails(couponId: string): Observable<CouponModel> {
    const query = `{ '_id' : GUID('` + couponId + `')  }`;
    const requestBody = [
      {
        source: this.couponEntity.getDetailsName(),
        text: null,
        filter: query,
        fields: this.couponEntity.getDetailsFields(),
        orderBy: 'Language',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(this.config.CouponService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        response[0].map(data => {
          data.CouponId = data.Id;
          return data;
        });

        if (response && response[0]) {
          return response[0][0] as CouponModel;
        }
        return null;
      })
    );
  }

  getCouponNameCount(nameSearchKey: string, codeSearchKey: string): Observable<any> {
    const nameSearchFilter = `{ CouponName: '${nameSearchKey}' }`;
    const codeSearchFilter = `{ CouponState: 'Published' , 'CouponCode': '${codeSearchKey}' }`;

    const requestBody = [
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: nameSearchFilter,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ];
    if (codeSearchKey.length > 0) {
      requestBody.push({
        source: this.couponEntity.getListName(),
        text: null,
        filter: codeSearchFilter,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      });
    }
    return this.http.post(this.config.CouponService.toQueryURL(), requestBody).pipe(
      map((response: any) => {
        return {
          couponNameCount: response[0][0][0],
          couponCodeCount: (response[1]) ? response[1][0][0] : 0
        };
      })
    );
  }

  getCouponListForRankingWithExtra(sortBy: string, isDescending: boolean, couponListPageSize: number, currentPageNumber: number, getTotalCount = false)
    : Observable<[Coupon[], Coupon, number | null]> {

    const payload = [
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: '{}',
        fields: this.couponEntity.getListFields(),
        orderBy: sortBy,
        descending: isDescending,
        pageSize: couponListPageSize,
        pageIndex: currentPageNumber,
        CountOnly: false,
      },
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: '{}',
        fields: this.couponEntity.getListFields(),
        orderBy: sortBy,
        descending: isDescending,
        pageSize: 1,
        pageIndex: (currentPageNumber + 1) * couponListPageSize,
        CountOnly: false,
      }
    ];
    if (getTotalCount) {
      payload.push({
        source: this.couponEntity.getListName(),
        text: null,
        filter: '{}',
        fields: this.couponEntity.getListFields(),
        orderBy: sortBy,
        descending: isDescending,
        pageSize: 10,
        pageIndex: 0,
        CountOnly: true,
      });
    }
    return this.http.post(this.config.CouponService.toQueryURL(), payload).pipe(
      map((response: any) => {
        return [
          response[0],
          response[1].length ? response[1][0] : null,
          response[2] ? response[2][0][0] : null];
      })
    );
  }

  getCouponList(tableModel: DatatableModel<any>, filter?: CouponFilter): Observable<CouponListResponse> {
    let searchFilter = '{}';
    const query = [];
    let sKey = '';
    if (filter) {
      if (filter.searchKey && filter.searchKey.length > 0) {
        const sQuery = [];
        sKey = this.utilityService.matchAnyCharacterRegx(filter.searchKey);
        // filter.searchKey = this.utilityService.matchAnyCharacterRegx(filter.searchKey);
        sQuery.push(`{ CouponName: { $regex: '${sKey}', $options: 'i'}}`);
        sQuery.push(`{ CouponCode: { $regex: '${sKey}', $options: 'i'}}`);
        query.push(`{$or: [ ${sQuery.join(', ')} ] }`);
      }
      if (filter.status) {
        query.push(`{ CouponState: '${filter.status}'}`);
      }

      if (query.length > 0) {
        searchFilter = `{$and: [ ${query.join(', ')} ] }`;
      }
    }

    return this.http.post(this.config.CouponService.toQueryURL(), [
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: searchFilter,
        fields: this.couponEntity.getListFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: searchFilter,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return {
          data: response[0],
          totalCount: response[1][0][0]
        };
      })
    );
  }

  getUnpublishedCouponList(tableModel: DatatableModel<any>): Observable<CouponListResponse> {
    const query = `{ $or: [  { 'CouponState': '` + CouponState.Draft + `'} ] }`;

    return this.http.post(this.config.CouponService.toQueryURL(), [
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: query,
        fields: this.couponEntity.getListFields(),
        orderBy: tableModel.SortBy,
        descending: tableModel.Descending,
        pageSize: tableModel.PageSize,
        pageIndex: tableModel.CurrentPageNumber
      },
      {
        source: this.couponEntity.getListName(),
        text: null,
        filter: query,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ]).pipe(
      map((response: any) => {
        return {
          data: response[0],
          totalCount: response[1][0][0]
        };
      })
    );
  }

}
