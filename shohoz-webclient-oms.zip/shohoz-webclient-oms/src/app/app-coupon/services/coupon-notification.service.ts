import {EevoNotificationBase} from '@eevo/eevo-core';
import {CommandNotificationModel} from '../../shared/models/command-notification-model';
import {Injectable} from '@angular/core';
import {SignalrNotificationService} from '@eevo/eevo-notification';
import {NotificationHandlerService} from '../../shared/services/notification/notification-handler.service';
import {CouponEntity} from '../entities/coupon-entity';

@Injectable({
  providedIn: 'root'
})

export class CouponNotificationService extends EevoNotificationBase<CommandNotificationModel> {
  constructor(
    private couponEntity: CouponEntity,
    private signalrNotificationService: SignalrNotificationService,
    private notificationHandlerService: NotificationHandlerService
  ) {
    super();
    this.errorMessage();
  }

  errorMessage(): void {
    this.signalrNotificationService.listenByKey(
      this.couponEntity.Events.CouponBusinessRuleViolatedEvent, (response) => {
        const data = this.notificationHandlerService.parseAndDisplayMessage(response, false);
        // this.deliver(data);
      });
  }

  couponCreated(): void {
    this.signalrNotificationService.listenByKey(this.couponEntity.Events.CouponCreatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.couponEntity.getMessages().CREATED);
      this.deliver(data);
    });
  }

  couponUpdated(): void {
    this.signalrNotificationService.listenByKey(this.couponEntity.Events.CouponUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.couponEntity.getMessages().UPDATED);
      this.deliver(data);
    });
  }

  couponDeactivated(): void {
    this.signalrNotificationService.listenByKey(this.couponEntity.Events.CouponDeactivatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, 'Coupon deactivated successfully done.');
      this.deliver(data);
    });
  }

  couponRankUpdated(): void {
    this.signalrNotificationService.listenByKey(this.couponEntity.Events.CouponRankUpdatedEvent, (response) => {
      const data = this.notificationHandlerService.parseAndDisplayMessage(response, true, this.couponEntity.getMessages().UPDATED);
      data.ActionName = this.couponEntity.Events.CouponRankUpdatedEvent;
      this.deliver(data);
    });
  }
}
