import {Inject, Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {UtilityService} from "@eevo/eevo-core";
import {Observable} from "rxjs";
import {map} from "rxjs/operators";
import {
  CouponCreateCommand,
  CouponRankUpdateCommand,
  DuplicateCouponCommand,
  UpdateSupportedCouponIdsCommand
} from '../models/coupon-commands';

@Injectable({
  providedIn: 'root'
})

export class CouponCommandService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    @Inject('config') private config: any) {
  }

  createCoupon(couponCreateCommand: CouponCreateCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/CreateCoupon',
      couponCreateCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateCoupon(couponCommand: CouponCreateCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/UpdateCoupon',
      couponCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  duplicateCoupon(duplicateCouponCommand: DuplicateCouponCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/DuplicateCoupon',
      duplicateCouponCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateCouponRank(couponRankUpdateCommand: CouponRankUpdateCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/UpdateCouponRank',
      couponRankUpdateCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  inactiveCouponRank(couponId: string): Observable<any> {
    const deactivateCouponCommand = {
      CorrelationId: this.utilityService.getNewGuid(),
      CouponId: couponId,
    };

    return this.http.post(this.config.CouponService + 'Coupons/DeactivateCoupon',
      deactivateCouponCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  updateSupportedCouponIds(updateSupportedCouponIdsCommand: UpdateSupportedCouponIdsCommand): Observable<any> {
    return this.http.post(this.config.CouponService + 'Coupons/UpdateSupportedCouponIds',
      updateSupportedCouponIdsCommand
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
