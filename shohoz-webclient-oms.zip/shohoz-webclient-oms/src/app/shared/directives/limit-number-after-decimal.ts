import {Directive, ElementRef, HostListener, Input, OnChanges, SimpleChanges} from '@angular/core';

@Directive({
  selector: '[limitNumberAfterDecimal]'
})
export class LimitNumberAfterDecimal implements OnChanges {
  @Input() _limitNumberAfterDecimal = 2;
  @Input() set limitNumberAfterDecimal(value: number) {
    this._limitNumberAfterDecimal = (value || value === 0) ? value : 2;
  }

  get limitNumberAfterDecimal(): number {
    return this._limitNumberAfterDecimal;
  }

  @Input() positiveNumbersOnly = false;
  // Allow decimal numbers and negative values

  private regex: RegExp = null;
  // Allow key codes for special events. Reflect :
  // Backspace, tab, end, home
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowLeft', 'ArrowRight', 'Del', 'Delete'];

  constructor(private el: ElementRef) {
    this.generateRegex();
  }

  private generateRegex(): void {
    const regexPattern = `^${this.positiveNumbersOnly ? '' : '-?'}\\d*${this.limitNumberAfterDecimal ? '\\.?\\d{0,' + this.limitNumberAfterDecimal + '}' : ''}$`;
    // console.log(regexPattern);
    this.regex = new RegExp(regexPattern, 'g');
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.hasOwnProperty('limitNumberAfterDecimal') && changes['limitNumberAfterDecimal'].currentValue !== null) {
      // console.log(this.limitNumberAfterDecimal);
      this.generateRegex();
    }

    if (
      changes.hasOwnProperty('positiveNumbersOnly')
      && changes['positiveNumbersOnly'].currentValue !== null) {
      // console.log(this.positiveNumbersOnly);
      this.generateRegex();
    }
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    // console.log(this.el.nativeElement.value);
    // Allow Backspace, tab, end, and home keys
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }
    let current: string = this.el.nativeElement.value;
    const position = this.el.nativeElement.selectionStart;
    const next: string = [current.slice(0, position), event.key == 'Decimal' ? '.' : event.key, current.slice(position)].join('');
    // console.log(!next.match(this.regex));
    if (next && !next.match(this.regex)) {
      event.preventDefault();
    }
  }
}
