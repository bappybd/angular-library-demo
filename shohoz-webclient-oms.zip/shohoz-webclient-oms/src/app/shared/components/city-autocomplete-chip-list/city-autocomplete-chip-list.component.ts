import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatAutocomplete, MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {ZoneService} from '@eevo/eevo-core';
import {debounceTime, finalize, map, startWith, switchMap, tap} from 'rxjs/operators';
import {Observable} from 'rxjs';


@Component({
  selector: 'app-city-autocomplete-chip-list',
  templateUrl: './city-autocomplete-chip-list.component.html',
  styleUrls: ['./city-autocomplete-chip-list.component.scss']
})
export class CityAutocompleteChipListComponent implements OnInit {
  dataList: any[];

  @Input()
  formGroup: FormGroup;

  @Input()
  options: CityAutocompleteOptions;

  cityDataList: { Id: string, Name: string }[] = [];
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  // auto complete
  filteredDataList: Observable<any[]>;
  searchCtrl = new FormControl();

  errorMsg: string;
  isLoading: boolean;

  @ViewChild('autocompleteInput') autocompleteInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  // end auto complete

  constructor( private zoneService: ZoneService) {
    this.dataList = [];
  }

  ngOnInit(): void {
    this.setOptions();
    this.loadData();
    // if (this.options.formControlName) {
    //   this.setCityData();
    //   // this.formGroup.get(this.options.formControlName).valueChanges.subscribe((data) => {
    //   //   this.setCityData();
    //   // });
    // }
  }

  // auto complete
  displayFn(data: any): string {
    return data && data.name ? data.name : '';
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.cityDataList.push({
      Id: event.option.value.id,
      Name: event.option.value.name
    });

    this.autocompleteInput.nativeElement.value = '';
    this.addOrRemove();
  }

  loadData(): void {
    this.zoneService.getFoodCities().subscribe((response) => {
      this.dataList = response.data;
      this.setFilteredCities();
      this.setCityData();
    });
  }

  private setFilteredCities(): void {
    this.filteredDataList = this.searchCtrl.valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this.cityFilter(name) : this.dataList.slice())
      );
  }

  private cityFilter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.dataList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  setCityData(): void {
    this.cityDataList = [];
    const values = this.formGroup.get(this.options.formControlName).value;
    if (values && typeof values === 'object' && values.length > 0) {
      values.forEach(value => {
        this.dataList.forEach(data => {
          if (value === data.id) {
            this.cityDataList.push({
              Id: data.id,
              Name: data.name,
            });
          }
        });
      });
    }
  }

  remove(i: number): void {
    if (i >= 0) {
      this.cityDataList.splice(i, 1);
      this.addOrRemove();
    }
  }

  private addOrRemove(): void {
    if (this.options.formControlName) {
      this.formGroup.get(this.options.formControlName).setValue(this.cityDataList);
    }
  }

  private setOptions(): void {
    if (this.options.formControlName === undefined) {
      console.warn('city chip list will not working, because you did not set `formControlName`');
    }
    if (this.options.removable === undefined) {
      this.options.removable = true;
    }
    if (this.options.selectable === undefined) {
      this.options.selectable = true;
    }
    if (!this.options.placeholder) {
      this.options.placeholder = 'Search';
    }
  }
}

export class CityAutocompleteOptions {
  formControlName: string;
  labelTxt: string;
  removable: boolean;
  selectable: boolean;
  placeholder: string;
  suggestionEnable: boolean;
  suggestionList: string[];
}
