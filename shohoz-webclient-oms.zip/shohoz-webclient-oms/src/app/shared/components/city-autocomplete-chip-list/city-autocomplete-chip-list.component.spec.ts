import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CityAutocompleteChipListComponent } from './city-autocomplete-chip-list.component';

describe('CityAutocompleteChipListComponent', () => {
  let component: CityAutocompleteChipListComponent;
  let fixture: ComponentFixture<CityAutocompleteChipListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CityAutocompleteChipListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CityAutocompleteChipListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
