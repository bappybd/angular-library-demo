import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators} from '@angular/forms';
import {DayOfWeek} from '../../../shared/enums/day-of-week.enum';
import {MatCheckboxChange} from '@angular/material/checkbox';
import {ScheduleHourOptions} from './schedule-hour.options';
import {ScheduleHourValidator} from './schedule-hour.validator';
import {distinctUntilChanged} from 'rxjs/operators';
import {EevoValidator} from '../../validator/eevo.validator';

@Component({
  selector: 'app-schedule-hour',
  templateUrl: './schedule-hour.component.html',
  styleUrls: ['./schedule-hour.component.scss']
})
export class ScheduleHourComponent implements OnInit {
  @Input()
  parent: FormGroup;

  @Input()
  scheduleHourOptions: ScheduleHourOptions;

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    if (!this.scheduleHourOptions) {
      this.scheduleHourOptions = new ScheduleHourOptions();
    }

    this.setValidation(this.isSameForAllDays);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------
  getNameOfWeekDay(enumValue): string {
    return DayOfWeek[enumValue];
  }

  get isSameForAllDays(): boolean {
    const sameForAllDays = this.parent.get('ScheduledHours')
      .get('IsSameForAllDaysServiceHours') as FormControl;

    return sameForAllDays.value;
  }

  setSameForAllDays(event: MatCheckboxChange): void {
    this.setValidation(event && event.checked);
  }

  /**
   * Start Every Day Time Slot
   */

  get operationHoursForEveryDay(): AbstractControl[] {
    return this.operationHoursOfEveryDay().controls;
  }

  get totalOperationHoursForEveryDay(): number {
    return this.operationHoursOfEveryDay().length;
  }

  operationHoursOfEveryDay(): FormArray {
    return this.parent
      .get('ScheduledHours')
      .get('SameForAllDays') as FormArray;
  }

  addTimeSlotForEveryDay(): void {
    this.operationHoursOfEveryDay().push(this.createTimeSlot(this.scheduleHourOptions.sameForAllDaysRequired));
  }

  removeTimeSlotForEveryDay(index: number): void {
    this.operationHoursOfEveryDay().removeAt(index);
  }

  isValidTimeSlotForEveryDay(index): boolean {
    if ((this.totalOperationHoursForEveryDay - 1) === index) {
      const formArray = this.operationHoursOfEveryDay();
      return this.isValidTimeSlot(formArray, index);
    }
    return false;
  }

  /**
   * End Every Day Time Slot
   */


  /**
   * Start Week Day Time Slot
   */

  operationHoursOfDays(): FormArray {
    return this.parent
      .get('ScheduledHours')
      .get('WeekDays') as FormArray;
  }

  get operationHoursForDays(): AbstractControl[] {
    return this.operationHoursOfDays().controls;
  }

  operationHoursOfDay(dayIndex: number): FormArray {
    return this.operationHoursOfDays()
      .at(dayIndex)
      .get('Hours') as FormArray;
  }

  operationHoursForDay(dayIndex: number): AbstractControl[] {
    return this.operationHoursOfDay(dayIndex).controls;
  }

  totalOperationHoursForDay(dayIndex: number): number {
    return this.operationHoursOfDay(dayIndex).length;
  }

  addTimeSlotForDay(dayIndex: number): void {
    this.operationHoursOfDay(dayIndex).push(this.createTimeSlot(this.scheduleHourOptions.allWeekDaysRequired));
    /* this.setPairValidationForWeekDay();*/
  }

  removeTimeSlotForDay(dayIndex: number, index: number): void {
    this.operationHoursOfDay(dayIndex).removeAt(index);
  }

  isValidTimeSlotForDay(dayIndex: number, index: number): boolean {
    if ((this.totalOperationHoursForDay(dayIndex) - 1) === index) {
      const formArray = this.operationHoursOfDay(dayIndex);
      return this.isValidTimeSlot(formArray, index);
    }
    return false;
  }

  /**
   * End Week Day Time Slot
   */

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private setValidation(isSameForAllDays: boolean): void {
    this.setValidationForOperationHour(isSameForAllDays);
    this.setValidationForOperationHoursOfEveryDay(isSameForAllDays);
    this.setValidationForOperationHoursOfDays(isSameForAllDays);
  }

  private setValidationForOperationHour(isSameForAllDays: boolean): void {
    /* ----- start is same for all days ----- */
    const operationHoursForEveryDay = this.operationHoursOfEveryDay();

    if (this.scheduleHourOptions.hourOverlapValidationRequired) {

      if (isSameForAllDays) {
        operationHoursForEveryDay.setValidators([ScheduleHourValidator.isValidHourSlots]);
        operationHoursForEveryDay.updateValueAndValidity();
      } else {
        operationHoursForEveryDay.clearValidators();
        operationHoursForEveryDay.setErrors(null);
      }
    }

    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < operationHoursForEveryDay.length; i++) {
      const operationHour = operationHoursForEveryDay.at(i) as FormControl;
      if (isSameForAllDays) {
        operationHour.setValidators([ScheduleHourValidator.isValidTimeSlot]);
        operationHour.updateValueAndValidity();
      } else {
        operationHour.clearValidators();
        operationHour.setErrors(null);
      }
    }
    /* ----- end is same for all days ----- */

    /* ----- start is not same for all days ----- */
    const operationHoursForDays = this.operationHoursOfDays();

    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < operationHoursForDays.length; i++) {
      const operationHoursOfDay = this.operationHoursOfDay(i) as FormArray;

      // tslint:disable-next-line:prefer-for-of
      for (let j = 0; j < operationHoursOfDay.length; j++) {
        const operationHour = operationHoursOfDay.at(j) as FormControl;

        if (!isSameForAllDays) {
          operationHour.setValidators([ScheduleHourValidator.isValidTimeSlot]);
          operationHour.updateValueAndValidity();
        } else {
          operationHour.clearValidators();
          operationHour.setErrors(null);
        }

      } // finish day loop

      if (this.scheduleHourOptions.hourOverlapValidationRequired) {
        if (!isSameForAllDays) {
          operationHoursOfDay.setValidators([ScheduleHourValidator.isValidHourSlots]);
          operationHoursOfDay.updateValueAndValidity();
        } else {
          operationHoursOfDay.clearValidators();
          operationHoursOfDay.setErrors(null);
        }
      }

    } // finish days loop

    /* ----- end is not same for all days ----- */
  }

  private setValidationForOperationHoursOfDays(isSameForAllDays: boolean): void {

    if (!this.scheduleHourOptions.allWeekDaysRequired && !this.scheduleHourOptions.atLeastOneDayRequired) {
      return;
    }

    const operationHoursForDays = this.operationHoursOfDays();

    if (this.scheduleHourOptions.allWeekDaysRequired) {

      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < operationHoursForDays.length; i++) {
        const operationHoursOfDay = this.operationHoursOfDay(i);

        // tslint:disable-next-line:prefer-for-of
        for (let j = 0; j < operationHoursOfDay.length; j++) {
          const operationHour = operationHoursOfDay.at(j) as FormControl;

          if (this.scheduleHourOptions.allWeekDaysRequired && !isSameForAllDays) {
            this.setOperationHourValidator(operationHour);
          } else {
            this.clearOperationHourValidator(operationHour);
          }

        } // finish day loop

      } // finish days loop

    } else {
      if (this.scheduleHourOptions.atLeastOneDayRequired && !isSameForAllDays) {
        this.setPairValidationForWeekDay();
        // operationHoursForDays.setValidators([EevoValidator.minLengthArray(1)]);
        // operationHoursForDays.setValidators([Validators.required]);
        operationHoursForDays.setValidators([ScheduleHourValidator.atLeastOneDayHoursSelected]);
        operationHoursForDays.updateValueAndValidity();
      } else {
        this.clearValueForWeekDay();
        operationHoursForDays.clearValidators();
        operationHoursForDays.setErrors(null);
      }
    }
  }

  private clearValueForWeekDay(): void {
    const operationHoursForDays = this.operationHoursOfDays();
    for (let i = 0; i < operationHoursForDays.length; i++) {
      const operationHoursOfDay = this.operationHoursOfDay(i);
      for (let j = 0; j < operationHoursOfDay.length; j++) {
        const operationHour = operationHoursOfDay.at(j) as FormGroup;
        operationHour.get('OpeningTime').setValue('');
        operationHour.get('ClosingTime').setValue('');
        // this.setPairValidationOnDays(operationHour, 'OpeningTime', 'ClosingTime');
      }
    }
  }

  private setPairValidationForWeekDay(): void {
    const operationHoursForDays = this.operationHoursOfDays();
    for (let i = 0; i < operationHoursForDays.length; i++) {
      const operationHoursOfDay = this.operationHoursOfDay(i);
      for (let j = 0; j < operationHoursOfDay.length; j++) {
        const operationHour = operationHoursOfDay.at(j) as FormControl;
        this.setPairValidationOnDays(operationHour, 'OpeningTime', 'ClosingTime');
      }
    }
  }

  private setValidationForOperationHoursOfEveryDay(isSameForAllDays: boolean): void {

    if (!this.scheduleHourOptions.sameForAllDaysRequired) {
      return;
    }

    const operationHoursForEveryDay = this.operationHoursOfEveryDay();

    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < operationHoursForEveryDay.length; i++) {

      const operationHour = operationHoursForEveryDay.at(i) as FormControl;
      if (this.scheduleHourOptions.sameForAllDaysRequired && isSameForAllDays) {
        this.setOperationHourValidator(operationHour);
      } else {
        this.clearOperationHourValidator(operationHour);
      }
    }
  }

  private setOperationHourValidator(operationHour: FormControl): void {
    const openingTime = operationHour.get('OpeningTime');
    openingTime.setValidators([Validators.required]);
    openingTime.updateValueAndValidity();

    const closingTime = operationHour.get('ClosingTime');
    closingTime.setValidators([Validators.required]);
    closingTime.updateValueAndValidity();
  }

  private clearOperationHourValidator(operationHour: FormControl): void {
    const openingTime = operationHour.get('OpeningTime');
    openingTime.clearValidators();
    openingTime.setErrors(null);

    const closingTime = operationHour.get('ClosingTime');
    closingTime.clearValidators();
    closingTime.setErrors(null);
  }

  private isValidTimeSlot(formArray: FormArray, index: number): boolean {
    const openingTime = formArray.at(index).get('OpeningTime').value;
    const closingTime = formArray.at(index).get('ClosingTime').value;

    if (openingTime !== '' && closingTime !== '') {
      return true;
    }

    return false;
  }

  private createTimeSlot(isRequired?: boolean): FormGroup {
    if (isRequired) {
      return this.fb.group({
        OpeningTime: ['', Validators.required],
        ClosingTime: ['', Validators.required],
      }, {validators: ScheduleHourValidator.isValidTimeSlot});
    } else {
      const form = this.fb.group({
        OpeningTime: [''],
        ClosingTime: [''],
      }, {validators: ScheduleHourValidator.isValidTimeSlot});
      this.setPairValidationOnDays(form, 'OpeningTime', 'ClosingTime');
      return form;
    }
  }

  private setPairValidationOnDays(form: FormGroup | FormControl, controlA: string, controlB: string, setReverse: boolean = true): void {
    form.get(controlA).valueChanges
      .pipe(distinctUntilChanged())
      .subscribe(value => {
        if (value) {
          form.get(controlB).setValidators([Validators.required]);
        } else {
          form.get(controlB).clearValidators();
        }
        form.get(controlB).updateValueAndValidity();
      });

    if (!setReverse) {
      return;
    }

    form.get(controlB).valueChanges
      .pipe(distinctUntilChanged())
      .subscribe(value => {
        if (value) {
          form.get(controlA).setValidators([Validators.required, EevoValidator.cannotWhiteSpace]);
        } else {
          form.get(controlA).clearValidators();
        }
        form.get(controlA).updateValueAndValidity();
      });
  }
}


