import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ScheduleHourComponent} from './schedule-hour.component';

describe('ScheduledHourComponent', () => {
  let component: ScheduleHourComponent;
  let fixture: ComponentFixture<ScheduleHourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ScheduleHourComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleHourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
