// required will be applicable
export class ScheduleHourOptions {

  // if same for all days selected
  sameForAllDaysRequired: boolean;

  // if same for all days not selected
  allWeekDaysRequired: boolean;

  // if same for all days not selected and all week days should be false
  atLeastOneDayRequired: boolean;

  hourOverlapValidationRequired: boolean;

  allDaysLabelEnable: boolean;
  allDaysLabel = 'All Days';
  startTimeLabel = 'Start time';
  endTimeLabel = 'End time';

  constructor() {
    this.sameForAllDaysRequired = false;
    this.allWeekDaysRequired = false;
    this.atLeastOneDayRequired = false;
    this.allDaysLabelEnable = false;
    this.hourOverlapValidationRequired = true;
  }

}
