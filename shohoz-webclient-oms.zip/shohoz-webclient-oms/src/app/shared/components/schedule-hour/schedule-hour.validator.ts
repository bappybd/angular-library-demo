import {AbstractControl, FormArray, FormGroup, ValidationErrors, ValidatorFn} from '@angular/forms';

export class ScheduleHourValidator {

  static atLeastOneDayHoursSelected(control: AbstractControl[] | any): ValidationErrors | any {

      if (!(control instanceof FormArray)) {
        return null;
      }

      const valueArr = control && control.value;
      if (valueArr !== '' && typeof valueArr === 'object') {

        let isValid = false;
        // tslint:disable-next-line:prefer-for-of
        for (let j = 0; j < valueArr.length; j++) {
          const hours = valueArr[j].Hours;

          // tslint:disable-next-line:prefer-for-of
          for (let i = 0; i < hours.length; i++) {
            const openingTime = hours[i].OpeningTime;
            const closingTime = hours[i].ClosingTime;

            if (openingTime !== '' && closingTime !== '') {
              isValid = true;
              break;
            }
          } // end loop

          if (isValid) {
            break;
          }

        } // end loop

        if (!isValid) {
          return {
            atLeastOneDayHoursSelected: true
          };
        }

      }

      return null;
  }

  static isValidHourSlots(control: AbstractControl[] | any): ValidationErrors | any {

    if (!(control instanceof FormArray)) {
      return null;
    }

    const valueArr = control && control.value;
    if (valueArr !== '' && typeof valueArr === 'object') {

      const operationHours = [];
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < valueArr.length; i++) {
        const hour = valueArr[i];
        const openingTime = hour.OpeningTime;
        const closingTime = hour.ClosingTime;

        if (!(openingTime === undefined || openingTime === '' || closingTime === undefined || closingTime === ''))
        {
          const operationHour = ScheduleHourValidator.getOperationHourInSecond(openingTime, closingTime);

          operationHours.push(operationHour);
        }

      } // end loop

      const isValid = ScheduleHourValidator.isValidHours(operationHours);
      if (!isValid) {
        return {
          isValidHourSlots: true
        };
      }

    }

    return null;
  }

  static isValidTimeSlot(control: AbstractControl): ValidationErrors | any {

    if (!(control instanceof FormGroup)) {
      return null;
    }

    const openingTime = control.get('OpeningTime').value;
    const closingTime = control.get('ClosingTime').value;

    if (openingTime === undefined || openingTime === '' || closingTime === undefined || closingTime === '')
    {
      return null;
    }

    const operationHour = ScheduleHourValidator.getOperationHourInSecond(openingTime, closingTime);

    let isInvalid = false;
    if (operationHour.openingTime === operationHour.closingTime) {
      isInvalid = true;
    } else if (operationHour.openingTime > operationHour.closingTime) {
      isInvalid = true;
    }

    if (isInvalid) {
      return {
        isValidTimeSlot: true
      };
    }

    return null;

  }

  private static getOperationHourInSecond(openingTime: string, closingTime: string): any {
    const minInSec = 60;
    let openingTimeInSec = 0;
    let closingTimeInSec = 0;

    if (openingTime !== undefined && openingTime !== '' && openingTime) {
      const opeingTimes = openingTime.split(':');
      const hour = Number(opeingTimes[0]) * minInSec * minInSec;
      const minute = Number(opeingTimes[1]) * minInSec;

      openingTimeInSec = hour + minute;
    }

    if (closingTime !== undefined && closingTime !== '' && closingTime) {
      const closingTimes = closingTime.split(':');
      const hour = Number(closingTimes[0]) * minInSec * minInSec;
      const minute = Number(closingTimes[1]) * minInSec;

      closingTimeInSec = hour + minute;
    }

    return {
      openingTime: openingTimeInSec,
      closingTime: closingTimeInSec
    };
  }

  private static isValidHours(operationHours: any[]): boolean {
    operationHours = operationHours.sort((slot1, slot2) => {
      return slot2.openingTime - slot1.openingTime;
    });

    let index = 0;
    for (let i = 1; i < operationHours.length; i++) {
      if (operationHours[index].openingTime < operationHours[i].closingTime) {
        // break;
        return false;
      } else {
        index = index + 1;
      }
    }

    return true;
  }

}
