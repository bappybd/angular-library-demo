import {Injectable} from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';
import * as _ from 'lodash';
import {OperatingHourModel, ScheduledHourModel} from '../../models/scheduled-hour-model';
import {ScheduleHourValidator} from './schedule-hour.validator';

@Injectable({
  providedIn: 'root'
})
export class ScheduleHourService {

  constructor(private formBuilder: FormBuilder) {}

  getScheduleHoursFormGroup(): FormGroup {
    const weekDaysFormArray = this.getWeekDaysFormArray();

    const scheduledHoursForm = this.formBuilder.group({
      IsSameForAllDaysServiceHours: [true],
      SameForAllDays: this.formBuilder.array([
        this.formBuilder.group({
          OpeningTime: [''],
          ClosingTime: [''],
        }),
      ]),
      WeekDays: _.cloneDeep(weekDaysFormArray)
    });

    return scheduledHoursForm;
  }

  getWeekDaysFormArray(): FormArray {
    return this.formBuilder.array([
      this.getServiceHourFormBuilder(0),
      this.getServiceHourFormBuilder(1),
      this.getServiceHourFormBuilder(2),
      this.getServiceHourFormBuilder(3),
      this.getServiceHourFormBuilder(4),
      this.getServiceHourFormBuilder(5),
      this.getServiceHourFormBuilder(6),
    ]);
  }

  getScheduledHoursPayload(payload: any): ScheduledHourModel[] {
    const scheduledHourModels: ScheduledHourModel[] = [];

    if (payload.IsSameForAllDaysServiceHours) {
      const operatingHourList: OperatingHourModel[] = [];
      const hours = payload.SameForAllDays as any[];

      hours.forEach((hour) => {
        if (this.isValidOperatingHour(hour)) {
          operatingHourList.push(this.getOperatingHourModel(hour));
        }
      });

      if (operatingHourList.length > 0) {
        payload.WeekDays.forEach((day) => {
          scheduledHourModels.push({
            Day: day.WeekDay,
            OperatingHour: operatingHourList
          } as ScheduledHourModel);
        });
      }
    } else {
      payload.WeekDays.forEach((weekDay) => {
        const scheduleHour = this.getScheduledHour(weekDay);
        if (scheduleHour.OperatingHour.length > 0) {
          scheduledHourModels.push(scheduleHour);
        }
      });
    }
    return scheduledHourModels as ScheduledHourModel[];
  }

  setScheduledHoursValues(
    formGroup: FormGroup,
    isSameForAllDaysServiceHours: boolean,
    scheduledHours: ScheduledHourModel[]): void {

    formGroup.get('IsSameForAllDaysServiceHours').setValue(isSameForAllDaysServiceHours);

    if (isSameForAllDaysServiceHours) {
      const sameForAllDays = formGroup.get('SameForAllDays') as FormArray;

      const operatingHours = scheduledHours[0].OperatingHour;

      this.setOperatingHours(sameForAllDays, operatingHours);
    } else {
      const weekDays = formGroup.get('WeekDays') as FormArray;

      for (let i = 0; i < scheduledHours.length; i++) {
        const scheduledHour = scheduledHours[i];
       /* weekDays.at(i).get('WeekDay').setValue(scheduledHour.Day);*/

        const operatingHours = scheduledHour.OperatingHour;
        const hours = weekDays.at(scheduledHours[i].Day).get('Hours') as FormArray;

        this.setOperatingHours(hours, operatingHours);
      }
    }
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------
  private isValidOperatingHour(hour: any): boolean {
    const openingTime = hour.OpeningTime;
    const closingTime = hour.ClosingTime;

    if (openingTime === undefined || openingTime === '' || closingTime === undefined || closingTime === '')
    {
      return false;
    }

    return true;
  }

  private getScheduledHour(payload: any): ScheduledHourModel {
    const weekDay = payload.WeekDay;
    const hours = payload.Hours as any[];
    const operatingHourList: OperatingHourModel[] = [];

    hours.forEach((hour) => {
      if (this.isValidOperatingHour(hour)) {
        operatingHourList.push(this.getOperatingHourModel(hour));
      }
    });

    const scheduledHourModel: ScheduledHourModel = {
      Day: weekDay,
      OperatingHour: operatingHourList
    };

    return scheduledHourModel as ScheduledHourModel;
  }

  private getOperatingHourModel(hour: any): OperatingHourModel {
    const opeingHour = hour.OpeningTime;
    const openingTime = {
      Minute: 0,
      Hour: 0,
    };
    const closingTime = {
      Minute: 0,
      Hour: 0,
    };

    if (opeingHour !== undefined && opeingHour !== '') {
      const opeingTimes = opeingHour.split(':');
      openingTime.Hour = Number(opeingTimes[0]);
      openingTime.Minute = Number(opeingTimes[1]);
    }

    const closingHour = hour.ClosingTime;
    if (closingHour !== undefined && closingHour !== '') {
      const closingTimes = closingHour.split(':');
      closingTime.Hour = Number(closingTimes[0]);
      closingTime.Minute = Number(closingTimes[1]);

    }

    const scheduleHour = {
      ClosingTime: closingTime,
      OpeningTime: openingTime
    } as OperatingHourModel;

    return scheduleHour;
  }

  private getServiceHourFormBuilder(weekDay): FormGroup {
    var form = this.formBuilder.group({
      WeekDay: [weekDay],
      Hours: this.formBuilder.array([
        this.formBuilder.group({
          OpeningTime: [''],
          ClosingTime: [''],
        }),
      ]),
    });
    const formArr = (form.get('Hours') as FormArray);
    return form;
  }

  private setOperatingHours(formArray: FormArray, operatingHours: OperatingHourModel[]): void {
    for (let hourIndex = 0; hourIndex < operatingHours.length; hourIndex++) {
      const openingTime = operatingHours[hourIndex].OpeningTime;
      const closingTime = operatingHours[hourIndex].ClosingTime;

      const openingSomoy = _.padStart(openingTime.Hour + '', 2, '0') + ':' + _.padStart(openingTime.Minute + '', 2, '0');
      const closingSomoy = _.padStart(closingTime.Hour + '', 2, '0') + ':' + _.padStart(closingTime.Minute + '', 2, '0');

      // console.log(closingSomoy, openingSomoy);

      if (!('00:00' === openingSomoy && openingSomoy === closingSomoy)) {
        if (hourIndex === 0) {
          formArray.at(hourIndex).get('OpeningTime').setValue(openingSomoy);
          formArray.at(hourIndex).get('ClosingTime').setValue(closingSomoy);
        } else {
          formArray.push(this.formBuilder.group({
            OpeningTime: [openingSomoy],
            ClosingTime: [closingSomoy],
          }));
        }
      }
    }
  }
}
