import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {EevoValidator} from "../../validator/eevo.validator";
import {distinctUntilChanged, tap} from "rxjs/operators";
import {ScheduleHourValidator} from "../schedule-hour/schedule-hour.validator";
import {debug} from "ng-packagr/lib/utils/log";

@Component({
  selector: 'app-curated-tags',
  templateUrl: './curated-tags.component.html',
  styleUrls: ['./curated-tags.component.scss']
})
export class CuratedTagsComponent implements OnInit {
  @Input()
  parent: FormGroup;

  constructor(
    private fb: FormBuilder
  ) {
  }

  ngOnInit(): void {
    this.setValidation();
  }

  setValidation(): void {
    this.setPairValidationForCurationTags();
  }

  setPairValidationForCurationTags(): void {
    const curationTagsControls = this.parent.get('CuratedTags') as FormArray;
    const curationTagsControl = curationTagsControls.controls[0];
    this.setPairValidationOnCurationTag(curationTagsControl, 'CuratedName', 'Order');
  }

  private setPairValidationOnCurationTag(form: FormGroup | FormControl | AbstractControl, controlA: string, controlB: string, setReverse: boolean = true): void {
    form.get(controlA).valueChanges
      .pipe(distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)))
      .subscribe(value => {
        if (value) {
          form.get(controlB).setValidators([Validators.required]);
        } else {
          form.get(controlB).clearValidators();
        }
        form.get(controlB).updateValueAndValidity();
      });

    if (!setReverse) {
      return;
    }

    form.get(controlB).valueChanges
      .pipe(distinctUntilChanged())
      .subscribe(value => {
        if (value) {
          form.get(controlA).setValidators([Validators.required, EevoValidator.cannotWhiteSpace]);
        } else {
          form.get(controlA).clearValidators();
        }
        form.get(controlA).updateValueAndValidity();
      });
  }

  get curatedTags(): AbstractControl[] {
    return this.curatedTagsFormArray().controls;
  }

  get totalCuratedTags(): number {
    return this.curatedTagsFormArray().length;
  }

  addNewSlot(): void {
    this.curatedTagsFormArray().push(this.createSlot());
  }

  removeSlot(index: number): void {
    this.curatedTagsFormArray().removeAt(index);
  }

  isValidSlot(index): boolean {
    if ((this.totalCuratedTags - 1) === index) {
      const formArray = this.curatedTagsFormArray();
      return this.isValidTimeSlot(formArray, index);
    }
    return false;
  }

  private curatedTagsFormArray(): FormArray {
    return this.parent
      // .get('Details')
      .get('CuratedTags') as FormArray;
  }

  private isValidTimeSlot(formArray: FormArray, index: number): boolean {
    const openingTime = formArray.at(index).get('CuratedName').value;
    const closingTime = formArray.at(index).get('Order').value;

    if (openingTime !== '' && closingTime !== '') {
      return true;
    }

    return false;
  }

  private createSlot(): FormGroup {
    const form = this.fb.group({
      CuratedName: [''],
      Order: [0],
    });
    this.setPairValidationOnCurationTag(form, 'CuratedName', 'Order');
    return form;
  }
}
