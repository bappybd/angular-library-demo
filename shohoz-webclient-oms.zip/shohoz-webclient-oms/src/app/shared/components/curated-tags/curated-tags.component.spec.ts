import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CuratedTagsComponent } from './curated-tags.component';

describe('CuratedTagsComponent', () => {
  let component: CuratedTagsComponent;
  let fixture: ComponentFixture<CuratedTagsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CuratedTagsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CuratedTagsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
