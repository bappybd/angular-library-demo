import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';

@Component({
  selector: 'app-info-viewer-dialog',
  templateUrl: './info-viewer-dialog.component.html',
  styleUrls: ['./info-viewer-dialog.component.scss']
})
export class InfoViewerDialogComponent implements OnInit {

  info: string;
  constructor(
    private dialogRef: MatDialogRef<InfoViewerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
  ) {
    if (data) {
      this.info = data;
    }
  }

  ngOnInit(): void {
  }

  onCancelClick(): void {
    this.dialogRef.close();
  }

}
