import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoViewerDialogComponent } from './info-viewer-dialog.component';

describe('InfoViewerDialogComponent', () => {
  let component: InfoViewerDialogComponent;
  let fixture: ComponentFixture<InfoViewerDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfoViewerDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoViewerDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
