import {Component, Input, OnInit} from '@angular/core';
import {MatChipInputEvent} from '@angular/material/chips';
import {FormGroup} from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {EevoQueryService} from '@eevo/eevo-core';

@Component({
  selector: 'app-eevo-basic-chip-list',
  templateUrl: './eevo-basic-chip-list.component.html',
  styleUrls: ['./eevo-basic-chip-list.component.scss']
})
export class EevoBasicChipListComponent implements OnInit {
  @Input()
  formGroup: FormGroup;

  @Input()
  options: EevoBasicChipOptions;

  chipDataList: string[] = [];
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  constructor(private eevoQueryService: EevoQueryService) { }

  ngOnInit(): void {
    this.setOptions();

    if (this.options.formControlName) {
      this.setData(true);
      this.formGroup.get(this.options.formControlName).valueChanges.subscribe((data) => {
        this.setData();
      });
    }
  }

  setData(setIntoFormControl?: boolean): void {
    this.chipDataList = [];
    const value = this.formGroup.get(this.options.formControlName).value;

    if (value && value.length > 0) {
      let texts = value;
      if (typeof value === 'string' ) {
        texts = value.split(',');
      } else if (typeof value !== 'object' ) {
        texts = [];
      }
      texts.forEach(data => {
        this.chipDataList.push(data);
      });
      if (setIntoFormControl) {
        this.addOrRemoveIntoFormControl();
      }
    }
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if ((value || '').trim()) {
      this.chipDataList.push(value.trim());
      this.addOrRemoveIntoFormControl();
    }

    if (input) {
      input.value = '';
    }
  }

  remove(i: number): void {
    if (i >= 0) {
      this.chipDataList.splice(i, 1);
      this.addOrRemoveIntoFormControl();
    }
  }

  private addOrRemoveIntoFormControl(): void {
    if (this.options.formControlName) {
      this.formGroup.get(this.options.formControlName).setValue(this.chipDataList);
    }
  }

  private setOptions(): void {
    if (this.options.formControlName === undefined) {
      console.warn('eevo chip list will not working, because you did not set `formControlName`');
    }

    if (this.options.removable === undefined) {
      this.options.removable = true;
    }
    if (this.options.selectable === undefined) {
      this.options.selectable = true;
    }
    if (!this.options.placeholder) {
      this.options.placeholder = 'Press ENTER to add';
    }
  }
}

export class EevoBasicChipOptions {
  formControlName: string;
  labelTxt: string;
  removable: boolean;
  selectable: boolean;
  placeholder: string; // Press ENTER to add
  suggestionEnable: boolean;
  suggestionList: string[];
}
