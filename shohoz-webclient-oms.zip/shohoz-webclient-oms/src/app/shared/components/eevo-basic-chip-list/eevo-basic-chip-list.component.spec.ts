import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoBasicChipListComponent } from './eevo-basic-chip-list.component';

describe('EevoBasicChipListComponent', () => {
  let component: EevoBasicChipListComponent;
  let fixture: ComponentFixture<EevoBasicChipListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoBasicChipListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoBasicChipListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
