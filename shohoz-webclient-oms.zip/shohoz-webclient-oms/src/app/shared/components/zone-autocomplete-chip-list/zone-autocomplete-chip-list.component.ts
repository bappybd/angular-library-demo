import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatAutocomplete, MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {ZoneService} from '@eevo/eevo-core';
import {debounceTime, finalize, map, startWith, switchMap, tap} from 'rxjs/operators';
import {Observable, Subject} from 'rxjs';
import {ZoneQueryService} from "../../../app-zone/services/zone-query.service";
import {ZoneModuleService} from "../../../app-zone/services/zone-module-service";


@Component({
  selector: 'app-zone-autocomplete-chip-list',
  templateUrl: './zone-autocomplete-chip-list.component.html',
  styleUrls: ['./zone-autocomplete-chip-list.component.scss']
})
export class ZoneAutocompleteChipListComponent implements OnInit {
  dataList: any[];

  @Input()
  formGroup: FormGroup;

  @Input()
  options: ZoneAutocompleteChipOptions;

  private EXCLUDED_ZONE: any;
  selectedZoneIds = {};

  @Input()
  set excludedZone(value: any) {
    this.EXCLUDED_ZONE = value;
    this.removeExcludedZone(this.EXCLUDED_ZONE);
  }

  get excludedZone(): any {
    return this.EXCLUDED_ZONE;
  }
  zoneDataList: { Id: string, Name: string }[] = [];
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  // auto complete
  filteredDataList: Observable<any[]>;
  searchCtrl = new FormControl();

  errorMsg: string;
  isLoading: boolean;

  subject = new Subject<any>();


  @ViewChild('autocompleteInput') autocompleteInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;
  // end auto complete

  constructor( private zoneService: ZoneService,
               private zoneQueryService: ZoneQueryService,
               private zoneModuleService: ZoneModuleService) {
    this.dataList = [];
  }

  ngOnInit(): void {
    this.setOptions();
    this.loadData();
    if (this.options.formControlName) {
      this.setData();
      this.formGroup.get(this.options.formControlName).valueChanges.subscribe((data) => {
        this.setData();
      });
    }
  }

  private removeExcludedZone(zone: any): void {
    const zoneId = (zone && zone._id) ? zone._id : zone.id;
    if (typeof zone === 'object') {
      this.dataList = this.dataList.filter(data => data.id !== zoneId);
      this.setFilteredZones();
    }
  }

  // auto complete
  displayFn(data: any): string {
    return data && data.name ? data.name : '';
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.zoneDataList.push({
      Id: event.option.value.id,
      Name: event.option.value.name
    });
    // this.selectedZoneIds[event.option.value.id] = true;
    this.selectedZoneIds[event.option.value.name] = true;
    this.autocompleteInput.nativeElement.value = '';
   /* this.searchCtrl.setValue(null);*/
    this.addOrRemove();
  }

  loadData(): void {
    this.zoneService.getFoodZones().subscribe((response) => {
      this.dataList = response?.data || [];
      this.removeExcludedZone(this.excludedZone);
      this.setFilteredZones();
    });
  }

  private setFilteredZones(): void {
    this.filteredDataList = this.searchCtrl.valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.name),
        map(name => name ? this.zoneFilter(name) : this.dataList.slice()),
      );
  }

  private zoneFilter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.dataList.filter(option => option.name.toLowerCase().indexOf(filterValue) === 0);
  }

  setData(): void {
    this.zoneDataList = [];
    const values = this.formGroup.get(this.options.formControlName).value;
    if (values && typeof values === 'object' && values.length > 0) {
      values.forEach(value => {
        this.zoneDataList.push({
          Id: value._id ? value._id : value.Id,
          Name: value.name ? value.name : value.Name,
        });
        // this.selectedZoneIds[value?._id || value.Id] = true;
         this.selectedZoneIds[value.Name] = true;
         this.zoneModuleService.setSubject(this.selectedZoneIds);
      });
    }
  }

  remove(i: number): void {
    if (i >= 0) {
      this.zoneDataList.splice(i, 1);
      this.addOrRemove();
    }
  }

  private addOrRemove(): void {
    if (this.options.formControlName) {
      this.formGroup.get(this.options.formControlName).setValue(this.zoneDataList);
    }
  }

  private setOptions(): void {
    if (this.options.formControlName === undefined) {
      console.warn('zone chip list will not working, because you did not set `formControlName`');
    }
    if (this.options.removable === undefined) {
      this.options.removable = true;
    }
    if (this.options.selectable === undefined) {
      this.options.selectable = true;
    }
    if (!this.options.placeholder) {
      this.options.placeholder = 'Search';
    }
  }
}

export class ZoneAutocompleteChipOptions {
  formControlName: string;
  labelTxt: string;
  removable: boolean;
  selectable: boolean;
  placeholder: string; // Press ENTER to add
  keyProp: string;
  valueProp: string;
  // queryProp: string;
  suggestionEnable: boolean;
  suggestionList: string[];
  ignoreKeyDatas: string[];

}
