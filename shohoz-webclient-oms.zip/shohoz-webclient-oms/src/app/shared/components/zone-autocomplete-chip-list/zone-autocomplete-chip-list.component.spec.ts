import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ZoneAutocompleteChipListComponent } from './zone-autocomplete-chip-list.component';

describe('ZoneAutocompleteChipListComponent', () => {
  let component: ZoneAutocompleteChipListComponent;
  let fixture: ComponentFixture<ZoneAutocompleteChipListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ZoneAutocompleteChipListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ZoneAutocompleteChipListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
