import {Component, Inject, OnInit} from '@angular/core';
import {MAT_SNACK_BAR_DATA, MatSnackBarRef} from '@angular/material/snack-bar';
import {CommandNotificationModel} from '../../models/command-notification-model';

@Component({
  selector: 'app-notification-snack-bar',
  templateUrl: './notification-snack-bar.component.html',
  styleUrls: ['./notification-snack-bar.component.scss']
})
export class NotificationSnackBarComponent {

  constructor(
    public snackBarRef: MatSnackBarRef<NotificationSnackBarComponent>,
    @Inject(MAT_SNACK_BAR_DATA) public data: CommandNotificationModel) {
  }

}
