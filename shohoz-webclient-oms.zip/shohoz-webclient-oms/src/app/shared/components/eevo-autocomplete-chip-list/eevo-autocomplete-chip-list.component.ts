import {Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {debounceTime, finalize, switchMap, tap} from 'rxjs/operators';
import {EevoQueryService} from '@eevo/eevo-core';
import {MatAutocomplete, MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {combineLatest,  Observable} from "rxjs";

@Component({
  selector: 'app-eevo-autocomplete-chip-list',
  templateUrl: './eevo-autocomplete-chip-list.component.html',
  styleUrls: ['./eevo-autocomplete-chip-list.component.scss']
})
export class EevoAutocompleteChipListComponent implements OnInit {
  @Input()
  formGroup: FormGroup;
  @Output()
  loading: EventEmitter<boolean> = new EventEmitter<boolean>();

  @Input()
  options: EevoAutocompleteChipOptions;

  chipDataList: { key: string, value: string }[] = [];
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  // auto complete
  filteredDataList: any[];
  searchCtrl = new FormControl();

  errorMsg: string;
  isLoading: boolean;

  @ViewChild('autocompleteInput') autocompleteInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  // end auto complete

  constructor(private eevoQueryService: EevoQueryService) {
  }

  ngOnInit(): void {
    this.setOptions();
    this.loadData();

    if (this.options.formControlName) {
      this.setData();
      this.formGroup.get(this.options.formControlName).valueChanges.subscribe((data) => {
        this.setData();
      });
    }
  }

  // auto complete
  displayFn(data: any): string {
    if (this.options.valueProp) {
      return data && data[this.options.valueProp] ? data[this.options.valueProp] : '';
    }

    return 'Invalid!!!';
  }

  selected(event: MatAutocompleteSelectedEvent): void {

    this.chipDataList.push({
      key: event.option.value,
      value: event.option.viewValue
    });

    this.autocompleteInput.nativeElement.value = '';
    this.searchCtrl.setValue(null);
    this.addOrRemove();
  }

  loadData(): void {
    this.searchCtrl
      .valueChanges
      .pipe(
        debounceTime(500),
        tap(() => {
          this.errorMsg = '';
          this.filteredDataList = [];
          this.isLoading = true;
        }),
        switchMap((value: any, index: number) => {
          const fields = [this.options.valueProp];

          if (this.options.keyProp !== 'Id') {
            fields.push(this.options.keyProp);
          }

          const filter = `{ '${this.options.valueProp}' : /${value}/i  }`;

          return this.eevoQueryService.getList<any>(
            this.options.dataUrl, this.options.dataSource, fields, filter
          ).pipe(
            finalize(() => {
              this.isLoading = false;
            })
          );
        })
      )
      .subscribe(dataList => {
        dataList.forEach(data => {
          const prorData = data[this.options.keyProp];
          const hasData = this.chipDataList.find(f => {
            return f.key === prorData;
          });
          const hasKeyData = this.options.ignoreKeyDatas.find(kd => {
            return kd === prorData;
          });

          if (!hasData && !hasKeyData) {
            this.filteredDataList.push(data);
          }
        });
      });
  }

  // end auto complete
  setData(): void {
    this.chipDataList = [];
    const values = this.formGroup.get(this.options.formControlName).value;

    if (values && typeof values === 'object' && values.length > 0) {
      const isStringArrayValues = typeof values[0] === 'string';

      if (isStringArrayValues) {
        const fields = [this.options.valueProp];

        let fieldKey = this.options.keyProp;
        if (this.options.keyProp !== 'Id') {
          fields.push(this.options.keyProp);
        } else {
          fieldKey = '_id';
        }

        const valueList = [];
        values.forEach(value => {
          valueList.push(`GUID('${value}')`);
        });

        const filter = `{ '${fieldKey}' : { $in: [${valueList.join(',')}]  } }`;
        this.getDataBySplittingCalls(valueList.length || 0, 100, fields, filter);
      } else {
        this.chipDataList = [];
        values.forEach(value => {
          this.chipDataList.push({
            key: value.key ? value.key : value[this.options.keyProp],
            value: value.value ? value.value : value[this.options.valueProp],
          });
        });
      }
    }
  }

  private getDataBySplittingCalls(dataCount: number, pageSize = 100, fields: string[], filter: string): void {
    this.loading.emit(true);
    combineLatest(this.getCallList(dataCount, pageSize, fields, filter))
      .subscribe((dataLists: any[]) => {
        this.chipDataList = [];
        dataLists.forEach(datalist => {
          datalist.forEach(data => {
            this.chipDataList.push({
              key: data[this.options.keyProp],
              value: data[this.options.valueProp],
            });
          });
        });
        this.addOrRemove();
        this.loading.emit(false);
      });
  }

  private getCallList(dataCount: number, pageSize = 100, fields: string[], filter: string): Observable<any>[] {
    let TotalNumberOfPage;
    if ((dataCount % pageSize) === 0) {
      TotalNumberOfPage = dataCount / pageSize;
    } else {
      TotalNumberOfPage = Math.floor(dataCount / pageSize) + 1;
    }
    const calls = [];
    for (let pageIndex = 0; pageIndex < TotalNumberOfPage; pageIndex++) {
      calls.push(
        this.eevoQueryService.getList<any>(
          this.options.dataUrl, this.options.dataSource, fields, filter, pageIndex, pageSize
        ));
    }
    return calls;
  }

  remove(i: number): void {
    if (i >= 0) {
      this.chipDataList.splice(i, 1);
      this.addOrRemove();
    }
  }

  private addOrRemove(): void {
    if (this.options.formControlName) {
      this.formGroup.get(this.options.formControlName).setValue(this.chipDataList);
    }
  }

  private setOptions(): void {
    if (this.options.formControlName === undefined) {
      console.warn('eevo chip list will not working, because you did not set `formControlName`');
    }

    if (this.options.keyProp === undefined) {
      console.warn('eevo chip list will not working, because you did not set `keyProp`');
    }
    if (this.options.valueProp === undefined) {
      console.warn('eevo chip list will not working, because you did not set `valueProp`');
    }
    if (this.options.dataSource === undefined) {
      console.warn('eevo chip list will not working, because you did not set `dataSource`');
    }

    if (this.options.removable === undefined) {
      this.options.removable = true;
    }
    if (this.options.selectable === undefined) {
      this.options.selectable = true;
    }
    if (!this.options.placeholder) {
      this.options.placeholder = 'Search';
    }
  }
}

export class EevoAutocompleteChipOptions {
  formControlName: string;
  labelTxt: string;
  removable: boolean;
  selectable: boolean;
  placeholder: string; // Press ENTER to add
  keyProp: string;
  valueProp: string;
  // queryProp: string;
  dataUrl: string;
  dataSource: string;
  suggestionEnable: boolean;
  suggestionList: string[];
  ignoreKeyDatas: string[];
}
