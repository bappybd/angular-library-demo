import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoAutocompleteChipListComponent } from './eevo-autocomplete-chip-list.component';

describe('EevoAutocompleteChipListComponent', () => {
  let component: EevoAutocompleteChipListComponent;
  let fixture: ComponentFixture<EevoAutocompleteChipListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoAutocompleteChipListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoAutocompleteChipListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
