import {Inject, Injectable} from '@angular/core';
import {
  CommandNotificationModel,
  NotificationMessageModel,
  NotificationMessageType
} from '../../models/command-notification-model';
import {EevoNotifyService, NotifyType, UtilityService} from '@eevo/eevo-core';
import * as _ from 'lodash';


@Injectable({
  providedIn: 'root'
})
export class NotificationHandlerService {

  private readonly PropPrefix = 'MES';

  constructor(
    private notifyService: EevoNotifyService,
    @Inject('eventMessages') private validationMessage: any | {}
  ) {
    if (!validationMessage) {
      throw new Error('{NotificationHandlerService} eventMessages not defined');
    }
  }

  parseAndDisplayMessage(response: any | {}, success: boolean, message?: string): CommandNotificationModel {
    const data = this.parseNotification(response, success, message);
    this.displayMessage(data);
    return data;
  }

  parseNotification(response: any | {}, success: boolean, message?: string): CommandNotificationModel {
    const data = JSON.parse(response.value);

    const errorCodePropPrefix = this.validationMessage.PropPrefix || this.PropPrefix;

    const eventMessages = data.EventMessages || [];

    let errorMessageList = [];
    eventMessages.forEach(eventMessage => {
      const messageData = eventMessage.Data;
      const messageCode = eventMessage.MessageCode;
      const messageType = eventMessage.MessageType;

      if (messageType === NotificationMessageType.Error) {
        const prop = `${errorCodePropPrefix}_${messageCode}`;
        const messageTxt = this.validationMessage[prop];

        const errorMessage = UtilityService.stringInject(messageTxt, messageData);

        const messageModel: NotificationMessageModel = {
          MessageCode: messageCode,
          MessageType: messageType,
          Message: errorMessage
        };

        errorMessageList.push(messageModel);
      }
    });

    if (data.ErrorCode && !message) {
      message = data.ErrorCode;
      message = _.lowerCase(message);
      message = _.upperFirst(message);
    }

    return {
      Details: data,
      Success: success,
      Message: message,
      Messages: errorMessageList,
      ActionName: data?.ActionName || response ?.key,
    };
  }

  displayMessage(message: CommandNotificationModel): void {
    if (!message.Success) {
      if (message.Messages && message.Messages.length > 0) {
        message.Messages.forEach(mes => {
          this.notifyService.displayMessage(mes.Message, NotifyType.Error);
        });
      } else {
        this.notifyService.displayMessage(message.Message, NotifyType.Error);
      }
    } else {
      this.notifyService.displayMessage(message.Message, NotifyType.Success);
    }
  }
}
