import {Injectable} from '@angular/core';

export interface AudioNotification {
  key: string;
  pause: any;
  stop: any;
  play: any;
  mute: any;
  setVolume: any;
  unMute: any;
  destroy: any;
  audioElement: HTMLAudioElement;
}

interface AudioData {
  activeAudios: { [key: string]: AudioNotification };
  length: number;
}

class Configs {
  muteAllSounds: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AudioNotificationService {

  private audiosUrls = {
    default: '../../../assets/audio/notification-sounds/notification-short.mp3'
  };

  private audioData: AudioData = {activeAudios: {}, length: 0};
  private configs = new Configs();
  private LOCAL_STORAGE_KEY_NAME = 'audio_notification_config';

  constructor() {
    this.getLocalStorageConfig();
  }

  get muted(): boolean {
    return this.configs?.muteAllSounds;
  }

  set muted(muted: boolean) {
    muted ? this.muteAllSounds() : this.unMuteAllSounds();
  }

  loadAudio(key?: string, audioUrl?: string, sec?: number): AudioNotification {
    if (!audioUrl) {
      audioUrl = this.audiosUrls.default;
    }
    const audio = new Audio(audioUrl);
    audio.load();

    const audioNotification = {
      key,
      play: this.playHOF(audio, sec).bind(this),
      pause: this.pauseHOF(audio).bind(this),
      stop: this.stopHOF(audio).bind(this),
      mute: this.muteHOF(audio).bind(this),
      setVolume: this.setVolumeHOF(audio).bind(this),
      unMute: this.unMuteHOF(audio).bind(this),
      destroy: this.destroyHOF(audio, key).bind(this),
      audioElement: audio,
    } as AudioNotification;

    this.storeAudioData(audioNotification);
    return audioNotification;
  }

  private playHOF(audioInstance: HTMLAudioElement, sec: number): any {
    let setTimeout = null;
    return () => {
      clearTimeout(setTimeout);
      audioInstance.play();
      if (sec) {
        audioInstance.loop = true;
        setTimeout = this.stopAudioAfterInterval(audioInstance, sec);
      }
    };
  }

  private stopAudioAfterInterval(audioInstance: HTMLAudioElement, sec: number): any {
    return setTimeout(() => {
      this.stopHOF(audioInstance)();
    }, sec * 1000);
  }

  private pauseHOF(audioInstance: HTMLAudioElement): any {
    return () => {
      audioInstance.pause();
    };
  }

  private setVolumeHOF(audioInstance: HTMLAudioElement): any {
    return (volume: number) => {
      audioInstance.volume = volume / 100;
    };
  }

  private stopHOF(audioInstance: HTMLAudioElement): any {
    return () => {
      audioInstance.pause();
      audioInstance.currentTime = 0;
    };
  }

  private muteHOF(audioInstance: HTMLAudioElement): any {
    audioInstance.muted = this.configs.muteAllSounds;
    return () => {
      audioInstance.muted = true;
    };
  }

  private unMuteHOF(audioInstance: HTMLAudioElement): any {
    return () => {
      audioInstance.muted = false;
    };
  }

  private destroyHOF(audioInstance: HTMLAudioElement, key?: string): any {
    return () => {
      audioInstance.src = '';
      audioInstance.load();
      this.removeAudioData(key);
    };
  }

  private storeAudioData(audioNotification: AudioNotification): void {
    if (audioNotification?.key) {
      this.audioData.activeAudios[audioNotification.key] = audioNotification;
      this.audioData.length++;
    }
  }

  private removeAudioData(key: string): void {
    if (this.audioData.activeAudios.hasOwnProperty(key)) {
      delete this.audioData.activeAudios[key];
      this.audioData.length--;
    }
  }

  private muteAllSounds(): void {
    this.configs.muteAllSounds = true;
    const activeAudios = this.audioData.activeAudios;
    for (const key in activeAudios) {
      if (activeAudios.hasOwnProperty(key)) {
        activeAudios[key].mute();
      }
    }
    this.updateLocalStorageConfig();
  }

  private unMuteAllSounds(): void {
    this.configs.muteAllSounds = false;
    const activeAudios = this.audioData.activeAudios;
    for (const key in activeAudios) {
      if (activeAudios.hasOwnProperty(key)) {
        activeAudios[key].unMute();
      }
    }
    this.updateLocalStorageConfig();
  }

  private updateLocalStorageConfig(): void {
    window.localStorage.setItem(this.LOCAL_STORAGE_KEY_NAME, JSON.stringify(this.configs));
  }

  private getLocalStorageConfig(): void {
    const localConfig = JSON.parse(window.localStorage.getItem(this.LOCAL_STORAGE_KEY_NAME));
    if (localConfig) {
      this.configs = localConfig;
    }
  }
}
