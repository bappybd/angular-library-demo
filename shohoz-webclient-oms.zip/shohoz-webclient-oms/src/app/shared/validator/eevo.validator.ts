import {AbstractControl, FormArray, FormGroup, ValidationErrors, ValidatorFn} from '@angular/forms';
import * as moment from 'moment';

export class EevoValidator {

  static minLengthArray(min: number): ValidatorFn | null {
    return (control: AbstractControl): { [key: string]: any } => {
      if (control.value.length >= min) {
        return null;
      }

      return {
        minLengthArray: {
          valid: false
        }
      };
    };

    return null;
  }

  static lessThan(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const group = control.parent;
      const fieldToCompare = group.get(field);
      const isLessThan = Number(fieldToCompare.value) < Number(control.value);
      return isLessThan ? {lessThan: {value: control.value}} : null;
    };
  }

  static greaterThanOrEqual(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const group = control.parent;
      const fieldToCompare = group.get(field);
      const isGreaterThanOrEqual = Number(fieldToCompare.value) >= Number(control.value);
      return isGreaterThanOrEqual ? {greaterThanOrEqual: {value: control.value}} : null;
    };
  }

  static minByFieldNameOrZero(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const group = control.parent;
      const fieldToCompare = group.get(field);
      const isGreaterThanOrEqual = Number(fieldToCompare.value) >= Number(control.value);
      return isGreaterThanOrEqual ? {minOrZero: {value: control.value}} : null;
    };
  }

  static isRequired(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const group = control.parent;
      const fieldToCompare = group.get(field);
      const isLessThan = Number(fieldToCompare.value) < Number(control.value);
      return isLessThan ? {lessThan: {value: control.value}} : null;
    };
  }

  static dateTimeLessThan(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const group = control.parent;
      const startDateTime = this.combineDateWithTime(group.get('AppliedDate').value, group.get('AppliedTime').value).toISOString();
      const endDateTime = this.combineDateWithTime(group.get('ExpiredDate').value, group.get('ExpiredTime').value).toISOString();
      const isLessThan = endDateTime < startDateTime;
      return isLessThan ? {dateTimeLessThan: {value: control.value}} : null;
    };
  }

  static highlightTextDateTime(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const group = control.parent;
      const startDateTime = this.combineDateWithTime(
        group.get('TagLineStartDate').value, group.get('TagLineStartTime').value).toISOString();
      const endDateTime = this.combineDateWithTime(
        group.get('TagLineEndDate').value, group.get('TagLineEndTime').value).toISOString();
      const isLessThan = endDateTime < startDateTime;
      return isLessThan ? {highlightTextDateTime: {value: control.value}} : null;
    };
  }

  static dateTimeLessThanCurrentTime(field: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const group = control.parent;
      const startDateTime = this.combineDateWithTime(group.get('AppliedDate').value, group.get('AppliedTime').value).getTime();
      const isLessThan = new Date().getTime() > startDateTime;
      return isLessThan ? {dateTimeLessThanCurrentTime: {value: control.value}} : null;
    };
  }

  static paymentMethodSelected(control: AbstractControl[] | any): ValidationErrors | any {
    if (!(control instanceof FormArray)) {
      return null;
    }

    const valueArr = control && control.value;
    const group = control.parent;
    if (valueArr !== '' && typeof valueArr === 'object') {

      let isValid = false;
      // tslint:disable-next-line:prefer-for-of
      for (let j = 0; j < valueArr.length; j++) {
        const pm = valueArr[j];

        if (pm) {
          isValid = true;
          return null;
        }

      } // end loop

      if (!isValid) {
        return {
          paymentMethodSelected: true
        };
      }

    }

    return null;
  }

  static cannotWhiteSpace(control: AbstractControl): ValidationErrors | null {
    const value = (control.value as string);
    if (value && value.indexOf(' ') >= 0 && value.trim().length == 0) {
      return {
        cannotWhiteSpace: true
      };
    }

    return null;
  }

  static cannotContainSpace(control: AbstractControl): ValidationErrors | null {

    if ((control.value as string).indexOf(' ') >= 0) {
      return {
        cannotContainSpace: true
      };
    }

    return null;
  }

  static dataSelectedValidator(): ValidatorFn | null {
    return (control: AbstractControl): { [key: string]: any } | null => {

      if (control && control.value !== '' && typeof control.value === 'string') {
        return {
          invalidDataSelected: {
            value: control.value
          }
        };
      }

      return null;
    };

  }

  private static combineDateWithTime(date: Date, time: string): Date {
    date = new Date(date);
    let hour = 0;
    let minute = 0;

    if (time !== '') {
      const hourAndMinute = time.split(':');
      hour = Number(hourAndMinute[0]);
      minute = Number(hourAndMinute[1]);
    }

    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      hour,
      minute
    );
  }

  static isValidDateAndTimeSlot(formGroup: FormGroup): ValidationErrors | any {
    if (!(formGroup instanceof FormGroup)) {
      return null;
    }

    let applicableFromDate = formGroup.get('ApplicableFromDate').value;
    let applicableToDate = formGroup.get('ApplicableToDate').value;
    const applicableFromTime = formGroup.get('ApplicableFromTime').value;
    const applicableToTime = formGroup.get('ApplicableToTime').value;

    if (typeof (applicableFromDate) === 'string') {
      applicableFromDate = moment(applicableFromDate).set({hour: 0, minute: 0, second: 0, millisecond: 0});
    }

    if (typeof (applicableToDate) === 'string') {
      applicableToDate = moment(applicableToDate).set({hour: 0, minute: 0, second: 0, millisecond: 0});
    }
    if (applicableFromTime === undefined || applicableFromTime === '' || applicableToTime === undefined || applicableToTime === '') {
      return null;
    }

    if (applicableFromDate && applicableToDate && (applicableFromDate._d.toString() === applicableToDate._d.toString())) {
      const operationHour = EevoValidator.getOperationHourInSecond(applicableFromTime, applicableToTime);
      let isInvalid = false;
      if (operationHour.applicableFromTime === operationHour.applicableToTime) {
        isInvalid = true;
      } else if (operationHour.applicableFromTime > operationHour.applicableToTime) {
        isInvalid = true;
      }

      if (isInvalid) {
        return {
          isValidDateAndTimeSlot: true
        };
      }

      return null;
    }
  }

  private static getOperationHourInSecond(applicableFromTime: string, applicableToTime: string): any {
    const minInSec = 60;
    let applicableFromTimeInSec = 0;
    let applicableToTimeInSec = 0;

    if (applicableFromTime !== undefined && applicableFromTime !== '') {
      const opeingTimes = applicableFromTime.split(':');
      const hour = Number(opeingTimes[0]) * minInSec * minInSec;
      const minute = Number(opeingTimes[1]) * minInSec;

      applicableFromTimeInSec = hour + minute;
    }

    if (applicableToTime !== undefined && applicableToTime !== '' && applicableToTime !== null) {
      const closingTimes = applicableToTime.split(':');
      const hour = Number(closingTimes[0]) * minInSec * minInSec;
      const minute = Number(closingTimes[1]) * minInSec;

      applicableToTimeInSec = hour + minute;
    }

    return {
      applicableFromTime: applicableFromTimeInSec,
      applicableToTime: applicableToTimeInSec
    };
  }

  static cannotContainStrings(strings: string[]): any {
    return (control: AbstractControl): ValidationErrors | null => {
      if (strings.some(s => (control.value as string).includes(s))) {
        return {
          hasInvalidString: true
        };
      }
      return null;
    };
  }
}
