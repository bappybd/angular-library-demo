import {Component, Input, OnInit, TemplateRef} from '@angular/core';

@Component({
  selector: 'app-list-page-layout',
  templateUrl: './list-page-layout.component.html',
  styleUrls: ['./list-page-layout.component.scss']
})
export class ListPageLayoutComponent implements OnInit {
  @Input() titleTemplateRef: TemplateRef<any>;
  @Input() searchTemplateRef?: TemplateRef<any>;
  @Input() loading: boolean;
  @Input() bodyGap = -50;
  @Input() disableSearchToggle = false;

  showSearchContainer: boolean;

  constructor() {
  }

  ngOnInit(): void {
  }

  toggleAdvancedSearch(): void {
    this.showSearchContainer = !this.showSearchContainer;
  }
}
