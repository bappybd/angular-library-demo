import {Component, HostListener, Input, OnInit, TemplateRef} from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {fuseAnimations} from '@eevo/eevo-base';

@Component({
  selector: 'app-details-page-layout',
  templateUrl: './details-page-layout.component.html',
  styleUrls: ['./details-page-layout.component.scss'],
  animations: fuseAnimations
})
export class DetailsPageLayoutComponent implements OnInit {
  @Input() titleTemplateRef?: TemplateRef<any>;
  @Input() searchTemplateRef?: TemplateRef<any>;
  @Input() breadcrumbList?: BreadcrumbModel[];
  @Input() loading: boolean;
  @Input() bodyGap = -50;
  @Input() disableSearchToggle = false;

  displayWidth = window.innerWidth;
  outerSpacingPx = 8;
  showSearchContainer: boolean;

  constructor() {
  }

  ngOnInit(): void {
    this.setSpacingByDisplaySize();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event): void {
    this.displayWidth = window.innerWidth;
    this.setSpacingByDisplaySize();
  }

  private setSpacingByDisplaySize(): void {
    if (this.displayWidth > 768) {
      this.outerSpacingPx = 24;
    } else if (this.displayWidth > 425) {
      this.outerSpacingPx = 16;
    }
  }

  toggleAdvancedSearch(): void {
    this.showSearchContainer = !this.showSearchContainer;
  }
}
