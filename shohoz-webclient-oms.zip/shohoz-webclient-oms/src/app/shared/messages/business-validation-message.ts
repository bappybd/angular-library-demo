export class BusinessValidationMessage
{
  static readonly PropPrefix = 'MES';
  static readonly MES_100001 = '{0} should not be null or empty';
  static readonly MES_100002 = '{0} invalid email.';
  static readonly MES_100003 = '{0} array must have an element';
  static readonly MES_100004 = '{0} invalid post code';
  static readonly MES_100005 = 'internal exception';
  static readonly MES_100006 = '{0}, invalid id';
  static readonly MES_100010 = '{0} is greater than {1}';
  static readonly MES_100011 = 'Shop Is Permanently Closed ';
  static readonly MES_100012 = 'Shop is closed either temporarily or permanently';
}

export class ShopBusinessValidationCodes
{
  static readonly Success: number = 0;

  static readonly PropertyIsNullEmpty: number = 100001; // 00100001;
  static readonly InvalidEmail: number = 100002; // 00100002;
  static readonly ArrayMustHaveAnElement: number = 100003; // 00100003;
  static readonly InvalidPostCode: number = 100004; // 00100004;
  static readonly InternalException: number = 100005; // 00100005;
  static readonly InvalidId: number = 100006; // 00100006;
}
