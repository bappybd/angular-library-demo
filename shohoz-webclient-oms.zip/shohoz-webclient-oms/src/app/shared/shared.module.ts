import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {NotificationSnackBarComponent} from './components/notification-snack-bar/notification-snack-bar.component';
import {MatIconModule} from '@angular/material/icon';
import {FlexLayoutModule, FlexModule} from '@angular/flex-layout';
import {RouterModule} from '@angular/router';
import {NotificationHandlerService} from './services/notification/notification-handler.service';
import {BusinessValidationMessage} from './messages/business-validation-message';
import {ConfirmationDialogComponent} from './components/confirmation-dialog/confirmation-dialog.component';
import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule} from '@angular/material/dialog';
import {ScheduleHourComponent} from './components/schedule-hour/schedule-hour.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatChipsModule} from '@angular/material/chips';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatRadioModule} from '@angular/material/radio';
import {MatTabsModule} from '@angular/material/tabs';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatMenuModule} from '@angular/material/menu';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatCardModule} from '@angular/material/card';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {FuseSharedModule} from '@eevo/eevo-base';
import {NumbersOnlyDirective} from './directives/numbers-only.directive';
import {EevoBasicChipListComponent} from './components/eevo-basic-chip-list/eevo-basic-chip-list.component';
import {EevoAutocompleteChipListComponent} from './components/eevo-autocomplete-chip-list/eevo-autocomplete-chip-list.component';
import {ZoneAutocompleteChipListComponent} from './components/zone-autocomplete-chip-list/zone-autocomplete-chip-list.component';
import {CityAutocompleteChipListComponent} from './components/city-autocomplete-chip-list/city-autocomplete-chip-list.component';
import {CuratedTagsComponent} from './components/curated-tags/curated-tags.component';
import {NotFoundComponent} from './components/not-found/not-found.component';
import {ListPageLayoutComponent} from './page-layouts/list-page-layout/list-page-layout.component';
import {DetailsPageLayoutComponent} from './page-layouts/details-page-layout/details-page-layout.component';
import {EevoPlatformBreadcrumbModule} from '@eevo/eevo-platform-breadcrumb';
import {LimitNumberAfterDecimal} from './directives/limit-number-after-decimal';
import {EevoPlatformDatatableModule} from '@eevo/eevo-platform-datatable';
import {InfoViewerDialogComponent} from './components/info-viewer-dialog/info-viewer-dialog.component';

@NgModule({
  declarations: [
    NotificationSnackBarComponent,
    ConfirmationDialogComponent,
    ScheduleHourComponent,
    NumbersOnlyDirective,
    EevoBasicChipListComponent,
    EevoAutocompleteChipListComponent,
    ZoneAutocompleteChipListComponent,
    CityAutocompleteChipListComponent,
    CuratedTagsComponent,
    NotFoundComponent,
    ListPageLayoutComponent,
    DetailsPageLayoutComponent,
    LimitNumberAfterDecimal,
    InfoViewerDialogComponent,
  ],
    imports: [
        FlexModule,
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        MatIconModule,
        MatInputModule,
        MatSelectModule,
        MatChipsModule,
        MatButtonModule,
        MatSnackBarModule,
        MatFormFieldModule,
        MatRadioModule,
        MatCheckboxModule,
        MatTabsModule,
        MatAutocompleteModule,
        MatMenuModule,
        MatSlideToggleModule,
        MatCardModule,
        MatProgressSpinnerModule,
        MatProgressBarModule,
        MatDialogModule,
        FuseSharedModule,
        EevoPlatformBreadcrumbModule,
        EevoPlatformDatatableModule,
        FlexLayoutModule,
    ],
    exports: [
        ScheduleHourComponent,
        ConfirmationDialogComponent,
        NumbersOnlyDirective,
        EevoBasicChipListComponent,
        EevoAutocompleteChipListComponent,
        ZoneAutocompleteChipListComponent,
        CityAutocompleteChipListComponent,
        CuratedTagsComponent,
        ListPageLayoutComponent,
        DetailsPageLayoutComponent,
        LimitNumberAfterDecimal,
    ],
  providers: [
    NotificationHandlerService,
    {provide: 'eventMessages', useValue: BusinessValidationMessage},
  ]
})
export class SharedModule {
}
