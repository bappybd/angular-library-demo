export interface CommandNotificationModel {
  Details: any | {};

  Success: boolean;
  ActionName: string;
  Message: string;
  Messages: NotificationMessageModel[];
}

export interface NotificationMessageModel {
  MessageCode: number;
  MessageType: NotificationMessageType;
  Message: string;
}

export enum NotificationMessageType
{
  Error,
  Warning,
  Success,
}
