import {ScheduledHourModel, TimeModel} from './scheduled-hour-model';
import {CuratedInfoModel} from '../../app-product/models/product-models';
import {CustomizationTagData} from '../../app-product/const/product-customization.const';

export enum CustomizationType {
  Single = 'Single',
  Multiple = 'Multiple',
}

export enum NumberOfItemType {
  Minimum = 'Minimum',
  Maximum = 'Maximum',
  Exact = 'Exact',
  Range = 'Range'
}

export interface ProductCustomizationItemViewModel {
  _id: string;
  Title: string;
  IsIncluded: boolean;
  Price: number;
  AdditionalPrice: number;
}

export interface ProductCustomizationViewModel {
  _id: string;
  Title: string;
  CustomizationType: CustomizationType;
  CustomizationTag: string;
  IsOptional: boolean;
  NumberOfItemType: NumberOfItemType;
  MaximumSelectable: number;
  MinimumSelectable: number;
  ExactSelectable: number;
  Items: ProductCustomizationItemViewModel[];
}

export interface ProductCustomizationItemModel {
  Id: string;
  Title: string;
  IsIncluded: boolean;
  Price: number;
  AdditionalPrice: number;
}

export interface ProductCustomizationModel {
  Id: string;
  Title: string;
  CustomizationTag: string;
  CustomizationType: CustomizationType;
  IsOptional: boolean;
  NumberOfItemType: NumberOfItemType;
  MaximumSelectable: number;
  MinimumSelectable: number;
  ExactSelectable: number;
  Items: ProductCustomizationItemModel[];
}

export interface ProductCatalogueModel {
  Id: string;
  ShopId: string;
  Name: string;
}

export interface ProductCategoryModel {
  ShopId: string;
  ProductCategoryId: string;
  Name: string;
  Description: string;
  ProductCatalogueId: string;
  CategoryOrderInCatalogue: number;
  IsActive: boolean;
  IsTemporaryUnavailable?: boolean;
  TemporaryUnavailableStartTime?: string;
  TemporaryUnavailableEndTime?: string;
}

export interface ProductModel {
  ShopId: string;
  ProductCatalogueId: string;
  ProductId: string;
  Name: string;
  Description: string;
  Price: number;
  PriceWithSD: number;
  SupplementaryDuty: number;
  PreparationTime: TimeModel;
  ProductCategories: ProductCategoryDto[];
  IsActive: boolean;
  MaximumAddLimit: number;
  IsTempProduct: boolean;
  TempStartDate: string;
  TempEndDate: string;
  Customizations: ProductCustomizationModel[];
  // Vat: number;
  ServiceHours: ScheduledHourModel[];
  IsSameForAllDaysServiceHours: boolean;
  Curations?: CuratedInfoModel[];
  IsTemporaryUnavailable?: boolean;
  TemporaryUnavailableStartTime?: string;
  TemporaryUnavailableEndTime?: string;
}

export interface ProductViewModel {
  ShopId: string;
  ProductCatalogueId: string;
  ProductId: string;
  Name: string;
  Description: string;
  Price: number;
  SupplementaryDuty: number;
  PreparationTime: TimeModel;
  ProductCategories: ProductCategoryDto[];
  IsActive: boolean;
  MaximumAddLimit: number;
  IsTempProduct: boolean;
  TempStartDate: string;
  TempEndDate: string;
  Customizations: ProductCustomizationViewModel[];
  Vat: number;
  ServiceHours: ScheduledHourModel[];
  IsSameForAllDaysServiceHours: boolean;
}

export interface ProductCategoryDto {
  ProductCategoryId: string;
  ProductOrderInProductCategory: number;
}

export interface CustomizationTag {
  name: string;
  value: string;
}
