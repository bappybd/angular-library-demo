import {ScheduledHourModel} from './scheduled-hour-model';
import {EntityBaseModel} from '@eevo/eevo-core';

export class ShopModel extends EntityBaseModel {
  public ShopId: string;

  public Name: string;

  public Description: string;

  public Tags: string[];

  public Cuisines: string[];

  /// <summary>
  /// Comma seperated string
  /// </summary>
  public AlternativeSearchText: string[];

  /// <summary>
  /// Cheap / Expensive / Luxury
  /// </summary>
  public Affordability: ShopAffordabilityEnum;

  public LogoFileId: string;

  public BannerFileId: string;

  public ListImageFileId: string;

  public HighlightedImageFileId: string;

  public EmergencyContactDetails: ContactDetailsModel;

  public FrontendDeskContactDetails: ContactDetailsModel;

  public KeyAccountsManagerContactDetails: ContactDetailsModel;

  public Address: AddressInfoModel;

  public IsSameForAllDaysServiceHours: boolean;

  public ServiceHours: ScheduledHourModel[];

  public AcceptPreOrders: boolean;

  public AllowPreorderEnd: AllowPreorderSpecEnum;

  public AllowPreorderStart: AllowPreorderSpecEnum;

  /// <summary>
  ///  0 - 10 days maximum
  /// </summary>
  public PreOrderMaxRangeDays: number;

  public IsSamePreOrderAsServiceHours: boolean;

  public IsSameForAllDaysPreOrderScheduledHours: boolean;

  public PreOrderScheduledHours: ScheduledHourModel[];

  public Settings: ShopSettingsModel;

  public Curations ?: CurationInfoModel[];

  public UpdatedByExternalUser?: boolean;
}

export class CurationInfoModel {
  Name: string;

  Order: number;
}

// -----------------------------------------------------------------------------------------------------
// @ DTO or models
// -----------------------------------------------------------------------------------------------------

export class AddressInfoModel {
  public Address: string;

  public City: string;

  public PostCode: string;

  public Latitude: number;

  public Longitude: number;

  public Zone: AddressZoneModel;

  public SubZone?: AddressZoneModel;
}

class AddressZoneModel {
  public Id: string;
  public Name: string;
}

export class BankInfoModel {
  public AccountName: string;

  public AccountNumber: string;

  public BankName: string;

  public BranchName: string;

  public RoutingNumber: string;
}

export class PaymentMethodModel {
  public Id: string;
  public Name: string;
}

export class ContactDetailsModel {
  public Name: string;

  public Email: string;

  public PhoneNumber: string;
}

export class ShopSettingsModel {
  /// <summary>
  /// Enum
  /// </summary>
  public ShopStatus: ShopStatusEnum;
  public ShopType: ShopTypeEnum;

/// <summary>
/// 0 - 99
/// </summary>
  public ZoneWiseSortOrder: number;

  public TagLine: string;

  public TagLineStartDate: string;

  public TagLineEndDate: string;

  public IsHomeCook: boolean;

/// <summary>
/// Time In Minutes
/// </summary>
  public MinimumProcessingTime: number;

  public MinimumOrderValue: number;

  public MaximumOrderValue: number;

  public isVatIncluded: boolean;

  public IsVatIncluded: boolean;

  public Vat: number;

  // public ServiceCharge: number;

  public Commission: number;

  public IsDeliveredByShop: boolean;

  public DeliveryFee: number;

  public OrderLimit: number;

  public IncludeTransactionFee: boolean;

/// <summary>
/// if true then give this information
/// </summary>
  public IsCreditShop: boolean;

  public IsPartialCreditShop: boolean;

  public ShopBank: BankInfoModel;

  public IsCompliantShop: boolean;

  public PaymentMethods: PaymentMethodModel[];

  public EnableOrderCreation: boolean;

  public ShopCustomersDeliveryFee: number;

  public ShopOrdersCommission: number;

  public IsTemporaryUnavailable: boolean;

  public TemporaryUnavailableStartTime: Date;

  public TemporaryUnavailableEndTime: Date;
}

// -----------------------------------------------------------------------------------------------------
// @ Enum
// -----------------------------------------------------------------------------------------------------

export enum ShopAffordabilityEnum {
  Affordable = 1,
  Moderate = 2,
  Expensive = 3,
}

export enum ShopStatusEnum {
  Live = 1,
  Unavailable = 2,
  Closed = 3,
  PermanentlyClosed = 4,
  ClosedUntilFurtherNotice = 5
}

export enum ShopTypeEnum {
  Restaurant,
  Grocery,
  Pharmacy,
  HomeCook,
}

export enum AllowPreorderSpecEnum {
  None = -1,
  Today,
  Tomorrow,
  Next3Days
}
