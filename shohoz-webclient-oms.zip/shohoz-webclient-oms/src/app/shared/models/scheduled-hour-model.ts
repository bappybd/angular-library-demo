import {DayOfWeek} from '../enums/day-of-week.enum';

export class ScheduledHourModel {
  public Day: DayOfWeek;
  public OperatingHour: OperatingHourModel[];
}

export class OperatingHourModel {
  constructor() {
    this.OpeningTime = new TimeModel();
    this.ClosingTime = new TimeModel();
  }

  public OpeningTime: TimeModel;
  public ClosingTime: TimeModel;
}

export class TimeModel {
  constructor() {
    this.Hour = 0;
    this.Minute = 0;
    this.TotalMinute = 0;
  }

  public Hour: number;
  public Minute: number;
  public TotalMinute?: number;
}
