export interface CouponLogicModel {
  _id: string;
  Id: string;
  Condition: string;
  Calculation: string;
  Description: string;
  IsFlatDiscount?: boolean;
}

export enum CouponState {
  Draft = 'Draft',
  Inactive = 'Inactive',
  Published = 'Published',
}

export enum CouponEntityType {
  None = 'None',
  Shop = 'Shop',
  ProductCategory = 'ProductCategory',
  Product = 'Product',
  User = 'User',
}

export enum CouponCategory {
  Default = 'default'
}

export interface CouponModel {
  Id: string;
  CouponId: string;
  CouponName: string;
  CouponCode: string;
  Category: string;
  ValidFrom: string;
  ValidTill: string;
  MaximumDiscountAmount: number;
  CouponLogics: CouponLogicModel[];
  Rank: number;
  SupportedCouponIds: string[];
  Description_En: string;
  HighlightText_En: string;
  MaxRedeemCountPerUser: number;
  MaxRedeemCountPerUserPerDay: number;
  MaxRedeemCount: number;
  ShohozPortionOfDiscount: number;
  AutoApplied: boolean;
  IsProductCoupon: boolean;
  IsGlobalCoupon: boolean;
  IsFlatDiscount: boolean;
  CouponState: CouponState;
  CityIds: string;
  PaymentMethodIds: string[];
  DiscountPartnerIds: string[];
}

export class PaymentMethodModel {
  public Id: string;
  public Name: string;
}
