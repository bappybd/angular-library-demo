import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AppReportRoutingModule} from './app-report-routing.module';
import {ReportComponent} from './container/report/report.component';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatTabsModule} from '@angular/material/tabs';
import {FuseSharedModule, FuseSidebarModule, FuseWidgetModule} from '@eevo/eevo-base';
import {MatDividerModule} from '@angular/material/divider';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatMenuModule} from '@angular/material/menu';
import {MatSelectModule} from '@angular/material/select';
import {MatTableModule} from '@angular/material/table';
import {NgxChartsModule} from '@swimlane/ngx-charts';
import {EevoPipeModule} from '@eevo/eevo-core';
import {EevoPlatformFeatureGuardModule} from '@eevo/eevo-platform-feature-guard';

@NgModule({
  declarations: [ReportComponent],
  imports: [
    CommonModule,
    AppReportRoutingModule,
    MatButtonModule,
    MatDividerModule,
    MatFormFieldModule,
    MatIconModule,
    MatMenuModule,
    MatSelectModule,
    MatTableModule,
    MatTabsModule,
    NgxChartsModule,
    FuseSharedModule,
    FuseSidebarModule,
    FuseWidgetModule,
    EevoPipeModule,
    EevoPlatformFeatureGuardModule
  ]
})
export class AppReportModule { }
