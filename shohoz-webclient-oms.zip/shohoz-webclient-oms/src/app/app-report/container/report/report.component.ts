import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {fuseAnimations} from '@eevo/eevo-base';
import {ReportDownloadService} from '../../services/report-download.service';

interface ButtonSettings {
  visibility: boolean;
  action: any;
}

interface FuseWidgetBoxDataModel {
  title: string;
  description?: string;
  icon: any;
  viewFunctionSettings: ButtonSettings;
  downloadFunctionSettings: ButtonSettings;
}

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss'],
  animations: fuseAnimations
})
export class ReportComponent implements OnInit {

  @Output() loading: EventEmitter<boolean> = new EventEmitter<boolean>();
  fuseWidgetBoxData: FuseWidgetBoxDataModel[] = [];

  constructor(private reportDownloadService: ReportDownloadService) {
  }

  ngOnInit(): void {
    this.createWidgetBoxDataOnNewSummaryData();
  }

  private createWidgetBoxDataOnNewSummaryData(): void {
    this.fuseWidgetBoxData = [
      {
        title: 'Restaurant Order Report',
        icon: 'summarize',
        description: '',
        viewFunctionSettings: {
          visibility: false,
          action: () => {
            console.log('Dummy View Data');
          }
        },
        downloadFunctionSettings: {
          visibility: true,
          action: () => {
            window.open(this.reportDownloadService.getRestaurantOrderReportUrl(), '_blank');
          }
        }
      },
    ];
    this.loading.emit(false);
  }
}
