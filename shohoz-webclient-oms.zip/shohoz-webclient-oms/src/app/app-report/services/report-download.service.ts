import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {TokenManagerService, UtilityService} from '@eevo/eevo-core';

@Injectable({
  providedIn: 'root'
})
export class ReportDownloadService {
  constructor(
    private http: HttpClient,
    private tokenManagerService: TokenManagerService,
    private utility: UtilityService,
    @Inject('config') private config: any
  ) {
  }

  getRestaurantOrderReportUrl(): string {
    const url = `${this.config['ReportingService']}/Report.aspx`;
    const correlationId = this.utility.getNewGuid();
    const download = true;
    const exportFormat = 'CharacterSeparatedValues';
    const reportId = '8250d437-b72c-4847-ba11-beb24f720c99';
    const parameters = '';
    const token = this.tokenManagerService.getAccessToken();

    return `${url}?CorrelationId=${correlationId}&Download=${download}&ExportFormat=${exportFormat}&Id=${reportId}&Parameters=${parameters}&token=${token}`;
  }
}
