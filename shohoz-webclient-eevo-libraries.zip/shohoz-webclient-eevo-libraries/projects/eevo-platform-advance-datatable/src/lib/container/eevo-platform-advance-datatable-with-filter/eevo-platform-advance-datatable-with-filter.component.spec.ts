import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformAdvanceDatatableWithFilterComponent } from './eevo-platform-advance-datatable-with-filter.component';

describe('EevoPlatformAdvanceDatatableComponent', () => {
  let component: EevoPlatformAdvanceDatatableWithFilterComponent;
  let fixture: ComponentFixture<EevoPlatformAdvanceDatatableWithFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformAdvanceDatatableWithFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformAdvanceDatatableWithFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
