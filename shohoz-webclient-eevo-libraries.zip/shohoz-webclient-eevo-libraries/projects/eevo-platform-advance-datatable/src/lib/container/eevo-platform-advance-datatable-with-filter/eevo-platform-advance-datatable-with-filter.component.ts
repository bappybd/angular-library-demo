import {
  ChangeDetectorRef,
  Component,
  EventEmitter, Input, OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import {BreadcrumbModel} from '@eevo/eevo-platform-breadcrumb';
import {fuseAnimations} from '@eevo/eevo-base';
import {
  EevoAdvanceDatatableOptions
} from "../../models/datatable.db.models";
import {Subject, Subscription} from "rxjs";
import {FinalFilterQueryEvent} from "../../models/datatable.event.models";

@Component({
  selector: 'eevo-platform-advance-datatable-with-filter',
  templateUrl: './eevo-platform-advance-datatable-with-filter.component.html',
  styleUrls: ['./eevo-platform-advance-datatable-with-filter.component.scss'],
  animations: fuseAnimations,
})
export class EevoPlatformAdvanceDatatableWithFilterComponent implements OnInit, OnDestroy {
  @Input() isMock: boolean;
  @Input() logicExecutorService: any;
  @Input() customFilterQuery: string;
  @Input() enableTabChangeValidation: boolean = false;
  @Input() options: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  @Input() selectTabIndex: Subject<number> = new Subject<number>();
  @Input() changeTableCurrentPage: Subject<number> = new Subject<number>();

  @Output() hasTabChangeAccess: EventEmitter<any> = new EventEmitter<any>();
  @Output() onTabChanged: EventEmitter<any> = new EventEmitter();
  @Output() onSidebarAction: EventEmitter<any> = new EventEmitter();
  @Output() onFinalFilterQuery: EventEmitter<FinalFilterQueryEvent> = new EventEmitter<FinalFilterQueryEvent>();
  @Output() initializeCompleted: EventEmitter<any> = new EventEmitter();
  @Output() listCurrentPage = new EventEmitter<number>();

  queryFilters: Subject<any> = new Subject<any>();
  searchOptions: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  tableConfigOptions: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  datatableConfigOptions: EevoAdvanceDatatableOptions = new EevoAdvanceDatatableOptions();

  loadingFromServer: boolean = false;
  breadcrumbList: BreadcrumbModel[] = [];
  subscriptions: Subscription[] = [];

  constructor(
    public cd: ChangeDetectorRef
  ) {
  }

  ngOnInit(): void {
    const subscription = this.options.subscribe(options => {
      this.datatableConfigOptions.NavId = options.NavId;
      this.datatableConfigOptions.TableConfigId = options.TableConfigId;
      this.datatableConfigOptions.TabIndex = options.TabIndex;
      this.datatableConfigOptions.InitialFilters = options.InitialFilters;
      this.datatableConfigOptions.ApplySearchFilterToAllTab = options.ApplySearchFilterToAllTab;
      this.datatableConfigOptions.InitialPageNumber = options.InitialPageNumber;
      this.searchOptions.next(options);
    });

    this.subscriptions.push(subscription);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  searchFilterOnSubmit($event): void {
    this.queryFilters.next($event);
  }

  filterInitializeCompleted($event): void {
    this.datatableConfigOptions.InitialFilters = $event;
    this.tableConfigOptions.next(this.datatableConfigOptions);
  }

  sideBarAction($event): void {
    this.onSidebarAction.emit($event);
  }

  finalFilterQuery($event: FinalFilterQueryEvent) {
    this.onFinalFilterQuery.emit($event);
  }

  canTabChangeAccess($event: any) {
    this.hasTabChangeAccess.emit($event);
  }

  tabChanged($event: any) {
    this.onTabChanged.emit($event);
  }
}
