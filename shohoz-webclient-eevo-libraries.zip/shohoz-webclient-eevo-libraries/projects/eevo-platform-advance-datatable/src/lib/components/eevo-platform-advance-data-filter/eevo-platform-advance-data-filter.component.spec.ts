import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformAdvanceDataFilterComponent } from './eevo-platform-advance-data-filter.component';

describe('DataListFilterComponent', () => {
  let component: EevoPlatformAdvanceDataFilterComponent;
  let fixture: ComponentFixture<EevoPlatformAdvanceDataFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformAdvanceDataFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformAdvanceDataFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
