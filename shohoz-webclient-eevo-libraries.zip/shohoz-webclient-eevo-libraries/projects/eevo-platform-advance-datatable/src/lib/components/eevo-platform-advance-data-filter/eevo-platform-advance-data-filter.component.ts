import {Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from "@angular/forms";
import * as moment from 'moment';
import * as cloneDeep from 'lodash/cloneDeep';
import {EevoAdvanceDatatableOptions, SearchFilterConfigDto} from '../../models/datatable.db.models';
import {Subject, Subscription} from 'rxjs';
import {DatatableSettingService} from '../../services/datatable.setting.service';
import {AppNavigation} from '@eevo/eevo-core';
import {SearchFilterMetaData} from '../../models/datatable.models';
import {NgxMatDatetimePicker} from '@angular-material-components/datetime-picker';

@Component({
  selector: 'eevo-platform-advance-data-filter',
  templateUrl: './eevo-platform-advance-data-filter.component.html',
  styleUrls: ['./eevo-platform-advance-data-filter.component.scss'],
})
export class EevoPlatformAdvanceDataFilterComponent implements OnInit, OnDestroy {
  date: moment.Moment;
  filterForm: FormGroup;

  @ViewChild('datepicker') datepicker: any;

  @Output() searchFilterOnChange: EventEmitter<any> = new EventEmitter();
  @Output() initializeCompleted: EventEmitter<any> = new EventEmitter();

  @Input()
  options: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();

  minDate;
  maxDate;
  touchUi;
  tableConfigId: string;
  appNavigationId: string;
  searchFilterConfig: SearchFilterConfigDto[];
  loadingFromServer: boolean = false;
  appAppNavigationDetails: AppNavigation;
  subscriptions: Subscription[] = [];
  private showSearchContainer: boolean;

  constructor(
    private formBuilder: FormBuilder,
    private datatableSettingService: DatatableSettingService
  ) {
  }

  ngOnInit(): void {

    const subscription = this.options.subscribe(options => {
      // console.log('data - filter', options);
      this.loadingFromServer = true;

      if (options.NavId && options.NavId !== '') {
        this.appNavigationId = options.NavId;
      }
      if (options.TableConfigId && options.TableConfigId !== '') {
        this.tableConfigId = options.TableConfigId;
      }

      this.loadConfiguration();
    });

    this.subscriptions.push(subscription);
  }

  ngOnDestroy(): void {
    this.filterForm = null;
    this.searchFilterConfig = [];
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  search(): void {
    this.showSearchContainer = false;
    const form = Object.assign({}, this.filterForm);
    const formData = form.value;
    this.searchFilterOnChange.emit(this.getSearchFilterObj(formData));
  }

  reset(): void {
    this.showSearchContainer = false;
    this.filterForm = cloneDeep(this.toFormGroup(this.searchFilterConfig));
    const form = Object.assign({}, this.filterForm);
    const formData = form.value;
    this.searchFilterOnChange.emit(this.getSearchFilterObj(formData));
  }

  selectAndOpenDatetimePicker(datepicker: NgxMatDatetimePicker<any>, groupName: string, fieldName: string): void {
    const dateTime = this.filterForm.get(groupName).get(fieldName).value;
    // datepicker.select(moment(dateTime));
    datepicker._selected = moment(dateTime);
    datepicker.open();
  }

  toggleAdvancedSearch(): void {
    this.showSearchContainer = !this.showSearchContainer;
  }

  // load configuration
  private loadConfiguration(): void {
    if (this.appNavigationId && this.appNavigationId != '') {
      const subscription = this.datatableSettingService
        .getAppNavigationDetails(this.appNavigationId).subscribe(appNavigarion => {
          this.appAppNavigationDetails = appNavigarion;
          this.loadSearchConfiguration();
        });
      this.subscriptions.push(subscription);
    } else if (this.tableConfigId && this.tableConfigId != '') {
      const subscription = this.datatableSettingService
        .getSearchFilterConfigListByTableConfigId(this.tableConfigId).subscribe(settings => {
          this.loadingFromServer = false;
          this.initFilterForm(settings);
        });
      this.subscriptions.push(subscription);
    } else {
      this.initializeCompleted.emit([]);
    }

  }

  private loadSearchConfiguration(): void {
    const subscription = this.datatableSettingService
      .getSearchFilterConfigListByNavId(this.appNavigationId).subscribe(settings => {
        this.loadingFromServer = false;
        this.initFilterForm(settings);
      });
    this.subscriptions.push(subscription);
  }

  // filter form config
  private initFilterForm(settings: SearchFilterConfigDto[]): void {
    this.searchFilterConfig = settings;
    this.filterForm = this.toFormGroup(this.searchFilterConfig);
    const form = Object.assign({}, this.filterForm);
    const formData = form.value;
    this.initializeCompleted.emit(this.getSearchFilterObj(formData));
  }

  private toFormGroup(searchFilterConfig: SearchFilterConfigDto[]): FormGroup {
    const group: any = {};
    searchFilterConfig.forEach(filter => {
      switch (filter.Type) {
        case 'dropdownWithInput':
          const value = (filter?.Values.length > 0) ? filter.Values[0]?.Key : '';
          group[filter.FormFieldName] = new FormControl(value);
          group[filter.FormFieldName + 'Input'] = new FormControl('');
          break;
        case 'dateTimeRange':
          group[filter.FormFieldName] = this.getDateTimeFormGroup(filter);
          break;
        case 'dropdown':
        case 'dropdownMulti':
          group[filter.FormFieldName] = new FormControl('');
          const selectedValues = filter.Values.filter(v => v.Selected).map(v => v.Key);
          if (selectedValues.length > 0) {
            group[filter.FormFieldName].setValue(
              filter.Type === 'dropdown' ? selectedValues[0] : selectedValues
            );
          }
          break;
        default:
          group[filter.FormFieldName] = new FormControl('');
          break;
      }
    });
    return new FormGroup(group);
  }

  private getDateTimeFormGroup(filter: SearchFilterConfigDto): FormGroup {
    const fromDateTime = new Date();
    fromDateTime.setHours(0);
    fromDateTime.setMinutes(0);
    fromDateTime.setSeconds(0);

    const toDateTime = new Date();
    toDateTime.setHours(23);
    toDateTime.setMinutes(59);
    toDateTime.setSeconds(59);

    if (filter.MetaData) {
      const metaData = filter.MetaData.find(md => {
        return !!(md[SearchFilterMetaData.DateTimeRangeInDay]);
      });

      if (metaData) {
        const dateTimeRangeInDay = Number(metaData[SearchFilterMetaData.DateTimeRangeInDay]);
        if (dateTimeRangeInDay > 1) {
          const totalOneDayInMillisecond = (1000 * 60 * 60 * 24);
          const startDateTime = fromDateTime.getTime() - (dateTimeRangeInDay * totalOneDayInMillisecond)
          fromDateTime.setTime(startDateTime);
        }
      }

      const metaMinDate = filter.MetaData.find(md => {
        return !!(md[SearchFilterMetaData.MinDateTimeInDay]);
      });

      if (metaMinDate) {
        const minDateTimeInDay = Number(metaMinDate[SearchFilterMetaData.MinDateTimeInDay]);
        const totalOneDayInMillisecond = (1000 * 60 * 60 * 24);
        const minDate = new Date().getTime() - (minDateTimeInDay * totalOneDayInMillisecond);
        this.minDate = new Date(minDate);
      }

      const metaTouchUi = filter.MetaData.find(md => {
        return !!(md[SearchFilterMetaData.IsDialogDateTimePicker]);
      });

      if (metaTouchUi) {
        this.touchUi = Boolean(metaTouchUi[SearchFilterMetaData.IsDialogDateTimePicker]);
      }
    }

    return new FormGroup({
      From: new FormControl(fromDateTime),
      To: new FormControl(toDateTime)
    });
  }

  private getSearchFilterObj(formData: any): any[] {
    let result = [];
    const formKeys = Object.keys(formData);
    formKeys.forEach(key => {
      const config = this.getConfig(key);
      if (!config || formData[key] === '') return;
      if (typeof formData[key] === 'object') {
        if (config.Type == 'dateTimeRange' && (formData[key]['From'] !== '' || formData[key]['To'] !== '')) {
          result.push({
            key: config.FilterKey,
            type: config.Type,
            values: {
              start: (formData[key]['From'] !== '') ? formData[key]['From'].toISOString() : '',
              end: (formData[key]['To'] !== '') ? formData[key]['To'].toISOString() : ''
            }
          });
        }
        else {
          result.push({
            type: config.Type,
            key: config.FilterKey,
            value: formData[key]
          });
        }
      } else {
        if (config.Type === 'dropdownWithInput') {
          if (formData[key + 'Input'] && formData[key + 'Input'] != '') {
            result.push({
              type: config.Type,
              key: formData[key],
              value: formData[key + 'Input']
            });
          }
        } else {
          result.push({
            type: config.Type,
            key: config.FilterKey,
            value: formData[key]
          });
        }
      }
    });
    return result;
  }

  private getConfig(formFieldName: string): any {
    return this.searchFilterConfig.find(config => config.FormFieldName === formFieldName);
  }

  // fromDateChanged(FormFieldName: string, toUpdateFormField: string = 'To'): void {
  //   const fromDatevalue = this.filterForm.get(FormFieldName).get('From').value;
  //   const toDatevalue = this.filterForm.get(FormFieldName).get('To').value;
  //   if (new Date(fromDatevalue).getTime() > new Date(toDatevalue).getTime()) {
  //     this.filterForm.get(FormFieldName).get('To').setValue(fromDatevalue);
  //   }
  // }

  dateChanged(formFieldName: string, selectedFormFieldName: string = 'From', toUpdateFormFieldName: string = 'To'): void {
    const selectedDateValue = this.filterForm.get(formFieldName).get(selectedFormFieldName).value;
    const toUpdateDateValue = this.filterForm.get(formFieldName).get(toUpdateFormFieldName).value;
    const day = 24 * 60 * 60 * 1000;
    const selectedDateTimeValue = new Date(selectedDateValue).getTime();

    const finalDate = (selectedFormFieldName === 'To') ?
      new Date(selectedDateTimeValue - day) :
      new Date(selectedDateTimeValue + day);

    if (selectedFormFieldName === 'To') {
      finalDate.setHours(0);
      finalDate.setMinutes(0);
      finalDate.setSeconds(0);
      if (new Date(selectedDateValue).getTime() < new Date(toUpdateDateValue).getTime()) {
        this.filterForm.get(formFieldName).get(toUpdateFormFieldName).setValue(finalDate);
      }
    } else {
      finalDate.setHours(23);
      finalDate.setMinutes(59);
      finalDate.setSeconds(59);
      if (new Date(selectedDateValue).getTime() > new Date(toUpdateDateValue).getTime()) {
        this.filterForm.get(formFieldName).get(toUpdateFormFieldName).setValue(finalDate);
      }
    }
  }
}
