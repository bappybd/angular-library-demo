import {
  ChangeDetectorRef,
  Component,
  EventEmitter, Input, OnDestroy,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {fuseAnimations} from '@eevo/eevo-base';
import {ColumnMode, DataListConfigModel, FilterFromEnum} from '../../models/datatable.models';
import {Router} from '@angular/router';
import {
  DataTable_BucketList,
} from '../../mock-data/demo-data-config';
import {DatatableSettingService} from '../../services/datatable.setting.service';
import {
  DataTableConfigDto, DataTableViewDto, EevoAdvanceDatatableOptions,
  GenericDataTableConfigDto, GenericDataTableTabConfigDto,
  KeyValue, LogicMetaData,
} from '../../models/datatable.db.models';
import {Subject, Subscription} from 'rxjs';
import {DatatableHelperService} from '../../services/datatable.helper.service';
import * as memoizee from 'memoizee';
import {AppNavigation} from '@eevo/eevo-core';
import * as cloneDeep from 'lodash/cloneDeep';
import {FinalFilterQueryEvent} from '../../models/datatable.event.models';
import {take} from "rxjs/operators";

export function memoize() {
  const mem = function (target, key, descriptor) {
    const oldFunction = descriptor.value;
    const newFunction = memoizee(oldFunction, {maxAge: 5000});
    descriptor.value = function () {
      return newFunction.apply(this, arguments);
    };
  };

  return mem;
}

interface TabTotalRecordsDataModel {
  count: number;
  visited: boolean;
}

interface TabTotalRecordsModel {
  [id: string]: TabTotalRecordsDataModel;
}

@Component({
  selector: 'eevo-platform-advance-datatable',
  templateUrl: './eevo-platform-advance-datatable.component.html',
  styleUrls: ['./eevo-platform-advance-datatable.component.scss'],
  animations: fuseAnimations,
  encapsulation: ViewEncapsulation.None
})
export class EevoPlatformAdvanceDatatableComponent implements OnInit, OnDestroy {
  // @Input()
  isMock: boolean = false;

  @Input() logicExecutorService: any;
  @Input() customFilterQuery: string;
  @Input() enableTabChangeValidation: boolean = false;
  @Input() options: Subject<EevoAdvanceDatatableOptions> = new Subject<EevoAdvanceDatatableOptions>();
  @Input() queryFilters: Subject<any> = new Subject<any>();
  @Input() selectTabIndex: Subject<number> = new Subject<number>();
  @Input() changeTableCurrentPage: Subject<number> = new Subject<number>();

  @Output() hasTabChangeAccess: EventEmitter<any> = new EventEmitter<any>();
  @Output() onTabChanged: EventEmitter<any> = new EventEmitter();
  @Output() onSidebarAction: EventEmitter<any> = new EventEmitter();
  @Output() onFinalFilterQuery: EventEmitter<FinalFilterQueryEvent> = new EventEmitter<FinalFilterQueryEvent>();
  @Output() initializeCompleted: EventEmitter<any> = new EventEmitter();
  @Output() listCurrentPage = new EventEmitter<number>();

  @ViewChild('genericCellTemplate', {static: true}) genericCellTemplate: TemplateRef<any>;

  tableConfigId: string;
  appNavigationId: string;
  selectedIndex: number = 0;
  initialSelectedTabIndex = 0;
  loadingFromServer: boolean = false;
  applySearchFilterToAllTab = false;
  appAppNavigationDetails: AppNavigation;
  dataTableConfig: DataTableViewDto;
  cacheDataTableConfig: DataTableViewDto;
  initialFilters: string[];
  searchFilters: string[] = [];
  searchFilter = new Subject<any>();
  subscriptions: Subscription[] = [];
  viewedTabTotalRecords: TabTotalRecordsModel;
  ManualReloadWithTabHighlight = false;
  resetTabCount = true;
  notificationCountEnabled = true;
  initialPageNumber: number;

  constructor(
    private router: Router,
    public cd: ChangeDetectorRef,
    private dhs: DatatableHelperService,
    private datatableSettingService: DatatableSettingService,
    private datatableHelperService: DatatableHelperService
  ) {
  }

  ngOnInit(): void {
    const optionsSubscription = this.options.subscribe((data: EevoAdvanceDatatableOptions) => {
      this.initialPageNumber = data.InitialPageNumber || 0;
      let reloadConfiguration: boolean = false;
      if (this.appNavigationId !== data.NavId) {
        reloadConfiguration = true;
      } else if (this.tableConfigId !== data.TableConfigId) {
        reloadConfiguration = true;
      }

      if (data.NavId && data.NavId !== '') {
        this.appNavigationId = data.NavId;
      }
      if (data.TableConfigId && data.TableConfigId !== '') {
        this.tableConfigId = data.TableConfigId;
      }
      const initialFilters = data?.InitialFilters;
      if (initialFilters) {
        this.initialFilters = initialFilters;
        this.searchFilters = initialFilters;
      }
      if (data.TabIndex > -1) {
        this.selectedIndex = data.TabIndex;
        this.onTabChanged.emit({
          currentIndex: this.selectedIndex,
          currentTabConfig: this.dataTableConfig?.BucketConfigs[this.selectedIndex],
        });
      }
      this.applySearchFilterToAllTab = data.ApplySearchFilterToAllTab;

      if (reloadConfiguration || !this.dataTableConfig) {
        this.loadingFromServer = true;
        this.dataTableConfig = new DataTableViewDto();
        this.loadConfiguration();
      } else if (!this.applySearchFilterToAllTab) {
        this.dataTableConfig = cloneDeep(this.cacheDataTableConfig);
        this.loadDataCountOfTab(this.initialFilters);
      } else if (this.selectedIndex === data.TabIndex && this.dataTableConfig.BucketConfigs[data.TabIndex]) {
        this.dataTableConfig.BucketConfigs[data.TabIndex].DataTableConfig =
          {
            ...this.dataTableConfig.BucketConfigs[data.TabIndex].DataTableConfig,
            CurrentPageNumber: data.InitialPageNumber || 0
          };
      }
    });

    const queryFiltersSubscription = this.queryFilters.subscribe(queries => {
      this.searchFilters = queries;
      this.searchFilter.next(queries);
      this.resetTabCount = true;
      this.loadDataCountOfTab(queries);
    });

    if (this.enableTabChangeValidation) {
      const selectTabIndexSubscription = this.selectTabIndex.subscribe((index: number) => {
        this.tabChangeIndex(index);
      });

      this.subscriptions.push(selectTabIndexSubscription);
    }

    this.subscribeDataTableReloadEvent();

    this.subscriptions.push(optionsSubscription);
    this.subscriptions.push(queryFiltersSubscription);
  }

  ngOnDestroy(): void {
    // if (memoizee) {
    //   memoizee.clear();
    // }
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  changeIndex(index): void {
    this.resetTablePageNumber();
    if (this.enableTabChangeValidation) {
      this.hasTabChangeAccess.emit({
        currentIndex: this.selectedIndex,
        selectedIndex: index,
        tabConfigs: this.dataTableConfig?.BucketConfigs
      });
    } else {
      this.tabChangeIndex(index);
    }

  }

  private resetTablePageNumber(): void {
    this.initialPageNumber = 0;

    if (this.dataTableConfig?.BucketConfigs) {
      this.dataTableConfig?.BucketConfigs.forEach((config, index) => {
        this.dataTableConfig.BucketConfigs[index].DataTableConfig.CurrentPageNumber = 0;
      });
    }

    // if (this.dataTableConfig?.BucketConfigs[this.initialSelectedTabIndex] &&
    //   this.dataTableConfig.BucketConfigs[this.initialSelectedTabIndex].DataTableConfig) {
    //   this.dataTableConfig.BucketConfigs[this.initialSelectedTabIndex].DataTableConfig.CurrentPageNumber = 0;
    // }
  }

  finalFilterQuery($event: FinalFilterQueryEvent): void {
    this.onFinalFilterQuery.emit($event);
    this.setViewedTabTotalRecordsOnTableLoad();
  }

  @memoize()
  getRowData(row, keys, defaultValue?: string): string {
    if (!keys) {
      return null;
    }

    let keyNotFound = false;
    let keyList = keys.split('.');

    keyList.forEach(key => {
      if (!keyNotFound && row[key] !== undefined && row[key] !== null) {
        row = row[key];
      } else {
        keyNotFound = true;
      }
    });

    if (keyNotFound) {
      if (defaultValue !== undefined && defaultValue !== '') {
        return defaultValue;
      }
      return null;
    }

    return row;
  }

  @memoize()
  logicExecutor(data, expression, log?: boolean): any {
    if (log) {
      console.log(expression);
    }

    if (expression && expression !== '') {
      const les = this.logicExecutorService;

      if (expression.indexOf('les.') > -1 && !les) {
        console.warn('Logic Executor Service Missing!!!');
        return null;
      } else if (les && expression.indexOf('les.') > -1 && expression.indexOf('dhs.') > -1) {
        const result = new Function('row', 'dhs', 'les', expression);

        return result(data, this.dhs, les);
      } else if (expression.indexOf('les.') > -1) {
        const result = new Function('data', 'les', expression);

        return result(data, les);
      } else if (expression.indexOf('dhs.') > -1) {
        const result = new Function('data', 'dhs', expression);

        return result(data, this.dhs);
      } else {
        const result = new Function('data', expression);

        return result(data);
      }
    }

    return true;
  }

  @memoize()
  hasAnchorLink(action): boolean {
    if (action) {
      return true;
    }
    return false;
  }

  actionLogic(row, action, column): void {
    if (action && action.IsSidebarAction && action.SidebarName) {

      this.onSidebarAction.emit({
        RowData: row,
        Action: action
      });

    } else if (action && !action.IsInternalLink && action.Path && action.Path !== '') {

      console.warn('is not internal link, no further action implemented', action.Path);

    } else if (action && action.IsInternalLink && action.Uris && action.Uris.length > 0) {
      const commands = [];

      action.Uris.forEach(uri => {
        if (uri.DataColumn && uri.DataColumn !== '') {
          const u = this.getRowData(row, uri.DataColumn);
          if (u) {
            commands.push(u);
          } else if (column) {
            const r = this.getRowData(column, uri.DataColumn);
            if (r) {
              commands.push(r);
            }
          }
        } else if (uri.Expression && uri.Expression !== '') {
          const uris = this.logicExecutor({row, column}, uri.Expression);

          if (uris && Array.isArray(uris) && uris.length > 0) {
            uris.forEach((u) => {
              commands.push(u);
            });
          } else {
            commands.push(uris);
          }
        } else if (uri.Uri) {
          commands.push(uri.Uri);
        }
      });

      if (commands.length > 0) {
        this.router.navigate(commands);
      }
    } else {
      if (action) {
        console.warn(action);
      }
    }
  }

  private loadConfiguration(): void {
    if (this.appNavigationId && this.appNavigationId !== '') {

      const subscription = this.datatableSettingService
        .getAppNavigationDetails(this.appNavigationId)
        .subscribe(appNavigarion => {
          this.appAppNavigationDetails = appNavigarion;
          this.loadTableConfigurationWithTab();
        }, error => {
          this.initializeDone();
        });
      this.subscriptions.push(subscription);

    } else if (this.tableConfigId && this.tableConfigId !== '') {

      const subscription = this.datatableSettingService
        .getDataTableConfigsByTableConfigId(this.tableConfigId)
        .subscribe((config: DataTableConfigDto) => {
          const dataTableConfig = this.getDataTableViewModel(config);
          this.initializeDone(dataTableConfig);
        }, error => {
          this.initializeDone();
        });

      this.subscriptions.push(subscription);
    }
  }

  private loadTableConfigurationWithTab(): void {
    if (this.isMock) {
      const bucketConfigs = DataTable_BucketList;
      const config: DataTableViewDto = {
        BucketEnable: true,
        BucketConfigs: bucketConfigs,
        Configs: null
      };
      const dataTableConfig = this.getDataTableViewModel(config);
      this.initializeDone(dataTableConfig);
    } else {
      const subscription = this.datatableSettingService
        .getDataTableConfigsByNavId(this.appNavigationId).subscribe((config: DataTableConfigDto) => {
          const dataTableConfig = this.getDataTableViewModel(config);
          this.initializeDone(dataTableConfig);
          this.loadDataCountOfTab();
        }, error => {
          this.initializeDone();
        });

      this.subscriptions.push(subscription);
    }
  }

  private loadDataCountOfTab(filters?: any[]): void {
    if (filters && this.applySearchFilterToAllTab) {
      this.dataTableConfig?.BucketConfigs?.forEach(config => {
        if (config.DataTableConfig) {
          const queryFilter = this.datatableSettingService.getSearchQueryFilter(filters);

          if (queryFilter) {
            config.DataTableConfig = this.datatableSettingService.getConfigModelWithOtherFilters(
              filters, config.DataTableConfig
            );
          }
        }
      });
    }
    this.datatableSettingService
      .getDataCountOfTab(this.dataTableConfig)
      .pipe(take(1))
      .subscribe(response => {
      this.setViewedTabTotalRecords();
    });
  }

  private setViewedTabTotalRecords(): void {
    if (!this.viewedTabTotalRecords) {
      this.viewedTabTotalRecords = {};
    }
    this.dataTableConfig.BucketConfigs.forEach((bc, idx) => {
      if (!this.viewedTabTotalRecords.hasOwnProperty(bc.Id) || this.resetTabCount) {
        this.viewedTabTotalRecords[bc.Id] = {count: bc?.TotalRecord || 0, visited: true};
      }
      if (this.viewedTabTotalRecords[bc.Id]?.count !== bc.TotalRecord) {
        this.viewedTabTotalRecords[bc.Id].visited = false;
      }
    });
    this.resetTabCount = false;
  }

  private setViewedTabTotalRecordsOnTableLoad(): void {
    if (!this.viewedTabTotalRecords) {
      this.viewedTabTotalRecords = {};
    }
    const bc = this.dataTableConfig.BucketConfigs[this.selectedIndex];
    if (bc) {
      this.viewedTabTotalRecords[bc.Id] = {count: bc?.TotalRecord || 0, visited: true};
    }
  }

  private getDataTableViewModel(config: DataTableConfigDto): DataTableViewDto {
    const dataTableViewDto = new DataTableViewDto();
    dataTableViewDto.BucketEnable = config.BucketEnable;
    if (config.Configs) {
      dataTableViewDto.Configs = this.getDataTableConfig(config.Configs);
      dataTableViewDto.Configs.CurrentPageNumber = this.initialPageNumber || 0;
    }

    if (config.BucketConfigs) {
      dataTableViewDto.BucketConfigs = config.BucketConfigs.map((bucket: GenericDataTableTabConfigDto, index) => {
        const bucketConfig: any = bucket;
        bucketConfig.DataTableConfig = this.getDataTableConfig(bucket.DataTableConfig, bucket);
        if (index === this.selectedIndex) {
          this.initialSelectedTabIndex = index;
          bucketConfig.DataTableConfig.CurrentPageNumber = this.initialPageNumber;
        }
        return bucketConfig;
      });
    }
    return dataTableViewDto;
  }

  private getDataTableConfig(config: GenericDataTableConfigDto, bucketInfo?: GenericDataTableTabConfigDto): DataListConfigModel {
    const dataListConfigModel = new DataListConfigModel();
    if (config) {
      let columnList = config.Columns.map((cloumn) => {
        cloumn['flexGrow'] = 1;
        cloumn['cellTemplate'] = this.genericCellTemplate;

        if (!this.isMock) {
          cloumn['prop'] = cloumn.Prop;
          cloumn['name'] = cloumn.Name;
          cloumn['sortable'] = cloumn.Sortable;
          cloumn['maxWidth'] = cloumn.MaxWidth || null;
          cloumn['minWidth'] = cloumn.MinWidth || null;
          if (cloumn.ColumnSize) {
            cloumn['flexGrow'] = cloumn.ColumnSize;
          }
        }
        if (this.appAppNavigationDetails) {
          cloumn['AppNavigation'] = this.appAppNavigationDetails;
        }

        return cloumn;
      });

      columnList = columnList.filter(c => {
        return this.logicExecutor({}, c.Expression);
      });

      dataListConfigModel.Columns = columnList;
      dataListConfigModel.DataSourceUrl = config.DataSourceUrl;
      dataListConfigModel.EntityName = config.EntityName;
      dataListConfigModel.EntityColumns = config.EntityColumns;
      dataListConfigModel.EntityFilter = config.EntityFilter;
      dataListConfigModel.PageSize = config.PageSize;
      dataListConfigModel.CurrentPageNumber = config.CurrentPageNumber;
      dataListConfigModel.OrderBy = config.OrderBy;
      dataListConfigModel.ColumnMode = ColumnMode.force;
      if (config.ColumnMode) {
        dataListConfigModel.ColumnMode = ColumnMode[config.ColumnMode];
      }
      if (config.Messages) {
        dataListConfigModel.messages = config.Messages;
      }
      this.ManualReloadWithTabHighlight = !!this.appAppNavigationDetails?.MetaData?.find(m => m?.Type === "ADVANCED_DATATABLE_CONFIG")?.ManualReloadWithTabHighlight;
      dataListConfigModel.ManualReload = this.ManualReloadWithTabHighlight;

      // dataListConfigModel.SelectionType = config.ColumnMode;
      // dataListConfigModel.rowClass = config.rowClass;
      // dataListConfigModel.messages = config.messages;
    }

    if (bucketInfo && bucketInfo.Filter) {
      const bucketInfoFilter = this.getQueryFiler(bucketInfo.MetaData, bucketInfo.Filter)();
      const isRerender = this.executeAlwaysEnable(bucketInfo.MetaData);
      dataListConfigModel.OtherFilters.push({
        FilterFrom: FilterFromEnum.TabSection,
        FilterString: bucketInfoFilter,
        ExecuteAlwaysFilterString: isRerender ? this.getQueryFiler(bucketInfo.MetaData, bucketInfo.Filter).bind(this) : null
      });
    }

    if (this.appAppNavigationDetails) {
      const navigationFilter = this.getQueryFiler(this.appAppNavigationDetails.MetaData, this.appAppNavigationDetails.QueryFilter)();
      const isRerender = this.executeAlwaysEnable(this.appAppNavigationDetails.MetaData);
      dataListConfigModel.OtherFilters.push({
        FilterFrom: FilterFromEnum.AppNavigation,
        FilterString: navigationFilter,
        ExecuteAlwaysFilterString: isRerender ? this.getQueryFiler(this.appAppNavigationDetails.MetaData, this.appAppNavigationDetails.QueryFilter).bind(this) : null
      });
    }

    if (this.customFilterQuery) {
      dataListConfigModel.OtherFilters.push({
        FilterFrom: FilterFromEnum.CustomQuery,
        FilterString: this.customFilterQuery,
      });
    }
    return dataListConfigModel;
  }

  private initializeDone(dataTableConfig?: any): void {
    this.loadingFromServer = false;

    if (dataTableConfig) {
      if (this.initialFilters) {
        dataTableConfig?.BucketConfigs?.forEach(config => {
          if (config.DataTableConfig) {
            config.DataTableConfig = this.getDataTableQueryFilter(config.DataTableConfig);
          }
        });

        if (dataTableConfig?.Configs) {
          dataTableConfig.Configs = this.getDataTableQueryFilter(dataTableConfig.Configs);
        }
      }

      this.cacheDataTableConfig = cloneDeep(dataTableConfig);
      this.dataTableConfig = dataTableConfig;
    }

    this.initializeCompleted.emit(true);
  }

  private getDataTableQueryFilter(dataTableConfig): void {
    const queryFilter = this.datatableSettingService.getSearchQueryFilter(this.initialFilters);

    if (queryFilter) {
      dataTableConfig = this.datatableSettingService.getConfigModelWithOtherFilters(
        this.initialFilters, dataTableConfig
      );
    }

    return dataTableConfig;
  }

  private subscribeDataTableReloadEvent(): void {
    const countReload = this.datatableHelperService.dataTableReloadEvent$.subscribe((queries) => {
      if (Array.isArray(queries)) {
        queries = (this.searchFilters) ? queries.concat(this.searchFilters) : queries;
        this.searchFilter.next(queries);
      } else {
        queries = this.searchFilters || [];
      }
      if (this.dataTableConfig?.BucketConfigs?.length) {
        if (queries) {
          this.loadDataCountOfTab(queries);
        } else {
          this.loadDataCountOfTab();
        }
      }
    });

    this.subscriptions.push(countReload);
  }

  private tabChangeIndex(index): void {
    if (this.selectedIndex !== index && this.dataTableConfig?.BucketEnable && this.dataTableConfig?.BucketConfigs[index]) {
      this.onTabChanged.emit({
        currentIndex: index,
        currentTabConfig: this.dataTableConfig?.BucketConfigs[index],
      });
    }
    this.selectedIndex = index;
  }

  // General Method
  private getQueryFiler(metaData: LogicMetaData[] | any, query: string): any {
    return () => {
      if (metaData && metaData.length) {
        let filterQuery = query;
        metaData.forEach(md => {
          const value = this.logicExecutor({}, md.LogicExecutor);
          filterQuery = filterQuery.replace(`{{${md.Key}}}`, value);
        });

        return filterQuery;
      } else {
        return query;
      }
    }
  }

  private executeAlwaysEnable(metaData: any): boolean {
    // EXECUTE_ALWAYS
    const metaDataList = metaData?.filter(data => data.Key === 'EXECUTE_ALWAYS');

    if (metaDataList && metaDataList.length) {
      const logicExecutor = metaDataList[0]?.LogicExecutor;
      return this.logicExecutor({}, logicExecutor);
    }
    return false;
  }

  getNewRecordsNumber(viewedTabRecord: TabTotalRecordsDataModel, TotalRecord: number): number {
    if (!viewedTabRecord) {
      return 0;
    }
    const diff = (TotalRecord || 0) - (viewedTabRecord?.count || 0);
    if (diff) {
      return diff;
    }
    return viewedTabRecord.visited === false ? -1 : 0;
  }

  onCurrentPageEvent($event: number): void {
    this.listCurrentPage.emit($event);
  }
}
