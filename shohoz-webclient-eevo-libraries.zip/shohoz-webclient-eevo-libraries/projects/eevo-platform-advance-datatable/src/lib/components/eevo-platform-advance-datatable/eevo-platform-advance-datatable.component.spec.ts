import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformAdvanceDatatableComponent } from './eevo-platform-advance-datatable.component';

describe('EevoPlatformAdvanceDatatableComponent', () => {
  let component: EevoPlatformAdvanceDatatableComponent;
  let fixture: ComponentFixture<EevoPlatformAdvanceDatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformAdvanceDatatableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformAdvanceDatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
