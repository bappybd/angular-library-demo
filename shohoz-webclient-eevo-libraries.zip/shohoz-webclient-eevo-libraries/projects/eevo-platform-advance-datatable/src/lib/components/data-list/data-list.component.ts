import {
  AfterViewInit,
  Component, ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
  Output, TemplateRef,
  ViewChild
} from '@angular/core';
import PerfectScrollbar from "perfect-scrollbar";
import {FuseConfigService} from "@eevo/eevo-base";
import {BehaviorSubject, Subject, Subscription} from "rxjs";
import {MatPaginator} from "@angular/material/paginator";
import {DataListConfigModel, ListResponse} from "../../models/datatable.models";
import {DatatableQueryService} from "../../services/datatable.query.service";
import {DatatableHelperService} from "../../services/datatable.helper.service";
import {DatatableSettingService} from "../../services/datatable.setting.service";
import {FinalFilterQueryEvent} from "../../models/datatable.event.models";
import {TableColumn} from '@swimlane/ngx-datatable';
import {filter, switchMap, tap} from 'rxjs/operators';

type ScreenViewTypes = 'mobile' | 'desktop';

class RequestListDataModel {
  dataListConfigModel: DataListConfigModel;
  preservePageNumber: boolean;
}

@Component({
  selector: 'app-data-list',
  templateUrl: './data-list.component.html',
  styleUrls: ['./data-list.component.scss']
})
export class DataListComponent implements OnInit, OnDestroy, AfterViewInit {
  // -----------------------------------------------------------------------------------------------------
  // @ Host Listener or View Child sections
  // -----------------------------------------------------------------------------------------------------
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;

  // -----------------------------------------------------------------------------------------------------
  // @ Input / Output sections
  // -----------------------------------------------------------------------------------------------------
  @Output()
  onSelectData = new EventEmitter<any>();

  @Output()
  onFinalFilterQuery = new EventEmitter<FinalFilterQueryEvent>();

  @Input()
  searchFilter: Subject<any>;

  @Output()
  listCurrentPage = new EventEmitter<number>();

  @Input() changeTableCurrentPage: Subject<number> = new Subject<number>();

  columns: TableColumn[];
  // -----------------------------------------------------------------------------------------------------
  // @ variables
  // -----------------------------------------------------------------------------------------------------
  ps: PerfectScrollbar | any;

  public isLoading = true;
  public reorderable = true;
  public selected: any[] = [];
  public displayedColumns = [];
  public dataListModel: DataListConfigModel;
  private defaultDataListModel: DataListConfigModel;
  public result: ListResponse = new ListResponse();
  subscriptions: Subscription[] = [];
  enableManualReload = false;
  showReloadButton = false;

  public pageLimitOptions = [
    {value: 10},
    {value: 25},
    {value: 50},
    {value: 100},
  ];

  public customClasses = {
    sortAscending: 'fa fa-sort-asc',
    sortDescending: 'fa fa-sort-desc',
    pagerLeftArrow: 'fa fa-chevron-left',
    pagerRightArrow: 'fa fa-chevron-right',
    pagerPrevious: 'fa fa-step-backward',
    pagerNext: 'fa fa-step-forward'
  };

  mobileViewSize = 600;
  renderView: ScreenViewTypes = 'desktop';
  mobileViewDatatableColumns: any[];
  mobileViewDataTableRows: any[];
  @ViewChild('mobileViewTemplateRow', {static: true}) mobileViewTemplateRow: TemplateRef<any>;
  @ViewChild('datatableContainer') datatableContainer: ElementRef<any>;

  requestListData$: BehaviorSubject<RequestListDataModel> = new BehaviorSubject<RequestListDataModel>(null);
  toggleDatatable = true;

  constructor(
    public fuseConfig: FuseConfigService,
    public queryService: DatatableQueryService,
    public datatableHelperService: DatatableHelperService,
    public datatableSettingService: DatatableSettingService
  ) {
  }

  // dataTableConfig = new Subject<DataListConfigModel>();

  // change data to use getter and setter
  private dataTableConfig = new BehaviorSubject<DataListConfigModel>(undefined);

  get dataConfig() {
    // get the latest value from dataTableConfig BehaviorSubject
    return this.dataTableConfig.getValue();
  }

  @Input()
  set dataConfig(value) {
    // set the latest value for _data BehaviorSubject
    if (value !== undefined) {
      this.enableManualReload = value.ManualReload || false;
      this.dataTableConfig.next(value);
    }
  }

  @HostListener('window:resize') onResize(): void {
    this.perfectScroll();
    this.setScreenView();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Life Cycle Hooks
  // -----------------------------------------------------------------------------------------------------

  ngOnInit(): void {
    this.dataListModel = new DataListConfigModel();
    this.setScreenView();
    this.dataChangeSubscribe();
    this.getListData();
    this.listenToDataReload();
  }

  ngOnDestroy(): void {
    // if (this.dataTableConfig) {
    //   this.dataTableConfig.unsubscribe();
    // }

    this.subscriptions.forEach((s) => s.unsubscribe());

    if (this.ps) {
      this.ps.destroy();
    }

    this.ps = null;
  }

  ngAfterViewInit(): void {
    this.perfectScroll();
    this.listenToPageChange();
  }

  private listenToPageChange(): void {
    this.subscriptions.push(
      this.changeTableCurrentPage.subscribe(res => {
        this.loadPage({offset: res || 0});
      })
    );
  }

  private showReloadButtonAfterCertainTime(): void {
    this.showReloadButton = false;
    if (!this.enableManualReload) {
      return;
    }
    setTimeout(() => {
      this.showReloadButton = true;
    }, 2 * 60 * 1000);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  private listenToDataReload(): void {
    this.subscriptions.push(
      this.datatableHelperService.dataTableReloadEvent$.subscribe(res => {
        if (this.enableManualReload) {
          this.showReloadButton = true;
        } else {
          this.reloadData();
        }
      })
    );
  }

  reloadData(): void {
    this.showReloadButton = false;
    this.requestListData$.next({
      dataListConfigModel: this.dataListModel,
      preservePageNumber: true
    });
  }

  onSort(event): void {
    if (this.dataListModel.SortBy !== event.sorts[0].prop) {
      this.dataListModel.CurrentPageNumber = 0;
    }
    this.dataListModel.SortBy = event.sorts[0].prop;
    this.dataListModel.Descending = (event.sorts[0].dir !== 'asc');
    // this.getListData(this.dataListModel, true);
    this.requestListData$.next({
      dataListConfigModel: this.dataListModel,
      preservePageNumber: true
    });
  }

  loadPage(pageEvent = {offset: 0}): void {
    this.dataListModel.CurrentPageNumber = pageEvent.offset;
    // this.getListData(this.dataListModel, true);
    this.requestListData$.next({
      dataListConfigModel: this.dataListModel,
      preservePageNumber: true
    });
  }

  public loadPageForMobile(pageEvent = {pageIndex: 0}): void {
    this.isLoading = true;
    this.dataListModel.CurrentPageNumber = pageEvent.pageIndex;
    // this.getListData(this.dataListModel);
    this.requestListData$.next({
      dataListConfigModel: this.dataListModel,
      preservePageNumber: true
    });
  }

  onSelect($event): void {
    this.onSelectData.emit(this.selected[0]);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private methods
  // -----------------------------------------------------------------------------------------------------

  private dataChangeSubscribe(): void {
    const dataConfigSubscription = this.dataTableConfig.subscribe(dataListConfigModel => {
        this.dataListModel = dataListConfigModel;
        this.defaultDataListModel = {...this.dataListModel, CurrentPageNumber: 0};

        if (!this.dataListModel.messages) {
          const dlcm = new DataListConfigModel();
          this.dataListModel.messages = dlcm.messages;
        }

        this.requestListData$.next({
          dataListConfigModel: this.dataListModel,
          preservePageNumber: true
        });
        this.displayedColumns = this.columnToDisplay(this.dataListModel.Columns);
        this.columns = this.dataListModel.Columns;
      },
    );
    this.subscriptions.push(dataConfigSubscription);

    const searchFilterSubscription = this.searchFilter.subscribe((filters: any[]) => {
      this.isLoading = true;
      this.showReloadButtonAfterCertainTime()
      const queryFilter = this.datatableSettingService.getSearchQueryFilter(filters);
      if (queryFilter) {
        this.dataListModel = this.datatableSettingService.getConfigModelWithOtherFilters(
          filters, this.dataListModel
        );
        // this.getListData(this.dataListModel, false);
        this.requestListData$.next({
          dataListConfigModel: this.dataListModel,
          preservePageNumber: false
        });
      }
    });
    this.subscriptions.push(searchFilterSubscription);

  }

  private getListData(): void {
    this.subscriptions.push(this.requestListData$
      .pipe(
        filter(d => !!d),
        tap(res => {
          this.isLoading = true;
        }),
        switchMap(({dataListConfigModel, preservePageNumber}) => {
          if (!preservePageNumber) {
            dataListConfigModel = this.defaultDataListModel;
            this.dataListModel = {...this.defaultDataListModel};
          }

          this.listCurrentPage.emit(this.dataListModel.CurrentPageNumber);

          const searchFilter = this.datatableSettingService.getFilterQuery(dataListConfigModel);
          return this.queryService.getList(searchFilter, dataListConfigModel).pipe(
            tap(data => {
              this.onFinalFilterQuery.emit({
                EntityFilter: dataListConfigModel.EntityFilter,
                OtherFilters: dataListConfigModel.OtherFilters,
                FinalQueryString: searchFilter
              });
              this.toggleDatatable = !this.toggleDatatable;
              this.result = data;
              this.perfectScroll();
              if (this.renderView === 'mobile') {
                this.createDataForMobileView();
              }
              this.isLoading = false;
            })
          );
        })
      ).subscribe(data => {
        this.showReloadButtonAfterCertainTime();
      }, error => {
        this.showReloadButtonAfterCertainTime();
      })
    );
    // this.isLoading = true;
    // this.subscriptions.push(subscription);
  }

  private columnToDisplay(columns: any): [] | any {
    return columns && columns.length ? columns.map(obj => obj.prop) : [];
  }

  private perfectScroll = () => {
    if (window.innerWidth > 600) {
      const dataTableBody: HTMLElement = document.querySelector('datatable-body');
      if (dataTableBody) {
        this.ps = new PerfectScrollbar(dataTableBody, {suppressScrollY: true});
      }
    }
  };

  identify(index, item): string {
    return item.Name;
  }


  private createDataForMobileView() {
    this.mobileViewDataTableRows = this.result.Data.map(d => ({data: d}));
    this.createColumnForMobileView();
  }

  private createColumnForMobileView() {
    this.mobileViewDatatableColumns = [
      {
        prop: 'data',
        name: 'Header',
        cellTemplate: this.mobileViewTemplateRow,
        minWidth: this.datatableContainer.nativeElement.offsetWidth - 24
      }
    ];
  }

  private setScreenView() {
    this.renderView = window.innerWidth <= this.mobileViewSize ? 'mobile' : 'desktop';
  }
}
