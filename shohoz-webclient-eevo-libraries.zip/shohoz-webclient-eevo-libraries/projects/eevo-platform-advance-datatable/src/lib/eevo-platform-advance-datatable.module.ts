import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {
  EevoPlatformAdvanceDatatableWithFilterComponent
} from "./container/eevo-platform-advance-datatable-with-filter/eevo-platform-advance-datatable-with-filter.component";
import {MatProgressBarModule} from "@angular/material/progress-bar";
import {FlexLayoutModule, FlexModule} from "@angular/flex-layout";
import {EevoPlatformBreadcrumbModule} from "@eevo/eevo-platform-breadcrumb";
import {MatTabsModule} from "@angular/material/tabs";
import {FuseDirectivesModule} from "@eevo/eevo-base";
import {DataListComponent} from './components/data-list/data-list.component';
import {NgxDatatableModule} from "@swimlane/ngx-datatable";
import {ReactiveFormsModule} from "@angular/forms";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatSelectModule} from "@angular/material/select";
import {SafeHtmlPipe} from "./pipes/safe.html.pipe";
import {
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule
} from "@angular-material-components/datetime-picker";
import {MatInputModule} from "@angular/material/input";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {MatButtonModule} from "@angular/material/button";
import {MatIconModule} from "@angular/material/icon";
import {MatMenuModule} from "@angular/material/menu";
import {MatCardModule} from "@angular/material/card";
import {EevoPlatformAdvanceDataFilterComponent} from "./components/eevo-platform-advance-data-filter/eevo-platform-advance-data-filter.component";
import {EevoPlatformAdvanceDatatableComponent} from "./components/eevo-platform-advance-datatable/eevo-platform-advance-datatable.component";
import {NgxCustomDateTimeModule} from './ngx-custom-date-time.module';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatTableModule} from '@angular/material/table';
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";

@NgModule({
  declarations: [
    DataListComponent,
    SafeHtmlPipe,
    EevoPlatformAdvanceDataFilterComponent,
    EevoPlatformAdvanceDatatableComponent,
    EevoPlatformAdvanceDatatableWithFilterComponent,
  ],
  exports: [
    EevoPlatformAdvanceDataFilterComponent,
    EevoPlatformAdvanceDatatableComponent,
    EevoPlatformAdvanceDatatableWithFilterComponent,
  ],
  imports: [
    CommonModule,
    MatProgressBarModule,
    FlexLayoutModule,
    EevoPlatformBreadcrumbModule,
    MatTabsModule,
    FuseDirectivesModule,
    NgxDatatableModule,
    ReactiveFormsModule,
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    NgxMatDatetimePickerModule,
    MatInputModule,
    MatDatepickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    MatButtonModule,
    MatMenuModule,
    MatCardModule,
    NgxCustomDateTimeModule,
    MatPaginatorModule,
    MatTableModule,
    MatProgressSpinnerModule
  ]
})
export class EevoPlatformAdvanceDatatableModule {}
