import {SelectionType, TableColumn} from '@swimlane/ngx-datatable';

export enum FilterFromEnum {
  AppNavigation = 'AppNavigation',
  TabSection = 'TabSection',
  CustomQuery = 'CustomQuery',
  SearchFilter = 'SearchFilter'
}

export enum SearchFilterMetaData {
  DateTimeRangeInDay = 'DateTimeRangeInDay',
  IsDialogDateTimePicker = 'IsDialogDateTimePicker',
  MinDateTimeInDay = 'MinDateTimeInDay',
  // MaxDateTimeInDay = 'MaxDateTimeInDay'
}

export class DatatableOtherFilters {
  FilterFrom: FilterFromEnum;
  FilterString: string;
  ExecuteAlwaysFilterString?: any;
}

export class DataListConfigModel {
  Columns: any[]; // TableColumn[];
  DataSourceUrl: string;
  EntityName: string;
  EntityColumns: string[];
  EntityFilter: string;
  OtherFilters: DatatableOtherFilters[];
  PageSize: number;
  CurrentPageNumber: number;
  OrderBy: any[];
  SelectionType?: SelectionType;
  rowClass?: any;
  ColumnMode?: ColumnMode;
  messages?: any;
  // deprecated
  SortBy: string;
  Descending: boolean;
  Version: string;
  ManualReload: boolean;

  constructor(pageSize: number = 10, orderBy: any[] = [{'CreatedDate': -1}]) {
    this.SortBy = 'CreatedDate';
    this.Descending = true;
    this.PageSize = 10;
    this.CurrentPageNumber = 0;
    this.OrderBy = orderBy;
    this.ColumnMode = ColumnMode.flex;
    this.EntityFilter = "{}";
    this.OtherFilters = [];
    this.messages = {
      emptyMessage: 'No data to display',
      totalMessage: 'Total'
    };
    this.ManualReload = false;
  }
}

export enum ColumnMode {
  standard = 'standard',
  flex = 'flex',
  force = 'force'
}

export class ListResponse {
  Data: any[];
  TotalElements: number;

  constructor() {
    this.Data = [];
    this.TotalElements = 0;
  }
}

export class EevoDatatableOptions {
  appNavigationId: string;
}
