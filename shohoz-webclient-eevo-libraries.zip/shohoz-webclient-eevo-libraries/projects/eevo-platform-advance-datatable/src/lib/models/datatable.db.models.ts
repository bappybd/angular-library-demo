export class EevoAdvanceDatatableOptions {
  TabIndex: number;
  NavId: string;
  TableConfigId: string;
  InitialFilters: any[];
  ApplySearchFilterToAllTab: boolean;
  Version: string;
  InitialPageNumber?: number
}

export class DataTableViewDto {
  Configs: any;
  BucketConfigs: any[];
  BucketEnable: boolean;

  constructor() {
    this.Configs = null;
    this.BucketConfigs = [];
    this.BucketEnable = false;
  }
}

export class DataTableConfigDto {
  Configs: GenericDataTableConfigDto;
  BucketConfigs: GenericDataTableTabConfigDto[];
  BucketEnable: boolean;

  constructor() {
    this.BucketConfigs = [];
    this.BucketEnable = false;
  }
}

export class SearchFilterConfigDto {
  AppNavigationId: string;

  Type: string;

  Label: string;

  FormFieldName: string;

  Order: number;

  FilterKey: string;

  Values: KeyValueProp[];

  MetaData: any[];
}

export class GenericDataTableConfigDto {
  _id: string;
  Id: string;

  Columns: DataTableColumn[];

  CurrentPageNumber: number;

  EntityColumns: string[];

  EntityFilter: string;

  EntityName: string;

  OrderBy: any[];

  PageSize: number;

  ColumnMode: string;

  IsActive: boolean;

  DataSourceUrl: string;

  Version: string;

  Messages: any;

  ManualReload: boolean;
}

export class GenericDataTableTabConfigDto {
  _id: string;
  Id: string;

  AppNavigationId: string;

  DataTableConfigId: string;

  Name: string;

  Key: string;

  Order: number;

  Filter: string;

  ShowDataCount: boolean;

  DataTableConfig: GenericDataTableConfigDto;

  TotalRecord: number;

  MetaData: LogicMetaData[];
}

export class KeyValue {
  Key: string;
  Value: string;
}

export class KeyValueProp {
  Key: string;
  Value: string;
  Selected: boolean;
}


export class LogicMetaData {
  Key: string;
  LogicExecutor: string;
}

export class DynamicKeyValue {
  Key: string;
  Value: any;
}

export class DataTableColumn {
  Prop: string;

  Name: string;

  Sortable: boolean;

  ColumnSize: number;

  MinWidth?: number;

  MaxWidth?: number;

  Renderer: DataTableRenderer[];

  Expression: string;

  Action: DataTableRendererAction;
}

export class DataTableRenderer {
  NewLine: boolean;

  DataColumn: string;

  DataType: string;

  DataPrefix: string;

  DataSuffix: string;

  DataClass: string;

  ColorExpression: string;

  IconExpression: string;

  Expression: string;

  Action: DataTableRendererAction;

  MenuItems: DataTableRendererAction[];
}

export class DataTableRendererAction {
  BtnLabel: string;

  IsInternalLink: boolean;

  IsSidebarAction: boolean;

  SidebarName: string;

  Path: string;

  Uris: UriValue[];
}

export class UriValue {
  Uri: string;

  DataColumn: string;

  Expression: string;
}
