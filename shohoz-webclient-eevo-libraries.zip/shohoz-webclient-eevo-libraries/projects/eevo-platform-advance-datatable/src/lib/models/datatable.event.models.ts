import {DatatableOtherFilters} from "./datatable.models";

export class FinalFilterQueryEvent {
  EntityFilter: string;
  OtherFilters: DatatableOtherFilters[];
  FinalQueryString: string;
}
