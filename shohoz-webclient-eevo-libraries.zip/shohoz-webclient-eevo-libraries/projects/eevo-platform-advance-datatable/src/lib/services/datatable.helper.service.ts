import {Inject, Injectable} from '@angular/core';
import {Subject} from 'rxjs';
import {EevoFeature, UserDataService} from '@eevo/eevo-core';
import {FeatureGuardService} from '@eevo/eevo-platform-feature-guard';

@Injectable({
  providedIn: 'root'
})

export class DatatableHelperService {
  dataTableReload = new Subject<any>();
  dataTableReloadEvent$ = this.dataTableReload.asObservable();

  constructor(
    private userDataService: UserDataService,
    private featureGuardService: FeatureGuardService
  ) {
  }

  getElapsedTime(startTime, endTime?: any): string {
    // let createdDateTimeInString = "2020-11-18T18:41:27.081Z";
    const startDateTime = new Date(startTime).getTime();
    const entDateTime = endTime ? new Date(endTime).getTime() : new Date().getTime();

    const millisecond = entDateTime - startDateTime;
    const second = millisecond / 1000;
    const min = second / 60;
    const hour = min / 60;
    const day = hour / 24;
    const month = day / 30;

    if (second < 60) {
      return Math.round(second) + ' s';
    } else if (min < 60) {
      return Math.round(min) + ' min';
    } else if (hour < 24) {
      return Math.round(hour) + ' hour(s)';
    } else if (day < 31) {
      return Math.round(day) + ' day(s)';
    } else {
      return Math.round(month) + ' month(s)';
    }
  }

  getCurrentUserId(): string {
    const userData = this.userDataService.getUserData();
    return userData?.UserId;
  }

  canAccess(activatesWith: EevoFeature[]): boolean {
    return this.featureGuardService.isValidFeatureSync(activatesWith);
  }
}
