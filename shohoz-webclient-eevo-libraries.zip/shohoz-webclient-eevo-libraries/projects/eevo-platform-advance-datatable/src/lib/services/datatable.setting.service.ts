import {Inject, Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AppNavigation, EevoQueryService, UtilityService} from '@eevo/eevo-core';
import {forkJoin, Observable} from 'rxjs';
import {
  DataTableConfigDto, DataTableViewDto,
  GenericDataTableConfigDto,
  GenericDataTableTabConfigDto,
  SearchFilterConfigDto
} from '../models/datatable.db.models';
import {DataListConfigModel, DatatableOtherFilters, FilterFromEnum} from "../models/datatable.models";

@Injectable({
  providedIn: 'root'
})

export class DatatableSettingService {
  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    private eevoQueryService: EevoQueryService,
    @Inject('config') private config: any) {
  }

  getAppNavigationDetails(appNavigationId: string): Observable<AppNavigation> {
    const entityName = 'AppNavigations';
    const fields = [
      'Key', 'Title', 'Type', 'Icon', 'IsFeatureFound', 'Url', 'ParentId', 'FeatureCanAccess', 'QueryFilter', 'MetaData'
    ];
    return this.eevoQueryService.getDetailsById<AppNavigation>(
      this.config.AppConfigService.toQueryURL(), entityName, appNavigationId, fields
    );
  }

  // Table Configs
  getDataTableConfigsByNavId(appNavigationId: string): Observable<DataTableConfigDto> {
    return this.getDataTableConfigs(appNavigationId);
  }

  getDataTableConfigsByTableConfigId(tableConfigId: string): Observable<DataTableConfigDto> {
    const result = new DataTableConfigDto();

    return new Observable((observer) => {

      const filter = `{'_id':  GUID('${tableConfigId}'), 'IsActive': true}`;

      this.getDataTableConfigList(filter).subscribe((configs: GenericDataTableConfigDto[]) => {
        if (configs && configs.length > 0) {
          result.Configs = configs[0];
        }
        return observer.next(result);
      }, (error => {
        return observer.next(result);
      }));

    });
  }

  // Search Filter
  getSearchFilterConfigListByNavId(appNavigationId: string): Observable<SearchFilterConfigDto[]> {
    const filter = `{'AppNavigationId': GUID('${appNavigationId}'), 'IsActive': true}`;

    return this.getSearchFilterConfigList(filter);
  }

  getSearchFilterConfigListByTableConfigId(appNavigationId: string): Observable<SearchFilterConfigDto[]> {
    const filter = `{'DataTableConfigId': GUID('${appNavigationId}'), 'IsActive': true}`;

    return this.getSearchFilterConfigList(filter);
  }

  // Tab count
  getDataCountOfTab(model: DataTableViewDto): Observable<DataTableViewDto> {

    return new Observable((observer) => {
      if (model.BucketConfigs) {
        let queryServiceUrl = null;
        const allUrlSame = model.BucketConfigs.every(bc => {
          queryServiceUrl = model?.BucketConfigs[0]?.DataTableConfig?.DataSourceUrl;
          return bc?.DataTableConfig?.DataSourceUrl === queryServiceUrl;
        });

        const calls = [];
        const countQueryRequestList = [];

        model.BucketConfigs.forEach(config => {
          if (config.DataTableConfig && config.DataTableConfig.EntityName) {
            const filter = this.getFilterQuery(config.DataTableConfig);
            const queryPayload = this.getCountRequestPaylaod(config.DataTableConfig.EntityName, filter);

            if (allUrlSame) {
              countQueryRequestList.push(queryPayload);
            } else {
              calls.push(
                this.http.post(
                  config.DataTableConfig?.DataSourceUrl?.toQueryURL(),
                  [queryPayload]
                )
              );
            }
          }
        });

        if (queryServiceUrl && allUrlSame) {
          return this.http.post(
            queryServiceUrl.toQueryURL(),
            countQueryRequestList
          ).subscribe((countList: any) => {

            if (countList && countList.length === countQueryRequestList.length) {
              model.BucketConfigs.forEach((bc, index) => {
                bc.TotalRecord = countList[index][0][0];
              });
            }

            return observer.next(model);
          }, ()=> {
            return observer.next(model);
          });
        } else if (calls.length > 0) {
          const subscription = forkJoin(calls).subscribe((results) => {

              if (results && results.length === calls.length) {
                model.BucketConfigs.forEach((bc, index) => {
                  const result = results[index];
                  bc.TotalRecord = result[0][0][0];
                });
              }

            return observer.next(model);

          }, error => {
            console.log(error);
            return observer.next(model);
          });
        } else {
          return observer.next(model);
        }

      } else {
        return observer.next(model);
      }
    });

  }

  // Filter Query
  getFilterQuery(configModel: DataListConfigModel): string {
    let searchFilter = '{}';
    const query = [];

    if (configModel.EntityFilter && configModel.EntityFilter != '' && configModel.EntityFilter != '{}') {
      query.push(configModel.EntityFilter);
    }
    if (configModel.OtherFilters && configModel.OtherFilters.length > 0) {
      configModel.OtherFilters.forEach(filter => {
        if (filter.FilterString && filter.FilterString != '' && filter.FilterString != '{}') {
          query.push(filter?.ExecuteAlwaysFilterString? filter.ExecuteAlwaysFilterString() : filter.FilterString);
        }
      });
    }

    if (query.length) {
      if (query.length === 1) {
        searchFilter = `${query.join(',')}`;
      } else {
        searchFilter = `{$and: [${query.join(',')}]}`;
      }
    }

    return searchFilter;
  }

  getSearchQueryFilter(filters: any[]): string {
    let filter = '{}';

    if (filters && filters.length > 0) {
      const query = [];
      filters.forEach((filter) => {
        if (filter.type === 'dateTimeRange') {
          if (filter.values.start && filter.values.end && filter.values.start != '' && filter.values.end != '') {
            query.push(`{ '${filter.key}' : { $gte: ISODate("${filter.values.start}"), $lte: ISODate("${filter.values.end}") } }`);
          } else if (filter.values.start && filter.values.start != '') {
            query.push(`{ '${filter.key}' : { $gte: ISODate("${filter.values.start}") } }`);
          } else if (filter.values.end && filter.values.end != '') {
            query.push(`{ '${filter.key}' : { $lte: ISODate("${filter.values.end}") } }`);
          }

        } else if (filter.type === 'dropdown' || filter.type === 'equalMatch') {
          if (filter.key && filter.key !== '') {
            query.push(`{ '${filter.key}': ${filter.value} }`);
          } else if (filter.value && filter.value !== '') {
            query.push(`${filter.value}`);
          }
        }
        else if (filter.type === 'dropdownMulti') {
          const nonEmptyValues = filter.value.filter(f => f); // removing empty items from array.
          if (filter.key && filter.key !== '' && nonEmptyValues.length > 0) {
            query.push(`{ '${filter.key}': {$in: [${nonEmptyValues}]}  }`);
          } else if (filter.value && filter.value !== '' && nonEmptyValues.length > 0) {
            query.push(`{ $or: [${nonEmptyValues}] }`);
          }
        } else {
          const filterValue = this.utilityService.matchAnyCharacterRegx(filter.value);
          query.push(`{ '${filter.key}': { $regex: '${filterValue}', $options: 'i'} }`);
        }
      });

      if (query.length) {
        filter = `{$and: [${query.join(',')}]}`;
      }
    }

    return filter;
  }

  getConfigModelWithOtherFilters(filters: any[], dataListModel: DataListConfigModel): DataListConfigModel {
    const queryFilter = this.getSearchQueryFilter(filters);

    if (queryFilter) {
      const searchQueryFilter: DatatableOtherFilters = {
        FilterFrom: FilterFromEnum.SearchFilter,
        FilterString: queryFilter
      };

      if (dataListModel.OtherFilters && dataListModel.OtherFilters.length > 0) {
        const dataIndex = dataListModel.OtherFilters.findIndex(data => {
          return data.FilterFrom === FilterFromEnum.SearchFilter;
        });

        if (dataIndex !== -1) {
          dataListModel.OtherFilters[dataIndex] = searchQueryFilter;
        } else {
          dataListModel.OtherFilters.push(searchQueryFilter);
        }
      } else {
        dataListModel.OtherFilters = [searchQueryFilter];
      }

      return dataListModel;
    } else {
      dataListModel.OtherFilters = [];
    }
  }

  private getSearchFilterConfigList(filter: string): Observable<SearchFilterConfigDto[]> {
    const entityName = 'GenericDataTableSearchConfigs';
    const fields = [
      'AppNavigationId', 'Type', 'Label', 'FormFieldName', 'Order', 'FilterKey', 'Values', 'MetaData'
    ]
    const pageIndex = 0;
    const pageSize = 100;

    return this.eevoQueryService.getList<SearchFilterConfigDto>(
      this.config.AppConfigService.toQueryURL(), entityName, fields, filter, pageIndex, pageSize, 'Order'
    );
  }

  private getDataTableConfigs(appNavigationId: string): Observable<DataTableConfigDto> {
    const result = new DataTableConfigDto();

    return new Observable((observer) => {

      this.getDataTableTabConfigList(appNavigationId).subscribe((tabs: GenericDataTableTabConfigDto[]) => {
        if (tabs.length > 0) {
          result.BucketEnable = true;

          const datatableConfigIds = tabs.map(tab => {
            if (tab.DataTableConfigId && tab.DataTableConfigId != '') {
              return `GUID('${tab.DataTableConfigId}')`;
            }
          }).filter( f=> {
            return f != undefined;
          });

          if (datatableConfigIds.length == 0) {
            result.BucketConfigs = this.getBucketConfigs(tabs, []);
            return observer.next(result);
          } else {
            const filter = `{'_id': {$in: [${datatableConfigIds.join(',')}] }, 'IsActive': true}`;
            this.getDataTableConfigList(filter).subscribe((configs: GenericDataTableConfigDto[]) => {
              if (configs && configs.length > 0) {
                result.BucketConfigs = this.getBucketConfigs(tabs, configs);
              } else {
                result.BucketConfigs = this.getBucketConfigs(tabs, []);
              }

              return observer.next(result);
            }, (error => {
              return observer.next(result);
            }));
          }
        } else {

          const filter = `{'AppNavigationId':  GUID('${appNavigationId}'), 'IsActive': true}`;

          this.getDataTableConfigList(filter).subscribe((configs: GenericDataTableConfigDto[]) => {
            if (configs && configs.length > 0) {
              result.Configs = configs[0];
            }
            return observer.next(result);
          }, (error => {
            return observer.next(result);
          }));
        }
      }, (error => {
        return observer.next(result);
      }));

    });

  }

  private getDataTableTabConfigList(appNavigationId: string): Observable<GenericDataTableTabConfigDto[]> {
    const entityName = 'GenericDataTableTabConfigs';
    const fields = [
      'AppNavigationId', 'Name', 'Key', 'Filter', 'Order', 'DataTableConfigId', 'IsActive', 'ShowDataCount', 'MetaData'
    ]
    const filter = `{'AppNavigationId': GUID('${appNavigationId}'), 'IsActive': true}`;
    const pageIndex = 0;
    const pageSize = 100;

    return this.eevoQueryService.getList<GenericDataTableTabConfigDto>(
      this.config.AppConfigService.toQueryURL(), entityName, fields, filter, pageIndex, pageSize, 'Order'
    );
  }

  private getDataTableConfigList(filter: string,): Observable<GenericDataTableConfigDto[]> {
    const entityName = 'GenericDataTableConfigs';
    const fields = [
      'AppNavigationId', 'Columns', 'CurrentPageNumber', 'EntityColumns', 'EntityFilter',
      'EntityName', 'OrderBy', 'PageSize', 'ColumnMode', 'IsActive', 'DataSourceUrl', 'Messages'
    ];
    const pageIndex = 0;
    const pageSize = 100;

    return this.eevoQueryService.getList<GenericDataTableConfigDto>(
      this.config.AppConfigService.toQueryURL(), entityName, fields, filter, pageIndex, pageSize
    );
  }

  private getBucketConfigs(tabs: GenericDataTableTabConfigDto[], configs: GenericDataTableConfigDto[]): GenericDataTableTabConfigDto[] {
    let tabOrder = 1;
    tabs.forEach((tab, index) => {
      const dataConfig = configs.find(config => {
        const isValid = ((config.Id === tab.DataTableConfigId) || (config._id === tab.DataTableConfigId));
        return isValid;
      });

      tabs[index].Order = tabOrder;
      tabs[index].TotalRecord = 0;

      if (dataConfig) {
        tabs[index].DataTableConfig = dataConfig;
      }
      tabOrder +=1;
    });

    return tabs;
  }

  private getCountRequestPaylaod(entityName: string, filter: string = '{}'): any {

    const requestBody = {
      source: entityName,
      text: null,
      filter,
      CountOnly: true,
      pageSize: 10,
      pageIndex: 0
    };

    return requestBody;
  }

}
