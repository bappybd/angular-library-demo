import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {UtilityService} from '@eevo/eevo-core';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {DataListConfigModel, ListResponse} from "../models/datatable.models";
import {DatatableSettingService} from "./datatable.setting.service";

@Injectable({
  providedIn: 'root'
})

export class DatatableQueryService {

  constructor(
    private http: HttpClient,
    private utilityService: UtilityService,
    private datatableSettingService: DatatableSettingService,
    @Inject('config') private config: any) {
  }

  getList(searchFilter: string, configModel: DataListConfigModel): Observable<ListResponse> {
    return this.http.post(configModel.DataSourceUrl.toQueryURL(), [
      {
        source: configModel.EntityName,
        text: null,
        filter: searchFilter,
        fields: configModel.EntityColumns,
        orderBy: configModel.SortBy,
        descending: configModel.Descending,
        pageSize: configModel.PageSize,
        pageIndex: configModel.CurrentPageNumber
      },
      {
        source: configModel.EntityName,
        text: null,
        filter: searchFilter,
        CountOnly: true,
        pageSize: configModel.PageSize,
        pageIndex: configModel.CurrentPageNumber
      }
    ]).pipe(
      map((response: any) => {
        return {
          Data: response[0],
          TotalElements: response[1][0][0]
        };
      })
    );
  }
}
