import {ColumnMode} from "../models/datatable.models";
import {GenericDataTableTabConfigDto} from "../models/datatable.db.models";

export const DataTable_DemoDataConfig = {
  Columns: [
    {
      prop: 'Name',
      name: 'Order ID',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: 'SF17653452',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: 'mb-8 mr-4 display-inbk',
          ColorExpression: `{ if (row.ShopStatus == 1) { return 'green'; } else { return '#109CF1'; } }`,
          IconExpression: null,
          Expression: null,
          Action: {
            IsInternalLink: false,
            Uris: [
              {uri: 'orders'},
              {uri: 'id', data: 'Id'},
              {uri: 'details'},
            ]
          }
        },
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'icon',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          IconExpression: `{
                if (row.ShopStatus == 1) {
                  return '<span style="color: green;" class="material-icons">dashboard</span>';
                } else {
                  return '<b style="color: red;"><i class="fas fa-info-circle"></i></b>';
                  return '<img src="/assets/icons/apps/subtract.png"/>';
                }
              }`,
          Expression: null,
          Action: null,
        },
        {
          NewLine: true,
          DataColumn: '',
          DataType: 'icon',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          IconExpression: `{
                // return '';
                if (row.ShopStatus !== 1) {
                  return '<span style="color: green;" class="material-icons">dashboard</span>'
                } else {
                  // return '<b style="color: red;"><i class="fas fa-info-circle"></i></b>';
                  return '<img src="/assets/icons/apps/subtract.png"/>';
                }
              }`,
          Expression: null,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: 'CreatedDate',
          DataType: 'datetime',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          Expression: null,
          IconExpression: null,
          Action: null,
        }
      ]
    },
    {
      prop: 'Settings',
      name: 'Order Status',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: 'Address.Zone.Name',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: 'mb-8 mr-4 display-inbk',
          ColorExpression: `{ return '#FF0000'}`,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: true,
          DataColumn: 'Settings.DeliveryFee',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' Km,',
          CellClass: '',
          ColorExpression: `{ return 'green'}`,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: 'Settings.Vat',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' min',
          CellClass: '',
          ColorExpression: `{ return 'green'}`,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'icon',
          DataPrefix: '',
          DataSuffix: ' min',
          CellClass: '',
          ColorExpression: null,
          IconExpression: `{ return '<img src="/assets/icons/apps/info.png"/>'; }`,
          Expression: null,
          Action: null,
        }
      ]
    },
    {
      prop: 'EmergencyContactDetails',
      name: 'User Detail',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: 'EmergencyContactDetails.Name',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' ',
          CellClass: 'mb-8 display-inbk text-hlnk',
          ColorExpression: `{ return '#109CF1'}`,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: true,
          DataColumn: 'EmergencyContactDetails.PhoneNumber',
          DataType: 'string',
          DataPrefix: ' ',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
      ]
    },
    {
      prop: 'FrontendDeskContactDetails',
      name: 'Provider',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: 'FrontendDeskContactDetails.Name',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: 'mb-8  display-inbk text-hlnk',
          ColorExpression: `{ return '#109CF1'}`,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: true,
          DataColumn: 'FrontendDeskContactDetails.PhoneNumber',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        }
      ]
    },
    {
      prop: 'Name',
      name: 'Restaurant',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: 'Name',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: 'mb-8  display-inbk text-hlnk',
          ColorExpression: `{ return '#109CF1'}`,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: true,
          DataColumn: 'FrontendDeskContactDetails.PhoneNumber',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        }
      ]
    },
    {
      prop: 'Name',
      name: 'Order Details',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: 'Cash',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ',',
          CellClass: 'mb-8 display-inbk',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: '250',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' TK',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        }
        ,
        {
          NewLine: true,
          DataColumn: '2',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' item',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        }
      ]
    },
    {
      prop: 'Name',
      name: 'Assignee',
      sortable: true,
      flexGrow: 1.1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'button',
          DataPrefix: '',
          DataSuffix: ' item',
          CellClass: 'mb-8 display-inbk danger-btn',
          ColorExpression: '{ if (row.ShopStatus == 1) { return true } else { return false; } }',
          IconExpression: null,
          Expression: `{ if (row.Address.Zone.Name == 'Dhanmondi') { return true } else { return false; } }`,
          Action: {
            IsInternalLink: false,
            Uris: [
              {uri: 'orders'},
              {uri: 'id', data: 'Data.res.Id'},
              {uri: 'details'},
            ]
          },
          BtnLabel: 'Assign to me',
        },
        {
          NewLine: false,
          DataColumn: '2',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' item',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: `{ if (row.Address.Zone.Name == 'Dhanmondi') { return false } else { return true; } }`,
          Action: null,
        }
      ]
    },
    {
      prop: 'Name',
      name: 'Flags',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'button',
          DataPrefix: '',
          DataSuffix: ' item',
          CellClass: 'mb-8 display-inbk green-btn',
          ColorExpression: '{ if (row.ShopStatus == 1) { return true } else { return false; } }',
          IconExpression: null,
          Expression: `{ if (row.Address.Zone.Name == 'Dhanmondi') { return false } else { return true; } }`,
          Action: {
            IsSidebarAction: true,
            SidebarName: 'flagsPanel'
          },
          BtnLabel: 'Flags Order',
        },
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'icon',
          DataPrefix: '',
          DataSuffix: ' ',
          CellClass: '',
          ColorExpression: null,
          IconExpression: `{
                return '<b style="color: #109CF1;margin-right: 4px;"><i class="fas fa-biking"></i></b>';
              }`,
          Expression: `{ if (row.Address.Zone.Name == 'Dhanmondi') { return true } else { return false; } }`,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: 'FrontendDeskContactDetails.Name',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' item',
          CellClass: 'mb-8 display-inbk text-hlnk',
          ColorExpression: null,
          IconExpression: null,
          Expression: `{ if (row.Address.Zone.Name == 'Dhanmondi') { return true } else { return false; } }`,
          Action: null,
        },
        {
          NewLine: true,
          DataColumn: 'User Fraud',
          DataType: 'string',
          DataPrefix: '',
          DataSuffix: ' item',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: `{ if (row.Address.Zone.Name == 'Dhanmondi') { return true } else { return false; } }`,
          Action: null,
        }
      ]
    },
    {
      prop: 'Name',
      name: '',
      sortable: true,
      flexGrow: 1,

      Renderer: [
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'icon',
          DataPrefix: '',
          DataSuffix: ' ',
          CellClass: '',
          ColorExpression: null,
          IconExpression: `{
                return '<b style="color: #109CF1;margin-right: 4px;"><i class="fa fa-comment"></i></b>';
              }`,
          Expression: null,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: '3',
          DataType: 'string',
          DataPrefix: '(',
          DataSuffix: ')',
          CellClass: 'text-hlnk',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
        },
        {
          NewLine: false,
          DataColumn: '',
          DataType: 'menu-item',
          DataPrefix: '',
          DataSuffix: '',
          CellClass: '',
          ColorExpression: null,
          IconExpression: null,
          Expression: null,
          Action: null,
          MenuItems: [
            {
              Action: {
                IsSidebarAction: true,
                SidebarName: 'flagsPanel'
              },
              BtnLabel: 'Flags Order'
            },
            {
              Action: {
                IsInternalLink: false,
                Uris: [
                  {uri: 'orders'},
                  {uri: 'id', data: 'Id'},
                  {uri: 'details'},
                ]
              },
              BtnLabel: 'Assign to Me'
            },
            {
              Action: {
                IsInternalLink: false,
                Uris: [
                  {uri: 'orders'},
                  {uri: 'id', data: 'Id'},
                  {uri: 'details'},
                ]
              },
              BtnLabel: 'Assign Ticket'
            }
          ]
        }
      ]
    }
  ],
  CurrentPageNumber: 0,
  Descending: false,
  EntityColumns: [
    'Name', 'CreatedDate', 'Contact', 'Affordability', 'DeliveryFee', 'Settings',
    'ShopStatus', 'Address', 'EmergencyContactDetails', 'FrontendDeskContactDetails'
  ],
  EntityFilter: '{}',
  EntityName: 'ShopListsDetails',
  OrderBy: [],
  PageSize: 10,
  SortBy: 'CreatedDate',
  ColumnMode: ColumnMode.flex
};

export const DataTable_BucketList = [
  {
    Name: 'Open Tickets (10)',
    Key: 'open-tickets',
    Order: 1,
    Filter: '{}',
    // DataConfig: DataTable_DemoDataConfig,
    DataTableConfig: DataTable_DemoDataConfig
  },
  {
    Name: 'Assigned Tickets (5)',
    Key: 'assigned-tickets',
    Order: 2,
    Filter: '{}',
    // DataConfig: DataTable_DemoDataConfig,
    DataTableConfig: DataTable_DemoDataConfig
  },
  {
    Name: 'Resolved (2)',
    Key: 'resoled-tickets',
    Order: 3,
    Filter: '{}',
    // DataConfig: DataTable_DemoDataConfig,
    DataTableConfig: DataTable_DemoDataConfig
  },
  {
    Name: 'All Tickets (25)',
    Key: 'all-tickets',
    Order: 4,
    Filter: '{}',
    // DataConfig: DataTable_DemoDataConfig,
    DataTableConfig: DataTable_DemoDataConfig
  }
]; // as GenericDataTableTabConfigDto[];


export const DataTable_SearchFilterConfig = [
  {
    Type: 'dropdownWithInput',
    Label: 'Search Order',
    FormFieldName: 'SearchOrder',
    Order: 1,
    FilterKey: '',
    Values: [
      {Key: 'PhoneNumber', Value: 'User Phone Number'},
      {Key: 'OrderStatus', Value: 'Order Status'},
      {Key: 'UserName', Value: 'User Name'},
      {Key: 'Provider', Value: 'Provider'},
      {Key: 'OrderId', Value: 'Order Id'}
    ]
  },
  {
    Type: 'dateTimeRange',
    Label: 'Valid Orders',
    FormFieldName: 'ValidOrders',
    Order: 3,
    FilterKey: 'OrderCreated'
  },
  {
    Type: 'dropdown',
    Label: 'Status',
    FormFieldName: 'Status',
    Order: 4,
    FilterKey: 'OrderStatus',
    Values: [
      {Key: '', Value: 'All'}, // empty value
      {Key: 'active', Value: 'Active'},
      {Key: 'inactive', Value: 'Inactive'},
      {Key: 'none', Value: 'None'}
    ]
  },
  {
    Type: 'dropdown',
    Label: 'Priority',
    FormFieldName: 'Priority',
    Order: 5,
    FilterKey: 'OrderPriority',
    Values: [
      {Key: '', Value: 'All'},  // empty value
      {Key: 'one', Value: 'One'},
      {Key: 'two', Value: 'Two'},
      {Key: 'three', Value: 'Three'}
    ]
  }
];
