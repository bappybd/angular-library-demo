import { NgModule } from '@angular/core';
import {SignalrNotificationService} from "./services/signalr-notification.service";

@NgModule({
  declarations: [],
  imports: [],
  exports: [],
  providers: [
    SignalrNotificationService
  ]
})
export class EevoNotificationModule { }
