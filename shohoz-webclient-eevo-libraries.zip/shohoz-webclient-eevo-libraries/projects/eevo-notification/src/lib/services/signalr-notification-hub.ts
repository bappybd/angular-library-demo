import {PLATFORM_ID, Inject, Injector} from '@angular/core';
import {isPlatformServer} from '@angular/common';
import * as signalR from '@microsoft/signalr';

export class SignalrNotificationHub {
  globalConnections = [];
  @Inject(Injector) injector: any;

  constructor(public hubName, public options, @Inject(PLATFORM_ID) private platformId?: Object) {
    const Hub: any = {
      connection: null,
      proxy: null,
      on: null,
      invoke: null,
      disconnect: null,
      reconnect: null,
      connect: null,
      promise: null
    };

    if (isPlatformServer(this.platformId)) {
      return Hub;
    }

    const data = this.getConnection(options);

    Hub.connection = data;

    Hub.on = (event, fn) => {
      Hub.connection.on(event, fn);
    };

    Hub.disconnect = () => {
      Hub.connection.stop();
    };
    Hub.reconnect = (callback) => {
      return Hub.connection.start().then((response) => {
        callback(response);
      });
    };
    Hub.invoke = (method, args) => {
      return Hub.connection.invoke.apply(Hub.connection, arguments);
    };

    return Hub;
  }

  initNewConnection(options): any {

    let connection = null;
    if (isPlatformServer(this.platformId)) {
      return connection;
    }

    if (options && options.rootPath) {
      connection = new signalR.HubConnectionBuilder()
        .withUrl(options.rootPath + '/' + this.hubName, {transport: 1, skipNegotiation: true})
        .withAutomaticReconnect() // Auto reconnect times: [0, 2000, 10000, 30000]
        // .configureLogging(signalR.LogLevel.Information)
        .build();
    } else {
      connection = new signalR.HubConnectionBuilder();
    }
    connection.logging = (options && options.logging);
    return connection;
  }

  getConnection(options): any {
    const useSharedConnection = !(options && options.useSharedConnection === false);
    if (useSharedConnection) {
      return typeof this.globalConnections[options.rootPath] === 'undefined' ?
        this.globalConnections[options.rootPath] = this.initNewConnection(options) :
        this.globalConnections[options.rootPath];
    } else {
      return this.initNewConnection(options);
    }
  }
}
