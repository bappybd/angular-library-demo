import {Injectable, EventEmitter, PLATFORM_ID, Inject} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {Observable, Subject} from 'rxjs';
import {SignalrUtility} from './utility/signalr-utility';
import {SignalrNotificationHub} from './signalr-notification-hub';
import {SignalrNotificationConstant} from '../models/signalr-notification.constant';
import {UserDataService} from '@eevo/eevo-core';
import {HubConnection} from '@microsoft/signalr';

// export enum HubConnectionState {
//   Connecting = 1,
//   Connected = 2,
//   Reconnecting = 3,
//   Disconnected = 4
// }

export enum HubConnectionState {
  /** The hub connection is disconnected. */
  Disconnected = 'Disconnected',
  /** The hub connection is connecting. */
  Connecting = 'Connecting',
  /** The hub connection is connected. */
  Connected = 'Connected',
  /** The hub connection is disconnecting. */
  Disconnecting = 'Disconnecting',
  /** The hub connection is reconnecting. */
  Reconnecting = 'Reconnecting',
}

export let signalrUtility = new SignalrUtility() as any;

@Injectable()
export class SignalrNotificationService {
  public static storage = signalrUtility.storage;
  public static topicGenerator = signalrUtility.topicGenerator;
  public static weight = signalrUtility.weight;
  public static reconnectCounter = 0;
  hub: any;
  isHubConnected = false;
  public requestPipeline: any[] = [];
  private signalRConnectionEstablished = new EventEmitter<boolean>();
  hubConnectionEstablished = this.signalRConnectionEstablished.asObservable();
  private stateObservable: Subject<string> = new Subject<string>();

  constructor(
    private userDataService: UserDataService,
    @Inject('config') private config: any,
    @Inject(PLATFORM_ID) private platformId: any) {

    if (isPlatformBrowser(this.platformId)) {
      this.isHubConnected = false;
      this.userDataService.currentUserData.subscribe(response => {
        if (response === 'USER_LOGGED_OUT') {
          this.disconnect();
        } else if (typeof response === 'object') {
          this.hubInitialization();
        } else if (response === 'USER_DEFAULT_MESSAGE' && this.userDataService.isUserLoggedIn()) {
          this.reconnect();
        }
      });
    }
  }

  getHubStateChange(): Observable<string> {
    return this.stateObservable.asObservable();
  }

  getHubState(): HubConnectionState {
    if (this.hub && this.hub.connection) {
      return this.hub.connection.state;
    }
  }

  getHubConnection(): HubConnection {
    return this.hub;
  }

  listenByKey(key, callback): void {
    signalrUtility.broadcastByKey(key, callback);
    const subscriptionFilters = {SubscriptionFilters: [{Context: key, ActionName: '', Value: ''}]};
    if (!(this.hub && this.hub.connection && this.hub.connection.connection.connectionState === HubConnectionState.Connecting)) {
      this.storeRequestContextInQueue(callback, subscriptionFilters);
    }
  }

  registerBroadcast(key, callback): void {
    signalrUtility.registerBroadcast(key, callback);
    const subscriptionFilters = {SubscriptionFilters: [{Context: key, ActionName: '', Value: ''}]};
    if (this.hub && this.hub.connection && this.hub.connection.connection.connectionState === HubConnectionState.Connecting) {
      if (this.hub.connection.invoke) {
        this.hub.connection.invoke('Subscribe', JSON.stringify(subscriptionFilters));
      }
    } else {
      this.storeRequestContextInQueue(callback, subscriptionFilters);
    }
  }

  subscribeRequestContextFromQueue(): void {
    this.requestPipeline.forEach((request) => {
      if (this.hub && this.hub.connection && this.hub.connection.invoke) {
        this.hub.connection.invoke('Subscribe', JSON.stringify(request.context));
      }
    });
    this.requestPipeline = [];
  }

  storeRequestContextInQueue(callback, requestContext): void {
    const duplicateContext = this.requestPipeline.find(x => x.context === requestContext);
    if (!duplicateContext) {
      this.requestPipeline.push({
        callback,
        context: requestContext
      });
    }
  }

  subscribeAll(context, action, callback): void {
    const model = {
      context,
      action: signalrUtility.populateActions(action)
    };

    this.subscribe(model, callback);
  }

  subscribeSingle(context, id, action, callback): void {
    const model = {
      context,
      id,
      action: signalrUtility.populateActions(action)
    };

    this.subscribe(model, callback);
  }

  subscribeGroup(context, id, action, callback): void {
    const model = {
      context,
      id,
      action: signalrUtility.populateActions(action)
    };

    this.subscribe(model, callback);
  }

  subscribe(model, callback): any {
    if (!model) {
      throw new Error('{Notification Service Subscribe} undefined model');
    }
    if (!callback || 'function' !== typeof callback) {
      throw new Error('{Notification Service Subscribe} illegal callback');
    }
    const ntopic = SignalrNotificationService.topicGenerator.normalize(model, SignalrNotificationService.weight);
    const topic = SignalrNotificationService.topicGenerator.generate(ntopic);
    const timestamp = Date.now();
    const subscriptionToken = [topic, timestamp].join(SignalrNotificationConstant.SEPERATOR[0]);

    SignalrNotificationService.storage.write(subscriptionToken, callback);

    const serverModel = signalrUtility.registerSubscription(model, callback);
    if (this.hub && this.hub.connection && this.hub.connection.connection.connectionState == HubConnectionState.Connecting) {
      if (this.hub.connection.invoke) {
        this.hub.connection.invoke('Subscribe', serverModel);
      }
    } else {
      this.storeRequestContextInQueue(callback, JSON.parse(serverModel));
    }

    // NOTE this line of code below has no obvious reason to live.
    // Perhaps it was writter to solve the hirarchical travarsal problem.
    // If no obvious errors are found remove this.
    SignalrNotificationService.storage.write(timestamp, signalrUtility.outgoingFormatProvider(model));

    return (function () {
      this.cancelSubscribtion(subscriptionToken);
    }).bind(this);
  }

  cancelSubscribtion(subscriptionToken): void {
    if (!subscriptionToken) {
      throw new Error('{SignalRNotificationManager.subscribe} undefined subscriptionToken');
    }

    SignalrNotificationService.storage.prune(subscriptionToken);
    const timestamp = subscriptionToken.slice(subscriptionToken.lastIndexOf(SignalrNotificationConstant.SEPERATOR[0]) + 1);
    this.hub.Unsubscribe(SignalrNotificationService.storage.read(timestamp));
  }

  unSubscribe(context, id, action, callback): void {
    const model = {
      context,
      id,
      action: signalrUtility.populateActions(action)
    };

    if (!model) {
      throw new Error('{SignalRNotificationManager.unSbscribe} undefined model');
    }

    const serverModel = JSON.stringify(signalrUtility.outgoingFormatProvider({...model}));

    const topic = SignalrNotificationService.topicGenerator.generate(
      SignalrNotificationService.topicGenerator.normalize(
        model, SignalrNotificationService.weight
      )
    );
    SignalrNotificationService.storage.prune(topic);

    this.hub.Unsubscribe(serverModel); // Calling a server method
    callback('Success');
  }

  disconnect(): void {
    // 	this.hub['disconnect']();
    if (this.hub && this.hub.connection) {
      this.hub.connection.stop();
    }
  }

  reconnect(): void {
    if (this.hub && this.hub.reconnect) {
      this.hub.reconnect( (response) => {
        SignalrNotificationService.reconnectCounter++;
      });
    } else {
      this.hubInitialization();
    }
  }

  hubInitialization(): void {
    const that = this;
    that.hub = new SignalrNotificationHub(this.config.NotificationHubName, {
      listeners: {
        Broadcast(message) {
          // console.log('hubInitialization>listeners>Broadcast', message);

          const model = signalrUtility.incomingFormatProvider(message);
          const topic = SignalrNotificationConstant.NOTIFICATIONSCOPE.FILTER === message.NotificationType
            ? SignalrNotificationService.topicGenerator.generate(
              SignalrNotificationService.topicGenerator.normalize(model, SignalrNotificationService.weight)
            ) : message.ResponseKey;

          // console.log('topic', topic);

          const callbacks = SignalrNotificationService.storage.read(topic) || Object.create(null);

          const invokeValue = {
            key: message.ResponseKey,
            value: message.ResponseValue
          };
          const keys = Object.keys(callbacks);
          for (let i = 0; i < keys.length; i++) {
            callbacks[keys[i]](invokeValue);
          }
        }
      },
      methods: ['Subscribe', 'Unsubscribe'],
      // queryParams: 'Authorization=' + 'bearer ' + response.access_token,
      rootPath: this.config.NotificationService,
      useSharedConnection: false,
      stateChanged(state) {
        switch (state.newState) {
          case HubConnectionState.Connecting:
            that.signalRConnectionEstablished.emit(true);
            that.isHubConnected = true;
            console.log('eevo notification connecting');
            break;
          case HubConnectionState.Connected:
            console.log('eevo notification connected');
            break;
          case HubConnectionState.Reconnecting:
            console.log('eevo notification reconnecting');
            break;
          case HubConnectionState.Disconnected:
            that.isHubConnected = false;
            console.log('eevo notification disconnected');
            break;
        }
      },
      transport: this.config.NotificationTransportMedium || ['webSockets', 'foreverFrame', 'serverSentEvents', 'longPolling'],
      autoConnect: true,
      logging: true,
      withCredentials: true,
      jsonp: false,
      errorHandler: (error) => {
        if (SignalrNotificationService.reconnectCounter == 0) {
          that.reconnect();
        } else {
          SignalrNotificationService.reconnectCounter--;
        }
      }
    });

    this.hub.connection.start().then(() => {
      if (this.hub && this.hub.connection && this.hub.connection.connection.connectionState == HubConnectionState.Connecting) {
        this.signalRConnectionEstablished.emit(true);
        this.isHubConnected = true;
        this.stateObservable.next(HubConnectionState.Connected);
        this.subscribeRequestContextFromQueue();
      }
    });

    this.hub.connection.on('Broadcast', function (message) {
      // console.log('hubInitialization>hub.connection.on>Broadcast', message);

      if (typeof message === 'string') {
        message = JSON.parse(message);
      }

      const keyLowerCase = signalrUtility.toLowerCaseNotificationReturnObject(message);
      const model = signalrUtility.incomingNotificationFormatProvider(keyLowerCase);
      let callbacks = {};

      if (SignalrNotificationConstant.NOTIFICATIONSCOPE.FILTER == keyLowerCase.notificationtype) {
        const ntopic = SignalrNotificationService.topicGenerator.normalize(model, SignalrNotificationService.weight);
        const topic = SignalrNotificationService.topicGenerator.generate(ntopic);
        callbacks = SignalrNotificationService.storage.read(topic) || Object.create(null);
      } else {
        const topic = model.responsekey;
        callbacks = SignalrNotificationService.storage.read(topic);
        if (!callbacks) {
          callbacks = SignalrNotificationService.storage.read(keyLowerCase.responsekey) || Object.create(null);
          model.id = undefined;
        }
      }

      const invokeValue = {
        key: message.ResponseKey,
        value: message.ResponseValue,
        // denormalizedMessage: message.denormalizedPayload
      };

      const keys = Object.keys(callbacks);
      for (let i = 0; i < keys.length; i++) {
        callbacks[keys[i]](invokeValue);
      }
    });

    this.hub.connection.onreconnecting(error => {
      if (this.hub.connection.state === HubConnectionState.Reconnecting) {
        this.stateObservable.next(HubConnectionState.Reconnecting);
      }
    });

    this.hub.connection.onreconnected(callback => {
      if (this.hub.connection.state === HubConnectionState.Connected) {
        this.stateObservable.next(HubConnectionState.Connected);
      }
    });

    this.hub.connection.onclose(callback => {
      if (this.hub.connection.state === HubConnectionState.Disconnected) {
        this.stateObservable.next(HubConnectionState.Disconnected);
      }
    });
  }
}
