import {Injectable} from "@angular/core";

import {NotificationTopicGenerator} from "./topic-generator";
import {NotificationInMemoryStorage} from "./in-memory-storage";
import {SignalrNotificationConstant} from "../../models/signalr-notification.constant";

@Injectable()
export class SignalrUtility {

  storage = new NotificationInMemoryStorage(SignalrNotificationConstant.SEPERATOR);
  topicGenerator = new NotificationTopicGenerator(SignalrNotificationConstant.SEPERATOR);
  weight = ["context", "id", "action"];

  constructor() {
  }

  incomingFormatProvider(message) {
    if (message.NotificationType === 'BroadcastReceiverType' || message.NotificationType === "UserSpecificReceiverType")
      return message;
    return {
      context: message.SubscriptionFilters[0].Context,
      id: message.SubscriptionFilters[0].Value,
      action: message.SubscriptionFilters[0].ActionName
    };
  }

  incomingNotificationFormatProvider(message) {
    if (message.notificationtype === 1 || message.notificationtype === 2 || message.notificationtype === 4) {
      return message;
    }
    if (message.NotificationType === 1 || message.NotificationType === 2 || message.Notificationtype === 4) {
      return message;
    }


    return {
      context: message.subscriptionfilters[0].context,
      id: message.subscriptionfilters[0].value,
      action: message.subscriptionfilters[0].actionname
    };
  }

  outgoingFormatProvider(model) {
    let aoo = [];

    if (!model.id)
      if (model.action && model.action.length > 0)
        for (let j = 0; j < model.action.length; j++)
          aoo.push({
            'Context': model.context,
            'ActionName': model.action[j],
            'Value': ''
          });
      else aoo.push({
        'Context': model.context,
      });
    else if (typeof model.id === 'string' || typeof model.id === 'number') {
      if (model.action && model.action.length > 0)
        for (let i = 0; i < model.action.length; i++)
          aoo.push({
            'Context': model.context,
            'Value': model.id,
            'ActionName': model.action[i]
          });
    } else
      for (let i = 0; i < model.id.length; i++)
        if (model.action && model.action.length > 0)
          for (let j = 0; j < model.action.length; j++)
            aoo.push({
              'Context': model.context,
              'Value': model.id[i],
              'ActionName': model.action[j]
            });

        else aoo.push({
          'Context': model.context,
          'ActionName': '',
          'Value': model.id[i],
        });

    return {
      'SubscriptionFilters': aoo
    };
  }

  populateActions(action) {
    let model = [];

    if (!action)
      model = [];
    else if (typeof action === 'string')
      model.push(action);
    else if (Array.isArray(action))
      model = action
        .filter(function (value, index, self) {
          return /*unique*/ index === self.indexOf(value);
        }.bind(this))
        .sort()
        .map(function (value: any) {
          return value.toLowerCase()
        });

    return model;
  }

  registerBroadcast(key, callback) {
    if (!key)
      throw '{SignalRNotificationManager.register} undefined key';

    if (!callback || 'function' !== typeof callback)
      throw '{SignalRNotificationManager.register} illegal callback';
    //this is for avoid duplicate register
    if (this.storage.read(key))
      return;
    const timestamp = Date.now();

    const subscriptionToken = [key, timestamp].join(SignalrNotificationConstant.SEPERATOR[0]);

    this.storage.write(subscriptionToken, callback);
  }

  broadcastByKey(key, callback): void {
    if (!key) {
      throw '{SignalRNotificationManager.register} undefined key';
    }

    if (!callback || 'function' !== typeof callback) {
      throw '{SignalRNotificationManager.register} illegal callback';
    }

    // this is for overwrite duplicate register
    const readKey = this.storage.read(key);
    if (readKey) {
      const readKeys = Object.keys(readKey);
      if (readKeys && readKeys.length > 0) {
        const dtstamp = readKeys[0];
        const removeKey = `${key}>${dtstamp}`;
        this.storage.prune(removeKey);
      } else {
        return;
      }
    }

    const timestamp = Date.now();

    const subscriptionToken = [key, timestamp].join(SignalrNotificationConstant.SEPERATOR[0]);

    this.storage.write(subscriptionToken, callback);
  }

  registerSubscription(model, callback) {
    if (!model)
      throw '{SignalRNotificationManager.subscribe} undefined model';
    if (!callback || "function" !== typeof callback)
      throw '{SignalRNotificationManager.subscribe} illegal callback';

    const serverModel = JSON.stringify(this.outgoingFormatProvider({...model}));

    const topic = this.topicGenerator.generate(this.topicGenerator.normalize(model, this.weight));

    const timestamp = Date.now();

    const subscriptionToken = [topic, timestamp].join(SignalrNotificationConstant.SEPERATOR[0]);

    this.storage.write(subscriptionToken, callback);
    return serverModel;

    // NOTE this line of code below has no obvious reason to live. Perhaps it was writter to solve the hirarchical travarsal problem. If no obvious errors are found remove this.
    //services.write(timestamp, outgoingFormatProvider(model));
  }

  toLowerCaseNotificationReturnObject(message) {
    var newObj = {};
    var keys1st = Object.keys(message);
    for (var i = 0; i < keys1st.length; i++) {
      var lowerCase = keys1st[i].toLowerCase();
      newObj[lowerCase] = message[keys1st[i]];
    }

    var subscriptionFilters = newObj["subscriptionfilters"];
    if (subscriptionFilters) {
      var newSubscriptionFilters = [];
      for (var j = 0; j < subscriptionFilters.length; j++) {
        var obj = subscriptionFilters[j];
        var keys2nd = Object.keys(obj);
        var innerNewObj = {};
        for (var k = 0; k < keys2nd.length; k++) {
          var innerLowerCase = keys2nd[k].toLowerCase();
          innerNewObj[innerLowerCase] = obj[keys2nd[k]];
        }
        newSubscriptionFilters.push(innerNewObj);
      }
      newObj["subscriptionfilters"] = newSubscriptionFilters;
    }

    return newObj;
  }

}
