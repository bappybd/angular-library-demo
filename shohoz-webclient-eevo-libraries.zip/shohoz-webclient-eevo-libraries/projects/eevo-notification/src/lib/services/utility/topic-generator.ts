export class NotificationTopicGenerator {
  seperator: any;

  constructor(public topicSeperator: any) {
    if (!topicSeperator) {
      throw '{TopicGenerator Constructor} undefined seperator';
    }

    this.seperator = topicSeperator;
  }

  generate(model) {
    if (!model)
      throw '{TopicGenerator.generate} undefined model';

    for (var i = 0; i < model.length; i++)
      if (Array.isArray(model[i]))
        if (model[i].length === 0)
          model.splice(i, 1);
        else
          model[i] = model[i].join(this.seperator[1]);

    return model.filter(function (item) {
      return item !== undefined && item !== null && item !== '';
    }).join(this.seperator[0]);
  }

  normalize(model, weight) {
    let normalizedModel = [];

    if (weight)
      for (var i = 0; i < weight.length; i++)
        normalizedModel.push(model[weight[i]]);
    else {
      var keys = Object.keys(model);
      for (var i = 0; i < keys.length; i++)
        normalizedModel.push(model[keys[i]]);
    }

    return normalizedModel;
  }
}
