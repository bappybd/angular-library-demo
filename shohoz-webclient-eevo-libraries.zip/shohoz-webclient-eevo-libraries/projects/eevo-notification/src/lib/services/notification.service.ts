import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, forkJoin, of } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';

// import { TokenProvider } from '../token/token.provider';
// import { UserInfoService } from '../bootstrap/user-info.service';
// import { AggregateService } from '../aggragate/aggregate.service';
// import { ShellDomainProvider } from '../utility/shell-domain.provider';

@Injectable()
export class NotificationService {
    loggedInUserId: string;
    header: any = new HttpHeaders({
        'Content-Type': 'application/json'
    });

    constructor(private http: HttpClient,
        // public tokenProvider: TokenProvider,
        // private aggregateService: AggregateService,
        // private userInfo: UserInfoService
    ) {
    }
    //
    // /**
    //  * Title: nofity
    //  * Description: Calling notify endpoint to broadcast notification for specific user .
    //  * @param payload (see bellow comment)
    //  * @return observable(with confirmation string)
    //  */
    //
    // nofity(payload): Observable<any> {
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/Notify',
    //         payload, { headers: this.header, withCredentials: true, observe: 'response' }).pipe(map((result: any) => {
    //             //
    //             return result;
    //         }));
    // }
    //
    // /**
    //  * Title:getUnreadNotificationCounter
    //  * Description: getting counter of all unread notifications
    //  * @param null
    //  * @return Observable
    //  */
    // getUnreadNotificationCounter(): Observable<number> {
    //     this.loggedInUserId = this.userInfo.getUserInfo() && this.userInfo.getUserInfo().UserId;
    //     return this.http.get(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetUnreadNotificationCount'+"?cacheBuster=" + new Date().getTime(), {
    //         headers: this.header,
    //         withCredentials: true,
    //         observe: 'response'
    //     })
    //         .pipe(map((result: any) => {
    //             return result.body;
    //         }));
    // }
    //
    // // getUnreadNotificationCounter(): Observable<number> {
    // //     this.loggedInUserId = this.userInfo.getUserInfo() && this.userInfo.getUserInfo().UserId;
    // //     return this.http.get(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetUnreadNotificationCount?userId=' + this.loggedInUserId, {
    // //         headers: this.header,
    // //         withCredentials: true,
    // //         observe: 'response'
    // //     })
    // //         .pipe(map((result: any) => {
    // //             return result.body;
    // //         }));
    // // }
    //
    // /**
    //  * Title:getAllNotification
    //  * Description: getting all notifications with details
    //  * @param payload
    //  * @return Observable
    //  */
    // getAllNotification(payload): Observable<any> {
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetOfflineNotificationsByQuery',
    //         payload, { headers: this.header, withCredentials: true, observe: 'response' }).pipe(map((result: any) => {
    //             return result;
    //         }));
    // }
    //
    // getAllNotificationForFloatingPanel(payload: any) {
    //
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetOfflineNotificationsByQuery',
    //         payload, { headers: this.header, withCredentials: true, observe: 'response' }).pipe(switchMap((result: any) => {
    //             const callList = [];
    //             let totalRecord;
    //             let firstResponseLength;
    //             if (result && result.body) {
    //                 totalRecord = result.body['TotalCount'];
    //                 if (result && result.body && result.body.Data) firstResponseLength = result.body.Data.length;
    //             }
    //             let queryUrl = ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetOfflineNotificationsByQuery';
    //             if (totalRecord > firstResponseLength) {
    //                 const numberOfCall = Math.ceil(totalRecord / firstResponseLength);
    //                 for (let index = 1; index <= numberOfCall; index++) {
    //                     const newModel = this.clone(payload);
    //                     newModel['PageNumber'] = index;
    //                     // callList.push(this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetOfflineNotificationsByQuery',
    //                     //     newModel, { headers: this.header, withCredentials: true, observe: 'response' }));
    //                     let model =
    //                     {
    //                         "Uri": queryUrl,
    //                         "Verb": "Post",
    //                         "Payload": JSON.stringify(newModel),
    //                         "SuccessIf": JSON.stringify({ Success: 'False' })
    //                     }
    //                     callList.push(model);
    //
    //                 }
    //             }
    //             let notifications = [];
    //             if (callList.length) {
    //                 return this.aggregateService.aggregateExecute(callList).pipe(map((response) => {
    //                     if (response['FailedCallIndex'] == -1) {
    //                         response['HttpAggregateCallResults'].forEach((result) => {
    //                             let data = JSON.parse(result.Response).Data;
    //                             notifications = notifications.concat(data);
    //                         });
    //                     }
    //                     return of(notifications);
    //                 }));
    //                 // return forkJoin(callList).pipe(map((response) => {
    //                 //     forEach(response, function (value, index) {
    //                 //         if (value && value.ok) {
    //                 //             notifications = notifications.concat(value.body.Data);
    //                 //         }
    //                 //     });
    //                 //     return notifications;
    //                 // }));
    //             } else {
    //                 return of(result.body.Data);
    //             }
    //         }));
    // }
    //
    // notificationQueryModel(filterModel) {
    //     const model = {
    //         'Uri': ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetOfflineNotificationsByQuery',
    //         'Verb': 'Post',
    //         'Payload': JSON.stringify(filterModel),
    //         'SuccessIf': JSON.stringify({ TotalCount: 15 })
    //     }
    //     return model;
    // }
    //
    // private clone(obj) {
    //     // in case of premitives
    //     if (obj === null || typeof obj !== "object") {
    //         return obj;
    //     }
    //
    //     // date objects should be
    //     if (obj instanceof Date) {
    //         return new Date(obj.getTime());
    //     }
    //
    //     // handle Array
    //     if (Array.isArray(obj)) {
    //         const clonedArr = [];
    //         const cloneTemp = this.clone;
    //         obj.forEach(function (element) {
    //             clonedArr.push(cloneTemp(element));
    //         });
    //         return clonedArr;
    //     }
    //
    //     // lastly, handle objects
    //     const clonedObj = new obj.constructor();
    //     for (let prop in obj) {
    //         if (obj.hasOwnProperty(prop)) {
    //             clonedObj[prop] = this.clone(obj[prop]);
    //         }
    //     }
    //
    //     return clonedObj;
    // }
    //
    // /**
    //  * Title:markNotificationAsRead
    //  * Description: Mark single notification as read
    //  * @param notificationIds array
    //  * @return Observable
    //  */
    // markNotificationAsRead(notificationIds): Observable<number> {
    //
    //     let payload = {
    //         UserId: this.loggedInUserId,
    //         NotificationIds: notificationIds
    //     };
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/UpdateNotificationStatusToRead', payload, {
    //         headers: this.header,
    //         withCredentials: true,
    //         observe: 'response'
    //     }).pipe(map((result: any) => {
    //
    //         return result;
    //     }));
    // }
    //
    // /**
    //  * Title:markAllNotificationAsRead
    //  * Description: Mark all notification as read
    //  * @param none
    //  * @return Observable
    //  */
    // markAllNotificationAsRead(): Observable<number> {
    //
    //     let payload = { UserId: this.userInfo.getUserInfo() && this.userInfo.getUserInfo().UserId };
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/MarkAllNotificationAsRead', payload, {
    //         headers: this.header,
    //         withCredentials: true,
    //         observe: 'response'
    //     }).pipe(map((result: any) => {
    //         return result;
    //     }));
    // }
    //
    // getUnreadNotificationCountByFilter(ResponseKeys, OnlyUnread?): Observable<number> {
    //     let payload = {
    //         "OnlyUnread": true,
    //         "OrderByCreatedDate": 1,
    //         "ReturnCount": true,
    //         "PageNumber": 1,
    //         "PageSize": 1
    //     }
    //     if (ResponseKeys) {
    //         payload["ResponseKeys"] = ResponseKeys;
    //     }
    //     if (!OnlyUnread) {
    //         payload.OnlyUnread = false;
    //     } else {
    //         payload.OnlyUnread = true;
    //     }
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetOfflineNotificationsByQuery', payload, {
    //         headers: this.header,
    //         withCredentials: true,
    //         observe: 'response'
    //     })
    //         .pipe(map((result: any) => {
    //             return result.body.TotalCount;
    //         }));
    // }
    //
    // getAllNotificationBySubscripFilter(): Observable<number> {
    //     const payload = {
    //         UserId: this.loggedInUserId,
    //         SubscriptionFilterData: {
    //             'Context': 'MessagingThreadNotification'
    //         },
    //         OrderBy: 1
    //     };
    //     return this.http.post(ShellDomainProvider['api'].NotificationService + '/api/Notifier/GetUnreadNotificationsBySubscriptionFilter',
    //         payload, { headers: this.header, withCredentials: true, observe: 'response' }).pipe(map((result: any) => {
    //             return result && result.body;
    //         }));
    // }

}
