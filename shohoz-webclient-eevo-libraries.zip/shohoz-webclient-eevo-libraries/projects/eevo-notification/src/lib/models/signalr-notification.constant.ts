export class SignalrNotificationConstant
{
    public static SEPERATOR= ['>', '+'];
    public static NOTIFICATIONSCOPE={
        BROADCAST:1,
        USER:2,
        FILTER:3
    };
}

export enum NotificationReceiverTypes
{
  NoReceiverType,
  BroadcastReceiverType,
  UserSpecificReceiverType,
  FilterSpecificReceiverType,
  UserAndRoleSpecificReceiverType
}
