/*
 * Public API Surface of eevo-notification
 */

export * from './lib/services/signalr-notification.service';
export * from './lib/eevo-notification.module';
