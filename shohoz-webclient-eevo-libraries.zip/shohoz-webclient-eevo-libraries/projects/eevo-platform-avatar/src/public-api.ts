/*
 * Public API Surface of eevo-platform-avatar
 */

export * from './lib/components/eevo-load-avatar/eevo-load-avatar.component';
export * from './lib/eevo-platform-avatar.module';
