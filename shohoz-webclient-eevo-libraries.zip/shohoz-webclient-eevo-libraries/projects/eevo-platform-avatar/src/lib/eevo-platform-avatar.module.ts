import { NgModule } from '@angular/core';
import { EevoLoadAvatarComponent } from './components/eevo-load-avatar/eevo-load-avatar.component';
import {CommonModule} from "@angular/common";
import {AvatarModule} from "ngx-avatar";
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";

@NgModule({
  declarations: [
    EevoLoadAvatarComponent
  ],
  imports: [
    CommonModule,
    AvatarModule,
    MatProgressSpinnerModule,
  ],
  exports: [
    EevoLoadAvatarComponent
  ],
  providers: []
})
export class EevoPlatformAvatarModule { }
