import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoLoadAvatarComponent } from './eevo-load-avatar.component';

describe('EevoLoadAvatarComponent', () => {
  let component: EevoLoadAvatarComponent;
  let fixture: ComponentFixture<EevoLoadAvatarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoLoadAvatarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoLoadAvatarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
