import {Component, Input, OnInit} from '@angular/core';
import {BehaviorSubject, Observable, Subscription} from "rxjs";
import {EevoStorageService} from "@eevo/eevo-core";

@Component({
  selector: 'eevo-load-avatar',
  templateUrl: './eevo-load-avatar.component.html',
  styleUrls: ['./eevo-load-avatar.component.scss']
})
export class EevoLoadAvatarComponent implements OnInit {
  subscriptionList: Subscription[] = [];
  @Input() avatar = true;
  @Input() imageType: string;
  @Input() size: number;
  @Input() round = false;

  imageUri: string;
  loading = false;
  private _imageFileId: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  private _imageFileKey: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  private _name: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(private eevoStorageService: EevoStorageService) {
  }

  get imageFileId() {
    return this._imageFileId.getValue();
  }

  @Input()
  set imageFileKey(value) {
    this._imageFileKey.next(value);
  }

  @Input()
  set imageFileId(value) {
    this._imageFileId.next(value);
  }

  get name() {
    return this._name.getValue();
  }

  @Input()
  set name(value) {
    this._name.next(value);
  }

  ngOnInit() {
    this.getImage();
  }

  getImage() {
    this.subscriptionList.push(
      this._imageFileId.subscribe(imageFileId => {
        this.loading = true;
        if (imageFileId) {
          this.subscriptionList.push(
            this.eevoStorageService.getFileInfo(imageFileId).subscribe((response) => {
              if (response && response.uri) {
                this.imageUri = response.uri;
              }
              this.loading = false;
            })
          );
        }
      })
    );

    this.subscriptionList.push(
      this._imageFileKey.subscribe(imageFileKey => {
        this.loading = true;
        if (imageFileKey) {
          const uri = this.eevoStorageService.getFileUrl(imageFileKey);
          this.isValidPath(uri).subscribe(data => {
            this.loading = false;
            this.imageUri = (data) ? uri : null;
          });
        }
      })
    );
  }

  private isSuccessCode(status: number): boolean {
    return (status >= 200 && status < 300) || status === 304;
  }

  isValidPath(url: string): Observable<boolean> {
    return new Observable((observer) => {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.responseType = 'blob';
      xhr.onload = () => {
        const success = this.isSuccessCode(xhr.status);
        if (success) {
          observer.next(true);
        } else {
          observer.next(false);
        }
        observer.complete();
      };

      xhr.onerror = (e) => {
        observer.next(false);
        observer.complete();
      };

      xhr.send();
    });
  }

  ngOnDestroy(): void {
    this.subscriptionList.forEach(subs => subs.unsubscribe());
  }
}
