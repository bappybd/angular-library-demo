class PaperDocumentBaseOptions {
  Enable = true;
  Label: string;

  constructor(label: string, enable: boolean) {
    this.Label = label;
    this.Enable = enable;
  }
}

export class PaperDocumentModel {
  ExpiryDate: string;
  DocumentType: any;
  DocumentNumber: any;
  FrontSideImageId: string;
  BackSideImageId: string;
}

export enum PaperDocumentType {
  FrontSideImage = 'front',
  BackSideImage = 'back'
}

export interface PaperDocumentTypesModel {
  Key: any;
  Value: any;
  FrontSideEnable: boolean;
}

export class PaperDocumentImageOptions extends PaperDocumentBaseOptions{
  Type: string;

  TextBrowseFile = 'Drop your document image here, or browse';
  SubTextBrowseFile = 'Supports PNG (1024*1024)';
  UploadIconName = 'insert_photo';

  constructor(label: string, type: string) {
    super(label, true);
    this.Type = type;
  }
}

export class PaperDocumentExpiryDateOptions extends PaperDocumentBaseOptions {
  IsRequired = false;
  FormControlName: string;
  MinDate = new Date(1950, 0, 1);

  constructor() {
    super('Expire Date', true);
    this.FormControlName = 'ExpiryDate';
  }
}

export class PaperDocumentTypeOptions extends PaperDocumentBaseOptions {
  IsRequired = false;
  FormControlName: string;
  DocumentTypeList: PaperDocumentTypesModel[];

  constructor(documentTypeList?: PaperDocumentTypesModel[]) {
    super('Document Type', true);
    this.FormControlName = 'DocumentType';
    this.DocumentTypeList = documentTypeList;
  }
}

export class PaperDocumentNumberOptions extends PaperDocumentBaseOptions {
  IsRequired = false;
  FormControlName: string;

  constructor() {
    super('Number', true);
    this.FormControlName = 'DocumentNumber';
  }
}

export class PaperDocumentOptions {
  ImageTitle: string;
  ImageSubTitle: string;

  ExpiryDate: PaperDocumentExpiryDateOptions = new PaperDocumentExpiryDateOptions();
  DocumentType: PaperDocumentTypeOptions = new PaperDocumentTypeOptions();
  DocumentNumber: PaperDocumentNumberOptions = new PaperDocumentNumberOptions();

  FrontSideImage: PaperDocumentImageOptions = new PaperDocumentImageOptions('Front side', PaperDocumentType.FrontSideImage);
  BackSideImage: PaperDocumentImageOptions = new PaperDocumentImageOptions('Back side', PaperDocumentType.BackSideImage);

  constructor() {
  }
}
