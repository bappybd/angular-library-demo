import { NgModule } from '@angular/core';
import {PaperDocumentsComponent} from "./components/paper-documents/paper-documents.component";
import {ReactiveFormsModule} from "@angular/forms";
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatSelectModule} from "@angular/material/select";
import {MatDatepickerModule} from "@angular/material/datepicker";
import {EevoImageUploaderModule} from "@eevo/eevo-image-uploader";
import {CommonModule} from "@angular/common";
import {FlexModule} from "@angular/flex-layout";
import {MatInputModule} from "@angular/material/input";
import {MatIconModule} from "@angular/material/icon";
import {MatButtonModule} from "@angular/material/button";



@NgModule({
  declarations: [PaperDocumentsComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatDatepickerModule,
    EevoImageUploaderModule,

    FlexModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
  ],
  exports: [PaperDocumentsComponent]
})
export class EevoPlatformPaperDocumentsModule { }
