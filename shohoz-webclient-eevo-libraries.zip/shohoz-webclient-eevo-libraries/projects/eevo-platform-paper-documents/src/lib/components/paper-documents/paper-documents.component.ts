import {Component, Input, OnInit} from '@angular/core';
import {EevoStorageService, FilesModel, UtilityService} from '@eevo/eevo-core';
import {PaperDocumentOptions, PaperDocumentType} from '../../models/paper-document.model';
import * as _ from 'lodash';
import {FormGroup} from '@angular/forms';
import {MatSelectChange} from '@angular/material/select';

@Component({
  selector: 'eevo-paper-documents',
  templateUrl: './paper-documents.component.html',
  styleUrls: ['./paper-documents.component.scss']
})
export class PaperDocumentsComponent implements OnInit {

  @Input()
  parent: FormGroup;

  @Input()
  files: FilesModel;

  @Input()
  options: PaperDocumentOptions;

  // frontSideImageUrl: string;
  // backSideImageUrl: string;
  frontSideImageId: string;
  backSideImageId: string;
  frontSideImageUploaderConfig = {
    thumbnailHeight: 192,
    thumbnailWidth: 200,
    showUploadButton: true,
    // defaultImage: '../../../../../assets/images/no_Image.svg',
    profileImage: false,
    allowedImageTypes: ['png'],
    maxImageSize: 5, // Megabyte,
    textBrowseFile: 'Drop your image here, or browse',
    subTextBrowseFile: 'Supports PNG (1024*1024)',
    uploadIconName: 'insert_photo',
    hideNotFoundError: true
  };
  backSideImageUploaderConfig = _.cloneDeep(this.frontSideImageUploaderConfig);

  constructor(
    private utilityService: UtilityService,
    private storageService: EevoStorageService
  ) {
  }

  ngOnInit(): void {
    if (this.options == null) {
      this.options = new PaperDocumentOptions();
    }

    if (this.options && this.options.FrontSideImage) {
      this.frontSideImageUploaderConfig.textBrowseFile = this.options?.FrontSideImage?.TextBrowseFile;
      this.frontSideImageUploaderConfig.subTextBrowseFile = this.options?.FrontSideImage?.SubTextBrowseFile;
      this.frontSideImageUploaderConfig.uploadIconName = this.options?.FrontSideImage?.UploadIconName;

      this.setFileUrlByType(this.options.FrontSideImage.Type);
    }

    if (this.options && this.options.BackSideImage) {
      this.backSideImageUploaderConfig.textBrowseFile = this.options?.BackSideImage?.TextBrowseFile;
      this.backSideImageUploaderConfig.subTextBrowseFile = this.options?.BackSideImage?.SubTextBrowseFile;
      this.backSideImageUploaderConfig.uploadIconName = this.options?.BackSideImage?.UploadIconName;

      this.setFileUrlByType(this.options.BackSideImage.Type, true);
    }

    if (this.options.DocumentType?.FormControlName) {
      const docType = this.parent.get(this.options.DocumentType?.FormControlName).value;

      this.updateImageSelection(docType);
    }

  }

  documentTypeChange($event: MatSelectChange): void {
    const documentType = $event.value;

    this.updateImageSelection(documentType);
  }

  compareFunction(value1: any, value2: any): boolean {
    return value1 == value2;
  }

  onFrontSideImageChanged(event): void {
    // console.log(event, this.files.Files, this.options, this.options?.FrontSideImage?.Type);

    this.onImageChanged(event, this.options?.FrontSideImage?.Type);
  }

  onBackSideImageChanged(event): void {
    // console.log(event, this.files.Files, this.options, this.options?.BackSideImage?.Type);

    this.onImageChanged(event, this.options?.BackSideImage?.Type);
  }

  private onImageChanged(event, imageType): void {
    this.files.Files.forEach((item, index) => {
      if (this.files.Files[index].Type === imageType) {
        this.files.Files[index] = {
          FileId: this.utilityService.getNewGuid(),
          FileData: event && event[0] ? event[0] : null,
          Type: imageType
        };

        // console.log(index, this.files.Files[index]);
      }
    });
  }

  private setFileUrlByType(type: string, isBackSideImage?: boolean): void {
    if (this.files && this.files.Files && this.files.Files.length > 0) {
      const file = this.files.Files.find(item => {
        // console.log(item.Type, type, item.Type === type);
        return item.Type === type;
      });

      // console.log(file);

      if (file && file.FileId) {
        if (isBackSideImage) {
          this.backSideImageId = file.FileId;
        } else {
          this.frontSideImageId = file.FileId;
        }

        // this.storageService.getFileInfo(file.FileId).subscribe((url) => {
        //   console.log(url);
        //   if (isBackSideImage) {
        //     this.backSideImageUrl = url;
        //   } else {
        //     this.frontSideImageUrl = url;
        //   }
        // });
      }

    }
  }

  private updateImageSelection(selectedType: any): void {
    const documnetData = this.options?.DocumentType?.DocumentTypeList?.find(dt => {
      return dt.Key === selectedType;
    });

    if (documnetData) {
      if (documnetData.FrontSideEnable) {
        this.options.BackSideImage.Enable = false;
        this.options.FrontSideImage.Enable = true;
      } else {
        this.options.BackSideImage.Enable = true;
        this.options.FrontSideImage.Enable = true;
      }
    }
  }

}
