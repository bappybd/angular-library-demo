import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaperDocumentsComponent } from './paper-documents.component';

describe('PaperDocumentsComponent', () => {
  let component: PaperDocumentsComponent;
  let fixture: ComponentFixture<PaperDocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaperDocumentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaperDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
