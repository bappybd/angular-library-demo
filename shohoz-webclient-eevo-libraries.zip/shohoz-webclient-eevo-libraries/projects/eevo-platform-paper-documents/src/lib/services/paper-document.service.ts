import {Injectable} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {PaperDocumentModel} from '../models/paper-document.model';

@Injectable({
  providedIn: 'root'
})
export class PaperDocumentService {

  constructor(private formBuilder: FormBuilder) {
  }

  getPaperDocumentForm(model?: PaperDocumentModel): FormGroup {

    const documentsForm = this.formBuilder.group({
      ExpiryDate: [model && model.ExpiryDate ? model.ExpiryDate : ''],
      DocumentType: [model && model.DocumentType ? model.DocumentType : ''],
      DocumentNumber: [model && model.DocumentNumber ? model.DocumentNumber : ''],
      // FrontSideImageId: [model && model.FrontSideImageId ? model.FrontSideImageId : ''],
      // BackSideImageId: [model && model.BackSideImageId ? model.BackSideImageId : ''],
    });

    return documentsForm;
  }
}
