/*
 * Public API Surface of eevo-platform-paper-documents
 */

export * from './lib/models/paper-document.model';
export * from './lib/services/paper-document.service';
export * from './lib/components/paper-documents/paper-documents.component';
export * from './lib/eevo-platform-paper-documents.module';
