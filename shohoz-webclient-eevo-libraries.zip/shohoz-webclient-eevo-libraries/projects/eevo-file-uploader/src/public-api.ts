/*
 * Public API Surface of eevo-file-uploader
 */

export * from './lib/directives/bytes.pipe';
// export * from './lib/services/eevo-file-uploader.service';
export * from './lib/components/eevo-file-uploader/eevo-file-uploader.component';
export * from './lib/eevo-file-uploader.module';
