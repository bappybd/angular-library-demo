import { TestBed } from '@angular/core/testing';

import { EevoFileUploaderService } from './eevo-file-uploader.service';

describe('EevoFileUploaderService', () => {
  let service: EevoFileUploaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EevoFileUploaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
