import {Component, EventEmitter, Input, OnDestroy, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {FileUploadQueueComponent} from '../file-upload-queue/file-upload-queue.component';

@Component({
  selector: 'eevo-file-uploader',
  templateUrl: './eevo-file-uploader.component.html',
  styleUrls: ['./eevo-file-uploader.component.scss']
})
export class EevoFileUploaderComponent implements OnInit {

  public static count = 0;
  @Input() config: IFileUploadConfig;
  @Input() fileChangeEvent: EventEmitter<any>;
  @Output() public allSelected: EventEmitter<any> = new EventEmitter<any>();
  @Output() public onFilesChange: EventEmitter<any> = new EventEmitter<any>();
  // @Input() isUploadIcon = false;
  public uploadAllEvent: EventEmitter<any> = new EventEmitter<any>();
  public removeFileEvent: EventEmitter<any> = new EventEmitter<any>();
  public c = 0;
  public fileTypes: string;
  public draggedOver = false;
  public dragText = 'Drag and drop or click here to browse files';
  public dragText1 = '';
  public dragText2 = '';
  fileUploadPlaceHolder: any = 'Drag and drop or click here to browse files';
  fileUploadSmallPlaceholder: string = 'Drag and drop or click here to browse files';
  maxFileReached: any = 'Max Number of Files Reached';
  onlyFilestypeof: any = 'Only file type of';
  areSuported: any = 'are supported';
  fileCannotMoreThan: any = 'Image size should be less than';
  Kb: any = 'KB';
  public filesList: any[] = [];
  @ViewChild('fileUploadQueue', { static: true }) fileUploadQueue: FileUploadQueueComponent;
  constructor() {
  }

  ngOnInit() {
    console.log(this.config);
    this.fileUploadQueue.files = this.config.files;
    const config = this.config;
    if (config) {
      if (config.label) {
        this.setLabels(config.label);
      }
      if (this.config.filesRead) {
        this.setDragText({ filesRead: config.filesRead, maxFiles: config.maxFiles });
      } else {
        this.setDragText({});
      }
    }

    if (this.fileChangeEvent) {
      this.fileChangeEvent.subscribe(() => {
        this.setDragText({});
      });
    }
    if (typeof this.config.IsErrorMsgShowOnBox == 'undefined') {
      this.config.IsErrorMsgShowOnBox = true;
    }
    console.log(this.config);
  }

  clickInput() {
    if (this.config && this.config.inputId) {
      document.getElementById(this.config.inputId).click();
    } else {
      document.getElementById('inputButton').click();
    }
  }

  upload(event) {
    this.c++;
    EevoFileUploaderComponent.count++;
  }

  allUploaded(event) {
    this.allSelected.emit(event);
  }

  onRemoved(event) {
    this.setDragText(event);
  }

  onFilesChanged(event: any) {
    if (event === 'CLEAR_QUEUE') {
      this.filesList.length = 0;
      this.setDragText({});
    } else {
      if (event && event.length) {
        this.filesList = event;
      }

      this.onFilesChange.emit(event);
    }
  }

  setDragText(event) {
    let fileType: any;
    let fileSize: any;
    let errorMessageObj = {
      errorType: "",
      errorMessage: ""
    };
    if (event && event.lastFile) {
      fileType = event.lastFile.type.split('/')[1];
      fileSize = event.lastFile.size / 1024;

      if (event.maxSize < fileSize) {
        // this.dragText = this.fileCannotMoreThan + ' ' + event.maxSize + ' ' + this.Kb;
        errorMessageObj = {
          errorType: "MaxFileSize",
          errorMessage: this.fileCannotMoreThan + ' ' + event.maxSize + ' ' + this.Kb
        }
      }
    }

    if (event.filesRead >= event.maxFiles) {
      // this.dragText = this.maxFileReached;
      errorMessageObj = {
        errorMessage: this.maxFileReached,
        errorType: "MaxFiles"
      };
    } else {
      if (fileType && event.fileTypes && event.fileTypes.indexOf(fileType) < 0) {
        // this.dragText = this.onlyFilestypeof + ' ' + event.fileTypes.split(',').map(m => `'.${m}'`).join(', ') + ' ' + this.areSuported;
        errorMessageObj = {
          errorMessage: this.onlyFilestypeof + ' ' + event.fileTypes.split(',').map(m => `'.${m}'`).join(', ') + ' ' + this.areSuported,
          errorType: "FileType"
        }
      } else {
        if (window.innerWidth <= 959) {
          // this.dragText = this.fileUploadSmallPlaceholder;
          errorMessageObj.errorMessage = this.fileUploadSmallPlaceholder;
        } else {
          this.dragText = this.fileUploadPlaceHolder;
        }
      }
    }
    // error message show on drag and drop box
    if (this.config.IsErrorMsgShowOnBox && errorMessageObj.errorMessage) {
      this.dragText = errorMessageObj.errorMessage;
    }
    //callback error message to business component
    if (errorMessageObj.errorMessage) {
      if (this.config.errorCallback) {
        this.config.errorCallback(errorMessageObj)
      }
    }
  }

  onChanged(event) {
    this.draggedOver = false;
    this.setDragText(event);
  }

  onDropped(event) {
    this.draggedOver = false;
    this.setDragText(event);
  }

  onDraggedOver(event) {
    // console.log(event);
    this.draggedOver = true;
    this.setDragText(event);
  }

  onDraggedLeave(event) {
    this.draggedOver = false;
    this.setDragText(event);

  }

  ngOnDestroy() { }

  private setLabels(label) {
    if(label.fileUploadPlaceHolder){
      this.fileUploadPlaceHolder = label.fileUploadPlaceHolder;
    }
    if(label.fileUploadSmallPlaceholder){
      this.fileUploadSmallPlaceholder = label.fileUploadSmallPlaceholder;
    }
    if(label.maxFileReached){
      this.maxFileReached = label.maxFileReached;
    }
    if(label.onlyFilestypeof){
      this.onlyFilestypeof = label.onlyFilestypeof;
    }
    if(label.areSuported){
      this.areSuported = label.areSuported;
    }
    if(label.fileCannotMoreThan){
      this.fileCannotMoreThan = label.fileCannotMoreThan;
    }
    if(label.Kb){
      this.Kb = label.Kb;
    }
    if(label.dragText1){
      this.dragText1 = label.dragText1;
    }
    if(label.dragText2){
      this.dragText2 = label.dragText2;
    }
  }

}

interface IFileUploadConfig {
  maxSize: number;
  maxFiles: number;
  fileTypes: string;
  filesRead: number;
  uploadOnConfirm?: EventEmitter<any>;
  inputId?: string;
  IsErrorMsgShowOnBox?: boolean;
  errorCallback?: Function;
  template?: TemplateRef<any>;
  removeFileEvent?: EventEmitter<any>;
  clearFileUploadQueue?: EventEmitter<any>;
  label: IFileUploadLabel;
  matIconName: string;
  files?: Array<any>[];
}

interface IFileUploadLabel {
  fileUploadPlaceHolder: string;
  fileUploadSmallPlaceholder: string;
  maxFileReached: string;
  onlyFilestypeof: string;
  areSuported: string;
  fileCannotMoreThan: string;
  Kb: string;
  dragText1: string;
  dragText2: string;
}


