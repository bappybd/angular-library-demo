import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoFileUploaderComponent } from './eevo-file-uploader.component';

describe('EevoFileUploaderComponent', () => {
  let component: EevoFileUploaderComponent;
  let fixture: ComponentFixture<EevoFileUploaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoFileUploaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoFileUploaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
