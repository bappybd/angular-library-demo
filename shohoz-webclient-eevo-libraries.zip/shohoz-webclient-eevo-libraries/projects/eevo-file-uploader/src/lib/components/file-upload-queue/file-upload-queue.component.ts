import { Component, OnInit, OnDestroy, QueryList, Input, Output, ContentChildren, forwardRef, EventEmitter } from '@angular/core';
import { Subscription, merge } from 'rxjs';
import { startWith } from 'rxjs/operators';
import {FileUploadComponent} from "../file-upload/file-upload.component";

@Component({
  selector: 'file-upload-queue',
  templateUrl: './file-upload-queue.component.html',
  styleUrls: ['./file-upload-queue.component.scss']
})
export class FileUploadQueueComponent implements OnDestroy, OnInit {

  @ContentChildren(forwardRef(() => FileUploadComponent)) fileUploads: QueryList<FileUploadComponent>;

  /** Subscription to remove changes in files. */
  public _fileRemoveSubscription: Subscription | null;

  /** Subscription to changes in the files. */
  public _changeSubscription: Subscription;

  /** Combined stream of all of the file upload remove change events. */
  get fileUploadRemoveEvents() {
    return merge(...this.fileUploads.map(fileUpload => fileUpload.removeEvent));
  }

  public files: Array<any> = [];

  public defaultFileTypes: string[] = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'pdf', 'txt', 'sql', 'csv', 'zip', 'rar', 'tar.gz', 'tar', '7z', 'vnd.openxmlformats-officedocument.wordprocessingml.document', 'x-zip-compressed', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'vnd.openxmlformats-officedocument.presentationml.presentation'];

  // public filesRead : number = 0;

  public lastFile: any;

  @Input()
  fileAlias: string = 'file';

  @Input() instantUpload: boolean;

  @Input() fileTypes: string = '';

  @Input() maxSize: number;

  @Input() maxFiles: number;

  @Input() filesRead: number = 0;

  @Input() uploadOnConfirm: EventEmitter<any>;

  @Input() removeFileEvent: EventEmitter<any>;

  @Input() clearFileUploadQueue: EventEmitter<any>;

  @Output() onInstantUpload: EventEmitter<any> = new EventEmitter<any>();

  @Output() onAllUploaded: EventEmitter<any> = new EventEmitter<any>();

  @Output() onFilesChange: EventEmitter<any> = new EventEmitter<any>();


  ngOnInit() {
    this.uploadOnConfirm.subscribe(() => {
      this.uploadAll();
    });

    this.removeFileEvent.subscribe((data) => {
      this.removeFile(data);
    });

    if (this.clearFileUploadQueue) {
      this.clearFileUploadQueue.subscribe((data) => {
        this.removeAll();
        this.filesRead = 0;
        this.onFilesChange.emit('CLEAR_QUEUE');
      });
    }
  }

  ngAfterViewInit() {
    // When the list changes, re-subscribe
    this._changeSubscription = this.fileUploads.changes.pipe(startWith(null)).subscribe(() => {
      if (this._fileRemoveSubscription) {
        this._fileRemoveSubscription.unsubscribe();
      }
      this._listenTofileRemoved();
    });
  }

  public _listenTofileRemoved(): void {
    this._fileRemoveSubscription = this.fileUploadRemoveEvents.subscribe((event: FileUploadComponent) => {
      this.files.splice(event.id, 1);
    });
  }

  public instantUploadFile() {
    // this.uploadAll();
  }

  addFile(file: any) {

    if(this.filesRead < this.maxFiles && this.maxFiles === 1){
      this.files = [file];
      this.onFilesChange.emit(this.files);
    } else {
      if (this.filesRead < this.maxFiles) {
        if (this.maxSize) {
          if (file.size / 1024 <= this.maxSize) {
            this.files.push(file);
            this.filesRead++;
          }
        } else {
          this.files.push(file);
          this.filesRead++;
        }
        this.onFilesChange.emit(this.files);
      }
    }

  }

  add(file: any) {

    this.lastFile = file;
    const currentFileType = file.type.split('/')[1];
    const fileExtnsions = {
      'msword': 'doc',
      'vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
      'x-zip-compressed': 'zip',
      'vnd.ms-excel': 'xls',
      'vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
      'vnd.ms-powerpoint': 'ppt',
      'vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx'
    };
    if (this.fileTypes) {
      const fileSplitted = this.fileTypes.split(',').map(elem => elem.trim());
      if (fileSplitted.indexOf(currentFileType) >= 0 || fileSplitted.indexOf(fileExtnsions[currentFileType]) >= 0) { this.addFile(file); }
    } else {
      if (this.defaultFileTypes.indexOf(currentFileType) >= 0) { this.addFile(file); }
    }
  }

  public uploadAll() {
    this.fileUploads.forEach((fileUpload) => {
      fileUpload.upload();
    });

    this.onAllUploaded.emit(this.files);
  }

  public removeAll() {
    this.files.splice(0, this.files.length);
  }

  public removeFile(index: any) {
    this.filesRead--;
    if (index > -1) {
      this.files.splice(index, 1);
    }
    this.onFilesChange.emit(this.files);
  }

  ngOnDestroy() {
    if (this.files) {
      this.removeAll();
    }
    this.files = [];
    this.filesRead = 0;
  }

}
