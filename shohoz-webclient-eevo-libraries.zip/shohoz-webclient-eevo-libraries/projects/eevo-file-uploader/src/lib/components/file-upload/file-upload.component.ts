import { Component, EventEmitter, Input, OnDestroy, Output } from '@angular/core';

@Component({
  selector: 'file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnDestroy {

  constructor() { }

  public isUploading: boolean = false;

  @Input()
  fileAlias: string = "file";

  @Input()
  get file(): any {
    return this._file;
  }
  set file(file: any) {
    this._file = file;
    this.total = this._file.size;
  }

  @Input()
  set id(id: number) {
    this._id = id;
  }
  get id(): number {
    return this._id;
  }

  @Input() removeFileEvent: EventEmitter<any>;
  @Input() isUploadIcon: boolean = false;

  /** Output  */
  @Output() removeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() onUpload: EventEmitter<any> = new EventEmitter<any>();
  @Output() onRemoved: EventEmitter<boolean> = new EventEmitter<boolean>();
  public progressPercentage: number = 100;
  public loaded: number = 0;
  public total: number = 0;
  public _file: any;
  public _id: number;
  public fileUploadSubscription: any;

  public upload(): void {
    this.isUploading = true;
    this.onUpload.emit(this._file);
    if (this.fileUploadSubscription) {
      this.fileUploadSubscription.unsubscribe();
    }
    this.isUploading = false;
    this.loaded = this.total;
    this.progressPercentage = 100;
  }

  public remove(): void {
    if (this.fileUploadSubscription) {
      this.fileUploadSubscription.unsubscribe();
    }
    this.removeEvent.emit(true);
    // this.removeFileEvent.emit(this._file);
    this.removeFileEvent.emit(this._id);
    this.onRemoved.emit(true);
  }

  ngOnDestroy() {
    // console.log('file '+ this._file.name + ' destryed...');
  }

}
