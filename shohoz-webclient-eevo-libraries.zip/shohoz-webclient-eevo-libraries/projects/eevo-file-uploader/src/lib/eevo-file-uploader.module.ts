import { NgModule } from '@angular/core';
import {EevoFileUploaderComponent} from "./components/eevo-file-uploader/eevo-file-uploader.component";
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import {MatProgressBarModule} from "@angular/material/progress-bar";
import {MatIconModule} from "@angular/material/icon";
import {MatCardModule} from "@angular/material/card";
import {BytesPipe} from "./directives/bytes.pipe";
import { FileUploadQueueComponent } from './components/file-upload-queue/file-upload-queue.component';
import {EevoFileUpload} from "./directives/eevo-file-upload.directive";
import {CommonModule} from "@angular/common";



@NgModule({
  declarations: [
    EevoFileUploaderComponent,
    FileUploadComponent,
    BytesPipe,
    FileUploadQueueComponent,
    EevoFileUpload
  ],
  imports: [
    MatProgressBarModule,
    MatIconModule,
    MatCardModule,
    CommonModule
  ],
  exports: [
    // EevoFileUpload,
    EevoFileUploaderComponent,
    BytesPipe
  ]
})
export class EevoFileUploaderModule { }
