// @ts-ignore
import {
  Directive, ElementRef, EventEmitter,
  HostListener, Input, Output,
} from '@angular/core';

/**
 * A material design file upload queue component.
 */
@Directive({
  selector: 'input[eevoFileUpload], div[eevoFileUpload]',
})
export class EevoFileUpload {

  private _queue: any = null;
  private _element: HTMLElement;
  @Output() public onFileSelected: EventEmitter<File[]> = new EventEmitter<File[]>();
  @Output() public onDropped : EventEmitter<any> = new EventEmitter<any>();
  @Output() public onDraggedOver : EventEmitter<any> = new EventEmitter<any>();
  @Output() public onDraggedLeave : EventEmitter<any> = new EventEmitter<any>();
  @Output() public onChanged : EventEmitter<any> = new EventEmitter<any>();
  constructor(private element: ElementRef) {
    this._element = this.element.nativeElement;
  }


  @Input('eevoFileUpload')
  set fileUploadQueue(value: any) {
    if (value) {
      this._queue = value;
    }
  }

  @HostListener('change')
  public onChange(): any {
    let files = this.element.nativeElement.files;
    this.onFileSelected.emit(files);

    for (var i = 0; i < files.length; i++) {
      this._queue.add(files[i]);
    }
    this.element.nativeElement.value = '';
    this.onChanged.emit(this._queue);
  }

  @HostListener('drop', [ '$event' ])
  public onDrop(event: any): any {
    let files = event.dataTransfer.files;
    this.onFileSelected.emit(files);

    for (var i = 0; i < files.length; i++) {
      this._queue.add(files[i]);
    }
    event.preventDefault();
    event.stopPropagation();
    this.element.nativeElement.value = '';
    this.onDropped.emit(this._queue);
  }

  @HostListener('dragover', [ '$event' ])
  public onDropOver(event: any): any {
    event.preventDefault();
    this.onDraggedOver.emit(this._queue);
  }

  @HostListener('dragleave', ['$event'])
  public onDragLeave(event: any) : any{
    event.preventDefault();
    this.onDraggedLeave.emit(this._queue);
  }

}
