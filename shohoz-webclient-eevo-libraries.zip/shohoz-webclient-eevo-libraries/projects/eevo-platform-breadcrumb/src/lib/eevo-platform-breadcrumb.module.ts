import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EevoPlatformBreadcrumbComponent } from './eevo-platform-breadcrumb/eevo-platform-breadcrumb.component';
import {RouterModule} from '@angular/router';
import {FlexModule} from '@angular/flex-layout';
import {MatIconModule} from '@angular/material/icon';
import {EevoPlatformBreadcrumbService} from './services/eevo-platform-breadcrumb.service';
import {EevoPlatformBreadcrumbResolver} from './services/eevo-platform-breadcrumb.resolver';
import { EevoBasicBreadcrumbComponent } from './eevo-basic-breadcrumb/eevo-basic-breadcrumb.component';



@NgModule({
  declarations: [EevoPlatformBreadcrumbComponent, EevoBasicBreadcrumbComponent],
    imports: [
        CommonModule,
        RouterModule,
        FlexModule,
        MatIconModule
    ],
  exports: [EevoPlatformBreadcrumbComponent, EevoBasicBreadcrumbComponent],
    providers: [
        EevoPlatformBreadcrumbService,
        EevoPlatformBreadcrumbResolver
    ]
})
export class EevoPlatformBreadcrumbModule { }
