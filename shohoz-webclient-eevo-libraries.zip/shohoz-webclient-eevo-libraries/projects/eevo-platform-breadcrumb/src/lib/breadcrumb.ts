export interface Breadcrumb {
    text: string;
    path: string;
}

export interface BreadcrumbModel {
  Text: string;
  Path?: string[];
}
