import {Component, OnInit} from '@angular/core';
import {Breadcrumb} from '../breadcrumb';
import {EevoPlatformBreadcrumbService} from '../services/eevo-platform-breadcrumb.service';
import {Subscription} from 'rxjs';

@Component({
    selector: 'app-eevo-platform-breadcrumb',
    templateUrl: './eevo-platform-breadcrumb.component.html',
    styleUrls: ['./eevo-platform-breadcrumb.component.scss']
})
export class EevoPlatformBreadcrumbComponent implements OnInit {

    constructor(private breadcrumbService: EevoPlatformBreadcrumbService) {
    }

    crumbs: Breadcrumb[];
    subscriptions: Subscription[] = [];
    public ngOnInit(): void {
        const subscription = this.breadcrumbService.crumbs$.subscribe((x) => {
            this.crumbs = x;
        });
        this.subscriptions.push(subscription);
    }

    ngOnDestroy(): void {
        this.subscriptions.forEach((x) => x.unsubscribe());
    }
}
