import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformBreadcrumbComponent } from './eevo-platform-breadcrumb.component';

describe('EevoPlatformBreadcrumbComponent', () => {
  let component: EevoPlatformBreadcrumbComponent;
  let fixture: ComponentFixture<EevoPlatformBreadcrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformBreadcrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
