import {Component, Input, OnInit} from '@angular/core';
import {BreadcrumbModel} from "../breadcrumb";

@Component({
  selector: 'eevo-basic-breadcrumb',
  templateUrl: './eevo-basic-breadcrumb.component.html',
  styleUrls: ['./eevo-basic-breadcrumb.component.scss']
})
export class EevoBasicBreadcrumbComponent implements OnInit {

  @Input()
  breadcrumbs: BreadcrumbModel[];

  constructor() { }

  ngOnInit(): void {
  }

}
