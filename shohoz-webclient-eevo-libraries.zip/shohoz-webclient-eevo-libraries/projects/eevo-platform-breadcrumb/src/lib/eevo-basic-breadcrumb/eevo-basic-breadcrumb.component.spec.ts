import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoBasicBreadcrumbComponent } from './eevo-basic-breadcrumb.component';

describe('EevoBasicBreadcrumbComponent', () => {
  let component: EevoBasicBreadcrumbComponent;
  let fixture: ComponentFixture<EevoBasicBreadcrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoBasicBreadcrumbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoBasicBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
