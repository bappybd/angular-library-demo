import {Injectable, Injector,} from '@angular/core';
import {ActivatedRoute, ActivatedRouteSnapshot, NavigationEnd, Router,} from '@angular/router';
import {Observable, BehaviorSubject, of,} from 'rxjs';
import {filter, flatMap, distinct, toArray, first, concat, tap,} from 'rxjs/operators';
import {Breadcrumb} from '../breadcrumb';
import {EevoPlatformBreadcrumbResolver} from '../services/eevo-platform-breadcrumb.resolver';

@Injectable()
export class EevoPlatformBreadcrumbService {

    private _breadcrumbs = new BehaviorSubject<Breadcrumb[]>([]);

    constructor(private _router: Router, private _defaultResolver: EevoPlatformBreadcrumbResolver,
                route: ActivatedRoute, private _injector: Injector) {

        this._router.events
            .pipe(filter((x) => x instanceof NavigationEnd))
            .subscribe((event: NavigationEnd) => {

                const currentRoot = _router.routerState.snapshot.root;
                this._resolveCrumbs(currentRoot).pipe(
                    flatMap((x) => x),
                    distinct((x) => x.text),
                    toArray(),
                ).subscribe((x) => {
                    this._breadcrumbs.next(x);
                });
            });
    }

    get crumbs$(): Observable<Breadcrumb[]> {
        return this._breadcrumbs;
    }

    private _resolveCrumbs(route: ActivatedRouteSnapshot)
        : Observable<Breadcrumb[]> {

        let crumbs$: Observable<Breadcrumb[]>;

        const data = route.routeConfig &&
            route.routeConfig.data;

        if (data && data.breadcrumbs) {
            crumbs$ = this._defaultResolver.resolve(route, this._router.routerState.snapshot);

        } else {
            crumbs$ = of([]);
        }

        if (route.firstChild) {
            crumbs$ = crumbs$.pipe(concat(this._resolveCrumbs(route.firstChild)));
        }

        return crumbs$;
    }
}
