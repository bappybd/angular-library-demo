import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

// chart module
import { NgxChartsModule } from "@swimlane/ngx-charts";
import { FlexLayoutModule } from "@angular/flex-layout";

// Chart components
import { EevoPlatformPieChartComponent } from "./components/eevo-platform-pie-chart/eevo-platform-pie-chart.component";
import { EevoPlatformLineChartComponent } from "./components/eevo-platform-line-chart/eevo-platform-line-chart.component";
import { EevoPlatformBarChartComponent } from "./components/eevo-platform-bar-chart/eevo-platform-bar-chart.component";

@NgModule({
    declarations: [
        EevoPlatformPieChartComponent,
        EevoPlatformLineChartComponent,
        EevoPlatformBarChartComponent,
    ],
    imports: [CommonModule, NgxChartsModule, FlexLayoutModule],
    exports: [
        EevoPlatformPieChartComponent,
        EevoPlatformLineChartComponent,
        EevoPlatformBarChartComponent,
    ],
})
export class EevoPlatformChartModule {}
