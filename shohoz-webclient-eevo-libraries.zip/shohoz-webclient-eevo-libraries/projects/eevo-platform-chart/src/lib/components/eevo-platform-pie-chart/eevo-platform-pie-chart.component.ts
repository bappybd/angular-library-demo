import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";

//mock data
import { data } from "./../eevo-platform-pie-chart/data/data";

//model
import { IPieChart } from "./../../models/pie-chart.model";

@Component({
    selector: "eevo-platform-pie-chart",
    templateUrl: "./eevo-platform-pie-chart.component.html",
    styleUrls: ["./eevo-platform-pie-chart.component.scss"],
})
export class EevoPlatformPieChartComponent implements OnInit {
    @Input()
    Configuration: IPieChart;

    data: any[];
    view: any[] = [700, 400];

    // options
    gradient: boolean = true;
    showLegend: boolean = true;
    showLabels: boolean = true;
    isDoughnut: boolean = false;
    legendPosition: string = "below";

    colorScheme = {
        domain: [],
    };

    constructor() {
        Object.assign(this, { data });
    }

    onSelect(data): void {
        console.log("Item clicked", JSON.parse(JSON.stringify(data)));
    }

    onActivate(data): void {
        console.log("Activate", JSON.parse(JSON.stringify(data)));
    }

    onDeactivate(data): void {
        console.log("Deactivate", JSON.parse(JSON.stringify(data)));
    }

    ngOnInit() {}
}
