import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformPieChartComponent } from './eevo-platform-pie-chart.component';

describe('EevoPlatformPieChartComponent', () => {
  let component: EevoPlatformPieChartComponent;
  let fixture: ComponentFixture<EevoPlatformPieChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformPieChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformPieChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
