import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformLineChartComponent } from './eevo-platform-line-chart.component';

describe('EevoPlatformLineChartComponent', () => {
  let component: EevoPlatformLineChartComponent;
  let fixture: ComponentFixture<EevoPlatformLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformLineChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
