import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";

@Component({
    selector: "eevo-platform-line-chart",
    templateUrl: "./eevo-platform-line-chart.component.html",
    styleUrls: ["./eevo-platform-line-chart.component.scss"],
})
export class EevoPlatformLineChartComponent implements OnInit {
    @Input()
    Configuration;

    @Output()
    select: EventEmitter<any> = new EventEmitter();

    @Output()
    activate: EventEmitter<any> = new EventEmitter();

    @Output()
    deactivate: EventEmitter<any> = new EventEmitter();

    constructor() {}

    ngOnInit(): void {}

    onSelect(data): void {
        this.select.emit(data);
    }

    onActivate(data): void {
        this.activate.emit(data);
    }

    onDeactivate(data): void {
        this.deactivate.emit(data);
    }
}
