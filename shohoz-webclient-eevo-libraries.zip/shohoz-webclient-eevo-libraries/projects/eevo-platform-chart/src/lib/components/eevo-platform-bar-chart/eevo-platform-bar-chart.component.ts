import { Component, OnInit } from "@angular/core";

@Component({
    selector: "eevo-platform-bar-chart",
    templateUrl: "./eevo-platform-bar-chart.component.html",
    styleUrls: ["./eevo-platform-bar-chart.component.scss"],
})
export class EevoPlatformBarChartComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
