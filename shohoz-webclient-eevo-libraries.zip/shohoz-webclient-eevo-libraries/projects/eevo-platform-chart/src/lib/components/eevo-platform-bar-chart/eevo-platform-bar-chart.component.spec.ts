import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformBarChartComponent } from './eevo-platform-bar-chart.component';

describe('EevoPlatformBarChartComponent', () => {
  let component: EevoPlatformBarChartComponent;
  let fixture: ComponentFixture<EevoPlatformBarChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformBarChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
