export interface IPieChart {
    scheme: object;
    view: any;
    doughnut?: boolean;
    results?: object;
    onSelect(event: any);
    gradient?: boolean;
    arcWidth?: number;
    animations?: boolean;
    labels?: boolean;
    legend?: boolean;
    explodeSlices?: boolean;
    tooltipDisabled?: boolean;
    customLegend?: boolean;
    title?: string;
    subtitle?: string;
    chartSum?: number;
    viewParcent?: boolean;
    isCustomTooltipEnable?: boolean;
    currency?: string;
    legendPosition?: string;
    hideAdditionalValueInToLegend?: boolean;
    hideAdditionalValueFromTooltip?: boolean;
}
