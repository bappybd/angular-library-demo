import {Directive, Input, OnDestroy, OnInit, TemplateRef, ViewContainerRef} from "@angular/core";
import {FeatureGuardService} from "../services/feature-guard.service";
import {Subscription} from "rxjs";
import {EevoFeature} from "@eevo/eevo-core";

@Directive({
  selector: '[activateWithFeatures]',
})
export class EevoPlatformFeatureGuardDirective implements OnInit, OnDestroy {
  featureSubscription: Subscription;

  constructor(
    private template: TemplateRef<any>,
    private container: ViewContainerRef,
    private fgs: FeatureGuardService
  ) {
  }

  @Input() activateWithFeatures: EevoFeature[]

  ngOnDestroy() {
    if (this.featureSubscription) {
      this.featureSubscription.unsubscribe();
    }
  }

  ngOnInit() {
    this.featureSubscription = this.fgs.isValidFeature(this.activateWithFeatures)
      .subscribe(isValid => {
        if (isValid) {
          this.container.createEmbeddedView(this.template);
        }
      })
  }
}
