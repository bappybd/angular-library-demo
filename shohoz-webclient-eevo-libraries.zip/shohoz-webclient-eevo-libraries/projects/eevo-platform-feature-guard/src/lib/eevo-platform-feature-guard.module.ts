import {NgModule} from '@angular/core';
import {EevoPlatformFeatureGuardComponent} from "./components/eevo-platform-feature-guard/eevo-platform-feature-guard.component";
import {CommonModule} from "@angular/common";
import {EevoPlatformFeatureGuardDirective} from "./directives/eevo-platform-feature-guard.directive";

@NgModule({
  declarations: [EevoPlatformFeatureGuardComponent, EevoPlatformFeatureGuardDirective],
  imports: [
    CommonModule
  ],
  exports: [EevoPlatformFeatureGuardComponent, EevoPlatformFeatureGuardDirective]
})
export class EevoPlatformFeatureGuardModule {
}
