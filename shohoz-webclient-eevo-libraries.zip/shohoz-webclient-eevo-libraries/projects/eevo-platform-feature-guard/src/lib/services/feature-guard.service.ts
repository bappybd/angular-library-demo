import { Injectable, Inject } from '@angular/core';
import {EevoFeature, FeatureProvider} from "@eevo/eevo-core";
import { filter } from 'lodash';
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class FeatureGuardService {

  constructor(
    private featureProvider: FeatureProvider
  ) {
  }

  public isValidFeature(activatesWith: EevoFeature[]): Observable<boolean> {

    return new Observable((observer) => {
      let isVisible = true;

      this.featureProvider.get().subscribe((features: EevoFeature[]) => {
        isVisible = this.canAccess(features, activatesWith);
        observer.next(isVisible);
      });

    });

  }

  public isValidFeatureSync(activatesWith: EevoFeature[]): boolean {
    const features = this.featureProvider.getFeatureList();
    return this.canAccess(features, activatesWith);
  }

  private canAccess(features, activatesWith: EevoFeature[]): boolean {
    if (!features || features.length === 0 || !activatesWith) {
      return false;
    }

    let isVisible = true;
    let isFeatureActive = [];

    for (let index = 0; index < activatesWith.length; index++) {
      const activateWith = activatesWith[index];

      if (!isFeatureActive.length) {
        isFeatureActive = features.filter(feature => {
          return feature.Key === activateWith.Key;
        });
      }
    }

    if (!isFeatureActive.length){
      isVisible = false;
    }

    return isVisible;
  }
}
