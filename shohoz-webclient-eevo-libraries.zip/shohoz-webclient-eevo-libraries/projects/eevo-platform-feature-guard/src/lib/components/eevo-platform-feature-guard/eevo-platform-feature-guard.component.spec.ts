import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformFeatureGuardComponent } from './eevo-platform-feature-guard.component';

describe('EevoPlatformFeatureGuardComponent', () => {
  let component: EevoPlatformFeatureGuardComponent;
  let fixture: ComponentFixture<EevoPlatformFeatureGuardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformFeatureGuardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformFeatureGuardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
