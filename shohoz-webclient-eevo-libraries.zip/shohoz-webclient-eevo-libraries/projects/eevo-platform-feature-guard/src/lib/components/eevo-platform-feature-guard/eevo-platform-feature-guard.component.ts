import {Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import {EevoFeature, FeatureProvider} from "@eevo/eevo-core";
import {FeatureGuardService} from "../../services/feature-guard.service";


@Component({
  selector: 'eevo-platform-feature-guard',
  templateUrl: './eevo-platform-feature-guard.component.html',
  styleUrls: ['./eevo-platform-feature-guard.component.scss']
})
export class EevoPlatformFeatureGuardComponent implements OnInit {

  @Input() activatesWith: EevoFeature[];
  @Output() onCheckedFeatureGuard = new EventEmitter<boolean>();

  isVisible: boolean = true;

  constructor(
    private featureGuardService: FeatureGuardService
  ) {
    this.isVisible = true;
  }

  ngOnInit() {

    this.featureGuardService.isValidFeature(this.activatesWith).subscribe((isVisible) => {
      console.log(isVisible);
      this.isVisible = isVisible;
      this.onCheckedFeatureGuard.emit(this.isVisible);
    });


  }

}
