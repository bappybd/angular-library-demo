import {ModuleWithProviders, NgModule} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { FuseNavigationModule } from '@eevo/eevo-base';
import { FuseSharedModule } from '@eevo/eevo-base';

import { NavbarVerticalStyle1Component } from './style-1.component';

@NgModule({
  declarations: [NavbarVerticalStyle1Component],
  imports: [
    MatButtonModule,
    MatIconModule,

    FuseSharedModule,
    FuseNavigationModule,
  ],
  exports: [NavbarVerticalStyle1Component]
})
export class NavbarVerticalStyle1Module {
  public static forRoot(
    config: any
  ): ModuleWithProviders<NavbarVerticalStyle1Module> {
    return {
      ngModule: NavbarVerticalStyle1Module,
      providers: [{ provide: 'config', useValue: config }],
    };
  }
}
