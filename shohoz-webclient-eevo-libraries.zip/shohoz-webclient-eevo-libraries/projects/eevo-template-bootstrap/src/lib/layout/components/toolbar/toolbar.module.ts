import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';

import { FuseSearchBarModule, FuseShortcutsModule } from '@eevo/eevo-base';
import { FuseSharedModule } from '@eevo/eevo-base';

import { ToolbarComponent } from './toolbar.component';
import { ToolbarDynamicComponent } from './toolbar-dynamic/toolbar-dynamic.component';

@NgModule({
  declarations: [ToolbarComponent, ToolbarDynamicComponent],
  imports: [
    RouterModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatToolbarModule,

    FuseSharedModule,
    FuseSearchBarModule,
    FuseShortcutsModule,
  ],
  exports: [ToolbarComponent, ToolbarDynamicComponent],
})
export class ToolbarModule { }
