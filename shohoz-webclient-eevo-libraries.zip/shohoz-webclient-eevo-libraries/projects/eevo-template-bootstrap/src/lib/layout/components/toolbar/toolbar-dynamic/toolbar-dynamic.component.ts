import { Component, ComponentFactoryResolver, Input, OnInit, ViewContainerRef } from '@angular/core';
import { ToolbarComponent } from '../toolbar.component'

@Component({
  selector: 'eevo-toolbar-dynamic',
  templateUrl: './toolbar-dynamic.component.html',
  styleUrls: ['./toolbar-dynamic.component.scss']
})
export class ToolbarDynamicComponent implements OnInit {
  @Input() public RefToolbarComponent: any;

  constructor(private vcr: ViewContainerRef, private cfr: ComponentFactoryResolver) { }

  ngOnInit(): void {
    if (this.RefToolbarComponent) {
      this.vcr.createComponent(this.RefToolbarComponent);
    } else {
      let myComp = this.cfr.resolveComponentFactory(ToolbarComponent);
      this.vcr.clear();
      this.vcr.createComponent(myComp);
    }
  }

}
