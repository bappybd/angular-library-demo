import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import {
  FuseSharedModule,
  FuseProgressBarModule,
  FuseSidebarModule,
} from '@eevo/eevo-base';

import { EevoTemplateBootstrapComponent } from './eevo-template-bootstrap.component';
import { LayoutModule } from './layout/layout.module';

// @dynamic
@NgModule({
  declarations: [EevoTemplateBootstrapComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    // Material moment date module
    MatMomentDateModule,

    // Material
    MatButtonModule,
    MatIconModule,
    LayoutModule,
    FuseSharedModule,
    FuseProgressBarModule,
    FuseSidebarModule,
  ],
  providers: [],
  exports: [EevoTemplateBootstrapComponent],
})
export class EevoTemplateBootstrapModule {}
