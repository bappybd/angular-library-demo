/*
 * Public API Surface of eevo-platform-datatable
 */
export * from './lib/eevo-platform-datatable.module';
export * from './lib/components/eevo-platform-table/eevo-platform-table.component';
export * from './lib/models/datatable-model';
export * from './lib/services/pagination.service';
