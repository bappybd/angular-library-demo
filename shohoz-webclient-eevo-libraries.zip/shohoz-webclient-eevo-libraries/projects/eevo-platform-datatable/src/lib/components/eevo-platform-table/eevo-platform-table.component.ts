import {
  AfterViewInit,
  Component,
  EventEmitter,
  HostListener,
  Inject,
  Input,
  OnDestroy,
  OnInit,
  Output,
  PLATFORM_ID,
  TemplateRef,
  ViewChild
} from '@angular/core';
import PerfectScrollbar from 'perfect-scrollbar';
import {FuseConfigService} from '@eevo/eevo-base';
import {isPlatformBrowser} from '@angular/common';
import {DatatableComponent, TableColumn} from '@swimlane/ngx-datatable';
import {BehaviorSubject, Subscription} from 'rxjs';
import {MatPaginator} from '@angular/material/paginator';
import {DatatableModel} from '../../models/datatable-model';

@Component({
  selector: 'eevo-platform-table',
  templateUrl: './eevo-platform-table.component.html',
  styleUrls: ['./eevo-platform-table.component.scss']
})
export class EevoPlatformTableComponent<T> implements OnInit, OnDestroy, AfterViewInit {
  isPlatformBrowser: boolean;
  ps: PerfectScrollbar | any;
  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    public fuseConfig: FuseConfigService) {
    this.isPlatformBrowser = isPlatformBrowser(this.platformId);
  }

  @Input()
  columns: TableColumn[];

  @Input()
  messages: any = {
    emptyMessage: 'No data to display',
    totalMessage: 'Total'
  };

  @Input()
  alternativeRowClass: any;

  selected: any[] = [];

  private _datatableModelInput = new BehaviorSubject<DatatableModel<T>>(undefined);

  @ViewChild('emptyTemplate', { static: true })
  public emptyTemplate: TemplateRef<any>;
  @ViewChild(DatatableComponent, { static: true }) table: DatatableComponent;

  dataTableUpdateFixTimeout;

  @ViewChild('idAnchorEditTemplate', { static: true })
  public idAnchorEditTemplate: TemplateRef<any>;

  @ViewChild('dateTemplate', { static: true })
  public dateTemplate: TemplateRef<any>;

  @ViewChild('dateTimeTemplate', { static: true })
  public dateTimeTemplate: TemplateRef<any>;

  // change data to use getter and setter
  @Input()
  set datatableModelInput(value) {
    // set the latest value for _data BehaviorSubject
    if (value !== undefined) {
      this._datatableModelInput.next(value);
    }
  }

  get datatableModelInput() {
    // get the latest value from _data BehaviorSubject
    return this._datatableModelInput.getValue();
  }

  @Output()
  onFetchDataRequired = new EventEmitter<DatatableModel<T>>();

  @Output()
  onSelectData = new EventEmitter<any>();

  public datatableModel: DatatableModel<T>;
  public isLoading = true;
  public currentPageLimit = 0;
  public pageLimitOptions = [
    { value: 10 },
    { value: 25 },
    { value: 50 },
    { value: 100 },
  ];

  rows: any[];
  reorderable = true;
  customClasses = {
    sortAscending: 'fa fa-sort-asc',
    sortDescending: 'fa fa-sort-desc',
    pagerLeftArrow: 'fa fa-chevron-left',
    pagerRightArrow: 'fa fa-chevron-right',
    pagerPrevious: 'fa fa-step-backward',
    pagerNext: 'fa fa-step-forward'
  };

  settingsChangeSubscription: Subscription;
  currentNavFold: boolean;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  displayedColumns = [];

  @HostListener('window:resize') onResize(): void {
    this.perfectScroll();
  }

  ngOnInit(): void {
    this.datatableModel = new DatatableModel<T>();

    this.settingsChangeSubscription = this.fuseConfig.config.
    pipe().
    subscribe(config => {
      if (this.table && this.currentNavFold !== config.layout.navbar.folded) {
        this.currentNavFold = config.layout.navbar.folded;
        this.dataTableUpdateFixTimeout = setTimeout(() => {
          this.table.rows = [...this.datatableModel.Data];
        }, 0);
      }
    });

    this._datatableModelInput.subscribe(datatableModel => {
        this.datatableModel = datatableModel;
        this.displayedColumns = this.columnToDisplay(this.columns);
        this.isLoading = false;
      }, //  err => console.log(err)
    );
    this.loadPage();
  }

  public loadPage(pageEvent = { offset: 0 }): void {
    this.isLoading = true;
    this.datatableModel.CurrentPageNumber = pageEvent.offset;
    this.onFetchDataRequired.emit(this.datatableModel);
  }

  public loadPageForMobile(pageEvent = { pageIndex: 0 }): void {
    this.isLoading = true;
    this.datatableModel.CurrentPageNumber = pageEvent.pageIndex;
    this.onFetchDataRequired.emit(this.datatableModel);
  }

  public onSort(event): void {
    if (this.datatableModel.SortBy !== event.sorts[0].prop) {
      this.datatableModel.CurrentPageNumber = 0;
    }
    this.datatableModel.SortBy = event.sorts[0].prop;
    this.datatableModel.Descending = (event.sorts[0].dir !== 'asc');

    this.loadPage();
  }

  public onLimitChange(limit: any): void {
    this.datatableModel.PageSize = this.currentPageLimit = parseInt(limit, 10);
    this.datatableModel.CurrentPageNumber = 0;
    this.loadPage();
  }

  public onSelect($event): void{
    this.onSelectData.emit(this.selected[0]);
  }
  onSelectMbl(row): void {
    this.onSelectData.emit(row);
  }

  ngOnDestroy(): void {
    clearTimeout(this.dataTableUpdateFixTimeout);

    if (this.settingsChangeSubscription) {
      this.settingsChangeSubscription.unsubscribe();
    }
    if (this._datatableModelInput) {
      this._datatableModelInput.unsubscribe();
    }

    if (this.ps) {
      this.ps.destroy();
    }
    // Clean up
    this.ps = null;
  }

  ngAfterViewInit(): void {
    this.perfectScroll();
  }

  perfectScroll = () => {
    if (this.isPlatformBrowser) {
      if (window.innerWidth > 600) {
        const dataTableBody: HTMLElement = document.querySelector('datatable-body');
        this.ps = new PerfectScrollbar(dataTableBody, { suppressScrollY: true });
      }
    }
  }

  columnToDisplay(columns: any): [] | any {
    return columns && columns.length ? columns.map(obj => obj.prop) : [];
  }

}
