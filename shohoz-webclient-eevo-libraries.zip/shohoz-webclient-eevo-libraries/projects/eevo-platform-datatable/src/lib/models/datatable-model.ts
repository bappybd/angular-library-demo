import {SelectionType} from '@swimlane/ngx-datatable';

export class DatatableModel<T> {
  PageSize: number;
  TotalElements: number;
  TotalPages?: number;
  CurrentPageNumber: number;
  SortBy: string;
  Descending: boolean;
  ExternalPaging?: boolean;
  ExternalSorting?: boolean;
  FooterHeight?: boolean;
  LoadingIndicator?: boolean;
  ScrollbarH?: boolean;
  ScrollbarV?: boolean;
  SelectionType?: SelectionType;
  TrackByProp?: string;
  Data: Array<T>;
  OnActivateEventType?: Array<string>;
  rowClass?: any;
  ColumnMode?: ColumnMode;
  constructor(defaultSortBy: string = 'CreatedDate', descending: boolean = true) {
    this.PageSize = 10;
    this.TotalElements = 0;
    this.TotalPages = 0;
    this.CurrentPageNumber = 0;
    this.Data = new Array<T>();
    this.OnActivateEventType = [];

    this.SortBy = defaultSortBy;
    this.Descending = descending;
    this.ColumnMode = ColumnMode.flex;
  }
}

export enum ColumnMode {
  standard = 'standard',
  flex = 'flex',
  force = 'force'
}

