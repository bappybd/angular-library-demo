import { NgModule } from '@angular/core';
import { EevoPlatformTableComponent } from './components/eevo-platform-table/eevo-platform-table.component';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {CommonModule} from '@angular/common';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {FlexLayoutModule} from '@angular/flex-layout';
import {EevoPipeModule} from '@eevo/eevo-core';

@NgModule({
  declarations: [EevoPlatformTableComponent],
    imports: [
        NgxDatatableModule,
        CommonModule,
        MatTableModule,
        MatPaginatorModule,
        FlexLayoutModule,
        EevoPipeModule
    ],
  exports: [EevoPlatformTableComponent]
})
export class EevoPlatformDatatableModule { }
