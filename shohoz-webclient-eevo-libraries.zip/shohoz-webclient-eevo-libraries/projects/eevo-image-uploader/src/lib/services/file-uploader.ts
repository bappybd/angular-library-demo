import { Observer, Subject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {Inject, Injectable, Input} from '@angular/core';
import { UploadedFile } from '../models/uploaded-file';
import { FileUploaderOptions, CropOptions } from '../models/interfaces';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class FileUploader {

  constructor( private http: HttpClient, @Inject('config') private config: any ) {
    this._fileProgress$ = (new Subject() as Subject<UploadedFile>);
  }

  get fileProgress$(): Observable<any> {
    return this._fileProgress$.asObservable();
  }
  private _fileProgress$: Subject<UploadedFile>;

  private static setDefaults(options: FileUploaderOptions): void {
    options.withCredentials = options.withCredentials || false;
    options.httpMethod = options.httpMethod || 'POST';
    options.authTokenPrefix = options.authTokenPrefix || 'Bearer';
    options.fieldName = options.fieldName || 'file';
  }

  private static isSuccessCode(status: number): boolean {
    return (status >= 200 && status < 300) || status === 304;
  }

  getFilesInfo(fileIds: string[]): Observable<any> {
    const header = new HttpHeaders({
      'x-service-id': 'restaurants',
    });
    return this.http.post(this.config.StorageQueryService + 'FileQuery/GetFiles',
      {
        FileIds: fileIds
      }
      , {headers: header}).pipe(
      map((response: any) => {
        return response[0].uri;
      })
    );
  }

  getImageById(fileId: string): Observable<any> {
    return this.getFilesInfo([fileId]);
  }

  getResourceImage(resourceData): Observable<any> {
    // return this.platformDataService.getResource(resourceData.EntityName,
    //   resourceData.EntityItemId, resourceData.FileEntityConnectionTag).pipe(map((response: any) => {
    //     const data = response.body;
    //     if (data && data.Result !== '') {
    //       return data.Result;
    //     } else {
    //       return null;
    //     }
    //   }));
    return null;
  }

  getFile(url: string, options: { authToken?: string, authTokenPrefix?: string }): Observable<File> {
    return Observable.create((observer: Observer<File>) => {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      xhr.responseType = 'blob';

      xhr.onload = () => {
        const success = FileUploader.isSuccessCode(xhr.status);

        if (!success) {
          observer.error(xhr.status);
          observer.complete();
        } else {
          const contentType = xhr.getResponseHeader('Content-Type');
          const blob = new File([xhr.response], 'filename', { type: contentType });

          if (blob.size > 0) {
            observer.next(blob);
            observer.complete();
          } else {
            observer.error('No image');
            observer.complete();
          }
        }
      };

      xhr.onerror = (e) => {
        observer.error(xhr.status);
        observer.complete();
      };

      if (options.authToken) {
        xhr.setRequestHeader('Authorization', `${options.authTokenPrefix} ${options.authToken}`);
      }

      xhr.send();
    });
  }
}
