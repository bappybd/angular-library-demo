import { NgModule } from '@angular/core';
import {EevoImageUploaderComponent} from './components/eevo-image-uploader/eevo-image-uploader.component';
import {CommonModule} from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FileUploader} from './services/file-uploader';
import {MatIconModule} from "@angular/material/icon";
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {ImagePreviewerComponent} from "./components/image-previewer/image-previewer.component";
import {MatSliderModule} from "@angular/material/slider";
import {FormsModule} from "@angular/forms";



@NgModule({
  declarations: [EevoImageUploaderComponent, ImagePreviewerComponent],
  imports: [
    CommonModule, MatButtonModule, MatInputModule, FlexLayoutModule, MatIconModule, MatProgressSpinnerModule, MatSliderModule, FormsModule
  ],
  exports: [EevoImageUploaderComponent],
  providers: [FileUploader],
})
export class EevoImageUploaderModule { }
