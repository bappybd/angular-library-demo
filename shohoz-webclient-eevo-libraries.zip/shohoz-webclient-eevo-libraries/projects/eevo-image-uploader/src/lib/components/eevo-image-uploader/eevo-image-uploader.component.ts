import {
  AfterViewChecked,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  forwardRef, Input,
  OnDestroy,
  OnInit, Output,
  ViewChild,
  Renderer2
} from '@angular/core';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {CustomImageUploaderOptions, ImageResult, ResizeOptions, Status} from '../../models/interfaces';
import {UploadedFile} from '../../models/uploaded-file';
import {FileUploader} from '../../services/file-uploader';
import {createImage, resizeImage} from '../../models/utils';
import {MatDialog} from "@angular/material/dialog";
import {ImagePreviewerComponent} from "../image-previewer/image-previewer.component";

@Component({
  selector: 'eevo-image-uploader',
  templateUrl: './eevo-image-uploader.component.html',
  styleUrls: ['./eevo-image-uploader.component.scss'],

  host: {
    '[style.width]': 'thumbnailWidth + "px"',
    '[style.height]': 'thumbnailHeight + "px"',
    '(drop)': 'drop($event)',
    '(dragenter)': 'dragenter($event)',
    '(dragover)': 'dragover($event)',
    '(dragleave)': 'dragleave($event)',
  },

  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => EevoImageUploaderComponent),
      multi: true
    }
  ]
})
export class EevoImageUploaderComponent implements OnInit,
  OnDestroy, AfterViewChecked, ControlValueAccessor {

  constructor(
    private renderer: Renderer2,
    private uploader: FileUploader,
    private changeDetector: ChangeDetectorRef,
    public matDialog: MatDialog
  ) {
  }

  get imageThumbnail(): string {
    return this._imageThumbnail;
  }

  set imageThumbnail(value) {
    this._imageThumbnail = value;
    this.propagateChange(this._imageThumbnail);

    if (value !== undefined) {
      this.status = Status.Selected;
    } else {
      this.status = Status.NotSelected;
    }
  }

  get errorMessage(): string {
    return this._errorMessage;
  }

  set errorMessage(value) {
    this._errorMessage = value;

    if (this.options.hideNotFoundError && (value == '404')) {
      this.imageThumbnail = undefined;
      this.errorMessage = undefined;
      this.status = Status.NotSelected;
    } else if (value) {
      this.status = Status.Error;
    } else {
      this.status = Status.NotSelected;
    }
  }

  get status(): Status {
    return this._status;
  }

  set status(value) {
    this._status = value;
    this.onStatusChange.emit(value);
  }

  @ViewChild('imageElement', {static: true}) imageElement: ElementRef;
  @ViewChild('fileInput', {static: true}) fileInputElement: ElementRef;
  @ViewChild('dragOverlay', {static: true}) dragOverlayElement: ElementRef;
  @Input() options: CustomImageUploaderOptions;
  @Input('fileId') fileId: string;
  @Input('resourceData') resourceData: any;
  @Input() imageUrl: string;
  @Output() onUpload: EventEmitter<UploadedFile> = new EventEmitter<UploadedFile>();
  @Output() onRemove: EventEmitter<any> = new EventEmitter<any>();
  @Output() onSelect: EventEmitter<any> = new EventEmitter<any>();
  @Output() onError: EventEmitter<any> = new EventEmitter<any>();
  @Output() onStatusChange: EventEmitter<Status> = new EventEmitter<Status>();

  statusEnum = Status;
  _status: Status = Status.NotSelected;

  thumbnailWidth = 150;
  thumbnailHeight = 150;
  _imageThumbnail: any;
  _errorMessage: string;
  progress: number;
  origImageWidth: number;
  orgiImageHeight: number;
  fileToUpload: File;
  _imageError = 'ERROR';

  // Localized strings
  uploadIconName: string;
  textBrowseFile: string;
  subTextBrowseFile: string;
  textMaxFileReached: string;
  textOnlyFilesTypeOf = 'Only file type of';
  textAreSupported = 'are supported';
  textFileCannotMoreThan: string;
  textMb: string;
  textKb: string;

  private static getType(dataUrl: string): string {
    const url = dataUrl.match(/:(.+\/.+;)/);
    return url && url.length > 0 ? url[1] : '';
  }

  propagateChange = (_: any) => {
  };

  writeValue(value: any): void {
    if (value) {
      this.loadAndResize(value);
    } else {
      this._imageThumbnail = undefined;
      this.status = Status.NotSelected;
    }
  }

  registerOnChange(fn: (_: any) => void): void {
    this.propagateChange = fn;
  }

  ngOnInit(): void {
    if (this.options) {
      if (this.options.thumbnailWidth) {
        this.thumbnailWidth = this.options.thumbnailWidth;
      }
      if (this.options.thumbnailHeight) {
        this.thumbnailHeight = this.options.thumbnailHeight;
      }
      if (this.options.resizeOnLoad === undefined) {
        this.options.resizeOnLoad = true;
      }
      if (this.options.textBrowseFile) {
        this.textBrowseFile = this.options.textBrowseFile;
      }
      if (this.options.subTextBrowseFile) {
        this.subTextBrowseFile = this.options.subTextBrowseFile;
      }
      if (this.options.uploadIconName) {
        this.uploadIconName = this.options.uploadIconName;
      }

      // Set initial image if any provided
      if (this.imageUrl && this.imageUrl.length > 0) {
        this.writeValue(this.imageUrl);
      } else if (this.fileId && this.fileId.length > 0) {
        this.status = Status.Loading;
        this.uploader.getImageById(this.fileId).subscribe(
          fileUrl => {
            this.imageUrl = fileUrl ? fileUrl : null;
            this.writeValue(fileUrl ? fileUrl : this._imageError);
          }, err => {
            this.writeValue(this._imageError);
          });
      } else if (this.resourceData) {
        this.uploader.getResourceImage(this.resourceData).subscribe(
          fileUrl => {
            this.writeValue(fileUrl);
          }, err => {
            this.writeValue(err);
          });
      }
    }
  }

  loadAndResize(url: string): void {
    this.status = Status.Loading;

    // If no image then set 404
    if (url === this._imageError) {
      this.errorMessage = '404';
      return;
    }
    this.uploader.getFile(url, this.options).subscribe(file => {
      if (this.options.resizeOnLoad) {
        // thumbnail
        const result: ImageResult = {
          file,
          url: URL.createObjectURL(file)
        };

        this.resize(result).then(r => {
          this._imageThumbnail = r.resized.dataURL;
          this.status = Status.Loaded;
        });
      } else {
        const result: ImageResult = {
          file: null,
          url: null
        };
        this.fileToDataURL(file, result).then(r => {
          this._imageThumbnail = r.dataURL;
          this.status = Status.Loaded;
        });
      }
    }, error => {
      this.errorMessage = error || 'Error while getting an image';
      this.onError.emit(this.errorMessage);
    });
  }

  onImageClicked(): void {
    this.renderer.selectRootElement(this.fileInputElement.nativeElement).click();
  }

  onFileChanged(): void {
    const file = this.fileInputElement.nativeElement.files[0];
    if (!file) {
      return;
    }
    this.validateAndUpload(file);
  }

  validateAndUpload(file: File): void {
    this.propagateChange(null);

    if (this.options && this.options.allowedImageTypes) {
      if (!this.options.allowedImageTypes.some(allowedType => file.type === 'image/' + allowedType)) {
        this.errorMessage = this.textOnlyFilesTypeOf + ' ' + this.options.allowedImageTypes.join(', ') + ' ' + this.textAreSupported;
        this.onError.emit(this.errorMessage);
        return;
      }
    }

    if (this.options && this.options.maxImageSize) {
      if (file.size > this.options.maxImageSize * 1024 * 1024) {
        this.errorMessage = `${this.textFileCannotMoreThan} ${this.options.maxImageSize} ${this.textMb}`;
        this.onError.emit(this.errorMessage);
        return;
      }
    }

    this.fileToUpload = file;

    // thumbnail
    const result: ImageResult = {
      file,
      url: URL.createObjectURL(file)
    };

    this.resize(result).then(r => {
      this._imageThumbnail = r.resized.dataURL;
      this.origImageWidth = r.width;
      this.orgiImageHeight = r.height;

      this.status = Status.Selected;

      this.onSelect.emit([file]);
    });
  }

  removeImage(): void {
    this.fileInputElement.nativeElement.value = null;
    this.imageThumbnail = undefined;

    this.onRemove.emit(true);
  }

  dismissError(): void {
    this.errorMessage = undefined;
    this.removeImage();
  }

  drop(e: DragEvent): void {
    e.preventDefault();
    e.stopPropagation();

    if (!e.dataTransfer || !e.dataTransfer.files.length) {
      return;
    }

    this.validateAndUpload(e.dataTransfer.files[0]);
    this.updateDragOverlayStyles(false);
  }

  dragenter(e: DragEvent): void {
    e.preventDefault();
    e.stopPropagation();
  }

  dragover(e: DragEvent): void {
    e.preventDefault();
    e.stopPropagation();
    this.updateDragOverlayStyles(true);
  }

  dragleave(e: DragEvent): void {
    e.preventDefault();
    e.stopPropagation();
    this.updateDragOverlayStyles(false);
  }

  private updateDragOverlayStyles(isDragOver: boolean): void {
    // TODO: find a way that does not trigger dragleave when displaying overlay
    // if (isDragOver) {
    //  this.renderer.setElementStyle(this.dragOverlayElement.nativeElement, 'display', 'block');
    // } else {
    //  this.renderer.setElementStyle(this.dragOverlayElement.nativeElement, 'display', 'none');
    // }
  }

  private resize(result: ImageResult): Promise<ImageResult> {
    const resizeOptions: ResizeOptions = {
      resizeHeight: this.thumbnailHeight,
      resizeWidth: this.thumbnailWidth,
      resizeType: result.file.type,
      resizeMode: this.options.thumbnailResizeMode
    };

    return new Promise((resolve) => {
      createImage(result.url, image => {
        const dataUrl = resizeImage(image, resizeOptions);

        result.width = image.width;
        result.height = image.height;
        result.resized = {
          dataURL: dataUrl,
          type: EevoImageUploaderComponent.getType(dataUrl)
        };

        resolve(result);
      });
    });
  }

  private fileToDataURL(file: File, result: ImageResult): Promise<ImageResult> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        result.dataURL = reader.result.toString();
        resolve(result);
      };
      reader.readAsDataURL(file);
    });
  }

  ngAfterViewChecked(): void {
  }

  ngOnDestroy(): void {
  }

  registerOnTouched(fn: any): void {
  }

  setDisabledState(isDisabled: boolean): void {
  }

  openViewer(): void {
    if (this.imageUrl) {
      const dialogRef = this.matDialog.open(ImagePreviewerComponent, {
        data: {imageUrl: this.imageUrl}
      });
    } else {
      console.log('OpenViewer ImageURL ->', this.imageUrl);
    }
  }
}
