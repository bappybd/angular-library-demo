import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoImageUploaderComponent } from './eevo-image-uploader.component';

describe('EevoImageUploaderComponent', () => {
  let component: EevoImageUploaderComponent;
  let fixture: ComponentFixture<EevoImageUploaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoImageUploaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoImageUploaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
