import {Component, Inject, OnInit} from "@angular/core";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {MatSliderChange} from "@angular/material/slider";

export interface ImageUrlModel {
  imageUrl: string;
}

@Component({
  selector: 'app-image-previewer',
  templateUrl: './image-previewer.component.html',
  styleUrls: ['./image-previewer.component.scss']
})
export class ImagePreviewerComponent implements OnInit {
  zoomLevel = 1;

  constructor(
    public dialogRef: MatDialogRef<ImagePreviewerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ImageUrlModel) {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

  onSliderValueChange($event: MatSliderChange): void {
    const zoomLevel = ($event.value / 10);
    this.zoomLevel = zoomLevel;
  }
}
