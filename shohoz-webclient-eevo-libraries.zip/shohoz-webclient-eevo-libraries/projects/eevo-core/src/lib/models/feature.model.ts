export interface EevoFeature {
  Name: string;
  Type: string;
  Key: string;
}
