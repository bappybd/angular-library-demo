export interface UserModel {
  Issuer: string;
  UserId: string;
  PhoneNumber: string;
  UserName: string;
  Email: string;
  Role: string[];
  FirstName: string;
  LastName: string;
  DisplayName: string;
  ExpiredOn: string | any;
}
