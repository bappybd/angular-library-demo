export class EntityBaseModel {

  public _id: string;
  public Id: string;

}
