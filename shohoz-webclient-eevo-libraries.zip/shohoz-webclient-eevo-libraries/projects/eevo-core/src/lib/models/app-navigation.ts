export class AppNavigation
{
  public _id: string;
  public Id: string;

  public QueryFilter: string;

  public Key: string;

  public Title: string;

  public Type: "item" | "group" | "collapsable"; // item, group, collapsable

  public Icon: string;

  public Url: string;

  public ParentId: string;

  public Order: number;

  public Children: AppNavigation[];

  public RolesAllowedToRead: string[];

  public MetaData: any[];

  public ExactMatch?: boolean;
  public ExternalUrl?: boolean;
  public OpenInNewTab?: boolean;
}
