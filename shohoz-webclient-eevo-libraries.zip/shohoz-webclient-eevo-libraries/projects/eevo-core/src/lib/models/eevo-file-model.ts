export interface CreateFilesByKeyModel {
  FileId: string;
  Key: string;
}

export interface CreateFileModel {
  FileId: string;
  Name: string;
  AccessType: string;
  MetaData: object;
}

export interface FileCreatedEventModel {
  FileId: string;
  Name: string;
  AccessType: string;
  MetaData: object;
  UploadUri: FileUploadUriModel;
}

class FileUploadUriModel {
  FileId: string;
  UploadUriWithSas: string;
}

export class FilesModel {
  constructor() {
    this.Files = [];
  }
  public Files: FileModel[];
}

export class FileModel {
  public FileId: string;
  public FileData: File;
  public Type: string;
}

