export class AuthRedirectionModel {
  Role: string;
  Authenticated: string;
  Unauthenticated: string;
}
