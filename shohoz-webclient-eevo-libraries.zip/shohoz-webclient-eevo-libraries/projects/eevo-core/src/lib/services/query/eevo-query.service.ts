import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EevoQueryService {

  constructor(
    private http: HttpClient
  ) {
  }

  getDetailsById<T>(serviceUrl: string, entityName: string, id: string, fields: string[]): Observable<T> {
    const query = `{ '_id' : GUID('${id}')  }`;

    const requestBody = [
      {
        source: entityName,
        text: null,
        filter: query,
        fields,
        orderBy: 'Language',
        descending: false,
        pageSize: 1,
        pageIndex: 0
      }
    ];

    return this.http.post(serviceUrl, requestBody).pipe(
      map((response: any) => {
        if (response && response[0]) {
          return response[0][0] as T;
        }
        return null;
      })
    );
  }

  getListCount(serviceUrl: string, entityName: string, filter: string = '{}'): Observable<number> {
    const requestBody = [
      {
        source: entityName,
        text: null,
        filter,
        CountOnly: true,
        pageSize: 10,
        pageIndex: 0
      }
    ];

    return this.http.post(serviceUrl, requestBody).pipe(
      map((response: any) => {
        if (response && response[0] && response[0][0] && response[0][0][0]) {
          return response[0][0][0] as number;
        }
        return 0;
      })
    );
  }

  getList<T>(serviceUrl: string, entityName: string, fields: string[], filter: string = '{}', pageIndex: number = 0, pageSize: number = 10,
             orderBy: string = 'CreatedDate', descending: boolean = false): Observable<T[]> {
    const requestBody = [
      {
        source: entityName,
        text: null,
        filter,
        fields,
        orderBy,
        descending,
        pageSize,
        pageIndex
      }
    ];

    return this.http.post(serviceUrl, requestBody).pipe(
      map((response: any) => {
        if (response && response[0]) {
          return response[0] as T[];
        }
        return null;
      })
    );
  }

}
