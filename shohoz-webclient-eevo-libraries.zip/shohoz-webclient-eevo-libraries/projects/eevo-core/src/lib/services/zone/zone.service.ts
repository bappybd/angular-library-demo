import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ZoneService {

  requestOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    }),
    withCredentials: true
  };

  constructor(
    private http: HttpClient,
    @Inject('config') private config: any
  ) {
  }

  getFoodCities(): Observable<any> {
    return this.http.get(this.config.ZoneService + 'foods/fetch-cities');
  }

  getFoodZones(): Observable<any> {
    return this.http.get(this.config.ZoneService + 'foods/fetch-zones', this.requestOptions);
  }
}
