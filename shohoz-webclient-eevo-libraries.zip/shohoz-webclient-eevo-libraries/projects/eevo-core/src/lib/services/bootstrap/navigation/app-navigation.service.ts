import {Inject, Injectable} from '@angular/core';
import {AppNavigation} from '../../../models/app-navigation';
import {SecureStorageService} from '../../utility/secure-storage-service';
import {EevoQueryService} from "../../query/eevo-query.service";
import {FeatureProvider} from "../feature/feature.provider";
import {NavigationProvider} from "./navigation.provider";
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AppNavigationService {

  private features;
  private navigation;

  constructor(
    private eevoQueryService: EevoQueryService,
    private featureProvider: FeatureProvider,
    private navigationProvider: NavigationProvider,
    private secureStorageService: SecureStorageService,
    @Inject('config') private config: any
  ) {
  }

  saveNavigationAndFeatures(): void {
    if (!this.features) {
      this.features = this.featureProvider.getFeature();
    }

    if (!this.navigation) {
      this.navigation = this.navigationProvider.getCurrentNavigation();
    }

    // console.log(this.features, this.navigation);
  }

  getAndSetAppNavigations(host?: string): void {
    this.saveNavigationAndFeatures();

    const entityName = 'AppNavigations';
    const fields = [
      'Key', 'Title', 'Type', 'Icon', 'IsFeatureFound', 'Url', 'ParentId', 'RolesAllowedToRead', 'Order'
    ]
    let filter = `{'IsActive': true}`;
    if (host) {
      filter = `{'IsActive': true, 'Host': '${host}'}`;
    }
    const pageIndex = 0;
    const pageSize = 100;

    this.eevoQueryService.getList(
      this.config.AppConfigService.toQueryURL(), entityName, fields, filter, pageIndex, pageSize, 'Order'
    ).subscribe((response: AppNavigation[]) => {
      const navigations = response;

      if (navigations) {
        this.setFeatures(navigations);

        const parentNavigations = navigations.filter(f => {
          return f.ParentId == '' || f.ParentId == null;
        });

        parentNavigations.forEach((nav, index) => {
          const childNavigations = navigations.filter(f => {
            return f.ParentId == nav.Id;
          });
          parentNavigations[index].Children = childNavigations.sort(s => {
            return s.Order;
          });
          this.setNavigation(parentNavigations[index]);
        });

        this.navigationProvider.setCurrentNavigations(this.navigation);
      }

    });
  }

  private setFeatures(appNavigations: AppNavigation[]): void {

    appNavigations.forEach(appNavigation => {
      if (appNavigation && appNavigation.RolesAllowedToRead) {
        appNavigation.RolesAllowedToRead.forEach(fca => {
          if (!(this.features[fca])) {
            this.features[fca] = [];
          }
          const featureIndex = this.features[fca].findIndex(item => {
            return item.Name == appNavigation.Key;
          });
          if (featureIndex == -1) {
            this.features[fca].push({
              Name: appNavigation.Key,
              Type: 'business',
            });
          }
        });
      }
    });

    this.setFeaturesToLocalStorage(this.features);
    this.featureProvider.resetFeatures();
    this.featureProvider.setFeature(this.features);
  }

  public getFeaturesFromStorage() : any {
    return this.secureStorageService.getSecureData('features');
  }

  private setFeaturesToLocalStorage(features: any) : void {
    this.secureStorageService.setSecureData('features', features);
  }

  private setNavigation(appNavigation: AppNavigation): void {

    if (appNavigation && appNavigation.Children) {
      const children = appNavigation.Children;
      const navigationList = [];

      const appNav = children.forEach((child) => {
        const nav = {
          id: child.Key,
          title: child.Title,
          type: child.Type,
          icon: child.Icon,
          isFeatureFound: child.IsFeatureFound,
          url: this.getNavUrl(child),
        };

        navigationList.push(nav);
      });

      const navObj = {
        id: appNavigation.Key,
        title: appNavigation.Title,
        type: appNavigation.Type,
        icon: appNavigation.Icon,
        isFeatureFound: appNavigation.IsFeatureFound,
        url: this.getNavUrl(appNavigation),
        children: navigationList
      };

      const navIndex = this.navigation.findIndex(item => {
        return item.id == appNavigation.Key;
      });

      if (navIndex == -1) {
        this.navigation.push(navObj);
      }
    }

  }

  private getNavUrl(appNavigation: AppNavigation): string {
    if (appNavigation && appNavigation.Url) {
      const url = appNavigation.Url.replace('{{APP-NAV-ID}}', appNavigation.Id);

      return url;
    }

    return '';
  }

}
