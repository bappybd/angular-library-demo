import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree} from "@angular/router";
import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {UserDataService} from "../user/user-data.service";
import {FeatureNavigationProvider} from '../feature-navigation.provider';

@Injectable({providedIn: "root"})
export class IsUnauthenticatedGuard implements CanActivate {

  constructor(
    private router: Router,
    private userDataService: UserDataService,
    private featureNavigationProvider: FeatureNavigationProvider
  ) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (!this.userDataService.isUserLoggedIn()) {
      return true;
    } else {
      const navigations = this.featureNavigationProvider.getNavigations();
      if (navigations && navigations.length) {
        const navigation = navigations.find(nav => {

          console.log(nav, nav.url, !nav.externalUrl,
            (!!(nav && nav.url && !nav.externalUrl) ||
              (nav.children && nav.children?.length)));

          return (!!(nav && nav.url && !nav.externalUrl)
            || (nav.children && nav.children?.length)
          );
        });
        if (navigation) {
          let redirectUrl = null;
          if (navigation.url && navigation.url !== '') {
            redirectUrl = navigation.url;
          } else if (navigation.children && navigation.children.length > 0){
            const nav = navigation.children.find(n => {
              console.log(n, n.url, !n.externalUrl);
              return !!(n && n.url && !n.externalUrl);
            });

            redirectUrl = nav.url;
          }

          if (redirectUrl) {
            this.router.navigate([redirectUrl]);
          }
        }
      }

      return true;
      // this.redirect(route);
    }
  }

  redirect(route: ActivatedRouteSnapshot): void {
    const baseUrl = '/';
    const redirect = route?.data?.redirect;
    const userData = this.userDataService.getUserData();

    if (Array.isArray(redirect) && userData) {
      const redirectData = redirect.find(r => {
        return userData.Role.includes(r.Role);
      });

      this.router.navigate([redirectData.Authenticated]);
    }

    if (!redirect || !userData) {
      this.router.navigate([baseUrl]);
    }
  }
}
