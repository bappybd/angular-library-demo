import {Injectable, Injector, Inject} from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpHeaders,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import {BehaviorSubject, Observable, throwError} from 'rxjs';
import {catchError, retry, switchMap} from 'rxjs/operators';
import {TokenManagerService} from '../token/token-manager.service';
import {Router} from '@angular/router';
import {CookieService} from 'ngx-cookie-service';
import {TokenStateService} from "../token/token-state.service";
import {UserDataService} from "../user/user-data.service";

@Injectable({
  providedIn: 'root',
})
export class HttpInterceptorService implements HttpInterceptor {
  private tokenStateObservable: BehaviorSubject<string>;

  constructor(
    private injector: Injector,
    private cookieService: CookieService,
    private tokenStateService: TokenStateService,
    private tokenManagerService: TokenManagerService,
    private userDataService: UserDataService,
    @Inject('config') private config: any
  ) {
    this.tokenStateObservable = this.tokenStateService.getTokenStateObservable();
  }

  public intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    let currentOrigin = window.location.hostname;

    const skipIntercept = req.headers.has('skip');
    if (skipIntercept) {
      req = req.clone({
        headers: req.headers.delete('skip')
      });

      return next.handle(req);
    }

    const hasContentType = req.headers.has('Content-Type');
    if (!hasContentType) {
      req = req.clone({
        setHeaders: {
          'Content-Type': 'application/json'
        },
        withCredentials: true
      });
    }

    const isVerticalEnable = this.config?.VerticalInfo?.IsEnable;
    if (isVerticalEnable) {
      const hasVerticalId = req.headers.has('x-vertical-id');
      if (!hasVerticalId) {
        req = req.clone({
          setHeaders: {
            'x-vertical-id': this.config.VerticalInfo.Default
          }
        });
      }
    }

    const tokenUrl = this.config.IAMService.toLowerCase() + 'token';

    return next.handle(req).pipe(catchError((err: HttpErrorResponse) => {
        if (err.url && err.url.toLowerCase() === tokenUrl && err.status === 400) {
          const that = this;

          this.tokenManagerService.resetAnonymousToken().subscribe((res) => {
            this.tokenStateObservable.next('400_RECOVERED');

            const router = this.injector.get(Router);
            router.navigate(['/']);

            return throwError('');
          });

          return throwError(err);
        } else if (err.status === 401) {
          return this.tokenManagerService.renewAccessToken().pipe(switchMap((newToken: any) => {
              this.userDataService.setUser(newToken?.access_token);
              const authReq = req.clone({withCredentials: true});
              this.tokenStateObservable.next('401_RECOVERED');
              return next.handle(authReq);
            })
          );
        } else {
          return throwError(err);
        }
      })
    );
  }
}
