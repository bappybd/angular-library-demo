import {BehaviorSubject, Observable} from "rxjs";
import {Injectable} from "@angular/core";
import {Navigation} from "../../../models/navigation.model";
import {FeatureProvider} from "../feature/feature.provider";
import {EevoFeature} from "../../../models/feature.model";

@Injectable({
  providedIn: "root",
})
export class NavigationProvider {
  private navigations: Navigation[];
  private navigationsObservable: BehaviorSubject<Navigation[]>;

  constructor(
    private featureProvider: FeatureProvider
  ) {
    this.navigationsObservable = new BehaviorSubject<Navigation[]>([]);

    this.featureProvider.onUpdate().subscribe(val => {
      if (this.navigations && this.navigations.length && val && val.length) {
        this.navigationsVisibility(val);
      }
    });
  }

  // Get the navigations
  public getCurrentNavigationObservable(): Observable<Navigation[]> {
    return this.navigationsObservable;
  }

  public getCurrentNavigation(): Navigation[] {
    return this.navigations;
  }

  /**
   * Set Navigations
   * @param navigations
   */
  public setCurrentNavigations(navigations: Navigation[]): void {
    //@if no navigation
    //@then return
    if (!navigations.length) return;

    // Set the navigation;
    this.navigations = navigations;

    // Identify whose link will be shown in the navbar
    this.assignNavigationsVisibility();
  }

  private assignNavigationsVisibility(): void {
    this.featureProvider.get().subscribe((features: EevoFeature[]) => {
      /**
       * Filter Navigation
       * filter navigation from the featurelist
       * @if feature is in the list --> isFeatureFound = true
       * @or isFeatureFound = false
       */

      this.navigationsVisibility(features);
    });
  }

  private navigationsVisibility(features: EevoFeature[]): void {
    /*---Call the feature provider for getting role based features--*/
    const NAVIGATIONS = JSON.parse(JSON.stringify(this.navigations));

    const filterNavigation = this.filterNavigation(
      NAVIGATIONS,
      features
    );

    // Broadcast the event with filterNavigation
    this.navigationsObservable.next(filterNavigation);
  }

  private filterNavigation(navigations: Navigation[], features: EevoFeature[]) {
    return navigations.map((item: Navigation) => {
      if (item.type === "collapsable" || item.type === "group") {
        if (
          !!features.filter((feature) => feature.Key === item.id)
            .length
        ) {
          if (item.hasOwnProperty("hidden")) {
            item.isFeatureFound = item.hidden;
          } else {
            if (!item.children.length) return;

            item.isFeatureFound = true;

            // Same implementation for children
            this.filterNavigation(item.children, features);
          }
        } else {
          item.isFeatureFound = false;
        }
      } else if (
        !!features.filter((feature) => feature.Key === item.id).length
      ) {
        if (item.hasOwnProperty("hidden")) {
          item.isFeatureFound = item.hidden;
        } else {
          item.isFeatureFound = true;
        }
      } else {
        item.isFeatureFound = false;
      }

      return item;
    });
  }
}
