import {Injectable, Inject} from '@angular/core';
import {TokenManagerService} from "./token/token-manager.service";
import {CookieService} from "ngx-cookie-service";
import {Observable} from "rxjs";
import {UserDataService} from "./user/user-data.service";
import {FeatureNavigationProvider} from "./feature-navigation.provider";

@Injectable({
  providedIn: 'root'
})
export class InitializerFactory {
  constructor(
    @Inject('config') private config: any,
    private cookieService: CookieService,
    private userDataService: UserDataService,
    private tokenManagerService: TokenManagerService,
    private featureNavigationProvider: FeatureNavigationProvider
  ) {
  }

  public start(): Observable<any> {

    return new Observable((observer) => {
      this.initalize().subscribe(data => {
        this.featureNavigationProvider.loadFromServer().subscribe(() => {
          observer.next(data);
        }, error => {
          observer.error();
        });
      }, error => {
        observer.error();
      });
    });

  }

  private initalize(): Observable<any> {
    const refreshToken = this.cookieService.get("REFRESH_TOKEN");
    const hasRefreshToken = refreshToken?.length > 0;
    const SSOEnabled = this.config.SSOEnabled;

    if (SSOEnabled) {
      return new Observable((observer) => {
        this.tokenManagerService.getSSOTokenForClient().subscribe(data => {
          if (data && data.sso_token) {
            this.tokenManagerService.authenticateUserWithSSO(data.sso_token).subscribe(response => {
              this.userDataService.setUser(response.access_token);
              observer.next(true);
            }, error => {
              observer.next(false);
            });
          }
        }, error => {
          this.authenticateOrRenewToken(hasRefreshToken).subscribe(data => {
            observer.next(data);
          }, err => {
            observer.error();
          });
        });
      });
    } else {
      return this.authenticateOrRenewToken(hasRefreshToken);
    }
  }

  private authenticateOrRenewToken(hasRefreshToken: boolean): Observable<any> {
    if (hasRefreshToken) {
      return this.tokenManagerService.renewAccessToken();
    } else {
      return this.tokenManagerService.resetAnonymousToken();
    }
  }

}
