import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree} from "@angular/router";
import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {UserDataService} from "../user/user-data.service";

@Injectable({providedIn: "root"})
export class IsAuthenticatedGuard implements CanActivate {

  constructor(
    private router: Router,
    private userDataService: UserDataService,
  ) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (!!this.userDataService.isUserLoggedIn()) {
      return true;
    } else {
      this.redirect(route);
    }
  }

  redirect(route: ActivatedRouteSnapshot): void {
    const loggedOutRedirectTo = '/login';
    const redirect = route?.data?.redirect;
    const userData = this.userDataService.getUserData();

    if (!redirect || !userData) {
      this.router.navigate([loggedOutRedirectTo]);
    }

    if (Array.isArray(redirect) && userData) {
      const redirectData = redirect.find(r => {
        return userData.Role.includes(r.Role);
      });

      this.router.navigate([redirectData.Unauthenticated]);
    }
  }
}
