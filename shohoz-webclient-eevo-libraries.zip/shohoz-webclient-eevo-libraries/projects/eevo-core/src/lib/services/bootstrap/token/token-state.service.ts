import { Injectable } from '@angular/core';
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class TokenStateService {

  tokenStateObservable: BehaviorSubject<string>;

  constructor() {
    this.tokenStateObservable = new BehaviorSubject('initial');
  }

  public getTokenStateObservable() {
    return this.tokenStateObservable;
  }

  public setTokenStateObservable(state) {
    this.tokenStateObservable.next(state);
  }
}
