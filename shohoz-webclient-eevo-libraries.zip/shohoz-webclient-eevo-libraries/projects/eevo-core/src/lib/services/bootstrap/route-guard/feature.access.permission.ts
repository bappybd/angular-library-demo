import {Injectable, Inject, PLATFORM_ID} from "@angular/core";
import {ActivatedRouteSnapshot, CanActivate, Router} from "@angular/router";
import {Observable} from "rxjs";
import {FeatureProvider} from "../feature/feature.provider";

// import Model
import {EevoFeature} from "../../../models/feature.model";
import {UserDataService} from "../user/user-data.service";

@Injectable({
  providedIn: "root",
})
export class FeatureAccessPermission implements CanActivate {
  constructor(
    private router: Router,
    private userDataService: UserDataService,
    private featureProvider: FeatureProvider,
    @Inject(PLATFORM_ID) private platform
  ) {
  }

  canActivate(
    route: ActivatedRouteSnapshot
  ): boolean | Promise<boolean> | Observable<boolean> {
    // Check: platform is browser ot not
    if (this.platform === "browser") {
      // @if this route have access the return true
      // @else false

      return this.routeHaveAccess(route);
    }
  }

  async routeHaveAccess(route: ActivatedRouteSnapshot) {
    const features = (await this.getValidFeatureList()) as EevoFeature[];
    const IS_ROUTE_VALID = this.isRouteValid(route, features);
    if (IS_ROUTE_VALID) {
      return true;
    } else {
      return false;
      // this.redirect(route);
    }
  }

  getValidFeatureList() {
    return new Promise((resolve, reject) => {
      this.featureProvider.get().subscribe(
        (features) => {
          resolve(features);
        },
        (error) => {
          reject(error);
        }
      );
    });
  }

  isRouteValid(route: ActivatedRouteSnapshot, features: EevoFeature[]): boolean {
    if (!features.length) return;
    const {name: REQUIRED_FEATURE} = route.data;
    const IS_ROUTE_ACTIVATED: boolean = !!features.filter(
      (feature: EevoFeature) => feature.Key === REQUIRED_FEATURE
    ).length;

    return IS_ROUTE_ACTIVATED;
  }

  redirect(route: ActivatedRouteSnapshot) {
    const redirect = route?.data?.redirect;
    const loggedOutRedirectTo = "/login";
    let loggedInRedirectTo = "";

    if (this.userDataService.isUserLoggedIn()) {
      const userData = this.userDataService.getUserData();
      redirect?.forEach(r => {
        if (userData.Role.includes(r.Role)){
          loggedInRedirectTo = r.Authenticated;
        }
      });
      this.router.navigate([loggedInRedirectTo]);
    } else {
      this.router.navigate([loggedOutRedirectTo]);
    }
  }
}
