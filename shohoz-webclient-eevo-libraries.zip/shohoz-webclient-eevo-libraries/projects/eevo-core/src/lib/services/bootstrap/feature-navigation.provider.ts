import {BehaviorSubject, Observable, Subject} from 'rxjs';
import {Inject, Injectable} from '@angular/core';
import {Navigation} from '../../models/navigation.model';
import {FeatureProvider} from './feature/feature.provider';
import {NavigationProvider} from './navigation/navigation.provider';
import {AppNavigation} from '../../models/app-navigation';
import {EevoQueryService} from '../query/eevo-query.service';
import {UserDataService} from './user/user-data.service';

@Injectable({
  providedIn: 'root',
})
export class FeatureNavigationProvider {
  private features = {};
  private navigations: Navigation[] = [];
  private appNavigations: AppNavigation[] = [];
  private featureLoaded = new Subject<any>();

  constructor(
    @Inject('config') private config: any,
    private userDataService: UserDataService,
    private featureProvider: FeatureProvider,
    private eevoQueryService: EevoQueryService,
    private navigationProvider: NavigationProvider,
  ) {
    this.userDataChangeEvent();
  }

  onLoaded(): Observable<any> {
    return this.featureLoaded.asObservable();
  }

  set(features: any, navigations: Navigation[]): void {

    if (!(this.config?.EnableStaticFeatureNavigation)) {
      // this.loadFromServer().subscribe(() => {
      //   this.featureLoaded.next();
      //   console.log(this.navigations, this.features);
      // });
      return;
    } // else {
    this.features = features;
    this.navigations = navigations;
    this.featureProvider.setFeature(features);
    this.navigationProvider.setCurrentNavigations(navigations);
    this.featureLoaded.next();
    // }

  }

  loadFromServer(): Observable<any> {

    return new Observable((observer) => {

      if (!(this.config?.EnableStaticFeatureNavigation)) {
        const hostName = this.config?.HostName;

        this.getAppFeaturesFromDB(hostName).subscribe((response: any[]) => {
          const features = response;
          if (features) {
            this.setFeatures(features);
          }
          this.setAppNavigationsFromDB(hostName).subscribe(() => {
            this.navigationProvider.setCurrentNavigations(this.navigations);
            observer.next();
          }, error => {
            return observer.error();
          });
        }, error => {
          return observer.error();
        });

      } else {
        observer.next();
      }

    });
  }

  getAppNavigationByKey(navKey: string): AppNavigation {
    return this.appNavigations.find(nav => {
      return nav.Key === navKey;
    });
  }

  getAppNavigationById(id: string): AppNavigation {
    return this.appNavigations.find(nav => {
      return (nav.Id === id || nav._id === id);
    });
  }

  getAppNavigation(): AppNavigation[] {
    return this.appNavigations;
  }

  getNavigations(): Navigation[] {
    return this.navigations;
  }

  private userDataChangeEvent(): void {
    this.userDataService.currentUserData.subscribe(response => {
      if (response === 'USER_LOGGED_OUT') {
        this.featureProvider.resetFeatures();
      } else if ((typeof response === 'object') && this.userDataService.isUserLoggedIn()) {
        // this.set(this.features, this.navigations);
        this.loadFromServer().subscribe(() => {
          this.featureLoaded.next();
          // console.log(this.navigations, this.features);
        });
      } else if (response === 'USER_DEFAULT_MESSAGE' && this.userDataService.isUserLoggedIn()) {
        // console.log('FeatureNavigationProvider UserDataChangeEvent step 3');
      }
    });
  }

  private getAppFeaturesFromDB(host?: string): Observable<any> {
    const entityName = 'AppFeatures';
    const fields = [
      'Name', 'Key', 'RolesAllowedToRead'
    ];

    let filter = `{'IsActive': true}`;

    if (host) {
      filter = `{'IsActive': true, 'Host': '${host}'}`;
    }
    const pageIndex = 0;
    const pageSize = 250;

    return this.eevoQueryService.getList(
      this.config.AppConfigService.toQueryURL(), entityName, fields, filter, pageIndex, pageSize
    );
  }

  private setAppNavigationsFromDB(host?: string): Observable<any> {

    return new Observable((observer) => {

      const entityName = 'AppNavigations';
      const fields = [
        'Key', 'Title', 'Type', 'Icon', 'IsFeatureFound', 'Url', 'ParentId',
        'RolesAllowedToRead', 'Order', 'MetaData', 'ExactMatch', 'ExternalUrl',
        'OpenInNewTab'
      ];

      let filter = `{'IsActive': true}`;
      if (host) {
        filter = `{'IsActive': true, 'Host': '${host}'}`;
      }
      const pageIndex = 0;
      const pageSize = 100;

      this.eevoQueryService.getList(
        this.config.AppConfigService.toQueryURL(), entityName, fields, filter, pageIndex, pageSize, 'Order'
      ).subscribe((response: AppNavigation[]) => {
        this.navigations = [];
        const navigations = response;

        if (navigations) {
          this.appNavigations = [...navigations];
          this.setFeatures(navigations, true);

          const parentNavigations = navigations.filter(f => {
            return f.ParentId == '' || f.ParentId == null;
          });

          parentNavigations.forEach((nav, index) => {
            const childNavigations = navigations.filter(f => {
              return f.ParentId == nav.Id;
            });
            parentNavigations[index].Children = childNavigations.sort(s => {
              return s.Order;
            });
            this.setNavigations(parentNavigations[index]);
          });
        }
        observer.next();
      }, error => {
        observer.next();
      });

    });
  }

  private setNavigations(appNavigation: AppNavigation): void {

    if (appNavigation && appNavigation.Children) {
      const children = appNavigation.Children;
      const navigationList = [];

      const appNav = children.forEach((child) => {
        const nav = {
          id: child.Key,
          title: child.Title,
          type: child.Type,
          icon: child.Icon,
          exactMatch: child.ExactMatch,
          externalUrl: child.ExternalUrl,
          openInNewTab: child.OpenInNewTab,
          url: this.getNavUrl(child),
        };

        navigationList.push(nav);
      });

      const navObj = {
        id: appNavigation.Key,
        title: appNavigation.Title,
        type: appNavigation.Type,
        icon: appNavigation.Icon,
        exactMatch: appNavigation.ExactMatch,
        externalUrl: appNavigation.ExternalUrl,
        openInNewTab: appNavigation.OpenInNewTab,
        url: this.getNavUrl(appNavigation),
        children: navigationList
      };

      const navIndex = this.navigations.findIndex(item => {
        return item.id == appNavigation.Key;
      });

      if (navIndex == -1) {
        this.navigations.push(navObj);
      }
    }

  }

  private getNavUrl(appNavigation: AppNavigation): string {
    if (appNavigation && appNavigation.Url) {
      let url = appNavigation.Url;
      url = url.replace('{{APP-NAV-ID}}', appNavigation.Id);
      url = url.replace('{{APP-NAV-KEY}}', appNavigation.Key);

      return url;
    }
    return '';
  }

  private setFeatures(itemList: any[], resetEnable?: boolean): void {
    itemList.forEach(item => {
      if (item && item.RolesAllowedToRead && item.Key) {
        const title = item.Title;
        const key = item.Key;
        const roles = item.RolesAllowedToRead;

        roles.forEach(fca => {
          if (!(this.features[fca])) {
            this.features[fca] = [];
          }
          const featureIndex = this.features[fca].findIndex(fItem => {
            return fItem.Key == key;
          });

          if (featureIndex == -1) {
            this.features[fca].push({
              Key: key,
              Name: title,
              Type: 'business',
            });
          }
        });
      }
    });

    if (resetEnable) {
      this.featureProvider.resetFeatures();
      this.featureProvider.setFeature(this.features);
    }
  }
}
