import {Inject, Injectable, Injector} from '@angular/core';
import {BehaviorSubject, Observable} from 'rxjs';
import {JwtHelperService} from '@auth0/angular-jwt';
import {CookieService} from "ngx-cookie-service";
import {UserModel} from "../../../models/user-model";

export const Message: any = {
  DefaultMessage: 'USER_DEFAULT_MESSAGE',
  LoggedOutMessage: 'USER_LOGGED_OUT'
};

@Injectable({
  providedIn: 'root'
})
export class UserDataService {
  private readonly IsUserLoggedIn = 'IsUserLoggedIn';
  private readonly USER_BASIC_INFO = 'USER_BASIC_INFO';

  // private currentUserEvent = new BehaviorSubject<any>(Message.DefaultMessage);
  private currentUserDataSource = new BehaviorSubject<any>(Message.DefaultMessage);
  currentUserData = this.currentUserDataSource.asObservable();

  public userInfo: any = {};

  constructor(
    private injector: Injector,
    private cookieService: CookieService,
    @Inject('config') private config: any
  ) {
    let currentOrigin = window.location.hostname;
  }

  changeCurrentUserData(data: any): void {
    this.currentUserDataSource.next(data);
  }

  resetSubscribeDataOnLogOut(): void {
    this.changeCurrentUserData(Message.DefaultMessage);
  }

  getUser(): Observable<UserModel> {
    return new Observable((observer) => {
      observer.next(this.getUserData());
    });
  }

  setUser(accessToken: string): void {
    try {
      const userParsedData = this.geJwtDecodedUserData(accessToken);
      this.setUserData(userParsedData);
      // set changed user data after set into cookie
      this.changeCurrentUserData(userParsedData);
    } catch (e) {
      this.resetUserData();
    }
  }

  geJwtDecodedUserData(accessToken: string): UserModel {
    const helper = new JwtHelperService();
    const decodedUserData = helper.decodeToken(accessToken);

    let roles: string[] = [];
    if (decodedUserData?.role && !Array.isArray(decodedUserData?.role)) {
      roles.push(decodedUserData.role)
    } else {
      roles = decodedUserData?.role;
    }

    const user: UserModel = {
      Role: roles,
      Issuer: decodedUserData?.iss,
      UserName: decodedUserData?.username,
      Email: decodedUserData?.email,
      PhoneNumber: decodedUserData?.phone_number,
      DisplayName: decodedUserData?.display_name,
      ExpiredOn: new Date(decodedUserData?.exp * 1000),
      FirstName: null, // decodedUserData.display_name,
      LastName: null, // decodedUserData.display_name,
      UserId: decodedUserData?.sub,
    };
    return user;
  }

  setUserData(userData: UserModel): void {
    const expiryDate = userData.ExpiredOn;

    // Set UserLoggedIn value
    this.cookieService.set(this.IsUserLoggedIn, 'true', expiryDate, '/');

    // Set UserBasicInfo data
    this.cookieService.set(this.USER_BASIC_INFO, JSON.stringify(userData || {}), expiryDate, '/');
  }

  getUserData(): UserModel {
    return JSON.parse(this.cookieService.get(this.USER_BASIC_INFO) || '{}');
  }

  resetUserData(): void {
    this.userInfo = {};
    this.cookieService.delete(this.IsUserLoggedIn, '/');
    this.cookieService.delete(this.USER_BASIC_INFO, '/');
    this.changeCurrentUserData(Message.LoggedOutMessage);
  }

  isUserLoggedIn() {
    return this.cookieService.get(this.IsUserLoggedIn) === 'true';
  }

  removeUserLoggedIn() {
    this.cookieService.delete(this.IsUserLoggedIn, '/');
  }

}
