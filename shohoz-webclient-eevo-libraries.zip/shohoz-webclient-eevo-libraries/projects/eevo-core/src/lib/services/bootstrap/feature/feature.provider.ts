import {Injectable} from "@angular/core";
import {map} from "rxjs/operators";
import {deleteFeatures, getFeatures, setFeatures} from "./feature.value";
import {BehaviorSubject, Observable, of, Subject} from "rxjs";
import {UserDataService} from "../user/user-data.service";
import {EevoFeature} from "../../../models/feature.model";

@Injectable({
  providedIn: "root",
})
export class FeatureProvider {
  features: any;
  private featureObservable = new Subject<any>();

  constructor(private userDataService: UserDataService) {
  }

  onUpdate(): Observable<any> {
    return this.featureObservable.asObservable();
  }

  getFeatureList(): any[] {
    return getFeatures();
  }

  get(): Observable<any> {
    const features = getFeatures();
    if (features.length !== 0) {
      return new Observable((observer) => {
        observer.next(features);
      });
    } else {
      return this.userDataService.getUser().pipe(
        map((currentUser) => {
          let featureList = [];

          if (currentUser.Role && this.features) {
            const roles = currentUser.Role;

            if (roles && typeof roles === 'object') {
              roles.forEach(role => {
                const feaList = this.features[role]; // as EevoFeature[];
                if (feaList) {
                  feaList.forEach((item: EevoFeature) => {
                    const hasFeature = featureList.find(fl => {
                      return item.Key === fl.Key && item.Name === fl.Name && item.Type === fl.Type;
                    });
                    if (!hasFeature) {
                      featureList.push(item);
                    }
                  });
                }
              });
            } else if (roles && typeof roles === 'string') {
              featureList = this.features[roles];
            }
          }

          setFeatures(featureList);
          this.featureObservable.next(featureList);

          return featureList;
        })
      );
    }
  }

  getFeature() {
    return this.features;
  }

  setFeature(features) {
    this.features = features;
  }

  public resetFeatures() {
    deleteFeatures();
    this.featureObservable.next();
  }
}
