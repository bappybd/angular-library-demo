import {Injectable, Injector, Inject} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {map, tap} from 'rxjs/operators';
import {Observable} from 'rxjs';
import {CookieService} from 'ngx-cookie-service';
import {UserDataService} from "../user/user-data.service";
import {FeatureProvider} from "../feature/feature.provider";

@Injectable({
  providedIn: 'root',
})
export class TokenManagerService {
  private accessToken: string;
  private refreshToken: string;

  constructor(
    private injector: Injector,
    private cookieService: CookieService,
    @Inject('config') private config: any
  ) {
    let currentOrigin = window.location.hostname;
    this.setAccessToken(this.cookieService.get(currentOrigin));
    this.refreshToken = this.cookieService.get('REFRESH_TOKEN');
  }

  getAccessToken() {
    return this.accessToken;
  }

  setAccessToken(token) {
    this.accessToken = token;
  }

  getRefreshToken() {
    const refresh_token = this.cookieService.get('REFRESH_TOKEN');
    return refresh_token? refresh_token : this.refreshToken;
  }

  setRefreshToken(token) {
    this.refreshToken = token;
    let currentDate = new Date();
    let expiryDate = new Date(currentDate.setMonth(currentDate.getMonth() + 1)).getTime();
    this.cookieService.set('REFRESH_TOKEN', token, expiryDate, '/');
  }

  removeRefreshToken() {
    this.cookieService.delete('REFRESH_TOKEN');
  }

  resetAnonymousToken(): Observable<any> {
    const http = this.injector.get(HttpClient);
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    const body = new HttpParams()
      .set('grant_type', 'authenticate_site')
      .set('client_id', this.config.ClientId)
      .set('scope', this.config.ClientScope);

    return http
      .post(
        this.config.IAMService + 'token',
        body.toString(),
        {headers: header, withCredentials: true}
      ).pipe(tap((result: any) => {
          this.resetUserAndTokenInfo();
          this.setRefreshToken(result.refresh_token);
        })
      );
  }

  getAnonymousToken(): Observable<any> {
    const http = this.injector.get(HttpClient);
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    const body = new HttpParams()
      .set('grant_type', 'authenticate_site')
      .set('client_id', this.config.ClientId)
      .set('scope', this.config.ClientScope);

    return http
      .post(
        this.config.IAMService + 'token',
        body.toString(),
        {headers: header, withCredentials: true}
      ).pipe(tap((result: any) => {
          this.removeRefreshToken();
          this.setRefreshToken(result.refresh_token);
        })
      );
  }

  renewAccessToken(): Observable<any> {
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    const http = this.injector.get(HttpClient);
    const body = new HttpParams()
      .set('grant_type', 'refresh_token')
      .set('client_id', this.config.ClientId)
      .set('scope', this.config.ClientScope)
      .set('refresh_token', this.getRefreshToken());

    return http
      .post(
        this.config.IAMService + 'token',
        body.toString(),
        {headers: header, withCredentials: true}
      ).pipe(
        tap((result: any) => {
          this.removeRefreshToken();
          this.setRefreshToken(result.refresh_token);
        })
      );
  }

  getSSOTokenForClient(): Observable<any> {
    const header = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    const http = this.injector.get(HttpClient);
    const body = {
      ClientId: this.config.ClientId
    };

    return http
      .post(
        this.config.IAMService + `sso/authenticate?ClientId=${this.config.ClientId}`, body,
        {headers: header, withCredentials: true}
      ).pipe(tap((result: any) => {
          return result;
        })
      );
  }

  authenticateUserWithSSO(ssoToken: string): Observable<any> {
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    const http = this.injector.get(HttpClient);
    let body = new HttpParams()
      .set('grant_type', 'sso')
      .set('client_id', this.config.ClientId)
      .set('scope', this.config.ClientScope)
      .set('sso_token', ssoToken);

    return http.post(
      this.config.IAMService + 'connect/token',
      body.toString(),
      {headers: header, withCredentials: true}
    ).pipe(
      map((response: any) => {
        this.removeRefreshToken();
        this.setRefreshToken(response.refresh_token);
        return response;
      })
    );
  }

  revocation(): Observable<any> {
    const http = this.injector.get(HttpClient);
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    const body = new HttpParams()
      .set('client_id', this.config.ClientId)
      .set('token', this.getRefreshToken());

    return http
      .post(
        this.config.IAMService + 'connect/revocation',
        body.toString(),
        {headers: header, withCredentials: true}
      ).pipe(
        tap((result: any) => {
          this.resetUserAndTokenInfo();
        })
      );
  }

  private resetUserAndTokenInfo(): void {
    this.removeRefreshToken();
    const userDataService = this.injector.get(UserDataService);
    userDataService.resetUserData();
    const featureProvider = this.injector.get(FeatureProvider);
    featureProvider.resetFeatures();
  }

}
