import {Inject, Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {CreateFileModel, CreateFilesByKeyModel} from "../../models/eevo-file-model";
import {UtilityService} from "../utility/utility.service";

@Injectable({
  providedIn: 'root'
})
export class EevoStorageService {

  constructor(
    private http: HttpClient,
    @Inject('config') private config: any,
    private utilityService: UtilityService
  ) {
  }

  getFileUrl(fileKey: string): string {
    return this.config.FileUriPrefix + fileKey;
  }

  getFileCreateModel(file: File, fileId?: string): CreateFileModel {
    const createFileModel: CreateFileModel = {
      FileId: fileId ? fileId : this.utilityService.getNewGuid(),
      AccessType: 'Public',
      Name: file.name,
      MetaData: {
        file_size: file.size,
        type: file.type
      }
    };
    return createFileModel;
  }

  getCreateFilesByKeyModel(fileKey: string, fileId?: string): CreateFilesByKeyModel {
    return {
      Key: fileKey,
      FileId: fileId || this.utilityService.getNewGuid()
    };
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Command
  // -----------------------------------------------------------------------------------------------------
  createFile(fileModel: CreateFileModel): Observable<any> {
    return this.createFiles([fileModel]);
  }

  createFiles(fileModels: CreateFileModel[]): Observable<any> {
    return this.http.post(
      this.config.StorageCommandService + 'Files/CreateFiles',
      {
        FileInfos: fileModels,
        CorrelationId: this.utilityService.getNewGuid()
      }
    ).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  createFilesByKey(createFilesByKeyModel: CreateFilesByKeyModel[]): Observable<any> {
    return this.http.post(this.config.StorageCommandService + 'Files/CreateFilesByKey',
      {
        FileInfos: createFilesByKeyModel,
        CorrelationId: this.utilityService.getNewGuid()
      }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  // todo: NEED TO REFACTOR
  uploadFileOld(file: File, url: string): Observable<any> {
    return this.http.put(url, file).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  uploadFile(file: File, url: string): Observable<any> {
    return new Observable(observer => {
      let xhr = new XMLHttpRequest();
      xhr.withCredentials = true;
      xhr.addEventListener('readystatechange', function () {
        if (this.readyState === 4) {
          observer.next(true);
        }
      });
      xhr.open('PUT', url);
      xhr.setRequestHeader('x-ms-blob-type', ' BlockBlob');
      xhr.setRequestHeader('Content-Type', 'image/png');
      xhr.send(file);
    });
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Query
  // -----------------------------------------------------------------------------------------------------

  getFileUploadUrl(fileId: string): Observable<any> {
    return this.getFileUploadUrls([fileId]);
  }

  getFileUploadUrls(fileIds: string[]): Observable<any> {
    return this.http.post(this.config.StorageCommandService + '/Files/CreateUploadUrls', {
      FildIds: fileIds,
      CorrelationId: this.utilityService.getNewGuid()
    }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getFileInfo(fileId: string): Observable<any> {
    return this.getFilesInfo([fileId]);
  }

  getFilesInfo(fileIds: string[]): Observable<any> {

    return this.http.post(this.config.StorageQueryService + 'FileQuery/GetFiles',
      {
        FileIds: fileIds,
        CorrelationId: this.utilityService.getNewGuid()
      }).pipe(
      map((response: any) => {
        return response[0];
      })
    );
  }

}


