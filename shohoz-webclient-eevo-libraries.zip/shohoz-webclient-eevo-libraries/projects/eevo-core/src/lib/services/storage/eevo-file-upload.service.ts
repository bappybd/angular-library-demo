import {Inject, Injectable} from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {
  CreateFileModel,
  CreateFilesByKeyModel,
  FileCreatedEventModel,
  FileModel,
  FilesModel
} from "../../models/eevo-file-model";
import {EevoNotifyService} from "../notify/eevo-notify.service";
import {EevoStorageService} from "./eevo-storage.service";

@Injectable({
  providedIn: 'root',
})
export class EevoFileUploadService {

  private $signalrEvent: any;
  private folderName: string;
  private folderId: string;
  private filesModel: FilesModel;
  private extension = 'png';
  private uploadCompleted = new Subject<FileModel>();

  constructor(
    private storageService: EevoStorageService,
    private notifyService: EevoNotifyService,
  ) {
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public
  // -----------------------------------------------------------------------------------------------------

  onCompleted(): Observable<FileModel> {
    return this.uploadCompleted.asObservable();
  }

  uploadImages(
    $signalrEvent: any,
    filesModel: FilesModel
  ): Observable<boolean> {

    this.$signalrEvent = $signalrEvent;
    this.filesModel = filesModel;

    if (typeof $signalrEvent !== 'object') {
      throw '{SignalR Notification Service} required';
    }

    return new Observable(observable => {

      if (filesModel.Files.length > 0) {
        const createFilesModels = this.getCreateFilesModel();

        if (createFilesModels.length > 0) {
          this.listenAndWorkOnFilesEvent();
          this.storageService.createFiles(createFilesModels).subscribe((response) => {
            observable.next(true);
            observable.complete();
          });
        } else {
          observable.next(false);
          observable.complete();
        }

      } else {
        observable.next(true);
        observable.complete();
      }

    });

  }

  uploadPublicImages(
    $signalrEvent: any,
    folderName: string,
    folderId: string,
    filesModel: FilesModel,
    extension = 'png'
  ): Observable<boolean> {

    this.$signalrEvent = $signalrEvent;
    this.folderName = folderName;
    this.folderId = folderId;
    this.filesModel = filesModel;
    this.extension = extension;

    if (typeof $signalrEvent !== 'object') {
      throw '{SignalR Notification Service} required';
    }

    return new Observable(observable => {

      if (filesModel.Files.length > 0) {
        const createFilesModels = this.getCreateFilesByKeyModel();

        if (createFilesModels.length > 0) {
          this.listenAndWorkOnFilesEvent();
          this.storageService.createFilesByKey(createFilesModels).subscribe((response) => {
            observable.next(true);
            observable.complete();
          });
        } else {
          observable.next(false);
          observable.complete();
        }

      } else {
        observable.next(true);
        observable.complete();
      }

    });

  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private
  // -----------------------------------------------------------------------------------------------------

  // for non protected
  private getFileKey(folderName: string, folderId: string, type: string, extension = 'png'): string {
    return `images/${folderName.toLowerCase()}/${folderId}/${type.toLowerCase()}.${extension}`;
  }

  private getCreateFilesByKeyModel(): CreateFilesByKeyModel[] {
    const createItemFilesModel: CreateFilesByKeyModel[] = [];

    this.filesModel.Files.forEach((item) => {
      if (item.FileData) {
        createItemFilesModel.push(
          this.storageService.getCreateFilesByKeyModel(
            this.getFileKey(this.folderName, this.folderId, item.Type, this.extension), item.FileId)
        );
      }
    });

    return createItemFilesModel;
  }

  // for protected
  private getCreateFilesModel(): CreateFileModel[] {
    const createFilesModel: CreateFileModel[] = [];

    this.filesModel.Files.forEach((item) => {
      if (item.FileData) {
        const data  = item.FileData;

        const createFileModel: CreateFileModel = {
          AccessType: 'Protected',
          FileId: item.FileId,
          Name: data.name,
          MetaData: {
            name: data.name,
            size: data.size,
            type: data.type,
          }
        };

        createFilesModel.push(createFileModel);
      }
    });

    return createFilesModel;
  }

  // Common methods
  private uploadedMessage(fileModel: FileModel): string {
    if (fileModel?.Type) {
      const type = fileModel?.Type;
      return `${type.charAt(0).toUpperCase()}${type.slice(1)} Image Uploaded Successfully!`;
    }

    return `Image Uploaded Successfully!`;
  }

  private getPotentialFileObject(fileId: string): FileModel | any {
    const itemFiles = this.filesModel.Files.filter(item => {
      return item.FileId === fileId;
    });

    return itemFiles && itemFiles.length > 0 ? itemFiles[0] : null;
  }

  private parseFileObject(response: any | {}): FileCreatedEventModel {
    const data = JSON.parse(response.value);

    return {
      FileId: data.FileId,
      MetaData: data.MetaData,
      Name: data.Name,
      UploadUri: data.UploadUri,
      AccessType: data.AccessType
    };
  }

  private listenAndWorkOnFilesEvent(): void {
    this.$signalrEvent.listenByKey('FileCreatedEvent', (response) => {
      const data = this.parseFileObject(response);

      const fileObject = this.getPotentialFileObject(data.FileId);
      if (fileObject) {
        this.storageService.uploadFile(fileObject.FileData, data.UploadUri.UploadUriWithSas).subscribe(() => {
          const message = this.uploadedMessage(fileObject);
          this.notifyService.displayMessage(message);

          this.filesModel.Files = this.filesModel.Files.filter( (item) => {
            if (item.FileId === fileObject.FileId) {
              this.uploadCompleted.next(item);
            }
            return item.FileId !== fileObject.FileId;
          });

        });
      } else {
        // console.log('File not found!!!');
        // console.log('File not found', fileObject, data.FileId, this.filesModel);
      }
    });
  }
}
