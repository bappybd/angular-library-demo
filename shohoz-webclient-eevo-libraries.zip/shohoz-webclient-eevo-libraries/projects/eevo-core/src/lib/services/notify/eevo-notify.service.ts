import {Injectable} from '@angular/core';
import {IndividualConfig, ToastrService} from 'ngx-toastr';
// import {MatSnackBar, MatSnackBarConfig} from '@angular/material/snack-bar';
// import {NotificationSnackBarComponent} from '../../components/notification-snack-bar/notification-snack-bar.component';

export enum NotifyType {
  Success,
  Info,
  Warning,
  Error
}

@Injectable({
  providedIn: 'root'
})
export class EevoNotifyService {
  constructor(
    private toasterService: ToastrService,
    // private snackBar: MatSnackBar
  ) {
  }

  displayMessage(
    message: string,
    notifyType: NotifyType = NotifyType.Success,
    title?: string,
    configs?: Partial<IndividualConfig>) {
    this.displayMessageByToast(message, notifyType, title, configs);
  }

  displayMessageByToast(
    message: string,
    notifyType: NotifyType = NotifyType.Success,
    title?: string,
    configs?: Partial<IndividualConfig>): void {
    const duration = 5 * 1000; // 5 sec

    const defaultConfigs: Partial<IndividualConfig> = {
      closeButton: true,
      progressBar: true,
      tapToDismiss: true,
      timeOut: duration,
      extendedTimeOut: 1000, // 1 sec
      progressAnimation: 'increasing',
      positionClass: 'toast-bottom-left'
    };

    const notifyConfig = (configs) ? Object.assign(defaultConfigs, configs) : defaultConfigs;

    switch (notifyType) {
      case NotifyType.Success: {
        this.toasterService.success(title, message, notifyConfig);
        break;
      }
      case NotifyType.Warning: {
        this.toasterService.warning(title, message, notifyConfig);
        break;
      }
      case NotifyType.Error: {
        notifyConfig.timeOut = 5 * 60 * 1000; // 5 min
        this.toasterService.error(title, message, notifyConfig);
        break;
      }
      case NotifyType.Info: {
        this.toasterService.info(title, message, notifyConfig);
        break;
      }
      default: {
        console.error('Define notification type properly!!')
        break;
      }
    }
  }

  // displayMessageBySnackbar(
  //   message: string,
  //   notifyType: NotifyType = NotifyType.Success,
  //   title?: string,
  //   configs?: MatSnackBarConfig) {
  //
  //   let duration = 5 * 1000; // 5 sec
  //   const defaultConfigs: MatSnackBarConfig = {
  //     panelClass: notifyType !== NotifyType.Error ? ['mat-toolbar', 'mat-primary'] :
  //       ['mat-toolbar', 'mat-warn'],
  //     duration: notifyType !== NotifyType.Error ? duration : 5 * 60 * 1000,
  //     horizontalPosition: 'left',
  //     verticalPosition: 'bottom',
  //   };
  //
  //   const notifyConfig = (configs) ? Object.assign(defaultConfigs, configs) : defaultConfigs;
  //
  //   this.snackBar.openFromComponent(NotificationSnackBarComponent, {
  //     data: message,
  //     ...notifyConfig
  //   });
  // }

}
