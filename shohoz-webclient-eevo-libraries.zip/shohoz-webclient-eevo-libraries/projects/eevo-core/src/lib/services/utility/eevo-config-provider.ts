import { Injectable, Inject } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EevoConfigProvider {

  private configData: any;

  constructor(@Inject('config') private config: any) {
    this.configData = config;
  }

  public getValues(): any {
    return this.configData;
  }
}
