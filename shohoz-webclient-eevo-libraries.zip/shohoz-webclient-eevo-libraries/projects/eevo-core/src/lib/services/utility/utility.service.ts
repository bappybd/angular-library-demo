import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor() { }

  getNewGuid(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  static stringInject(str, data): string {
    if (typeof str === 'string' && (data instanceof Array)) {

      return str.replace(/({\d})/g, function (i) {
        return data[i.replace(/{/, '').replace(/}/, '')];
      });

    } else if (typeof str === 'string' && (data instanceof Object)) {

      if (Object.keys(data).length === 0) {
        return str;
      }

      for (let key in data) {
        return str.replace(/({([^}]+)})/g, function(i) {
          let key = i.replace(/{/, '').replace(/}/, '');
          if (!data[key]) {
            return i;
          }

          return data[key];
        });
      }

    } else if (typeof str === 'string' && data instanceof Array === false || typeof str === 'string' && data instanceof Object === false) {

      return str;
    } else {
      return null;
    }
  }

  /**
   * Returns sanitized value of given string.
   *
   * @param {value} value the string to sanitize.
   */
  getSanitizedRegxValue(value: string): string {
    if (value.length == 0) return value;
    return value
      .replace(/[\\]/g, '\\\\\\\\')
      .replace(/[']/g, "\\\'")
      .replace(/[\-\[\]\/{}()*+?.^$|]/g, "\\\\$&");
  }

  /**
   * Returns sanitized value of given string with appending and prepending of '.*'.
   *
   * @param {value} value the string to sanitize and 'like' match regx.
   */
  matchAnyCharacterRegx(value: string): string {
    if (value.length > 0) {
      value = this.getSanitizedRegxValue(value);
    }
    return `.*${value}.*`;
  }
}
