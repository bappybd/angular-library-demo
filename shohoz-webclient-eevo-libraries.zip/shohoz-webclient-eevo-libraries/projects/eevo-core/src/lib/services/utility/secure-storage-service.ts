import {Injectable} from "@angular/core";
import CryptoES from "crypto-es";
import {BehaviorSubject, Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})

export class SecureStorageService {
  private subjects: Map<string, BehaviorSubject<any>>;
  private secret_key = 'delivery.shohoz.com';


  /**
   * Constructor with service injection
   */
  constructor() {
    this.subjects = new Map<string, BehaviorSubject<any>>();
  }

  /**
   * watch data of given key
   * @param key
   */
  watch(key: string): Observable<any> {
    if (!this.subjects.has(key)) {
      this.subjects.set(key, new BehaviorSubject<any>(null));
    }
    let item = localStorage.getItem(key);

    if (item === 'undefined') {
      item = undefined;
    } else {
      item = JSON.parse(item);
    }
    this.subjects.get(key).next(item);
    return this.subjects.get(key).asObservable();
  }

  /**
   * get data of given key
   * @param key
   */
  get(key: string): any {
    let item = localStorage.getItem(key);
    if (item === 'undefined') {
      item = undefined;
    } else {
      item = JSON.parse(item);
    }
    return item;
  }

  /**
   * set value on given key
   * @param key
   * @param value
   */
  set(key: string, value: any) {
    localStorage.setItem(key, JSON.stringify(value));
    if (!this.subjects.has(key)) {
      this.subjects.set(key, new BehaviorSubject<any>(value));
    } else {
      this.subjects.get(key).next(value);
    }
  }

  getSecureData(key: string) {
    let item = localStorage.getItem(key);
    let DECRYPTED_DATA = this.decryptData(item);
    if (DECRYPTED_DATA === 'undefined') {
      DECRYPTED_DATA = null;
    }
    return DECRYPTED_DATA;
  }

  setSecureData(key: string, data: any) {
    const ENCRYPTED_DATA = this.encryptData(data);
    localStorage.setItem(key, ENCRYPTED_DATA);
  }

  encryptData(data: any) {
    try {
      return CryptoES.AES.encrypt(
        JSON.stringify(data),
        this.secret_key
      ).toString();
    } catch (e) {
      console.error(e);
    }
  }

  decryptData(data: any) {
    if (!data) return;
    try {
      const bytes = CryptoES.AES.decrypt(data, this.secret_key);
      let a = JSON.parse(bytes.toString(CryptoES.enc.Utf8));

      if (bytes.toString()) {
        return JSON.parse(bytes.toString(CryptoES.enc.Utf8));
      }
      return data;
    } catch (e) {
      console.log(e);
    }
  }

  /**
   * remove given key
   * @param key
   */
  remove(key: string) {
    if (this.subjects.has(key)) {
      this.subjects.get(key).complete();
      this.subjects.delete(key);
    }
    localStorage.removeItem(key);
  }

  /**
   * clear all available keys
   */
  clear() {
    this.subjects.clear();
    localStorage.clear();
  }
}
