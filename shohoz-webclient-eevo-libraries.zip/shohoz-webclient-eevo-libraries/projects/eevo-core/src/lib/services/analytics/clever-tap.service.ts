import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CleverTapService {
  constructor() {}

  initialize(accountId: string): void {
    window['clevertap'] = {
      event: [],
      profile: [],
      account: [],
      onUserLogin: [],
      notifications: [],
      privacy: [],
    };
    window['clevertap'].account.push({ id: accountId });

    (function () {
      var wzrk = document.createElement('script');
      wzrk.type = 'text/javascript';
      wzrk.async = true;
      wzrk.src =
        ('https:' == document.location.protocol
          ? 'https://d2r1yp2w7bby2u.cloudfront.net'
          : 'http://static.clevertap.com') + '/js/a.js';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(wzrk, s);
    })();
  }

  event(name: string, payload?: any) {
    if (payload) {
      window['clevertap'].event.push(name, payload);
    } else {
      window['clevertap'].event.push(name);
    }
  }

  profile(payload: any) {
    window['clevertap'].profile.push(payload);
  }
}
