import {
  APP_INITIALIZER, Inject,
  ModuleWithProviders,
  NgModule,
  PLATFORM_ID,
} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HttpClientModule, HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import {HttpInterceptorModule} from './services/bootstrap/http-interceptor/http-interceptor.module';
import {TokenManagerService} from './services/bootstrap/token/token-manager.service';
import {TokenStateService} from './services/bootstrap/token/token-state.service';
import {CookieService} from 'ngx-cookie-service';
import {FeatureProvider} from './services/bootstrap/feature/feature.provider';
import {NavigationProvider} from './services/bootstrap/navigation/navigation.provider';
import {FeatureAccessPermission} from './services/bootstrap/route-guard/feature.access.permission';
import {UtilityService} from "./services/utility/utility.service";
import {UserDataService} from './services/bootstrap/user/user-data.service';
import {EevoConfigProvider} from "./services/utility/eevo-config-provider";
import {EevoNotifyService} from "./services/notify/eevo-notify.service";
import {EevoFileUploadService} from "./services/storage/eevo-file-upload.service";
import {EevoStorageService} from "./services/storage/eevo-storage.service";
import {EevoQueryService} from "./services/query/eevo-query.service";
import {InitializerFactory} from "./services/bootstrap/initializer.factory";
import {FeatureNavigationProvider} from "./services/bootstrap/feature-navigation.provider";
import {EevoPipeModule} from "./pipes/eevo-pipe.module";
import {IsAuthenticatedGuard} from './services/bootstrap/route-guard/is-authenticated.guard';
import {IsUnauthenticatedGuard} from './services/bootstrap/route-guard/is-unauthenticated.guard';

export function appInitializerFactory(
  initializerFactory: InitializerFactory
) {

  console.log('App Initializer Start');

  return () => {
    return new Promise(function (resolve, reject) {
      initializerFactory.start().subscribe(data => {
        resolve();
      }, error => {
        resolve();
      });
    });
  };
}

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    HttpInterceptorModule,
  ],
  declarations: [],
  exports: [],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializerFactory,
      deps: [
        InitializerFactory
      ],
      multi: true
    }
  ]
})
export class EevoCoreModule {
  public static forRoot(config: any): ModuleWithProviders<EevoCoreModule> {
    return {
      ngModule: EevoCoreModule,
      providers: [
        EevoPipeModule,
        HttpInterceptorModule,
        UserDataService,
        TokenStateService,
        TokenManagerService,
        NavigationProvider,
        FeatureProvider,
        FeatureAccessPermission,
        IsAuthenticatedGuard,
        IsUnauthenticatedGuard,
        FeatureNavigationProvider,
        {provide: 'config', useValue: config},
        EevoConfigProvider,
        EevoNotifyService,
        EevoFileUploadService,
        EevoStorageService,
        EevoQueryService,
        // AppNavigationService,
        CookieService,
        UtilityService,
      ],

    };
  }
}
