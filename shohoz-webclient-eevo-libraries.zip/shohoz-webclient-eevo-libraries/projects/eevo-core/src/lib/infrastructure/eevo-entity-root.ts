import {Injectable} from "@angular/core";
import {EevoDefaultMessage} from "./eevo-default-message";

export abstract class EevoEntityRoot {

  private readonly Name: string;
  private readonly eevoDefaultMessage: EevoDefaultMessage;

  protected Events: any | {};
  protected ImageType: any | {};

  protected constructor(name: string, defaultMessagePrefix?: string) {
    this.Name = name;

    defaultMessagePrefix = defaultMessagePrefix || this.getDomain();
    this.eevoDefaultMessage = new EevoDefaultMessage(defaultMessagePrefix);
  }

  public getListName(): string {
    return this.Name;
  }

  public getDetailsName(): string {
    return `${this.Name}Details`;
  }

  public getFolderName(folderName?: string): string {
    return this.getDomain(folderName);
  }

  public getFileKey(folderId: string, type: string, extension = 'png', folderName?: string, params?: string): string {
    folderName = this.getFolderName(folderName);

    if (params) {
      return `images/${folderName.toLowerCase()}/${folderId}/${type.toLowerCase()}.${extension}?${params}`;
    }
    return `images/${folderName.toLowerCase()}/${folderId}/${type.toLowerCase()}.${extension}`;
  }

  public getMessages(): EevoDefaultMessage {
    return this.eevoDefaultMessage;
  }

  public abstract getListFields(): string[];

  public abstract getDetailsFields(): string[];

  // Private Methods
  private getDomain(name?: string): string {
    name = (name) ? name :
      this.Name.replace('Lists', '').replace('Models', '');

    return name;
  }
}
