import {Injectable} from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {FileCreatedEventModel} from '../models/eevo-file-model';

export class EevoNotificationBase<T> {
  private subject = new Subject<T>();
  private fileSubject = new Subject<FileCreatedEventModel>();

  constructor() {
  }

  clear(): void {
    this.subject.next();
    this.fileSubject.next();
  }

  deliver(dataModel: T): void {
    this.subject.next(dataModel);
  }

  onReceived(): Observable<T> {
    return this.subject.asObservable();
  }

  deliverFile(fileModel: FileCreatedEventModel): void {
    this.fileSubject.next(fileModel);
  }

  onReceivedFile(): Observable<FileCreatedEventModel> {
    return this.fileSubject.asObservable();
  }
}
