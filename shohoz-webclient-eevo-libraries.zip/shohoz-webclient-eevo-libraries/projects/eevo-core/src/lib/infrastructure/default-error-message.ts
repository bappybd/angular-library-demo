import {Injectable} from "@angular/core";

export class DefaultErrorMessage {
  EC_0000 = '{0} required fields';
  EC_0001 = '{0} should not be empty';
  EC_0002 = '{0} should not be null';
}
