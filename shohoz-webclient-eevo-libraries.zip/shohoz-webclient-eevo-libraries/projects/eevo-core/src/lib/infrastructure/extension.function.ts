declare global {
  interface String {
    toQueryURL(): string;
    toQueryUri(): string;
    toCommandUri(): string;
    toCommandURL(commandName: string): string;
  }
}

String.prototype.toQueryURL = function(): string {
  return String(this).toString() + 'Query/GetByQuery';
};

String.prototype.toQueryUri = function(): string {
  return String(this).toString() + 'Query/';
};

String.prototype.toCommandUri = function(): string {
  return String(this).toString() + 'Command/';
};

String.prototype.toCommandURL = function(commandName): string {
  return String(this).toString() + 'Command/' + commandName;
};

export {};
