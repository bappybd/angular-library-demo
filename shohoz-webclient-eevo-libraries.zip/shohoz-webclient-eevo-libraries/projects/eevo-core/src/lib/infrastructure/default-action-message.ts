import {Injectable} from "@angular/core";
import {DefaultErrorMessage} from "./default-error-message";

export class DefaultActionMessage extends DefaultErrorMessage {

  CREATE_REQUEST: string;
  UPDATE_REQUEST: string;
  DELETE_REQUEST: string;
  FILE_CREATED: string;
  FILE_UPDATED: string;
  CREATED: string;
  UPDATED: string;
  ACTIVATED: string;
  DEACTIVATED: string;
  DELETED: string;
  ERROR: string;

  private NAME: string;

  constructor(name: string) {
    super();
    this.NAME = `${name.charAt(0).toUpperCase()}${name.slice(1)}`;
    this.init();
  }

  private init(): void {
    this.CREATE_REQUEST = `${this.NAME} creation request submitted!`;
    this.UPDATE_REQUEST = `${this.NAME} update request submitted!`;
    this.DELETE_REQUEST = `${this.NAME} delete request submitted!`;
    this.FILE_CREATED = `${this.NAME} file created!`;
    this.FILE_UPDATED = `${this.NAME} file updated!`;
    this.CREATED = `${this.NAME} created successfully!`;
    this.UPDATED = `${this.NAME} updated successfully!`;
    this.ACTIVATED = `${this.NAME} activated successfully!`;
    this.DEACTIVATED = `${this.NAME} deactivated successfully!`;
    this.DELETED = `${this.NAME} deleted successfully!`;
    this.ERROR = `Something went wrong!`;
  }
}
