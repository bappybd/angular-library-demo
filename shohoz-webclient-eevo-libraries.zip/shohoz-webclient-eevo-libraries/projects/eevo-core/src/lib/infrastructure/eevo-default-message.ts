import {DefaultActionMessage} from "./default-action-message";

export class EevoDefaultMessage extends DefaultActionMessage {

  constructor(name: string = null) {
    super(name);
  }

  imageUploaded(type: string): string {
    return `${type.charAt(0).toUpperCase()}${type.slice(1)} Image Uploaded Successfully!`;
  }

  fileUploaded(type: string): string {
    return `${type.charAt(0).toUpperCase()}${type.slice(1)} File Uploaded Successfully!`;
  }
}
