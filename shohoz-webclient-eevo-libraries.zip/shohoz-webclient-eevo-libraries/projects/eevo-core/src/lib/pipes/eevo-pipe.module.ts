import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {NumShortenPipe} from "./num-shorten.pipe";
import {SafeHtmlPipe} from "./safe.html.pipe";

@NgModule({
  imports: [CommonModule],
  exports: [NumShortenPipe, SafeHtmlPipe],
  declarations: [NumShortenPipe, SafeHtmlPipe]
})
export class EevoPipeModule {
}
