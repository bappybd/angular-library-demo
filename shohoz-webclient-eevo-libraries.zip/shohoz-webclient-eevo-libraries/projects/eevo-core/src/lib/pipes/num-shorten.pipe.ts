import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name: 'numShorten'})
export class NumShortenPipe implements PipeTransform {
  transform(
    value: number | string,
    digitAfterDecimal = 0,
    minForK = 1000,
    minForM = 1000000,
    minForB = 1000000000
  ): string | number {
    const num: number = +value;
    if (!num && num !== 0) {
      return 0;
    }
    if (num < minForK) {
      return `${num}`;
    } else if (num >= minForK && num < minForM) {
      return `${((num / 1000)).toFixed(digitAfterDecimal)}K`;
    } else if (num >= minForM && num < minForB) {
      return `${((num / 1000000)).toFixed(digitAfterDecimal)}M`;
    } else {
      return `${((num / 1000000000)).toFixed(digitAfterDecimal)}B`;
    }
  }
}
