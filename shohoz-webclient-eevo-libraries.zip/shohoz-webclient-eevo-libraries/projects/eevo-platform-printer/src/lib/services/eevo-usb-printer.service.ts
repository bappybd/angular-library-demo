export class EevoUsbPrinterService {

  private device;

  constructor() {
  }

  async print(data: any): Promise<any> {
    if (!(this.device)) {
      this.device = await this.getDevice();
    }

    return await this.deviceOpenConfigAndPrint(data);
  }

  async getDevice(): Promise<any> {
    try {
      const devices = await navigator['usb'].getDevices();
      if (devices && devices.length > 0) {
        return devices[0];
      } else {
        const device = await this.requestDevice();
        if (!device) {
          console.log('device not found!!!');
        }
        return device;
      }
    } catch (error) {
      console.log(error);
    }
  }

  requestDevice(): Promise<any> {
    const filters = [
      {vendorId: 0x0FE6, productId: 0x811E},
      {vendorId: 0x0525, productId: 0xA700}
    ];

    return new Promise((resolve, reject) => {

      navigator['usb'].requestDevice({filters: filters}).then(device => {
        console.log('Product name: ' + device.productName);
        resolve(device);
      }).catch(e => {
        console.log('There is no device. ' + e);
        resolve(null);
      });

    });

  }

  private async deviceOpenConfigAndPrint(data: any): Promise<any> {
    if (!(this.device)) {
      console.log('usb print not found');
      return false;
    }

    try {
      await this.device.open();
    } catch (e) {
      console.log('open error', e);
      return false;
    }

    try {
      await this.device.selectConfiguration(1);
    } catch (e) {
      console.log('select conf error', e);
      return false;
    }

    try {
      await this.device.claimInterface(0);
    } catch (e) {
      console.log('claim interface error', e);
      return false;
    }

    try {
      console.log('ready to print');
      this.device.transferOut(1, data);
    } catch (error) {
      console.log('usb print error', error);
      return false;
    }

    return true;
  }

}
