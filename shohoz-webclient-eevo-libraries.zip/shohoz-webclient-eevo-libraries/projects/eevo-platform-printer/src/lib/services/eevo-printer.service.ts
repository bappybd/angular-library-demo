import {EscPosCommand} from './esc-pos-command';
import {Buffer} from 'buffer';
import {MutableBuffer} from 'mutable-buffer';
import * as iconv from 'iconv-lite';
import {EevoPrinterOptions} from '../models/eevo-printer.model';

class Utils {
  /**
   * [getParityBit description]
   * @return {[type]} [description]
   */
  getParityBit(str): string {
    let parity = 0;
    const reversedCode = str.split('').reverse().join('');
    for (let counter = 0; counter < reversedCode.length; counter += 1) {
      parity += parseInt(reversedCode.charAt(counter), 10) * Math.pow(3, ((counter + 1) % 2));
    }
    return String((10 - (parity % 10)) % 10);
  }

  codeLength(str): string {
    const buff = Buffer.from((str.length).toString(16), 'hex');
    return buff.toString();
  }
}

export class EevoPrinterService {
  // adapter;
  options = {
    width: 48,
    encoding: 'GB18030',
  };
  buffer: MutableBuffer;

  private utils;
  private width;
  private encoding;
  private printerMode = null;

  constructor(options?: EevoPrinterOptions) {
    if (options) {
      this.options = options;
    }

    this.utils = new Utils();
    this.buffer = new MutableBuffer();
    this.encoding = this.options && this.options.encoding || 'GB18030';
    this.width = this.options && this.options.width || 48;
  }

  /**
   * Set printer model to recognize model-specific commands.
   * Supported models: [ null, 'qsprinter' ]
   *
   * For generic printers, set model to null
   *
   * [function set printer model]
   * @param  {[String]}  model [mandatory]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  model(model) {
    this.printerMode = model;
    return this;
  }

  /**
   * Set character code table
   * @param  {[Number]} codeTable
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  setCharacterCodeTable(codeTable) {
    this.buffer.write(EscPosCommand.ESC);
    this.buffer.write(EscPosCommand.TAB);
    this.buffer.writeUInt8(codeTable);
    return this;
  }

  /**
   * Fix bottom margin
   * @param  {[String]} size
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  marginBottom(size) {
    this.buffer.write(EscPosCommand.MARGINS.BOTTOM);
    this.buffer.writeUInt8(size);
    return this;
  }

  /**
   * Fix left margin
   * @param  {[String]} size
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  marginLeft(size) {
    this.buffer.write(EscPosCommand.MARGINS.LEFT);
    this.buffer.writeUInt8(size);
    return this;
  }

  /**
   * Fix right margin
   * @param  {[String]} size
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  marginRight(size) {
    this.buffer.write(EscPosCommand.MARGINS.RIGHT);
    this.buffer.writeUInt8(size);
    return this;
  }

  /**
   * [function print]
   * @param  {[String]}  content  [mandatory]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  print(content) {
    this.buffer.write(content);
    return this;
  }

  /**
   * [function print pure content with End Of Line]
   * @param  {[String]}  content  [mandatory]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  println(content) {
    return this.print(content + EscPosCommand.EOL);
  }

  /**
   * [function print pure content with End Of Line]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  newLine() {
    return this.print(EscPosCommand.EOL);
  }

  /**
   * [function Print encoded alpha-numeric text with End Of Line]
   * @param  {[String]}  content  [mandatory]
   * @param  {[String]}  encoding [optional]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  text(content, encoding?) {
    return this.print(iconv.encode(content + EscPosCommand.EOL, encoding || this.encoding));
  }

  /**
   * [function Print draw line End Of Line]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  drawLine() {
    // this.newLine();
    for (let i = 0; i < this.width; i++) {
      this.buffer.write(Buffer.from("-"));
    }
    this.newLine();

    return this;
  }

  /**
   * [function Print  table   with End Of Line]
   * @param  {[List]}  data  [mandatory]
   * @param  {[String]}  encoding [optional]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  table(data, encoding?) {
    let cellWidth = this.width / data.length;
    let lineTxt = "";

    for (let i = 0; i < data.length; i++) {

      lineTxt += data[i].toString();

      let spaces = cellWidth - data[i].toString().length;
      for (let j = 0; j < spaces; j++) {
        lineTxt += " ";
      }

    }
    this.buffer.write(iconv.encode(lineTxt + EscPosCommand.EOL, encoding || this.encoding));

    return this;
  }

  /**
   * [function Print  custom table  with End Of Line]
   * @param  {[List]}  data  [mandatory]
   * @param  {[String]}  encoding [optional]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  tableCustom(data, encoding?) {

    let cellWidth = this.width / data.length;
    let secondLine = [];
    let secondLineEnabled = false;
    let lineStr = "";
    for (let i = 0; i < data.length; i++) {
      let tooLong = false;
      let obj = data[i];
      obj.text = obj.text.toString();

      if (obj.width) {
        cellWidth = this.width * obj.width;
      } else if (obj.cols) {
        cellWidth = obj.cols
      }


      // If text is too wide go to next line
      if (cellWidth < obj.text.length) {
        tooLong = true;
        obj.originalText = obj.text;
        obj.text = obj.text.substring(0, cellWidth - 1);
      }

      if (obj.align == "CENTER") {
        let spaces = (cellWidth - obj.text.toString().length) / 2;
        for (let j = 0; j < spaces; j++) {
          lineStr += " ";
        }
        if (obj.text != '')
          lineStr += obj.text;

        for (let j = 0; j < spaces - 1; j++) {
          lineStr += " ";
        }

      } else if (obj.align == "RIGHT") {
        let spaces = cellWidth - obj.text.toString().length;
        for (let j = 0; j < spaces; j++) {
          lineStr += " ";
        }
        if (obj.text != '')
          lineStr += obj.text;

      } else {
        if (obj.text != '')
          lineStr += obj.text;

        let spaces = cellWidth - obj.text.toString().length;
        for (let j = 0; j < spaces; j++) {
          lineStr += " ";
        }

      }

      if (tooLong) {
        secondLineEnabled = true;
        obj.text = obj.originalText.substring(cellWidth - 1);
        secondLine.push(obj);
      } else {
        obj.text = "";
        secondLine.push(obj);
      }
    }
    this.buffer.write(iconv.encode(lineStr + EscPosCommand.EOL, encoding || this.encoding));

    // Print the second line
    if (secondLineEnabled) {
      return this.tableCustom(secondLine);
    } else {
      return this;
    }
  }

  /**
   * [function Print encoded alpha-numeric text without End Of Line]
   * @param  {[String]}  content  [mandatory]
   * @param  {[String]}  encoding [optional]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  pureText(content, encoding?) {
    return this.print(iconv.encode(content, encoding || this.encoding));
  }

  /**
   * [function encode text]
   * @param  {[String]}  encoding [mandatory]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  encode(encoding) {
    this.encoding = encoding;
    return this;
  }

  /**
   * [line feed]
   * @param  {[type]} n [lines]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  feed(n) {
    this.buffer.write(new Array(n || 1).fill(EscPosCommand.EOL).join(''));
    return this;
  }

  /**
   * [feed control sequences]
   * @param  {[type]}    ctrl     [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  control(ctrl) {
    this.buffer.write(EscPosCommand.FEED_CONTROL_SEQUENCES[
    'CTL_' + ctrl.toUpperCase()
      ]);
    return this;
  }

  /**
   * [text align]
   * @param  {[type]}    align    [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  align(align) {
    this.buffer.write(EscPosCommand.TEXT_FORMAT[
    'TXT_ALIGN_' + align.toUpperCase()
      ]);
    return this;
  }

  /**
   * [font family]
   * @param  {[type]}    family  [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  font(family) {
    this.buffer.write(EscPosCommand.TEXT_FORMAT[
    'TXT_FONT_' + family.toUpperCase()
      ]);
    if (family.toUpperCase() === 'A')
      this.width = this.options && this.options.width || 42;
    else
      this.width = this.options && this.options.width || 56;
    return this;
  }

  /**
   * [font style]
   * @param  {[type]}    type     [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  style(type) {
    switch (type.toUpperCase()) {
      case 'B':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_OFF);
        break;
      case 'I':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_OFF);
        break;
      case 'U':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_ON);
        break;
      case 'U2':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL2_ON);
        break;

      case 'BI':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_OFF);
        break;
      case 'BIU':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_ON);
        break;
      case 'BIU2':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL2_ON);
        break;
      case 'BU':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_ON);
        break;
      case 'BU2':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL2_ON);
        break;
      case 'IU':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_ON);
        break;
      case 'IU2':
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_ON);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL2_ON);
        break;

      case 'NORMAL':
      default:
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_BOLD_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_ITALIC_OFF);
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_UNDERL_OFF);
        break;
    }
    return this;
  }

  /**
   * [font size]
   * @param  {[String]}  width   [description]
   * @param  {[String]}  height  [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  size(width, height) {
    if (2 >= width && 2 >= height) {
      this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_NORMAL);
      if (2 == width && 2 == height) {
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_4SQUARE);
      } else if (1 == width && 2 == height) {
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_2HEIGHT);
      } else if (2 == width && 1 == height) {
        this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_2WIDTH);
      }
    } else {
      this.buffer.write(EscPosCommand.TEXT_FORMAT.TXT_CUSTOM_SIZE(width, height));
    }
    return this;
  }

  /**
   * [set character spacing]
   * @param  {[type]}    n     [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  spacing(n) {
    if (n === undefined || n === null) {
      this.buffer.write(EscPosCommand.CHARACTER_SPACING.CS_DEFAULT);
    } else {
      this.buffer.write(EscPosCommand.CHARACTER_SPACING.CS_SET);
      this.buffer.writeUInt8(n);
    }
    return this;
  }

  /**
   * [set line spacing]
   * @param  {[type]} n [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  lineSpace(n) {
    if (n === undefined || n === null) {
      this.buffer.write(EscPosCommand.LINE_SPACING.LS_DEFAULT);
    } else {
      this.buffer.write(EscPosCommand.LINE_SPACING.LS_SET);
      this.buffer.writeUInt8(n);
    }
    return this;
  }

  /**
   * [hardware]
   * @param  {[type]}    hw       [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  hardware(hw) {
    this.buffer.write(EscPosCommand.HARDWARE['HW_' + hw.toUpperCase()]);
    return this;
  }

  /**
   * [barcode]
   * @param  {[type]}    code     [description]
   * @param  {[type]}    type     [description]
   * @param  {[type]}    options  [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  barcode(code, type, options?) {
    options = options || {};
    let width, height, position, font, includeParity;
    // Backward compatibility
    width = arguments[2];
    if (typeof width === 'string' || typeof width === 'number') {
      width = arguments[2];
      height = arguments[3];
      position = arguments[4];
      font = arguments[5];
    } else {
      width = options.width;
      height = options.height;
      position = options.position;
      font = options.font;
      includeParity = options.includeParity !== false; // true by default
    }

    type = type || 'EAN13'; // default type is EAN13, may a good choice ?
    let convertCode = String(code), parityBit = '', codeLength = '';
    if (typeof type === 'undefined' || type === null) {
      throw new TypeError('barcode type is required');
    }
    if (type === 'EAN13' && convertCode.length !== 12) {
      throw new Error('EAN13 Barcode type requires code length 12');
    }
    if (type === 'EAN8' && convertCode.length !== 7) {
      throw new Error('EAN8 Barcode type requires code length 7');
    }
    if (this.printerMode === 'qsprinter') {
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.BARCODE_MODE.ON);
    }
    if (this.printerMode === 'qsprinter') {
      // qsprinter has no BARCODE_WIDTH command (as of v7.5)
    } else if (width >= 1 && width <= 5) {
      this.buffer.write(EscPosCommand.BARCODE_FORMAT.BARCODE_WIDTH[width]);
    } else {
      this.buffer.write(EscPosCommand.BARCODE_FORMAT.BARCODE_WIDTH_DEFAULT);
    }
    if (height >= 1 && height <= 255) {
      this.buffer.write(EscPosCommand.BARCODE_FORMAT.BARCODE_HEIGHT(height));
    } else {
      if (this.printerMode === 'qsprinter') {
        this.buffer.write(EscPosCommand.MODEL.QSPRINTER.BARCODE_HEIGHT_DEFAULT);
      } else {
        this.buffer.write(EscPosCommand.BARCODE_FORMAT.BARCODE_HEIGHT_DEFAULT);
      }
    }
    if (this.printerMode === 'qsprinter') {
      // Qsprinter has no barcode font
    } else {
      this.buffer.write(EscPosCommand.BARCODE_FORMAT[
      'BARCODE_FONT_' + (font || 'A').toUpperCase()
        ]);
    }
    this.buffer.write(EscPosCommand.BARCODE_FORMAT[
    'BARCODE_TXT_' + (position || 'BLW').toUpperCase()
      ]);
    this.buffer.write(EscPosCommand.BARCODE_FORMAT[
    'BARCODE_' + ((type || 'EAN13').replace('-', '_').toUpperCase())
      ]);
    if (includeParity) {
      if (type === 'EAN13' || type === 'EAN8') {
        parityBit = this.utils.getParityBit(code);
      }
    }
    if (type == 'CODE128' || type == 'CODE93') {
      codeLength = this.utils.codeLength(code);
    }
    this.buffer.write(codeLength + code + (includeParity ? parityBit : '') + '\x00'); // Allow to skip the parity byte
    if (this.printerMode === 'qsprinter') {
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.BARCODE_MODE.OFF);
    }
    return this;
  }

  /**
   * [print qrcode]
   * @param  {[type]} code    [description]
   * @param  {[type]} version [description]
   * @param  {[type]} level   [description]
   * @param  {[type]} size    [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  qrcode(code, version, level, size) {
    if (this.printerMode !== 'qsprinter') {
      this.buffer.write(EscPosCommand.CODE2D_FORMAT.TYPE_QR);
      this.buffer.write(EscPosCommand.CODE2D_FORMAT.CODE2D);
      this.buffer.writeUInt8(version || 3);
      this.buffer.write(EscPosCommand.CODE2D_FORMAT[
      'QR_LEVEL_' + (level || 'L').toUpperCase()
        ]);
      this.buffer.writeUInt8(size || 6);
      this.buffer.writeUInt16LE(code.length);
      this.buffer.write(code);
    } else {
      const dataRaw = iconv.encode(code, 'utf8');
      if (dataRaw.length < 1 && dataRaw.length > 2710) {
        throw new Error('Invalid code length in byte. Must be between 1 and 2710');
      }

      // Set pixel size
      if (!size || (size && typeof size !== 'number'))
        size = EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PIXEL_SIZE.DEFAULT;
      else if (size && size < EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PIXEL_SIZE.MIN)
        size = EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PIXEL_SIZE.MIN;
      else if (size && size > EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PIXEL_SIZE.MAX)
        size = EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PIXEL_SIZE.MAX;
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PIXEL_SIZE.CMD);
      this.buffer.writeUInt8(size);

      // Set version
      if (!version || (version && typeof version !== 'number'))
        version = EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.VERSION.DEFAULT;
      else if (version && version < EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.VERSION.MIN)
        version = EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.VERSION.MIN;
      else if (version && version > EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.VERSION.MAX)
        version = EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.VERSION.MAX;
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.VERSION.CMD);
      this.buffer.writeUInt8(version);

      // Set level
      if (!level || (level && typeof level !== 'string'))
        level = EscPosCommand.CODE2D_FORMAT.QR_LEVEL_L;
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.LEVEL.CMD);
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.LEVEL.OPTIONS[level.toUpperCase()]);

      // Transfer data(code) to buffer
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.SAVEBUF.CMD_P1);
      this.buffer.writeUInt16LE(dataRaw.length + EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.LEN_OFFSET);
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.SAVEBUF.CMD_P2);
      this.buffer.write(dataRaw);

      // Print from buffer
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PRINTBUF.CMD_P1);
      this.buffer.writeUInt16LE(dataRaw.length + EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.LEN_OFFSET);
      this.buffer.write(EscPosCommand.MODEL.QSPRINTER.CODE2D_FORMAT.PRINTBUF.CMD_P2);
    }
    return this;
  }

  // /**
  //  * [print qrcode image]
  //  * @param  {[type]}   content  [description]
  //  * @param  {[type]}   options  [description]
  //  * @param  {[Function]} callback [description]
  //  * @return {[EscPosCommand]} printer  [the escpos printer instance]
  //  */
  // qrimage(content, options, callback) {
  //   let self = this;
  //   if (typeof options == 'function') {
  //     callback = options;
  //     options = null;
  //   }
  //   options = options || { type: 'png', mode: 'dhdw' };
  //   let buffer = qr.imageSync(content, options);
  //   let type = ['image', options.type].join('/');
  //   getPixels(buffer, type, function (err, pixels) {
  //     if (err) return callback && callback(err);
  //     self.raster(new Image(pixels), options.mode);
  //     callback && callback.call(self, null, self);
  //   });
  //   return this;
  // };

  // /**
  //  * [image description]
  //  * @param  {[type]} image   [description]
  //  * @param  {[type]} density [description]
  //  * @return {[EscPosCommand]} printer  [the escpos printer instance]
  //  */
  // image = async function (image, density) {
  //   if (!(image instanceof Image))
  //     throw new TypeError('Only escpos.Image supported');
  //   density = density || 'd24';
  //   let n = !!~['d8', 's8'].indexOf(density) ? 1 : 3;
  //   let header = EscPosCommand.BITMAP_FORMAT['BITMAP_' + density.toUpperCase()];
  //   let bitmap = image.toBitmap(n * 8);
  //   let self = this;
  //
  //   // added a delay so the printer can process the graphical data
  //   // when connected via slower connection ( e.g.: Serial)
  //   this.lineSpace(0); // set line spacing to 0
  //   bitmap.data.forEach(async (line) => {
  //     self.buffer.write(header);
  //     self.buffer.writeUInt16LE(line.length / n);
  //     self.buffer.write(line);
  //     self.buffer.write(EscPosCommand.EOL);
  //     await new Promise((resolve, reject) => {
  //       setTimeout(() => { resolve(true) }, 200);
  //     });
  //   });
  //   return this.lineSpace();
  // };

  // /**
  //  * [raster description]
  //  * @param  {[type]} image [description]
  //  * @param  {[type]} mode  [description]
  //  * @return {[EscPosCommand]} printer  [the escpos printer instance]
  //  */
  // raster(image, mode) {
  //   if (!(image instanceof Image))
  //     throw new TypeError('Only escpos.Image supported');
  //   mode = mode || 'normal';
  //   if (mode === 'dhdw' ||
  //     mode === 'dwh' ||
  //     mode === 'dhw') mode = 'dwdh';
  //   let raster = image.toRaster();
  //   let header = EscPosCommand.GSV0_FORMAT['GSV0_' + mode.toUpperCase()];
  //   this.buffer.write(header);
  //   this.buffer.writeUInt16LE(raster.width);
  //   this.buffer.writeUInt16LE(raster.height);
  //   this.buffer.write(raster.data);
  //   return this;
  // };

  /**
   * [function Send pulse to kick the cash drawer]
   * @param  {[type]} pin [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  cashdraw(pin) {
    this.buffer.write(EscPosCommand.CASH_DRAWER[
    'CD_KICK_' + (pin || 2)
      ]);
    return this;
  }

  /**
   * Printer Buzzer (Beep sound)
   * @param  {[Number]} n Refers to the number of buzzer times
   * @param  {[Number]} t Refers to the buzzer sound length in (t * 100) milliseconds.
   */
  beep(n, t) {
    this.buffer.write(EscPosCommand.BEEP);
    this.buffer.writeUInt8(n);
    this.buffer.writeUInt8(t);
    return this;
  }

  // /**
  //  * Send data to hardware and flush buffer
  //  * @param  {Function} callback
  //  * @return {[EscPosCommand]} printer  [the escpos printer instance]
  //  */
  // flush(callback) {
  //   let buf = this.buffer.flush();
  //   this.adapter.write(buf, callback);
  //   return this;
  // };

  /**
   * [function Cut paper]
   * @param  {[type]} part [description]
   * @param  {[type]} feed [description]
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  cut(part?, feed?) {
    this.feed(feed || 3);
    this.buffer.write(EscPosCommand.PAPER[
      part ? 'PAPER_PART_CUT' : 'PAPER_FULL_CUT'
      ]);
    return this;
  }

  // /**
  //  * [close description]
  //  * @param  {Function} callback [description]
  //  * @param  {[type]}   options  [description]
  //  * @return {[type]}            [description]
  //  */
  // close(callback, options) {
  //   let self = this;
  //   return this.flush(function () {
  //     self.adapter.close(callback, options);
  //   });
  // };

  /**
   * [color select between two print color modes, if your printer supports it]
   * @param  {Number} color - 0 for primary color (black) 1 for secondary color (red)
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  color(color) {
    this.buffer.write(EscPosCommand.COLOR[
      color === 0 || color === 1 ? color : 0
      ]);
    return this;
  }

  /**
   * [reverse colors, if your printer supports it]
   * @param {Boolean} bool - True for reverse, false otherwise
   * @return {[EscPosCommand]} printer  [the escpos printer instance]
   */
  setReverseColors(bool) {
    this.buffer.write(bool ? EscPosCommand.COLOR.REVERSE : EscPosCommand.COLOR.UNREVERSE);
    return this;
  }


  /**
   * [writes a low level command to the printer buffer]
   *
   * @usage
   * 1) raw('1d:77:06:1d:6b:02:32:32:30:30:30:30:32:30:30:30:35:30:35:00:0a')
   * 2) raw('1d 77 06 1d 6b 02 32 32 30 30 30 30 32 30 30 30 35 30 35 00 0a')
   * 3) raw(Buffer.from('1d77061d6b0232323030303032303030353035000a','hex'))
   *
   * @param data {Buffer|string}
   * @returns {}
   */
  rawraw(data) {
    if (Buffer.isBuffer(data)) {
      this.buffer.write(data);
    } else if (typeof data === 'string') {
      data = data.toLowerCase();
      this.buffer.write(Buffer.from(data.replace(/(\s|:)/g, ''), 'hex'));
    }
    return this;
  }
}
