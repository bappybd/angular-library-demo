export interface EevoPrinterOptions {
  width: number;
  encoding: string;
}
