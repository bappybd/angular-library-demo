import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { EevoPlatformTableComponent } from "./components/eevo-platform-table/eevo-platform-table.component";
import { MatTableModule } from "@angular/material/table";
import { MatSortModule } from "@angular/material/sort";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatIconModule } from "@angular/material/icon";
import { EevoHighlightDirective } from "./directives/eevo-highlight.directive";
import { EevoTableFilterDirective } from "./directives/eevo-table-filter.directive";

@NgModule({
    declarations: [EevoPlatformTableComponent, EevoHighlightDirective, EevoTableFilterDirective],
    imports: [
        CommonModule,
        MatTableModule,
        MatSortModule,
        MatPaginatorModule,
        MatProgressSpinnerModule,
        MatFormFieldModule,
        MatInputModule,
        MatIconModule,
    ],
    exports: [EevoPlatformTableComponent, EevoTableFilterDirective],
})
export class EevoPlatformDataTableModule {}
