import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformTableComponent } from './eevo-platform-table.component';

describe('EevoPlatformTableComponent', () => {
  let component: EevoPlatformTableComponent;
  let fixture: ComponentFixture<EevoPlatformTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
