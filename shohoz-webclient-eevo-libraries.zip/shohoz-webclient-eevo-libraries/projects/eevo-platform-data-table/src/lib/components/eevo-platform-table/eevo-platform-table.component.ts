import {AfterViewInit, Component, Input, OnInit, Output, TemplateRef, ViewChild} from '@angular/core';
import {EevoDataTableConfig, TableData} from '../../contracts/eevo-data-table-config';
import {MatPaginator, PageEvent} from '@angular/material/paginator';
import {MatSort, Sort} from '@angular/material/sort';
import {DATA_TYPES} from '../../enums/eevo-table-data-types';
import {merge, Subject, timer} from 'rxjs';
import {debounce, startWith, switchMap} from 'rxjs/operators';
import {RELOAD_EVENT_TYPES} from '../../enums/eevo-table-reload-event-types';
import {EevoTableReloadEvent} from '../../models/eevo-table-reload-event';
import {EevoDataTableModel} from '../../models/eevo-data-table-model';

@Component({
    selector: 'eevo-platform-table',
    templateUrl: './eevo-platform-table.component.html',
    styleUrls: ['./eevo-platform-table.component.scss']
})
export class EevoPlatformTableComponent<T> implements OnInit, AfterViewInit {
    @Input() dataTableModel: EevoDataTableModel<T>;

    @Output() reloadEvent = new Subject<EevoTableReloadEvent>();

    @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
    @ViewChild(MatSort, {static: false}) sort: MatSort;
    @ViewChild('cellDataTypeDefault', {static: true}) cellDefault: TemplateRef<any>;
    @ViewChild('cellDataTypeDateTime', {static: true}) cellDateTime: TemplateRef<any>;

    config: EevoDataTableConfig<T>;
    displayedColumns: string[] = [];
    defaultPageSizeOptions = [5, 10, 20, 30, 50];
    defaultPageSize = 10;
    tableData: TableData<T> = {
        TotalCount: 0,
        List: [],
        Loading: true
    };
    reloadEventSource = new Subject<EevoTableReloadEvent>();

    constructor() {
    }

    private prepareCellTemplates() {
        for (const column of this.config.Columns) {
            if (!column.CellTemplate) {
                if (column.Type) {
                    column.CellTemplate = this['cell' + DATA_TYPES[column.Type]];
                } else {
                    column.CellTemplate = this.cellDefault;
                }
            }
        }

    }

    ngAfterViewInit(): void {
        if (this.config && this.config.Columns && this.config.Columns.length) {
            for (const column of this.config.Columns) {
                if (!column.Hidden) {
                    this.displayedColumns.push(column.Title);
                }
            }
        }
        this.prepareCellTemplates();
        this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

        merge(this.sort.sortChange, this.paginator.page, this.reloadEventSource)
            .subscribe(event => {
                let reloadEvent = {...this.config.LastReloadEvent};
                if (event instanceof EevoTableReloadEvent) {
                    reloadEvent = {...reloadEvent, ...event};
                } else if ((event as PageEvent).pageSize) {
                    reloadEvent.EventType = RELOAD_EVENT_TYPES.PAGE;
                    reloadEvent.Page = event as PageEvent;
                } else if ((event as Sort).active) {
                    reloadEvent.EventType = RELOAD_EVENT_TYPES.SORT;
                    reloadEvent.Sort = event as Sort;
                }
                this.config.LastReloadEvent = reloadEvent;
                this.reloadEvent.next(reloadEvent);
            });
        this.config.DataSource.subscribe(data => {
            setTimeout(() => {
                this.tableData = data;
            });
        });
        this.reloadEventSource.next(new EevoTableReloadEvent(RELOAD_EVENT_TYPES.MANUAL));

    }

    ngOnInit(): void {
        this.config = this.dataTableModel.config;
        this.dataTableModel.OnFilterEvent = this.onFilterEvent;
    }

    onFilterEvent = (event: EevoTableReloadEvent) => {
        this.reloadEventSource.next(event);
    }

    identify(index, item): string {
        return item.Title;
    }
}
