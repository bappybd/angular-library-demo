export enum DATA_TYPES {
  Number,
  Number2Decimal,
  Number3Decimal,
  String,
  DateTime,
  StringArray
}
