import {Directive, ElementRef, HostListener, Input} from '@angular/core';

@Directive({
  selector: '[libHighlight]'
})
export class EevoHighlightDirective {

  constructor(private el: ElementRef) {
  }

  @Input('libHighlight') highlightColor: string;

  @HostListener('mouseenter') onMouseEnter() {
    if (!this.highlightColor) { return; }
    this.highlight(this.highlightColor || 'lightgrey');
  }

  @HostListener('mouseleave') onMouseLeave() {
    if (!this.highlightColor) { return; }
    this.highlight(null);
  }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }
}
