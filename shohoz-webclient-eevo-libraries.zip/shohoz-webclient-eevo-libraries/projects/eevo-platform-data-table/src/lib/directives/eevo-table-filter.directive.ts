import {AfterViewInit, Directive, ElementRef, HostListener, Input, Output} from '@angular/core';
import {Subject, timer} from 'rxjs';
import {FormGroup} from '@angular/forms';
import {debounce} from 'rxjs/operators';
import {EevoTableReloadEvent} from '../models/eevo-table-reload-event';
import {RELOAD_EVENT_TYPES} from '../enums/eevo-table-reload-event-types';
import {EevoDataTableModel} from '../models/eevo-data-table-model';

@Directive({
  selector: '[libTableFilter]'
})
export class EevoTableFilterDirective implements AfterViewInit {
  @Input('libTableFilter') filterForm: FormGroup;
  @Input('onFilterEvent') onFilterEvent: (event: EevoTableReloadEvent) => void;

  constructor() {
  }


  ngAfterViewInit(): void {
    if (!this.filterForm) {
      console.error('FormGroup is not initialized correctly');
      return;
    }
    this.filterForm.valueChanges
      .pipe(
        debounce(() => timer(300))
      )
      .subscribe(value => {
        const filterReloadEvent = new EevoTableReloadEvent(RELOAD_EVENT_TYPES.FILTER);
        filterReloadEvent.Filter = value;
        // console.log(filterReloadEvent);
        this.onFilterEvent(filterReloadEvent);
      });
  }

}
