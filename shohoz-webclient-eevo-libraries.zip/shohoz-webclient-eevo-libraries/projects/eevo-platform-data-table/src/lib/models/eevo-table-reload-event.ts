import {Sort} from '@angular/material/sort';
import {PageEvent} from '@angular/material/paginator';
import {RELOAD_EVENT_TYPES} from '../enums/eevo-table-reload-event-types';

export class EevoTableReloadEvent {
  constructor(eventType) {
    this.EventType = eventType;
  }

  EventType: RELOAD_EVENT_TYPES;
  Sort?: Sort;
  Page?: PageEvent;
  Filter?: {
    SearchText?: string;
    [PropertyName: string]: any;
  };
}
