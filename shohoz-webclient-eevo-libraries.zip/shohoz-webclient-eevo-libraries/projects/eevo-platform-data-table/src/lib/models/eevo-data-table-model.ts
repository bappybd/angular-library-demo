import {EevoDataTableConfig} from '../contracts/eevo-data-table-config';

export class EevoDataTableModel <T>{
  config: EevoDataTableConfig<T>;
  constructor(config) {
    this.config = config;
  }
  OnFilterEvent(event){
    console.log(event);
  }
}
