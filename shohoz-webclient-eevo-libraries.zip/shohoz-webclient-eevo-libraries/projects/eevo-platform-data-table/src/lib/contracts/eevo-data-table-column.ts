import {TemplateRef} from '@angular/core';
import {DATA_TYPES} from '../enums/eevo-table-data-types';

export interface EevoDataTableColumn {
  Title: string;
  Key?: string;
  Type?: DATA_TYPES;
  CellTemplate?: TemplateRef<any>;
  HeaderTemplate?: TemplateRef<any>;
  IsSortable?: boolean;
  Hidden?: boolean;
}
