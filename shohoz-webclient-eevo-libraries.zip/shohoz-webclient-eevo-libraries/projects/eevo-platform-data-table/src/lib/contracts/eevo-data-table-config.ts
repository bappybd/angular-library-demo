import {EevoDataTableColumn} from './eevo-data-table-column';
import {EevoDataTableStyle} from './eevo-data-table-style';
import {TemplateRef} from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {EevoTableReloadEvent} from '../models/eevo-table-reload-event';

export interface EevoDataTableConfig<T> {
    Columns: EevoDataTableColumn[];
    Page?: {
        PageSizeOptions?: number[],
        PageSize?: number
    };
    RowHighlightColor?: string;
    Styles?: EevoDataTableStyle;
    Filter?: string;
    Error?: string | TemplateRef<any>;
    DataSource: Observable<TableData<T>>;
    LastReloadEvent?: EevoTableReloadEvent;
    OnFilterEvent?: (event: EevoTableReloadEvent) => void;
    OnRowClick?: Function;
}

export interface TableData<T> {
    TotalCount?: number;
    List: T[];
    Error?: Error;
    Loading?: boolean;
}


