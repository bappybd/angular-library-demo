export interface EevoDataTableStyle {
  Properties?: {
    [name: string]: string
  };
  Selectors?: string;
}
