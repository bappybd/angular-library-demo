import {Injectable, Inject} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {map, switchMap, tap} from 'rxjs/operators';
import {TokenManagerService, UserDataService} from '@eevo/eevo-core';

@Injectable({
  providedIn: 'root',
})
export class EevoPlatformLoginService {
  constructor(
    private http: HttpClient,
    private userDataService: UserDataService,
    private tokenManagerService: TokenManagerService,
    @Inject('config') private config: any
  ) {
  }

  userAuthenticate(username: string, password: string): Observable<any> {
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    let url = 'token'

    let body = new HttpParams()
      .set('grant_type', 'password')
      .set('client_id', this.config.ClientId)
      .set('scope', this.config.ClientScope)
      .set('username', username)
      .set('password', password);

    return this.http.post(
      this.config.IAMService + url,
      body.toString(),
      { headers: header, withCredentials: true }
    ).pipe(
      map((response: any) => {
        this.setUserAndTokenDataAfterLogin(response);
        return response;
      })
    );
  }

  user2FAAuthenticate(otpToken: string, otpCode: string): Observable<any> {
    const header = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded'
    });

    const body = new HttpParams()
      .set('grant_type', '2fa')
      .set('client_id', this.config.ClientId)
      .set('scope', this.config.ClientScope)
      .set('otp_token', otpToken)
      .set('otp_code', otpCode);

    return this.http.post(
      this.config.IAMService + 'token',
      body.toString(),
      { headers: header, withCredentials: true }
    ).pipe(
      map((response: any) => {
        this.setUserAndTokenDataAfterLogin(response);
        return response;
      })
    );
  }

  send2FA(username: string, password: string): Observable<any> {
    const body = {
      "Username": username,
      "Password": password,
      "ClientId": this.config.ClientId
    };

    return this.http.post(this.config.IAMService + 'otp/send2fa', body);
  }

  resend2FA(otpToken: string): Observable<any> {
    const body = {
      "VerifyToken": otpToken,
      "ClientId": this.config.ClientId
    };

    return this.http.post(this.config.IAMService + 'otp/resend', body);
  }

  private setUserAndTokenDataAfterLogin(response: any): void {
    this.tokenManagerService.removeRefreshToken();
    this.tokenManagerService.setRefreshToken(response.refresh_token);
    this.userDataService.setUser(response.access_token);
  }
}
