import {AuthRedirectionModel} from "@eevo/eevo-core";

export interface LoginConfiguration {
  loginBodyHeader: string,
  loginBodySubHeader: string,
  loginBodyContent: string,
  loginBodyLogo: any,
  loginFormHeaderText: string,
  loginFormSubHeaderText: string,
  loginFormLogo: any,
}

export interface EevoLoginOption {
  defaultRedirectUrl: string,
  authRedirection: AuthRedirectionModel[],
  allow2FALogin: boolean;
  allowSocialLogin: boolean,
  allowCreateAccount: boolean,
  allowRememberMe: boolean,
  allowForgotPassword: boolean,
  allowLanguageOption: boolean,
}
