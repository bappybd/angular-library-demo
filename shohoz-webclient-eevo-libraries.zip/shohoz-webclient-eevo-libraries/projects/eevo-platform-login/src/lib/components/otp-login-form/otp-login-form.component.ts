import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {EevoLoginOption} from '../../contracts/login-configuration';
import {EevoNotifyService, FeatureProvider, NotifyType} from '@eevo/eevo-core';
import {EevoPlatformLoginService} from '../../services/eevo-platform-login.service';

@Component({
  selector: 'otp-login-form',
  templateUrl: './otp-login-form.component.html',
  styleUrls: ['./otp-login-form.component.scss']
})
export class OtpLoginFormComponent implements OnInit {

  btnBlock: boolean = false;
  showResendBtn: boolean;
  loginForm: FormGroup;
  @Input() loginOption: EevoLoginOption;
  @Input() otpToken: string;
  @Output() tryDifferentAccount: EventEmitter<boolean> = new EventEmitter();
  @Output() onLoginSuccess: EventEmitter<any> = new EventEmitter();

  constructor(
    private formBuilder: FormBuilder,
    private featureProvider: FeatureProvider,
    private eevoNotifyService: EevoNotifyService,
    private eevoPlatformLoginService: EevoPlatformLoginService
  ) {
  }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      otp: ['', [Validators.required]],
    });

    setTimeout(() => {
      this.showResendBtn = true;
    }, 3000);
  }

  tryAnotherAccount() {
    this.tryDifferentAccount.emit(true);
  }

  otpResend(): void {
    this.btnBlock = true;
    this.eevoPlatformLoginService.resend2FA(
      this.otpToken,
    ).subscribe((res) => {
        this.btnBlock = false;
        if (res.otp_token) {
          this.otpToken = res.otp_token;
        } else {
          this.eevoNotifyService.displayMessage(
            'Something went wrong!',
            NotifyType.Error
          );
        }

      }, (error) => {
        this.btnBlock = false;
        const message = error?.error?.error_description;
        this.eevoNotifyService.displayMessage(
          (message != null || '') ? message : 'Something went wrong!',
          NotifyType.Error
        );
      }
    );
  }

  login(): void {
    this.btnBlock = true;
    this.eevoPlatformLoginService.user2FAAuthenticate(
      this.otpToken,
      this.loginForm.value.otp
    ).subscribe((res) => {

        this.btnBlock = false;

        this.onLoginSuccess.emit(res);

        this.eevoNotifyService.displayMessage('Login Successful');
      }, (error) => {
        this.btnBlock = false;
        this.onLoginSuccess.emit(null);

        const err = error?.error?.error;
        let message = error?.error?.error_description;

        if (err === 'invalid_request' && message === '2fa' || message?.toLowerCase() === 'invalid otp') {
          message = 'You have entered an invalid OTP, Please try again.';
        }

        this.eevoNotifyService.displayMessage(
          (message != null || '') ? message : 'Something went wrong!',
          NotifyType.Error
        );

      }
    );
  }

}
