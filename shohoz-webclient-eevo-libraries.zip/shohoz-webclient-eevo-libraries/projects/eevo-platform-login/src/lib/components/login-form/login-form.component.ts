import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {EevoNotifyService, FeatureProvider, NotifyType} from "@eevo/eevo-core";
import {EevoPlatformLoginService} from "../../services/eevo-platform-login.service";
import {EevoLoginOption} from "../../contracts/login-configuration";

@Component({
  selector: 'login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss']
})
export class LoginFormComponent implements OnInit {
  btnBlock: boolean = false;
  loginForm: FormGroup;
  @Input() loginOption: EevoLoginOption;

  @Input() username: string;
  @Input() password: string;
  @Output() onOtpToken: EventEmitter<string> = new EventEmitter();
  @Output() onLoginSuccess: EventEmitter<any> = new EventEmitter();

  constructor(
    private formBuilder: FormBuilder,
    private featureProvider: FeatureProvider,
    private eevoNotifyService: EevoNotifyService,
    private eevoPlatformLoginService: EevoPlatformLoginService
  ) {
  }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: [this.username || '', [Validators.required]],
      password: [this.password || '', Validators.required],
    });
  }

  public login(): void {
    if (this.loginOption.allow2FALogin) {
      this.login2FA();
    } else {
      this.basicLogin();
    }
  }

  private basicLogin(): void {
    this.btnBlock = true;
    this.eevoPlatformLoginService.userAuthenticate(
      this.loginForm.value.username,
      this.loginForm.value.password
    ).subscribe((res) => {
        this.btnBlock = false;

        this.onLoginSuccess.emit(res);

        this.eevoNotifyService.displayMessage('Login Successful');
      }, (error) => {
        this.btnBlock = false;
        this.onLoginSuccess.emit(null);
        const message = error?.error?.error_description;
        this.eevoNotifyService.displayMessage(
          (message != null || '') ? message : 'Something went wrong!',
          NotifyType.Error
        );
      }
    );
  }

  private login2FA(): void {
    this.btnBlock = true;
    this.eevoPlatformLoginService.send2FA(
      this.loginForm.value.username,
      this.loginForm.value.password
    ).subscribe((res) => {
        this.btnBlock = false;
        if (res.otp_token) {
          this.onOtpToken.emit(res.otp_token);
        } else {
          this.eevoNotifyService.displayMessage(
            'Something went wrong!',
            NotifyType.Error
          );
        }

      }, (error) => {
        this.btnBlock = false;
        const message = error?.error?.error_description;
        this.eevoNotifyService.displayMessage(
          (message != null || '') ? message : 'Something went wrong!',
          NotifyType.Error
        );
      }
    );
  }


}
