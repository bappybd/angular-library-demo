import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EevoPlatformLoginMainComponent } from './eevo-platform-login-main.component';

describe('EevoPlatformLoginMainComponent', () => {
  let component: EevoPlatformLoginMainComponent;
  let fixture: ComponentFixture<EevoPlatformLoginMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EevoPlatformLoginMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EevoPlatformLoginMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
