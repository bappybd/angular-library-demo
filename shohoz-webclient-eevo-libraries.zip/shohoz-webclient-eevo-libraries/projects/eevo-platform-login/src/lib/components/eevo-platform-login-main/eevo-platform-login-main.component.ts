import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core';
import {fuseAnimations, FuseConfigService} from '@eevo/eevo-base';
import {EevoLoginOption, LoginConfiguration} from '../../contracts/login-configuration';
import {FeatureNavigationProvider, UserDataService} from "@eevo/eevo-core";
import {Subscription} from "rxjs";
import {Router} from "@angular/router";

@Component({
  selector: 'eevo-platform-login-main',
  templateUrl: './eevo-platform-login-main.component.html',
  styleUrls: ['./eevo-platform-login-main.component.scss'],
  animations: fuseAnimations,
})
export class EevoPlatformLoginMainComponent implements OnInit, OnDestroy {
  @Input() loginBizContent: LoginConfiguration;
  @Input() loginOption: EevoLoginOption;
  @Output() onLoginSuccess: EventEmitter<any> = new EventEmitter();

  @Input() username: string;
  @Input() password: string;
  @Input() otp: string;

  loginData: any;
  otpToken: string = null;
  subscriptions: Subscription[] = [];

  constructor(
    private route: Router,
    private fuseConfigService: FuseConfigService,
    private userDataService: UserDataService,
    private featureNavigationProvider: FeatureNavigationProvider
  ) {
    // Configure the layout
    this.fuseConfigService.config = {
      layout: {
        breadcrumb: {
          hidden: true,
        },
        navbar: {
          hidden: true,
        },
        toolbar: {
          hidden: true,
        },
        footer: {
          hidden: true,
        },
        sidepanel: {
          hidden: true,
        },
      },
    };
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    const subscription = this.featureNavigationProvider.onLoaded().subscribe(data => {
      this.redirect();
    });

    this.subscriptions.push(subscription);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }
  // -----------------------------------------------------------------------------------------------------
  // @ Public Method
  // -----------------------------------------------------------------------------------------------------

  setOtpToken(otpToken: string) {
    this.otpToken = otpToken;
  }

  tryDifferentAccount($event: boolean) {
    if ($event) {
      this.otpToken = null;
    }
  }

  loginSuccess($event: any): void {
    this.loginData = $event;
    this.onLoginSuccess.emit($event);
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Private Method
  // -----------------------------------------------------------------------------------------------------

  private redirect(): void {
    const userData = this.userDataService.getUserData();
    const roles = userData?.Role || [];

    const redirect = this.loginOption?.authRedirection.find(ar => {
      return roles.includes(ar.Role);
    });

    if (redirect) {
      this.route.navigate([redirect.Authenticated]);
    } else {
      this.route.navigate([this.loginOption.defaultRedirectUrl]);
    }

  }
}
