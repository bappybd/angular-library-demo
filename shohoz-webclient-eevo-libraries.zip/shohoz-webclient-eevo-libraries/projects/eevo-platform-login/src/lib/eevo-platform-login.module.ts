import { ModuleWithProviders, NgModule } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { FuseSharedModule } from '@eevo/eevo-base';
import { MatButtonModule } from '@angular/material/button';
import { EevoPlatformLoginMainComponent } from './components/eevo-platform-login-main/eevo-platform-login-main.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { EevoPlatformLoginService } from './services/eevo-platform-login.service';
import { TokenManagerService } from '@eevo/eevo-core';
import { LoginFormComponent } from './components/login-form/login-form.component';
import { OtpLoginFormComponent } from './components/otp-login-form/otp-login-form.component';

@NgModule({
  declarations: [
    EevoPlatformLoginMainComponent,
    LoginFormComponent,
    OtpLoginFormComponent
  ],
  imports: [
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatSnackBarModule,
    FuseSharedModule,
  ],
  providers: [
    EevoPlatformLoginService,
    TokenManagerService
  ],
  exports: [
    EevoPlatformLoginMainComponent
  ],
})
export class EevoPlatformLoginModule {
  public static forRoot(
    config: any
  ): ModuleWithProviders<EevoPlatformLoginModule> {
    return {
      ngModule: EevoPlatformLoginModule,
      providers: [{ provide: 'config', useValue: config }],
    };
  }
}
