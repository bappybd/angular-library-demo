/*
 * Public API Surface of eevo-platform-login
 */


export * from './lib/components/eevo-platform-login-main/eevo-platform-login-main.component';
export * from './lib/contracts/login-configuration';
export * from './lib/eevo-platform-login.module';
